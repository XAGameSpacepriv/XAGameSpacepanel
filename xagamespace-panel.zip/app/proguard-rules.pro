# Preserve Shizuku API classes, UserService, and reflective newProcess method
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class com.example.core.ShizukuInputUserService { *; }
-keep class com.example.core.RootTouchDaemon { *; }
-keep class com.example.core.KernelTouchEngine { *; }
-keep class com.example.core.TouchDeviceSpec { *; }
-keep class com.example.core.TouchAmplifierConfig { *; }
-keep class com.example.core.TouchAmplifierMath { *; }
-keep class com.example.core.TouchBoostController { *; }
-keep class com.example.core.PhysicalPointerPoint { *; }
-keep class com.example.core.ActivePhysicalTouchSnapshot { *; }
-dontwarn rikka.shizuku.**

# Preserve Services and ViewModels
-keep class com.example.service.** { *; }
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    public <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    public <init>(android.app.Application);
}
