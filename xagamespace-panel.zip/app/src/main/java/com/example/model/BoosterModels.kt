package com.example.model

enum class MainTab {
    HOME, OPTIMIZER, PROFILE
}

enum class SubScreen {
    NONE, ADD_GAME, BURIK, COMPILE, DEBLOAT, COMPATIBILITY
}

enum class PanelTab(val labelId: String) {
    MONITOR("Monitor"),
    BOOST("Boost"),
    THERMAL("Thermal"),
    TOUCH("Touch"),
    CROSSHAIR("Crosshair"),
    MACRO("Macro"),
    AI_TRIGGER("AI Trigger"),
    BURIK("Burik"),
    RADIAL("Radial")
}

enum class PrivilegeMode(val label: String) {
    ROOT("Root (UID 0)"),
    SHIZUKU("Shizuku (Non-Root)")
}

enum class RootGrantState {
    NOT_FOUND,
    AVAILABLE_NOT_GRANTED,
    GRANTED,
    DENIED
}

enum class PerformanceProfile(
    val label: String,
    val shortLabel: String,
    val subtitle: String
) {
    BATTERY("Hemat Daya", "Hemat", "Prioritas suhu dingin & hemat baterai"),
    BALANCED("Seimbang", "Normal", "Performa seimbang bawaan sistem"),
    PRO_GAMER("Pro Gamer", "Pro", "Prioritas CPU/GPU & mode performa game"),
    ESPORT_TURBO("Esport Turbo", "Turbo", "Fixed performance penuh & respons ultra cepat")
}

data class BypassChargingStatus(
    val supported: Boolean = false,
    val enabled: Boolean = false,
    val activeNodePath: String = "",
    val detail: String = "Belum dicek"
)

data class StopwatchConfig(
    val enabled: Boolean = false,
    val normX: Float = 0.14f,
    val normY: Float = 0.16f,
    val running: Boolean = false,
    val elapsedMs: Long = 0L
)

data class GyroAimConfig(
    val enabled: Boolean = false,
    val sensitivityX: Int = 55,
    val sensitivityY: Int = 55,
    val deadzoneDeg: Float = 1.5f,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val anchorNormX: Float = 0.76f,
    val anchorNormY: Float = 0.50f
)

enum class ThermalProfile(
    val label: String,
    val shortLabel: String,
    val subtitle: String
) {
    STOCK("Bawaan", "Stock", "Kebijakan thermal standar pabrikan"),
    COOL("Dingin", "Cool", "Menahan panas agar HP tetap adem"),
    DYNAMIC("Dinamis", "Dyn", "Thermal adaptif stabil untuk main lama"),
    EVALUATION("Evaluasi", "Eval", "Buka limit performa dengan Thermal Guard"),
    DISABLE_THROTTLE("Bypass Thermal", "Bypass", "Lepas throttle thermal (Root UID 0 penuh)")
}

data class ThermalConfig(
    val profile: ThermalProfile = ThermalProfile.STOCK,
    val guardEnabled: Boolean = true,
    val guardThresholdC: Int = 46,
    val stopThermalDaemonsOnRoot: Boolean = false,
    val thermalMaxLimitEnabled: Boolean = false,
    val thermalMaxTargetC: Int = 39
)

data class ThermalZoneReading(
    val name: String,
    val type: String,
    val tempC: Float
)

data class ThermalStatus(
    val systemThermalState: String = "Normal",
    val supportedNodes: List<String> = emptyList(),
    val activeNodeSummary: String = "Belum dicek",
    val isRootVerified: Boolean = false,
    val zones: List<ThermalZoneReading> = emptyList(),
    val guardTriggered: Boolean = false,
    val maxLimitActive: Boolean = false,
    val maxLimitDetail: String = ""
)

enum class TouchPollingPreset(
    val level: Int,
    val label: String,
    val shortLabel: String
) {
    DEFAULT(0, "Standar", "Std"),
    HIGH_240(1, "240 Hz", "240Hz"),
    ULTRA_480(2, "480 Hz", "480Hz"),
    MAX_HARDWARE(3, "Max HW", "Max")
}

data class TouchDriverStatus(
    val detectedNodes: List<String> = emptyList(),
    val activeSummary: String = "Belum dicek"
)

/**
 * Tingkat respons layar untuk fitur baru "Responsif Layar Max".
 * Mengatur pipeline display refresh rate, zero touch blocking, SurfaceFlinger low-latency,
 * scroll friction rendah, polling touch hardware OEM, dan CPU input boost tanpa mengubah DPI.
 */
enum class ScreenResponseLevel(
    val label: String,
    val shortLabel: String,
    val subtitle: String,
    val longPressMs: Int,
    val multiPressMs: Int,
    val touchSlopPx: Int,
    val scrollFriction: Float,
    val inputBoostMs: Int,
    val phaseOffsetNs: Long
) {
    FAST(
        label = "Cepat",
        shortLabel = "Cepat",
        subtitle = "Respons sentuhan ringan & halus, hemat daya",
        longPressMs = 160,
        multiPressMs = 140,
        touchSlopPx = 6,
        scrollFriction = 0.0080f,
        inputBoostMs = 90,
        phaseOffsetNs = -2_000_000L
    ),
    ESPORT(
        label = "Esport",
        shortLabel = "Esport",
        subtitle = "Polling tinggi, anti-delay & latensi frame rendah",
        longPressMs = 110,
        multiPressMs = 95,
        touchSlopPx = 4,
        scrollFriction = 0.0045f,
        inputBoostMs = 140,
        phaseOffsetNs = -4_000_000L
    ),
    MAX_ULTRA(
        label = "Max Ultra",
        shortLabel = "Max Ultra",
        subtitle = "Respons layar maksimal: Max Hz, 0ms blocking, Polling Max & Low-Latency",
        longPressMs = 75,
        multiPressMs = 70,
        touchSlopPx = 2,
        scrollFriction = 0.0020f,
        inputBoostMs = 200,
        phaseOffsetNs = -6_000_000L
    )
}

data class MaxScreenResponseConfig(
    val enabled: Boolean = false,
    val level: ScreenResponseLevel = ScreenResponseLevel.MAX_ULTRA,
    val maxRefreshSync: Boolean = true,
    val zeroTouchDelay: Boolean = true,
    val maxTouchPolling: Boolean = true,
    val lowLatencySurfaceFlinger: Boolean = true,
    val disableEdgeRejection: Boolean = true,
    val cpuInputBoost: Boolean = true
)

data class ScreenResponseStatus(
    val active: Boolean = false,
    val detectedMaxHz: Int = 60,
    val writableDriverNodes: Int = 0,
    val longPressMs: Int = 400,
    val touchSlopPx: Int = 16,
    val activeEngineLabel: String = "Standar",
    val detail: String = "Nonaktif • Aktifkan untuk respons layar maksimal"
)

data class AntiMistouchConfig(
    val enabled: Boolean = false,
    val blockBackGesture: Boolean = true,
    val blockStatusBarPull: Boolean = true,
    val disableEdgeGestures: Boolean = true,
    val immersiveFull: Boolean = true,
    val blockHeadsUp: Boolean = true,
    val lockAutoBrightness: Boolean = true,
    val enableDnd: Boolean = false
)

data class FpsSessionRecord(
    val id: String,
    val gameName: String,
    val timestampMs: Long,
    val fpsMin: Int,
    val fpsAvg: Int,
    val fpsMax: Int,
    val peakSocTempC: Float
)

data class GameProfileConfig(
    val packageName: String,
    val performanceProfile: PerformanceProfile? = null,
    val thermalProfile: ThermalProfile? = null,
    val fpsOverride: FpsLockTarget? = null,
    val touchBoostOverride: Boolean? = null,
    val bypassCharging: Boolean? = null,
    val gyroAim: Boolean? = null,
    val burikPreset: BurikPreset? = null
)

data class GameNoteConfig(
    val pinnedOverlay: Boolean = false,
    val text: String = "",
    val normX: Float = 0.10f,
    val normY: Float = 0.28f
)

enum class BurikPreset(
    val title: String,
    val subtitle: String,
    val textureQualityPercent: Int,
    val mipmapLevel: Int,
    val nearestFiltering: Boolean,
    val disableAnisotropic: Boolean
) {
    OFF("Off", "Driver OpenGL ES standar (Default)", 100, 0, false, false),
    SOFT("Soft", "ANGLE Vulkan • Matikan Anisotropic", 75, 1, false, true),
    PIXEL("Pixel", "ANGLE Nearest Mipmap • Tekstur kotak ringan", 55, 2, true, true),
    FLAT("Flat", "ANGLE Low Graphics • Nearest Mip + Zero Sync Stall", 35, 3, true, true),
    RETRO("Retro", "ANGLE Ultra Low • Maksimal ringan untuk kentang", 20, 4, true, true),
    CUSTOM("Custom", "Racik flag fitur ANGLE secara manual", 50, 2, true, true)
}

data class BurikConfig(
    val preset: BurikPreset = BurikPreset.OFF,
    val customTextureQualityPercent: Int = 50,
    val customMipmapLevel: Int = 2,
    val customNearestFiltering: Boolean = true,
    val customDisableAnisotropic: Boolean = true,
    val applyAllGames: Boolean = true
) {
    fun effectiveTextureQuality(): Int =
        if (preset == BurikPreset.CUSTOM) customTextureQualityPercent.coerceIn(15, 100)
        else preset.textureQualityPercent

    fun effectiveMipmapLevel(): Int =
        if (preset == BurikPreset.CUSTOM) customMipmapLevel.coerceIn(0, 4)
        else preset.mipmapLevel

    fun effectiveNearestFiltering(): Boolean =
        if (preset == BurikPreset.CUSTOM) customNearestFiltering else preset.nearestFiltering

    fun effectiveDisableAnisotropic(): Boolean =
        if (preset == BurikPreset.CUSTOM) customDisableAnisotropic else preset.disableAnisotropic

    fun angleFeatureFlags(): List<String> {
        if (preset == BurikPreset.OFF) return emptyList()
        val mip = effectiveMipmapLevel()
        val quality = effectiveTextureQuality()
        return buildList {
            add("enableRenderPassLoadStoreOpNone")
            if (effectiveDisableAnisotropic()) {
                add("disableAnisotropicFiltering")
            }
            if (effectiveNearestFiltering() || mip >= 2) {
                add("forceNearestMipFiltering")
            }
            if (mip >= 3 || quality <= 40) {
                add("disableFlippingBlockingFence")
            }
        }
    }
}

data class AngleRuntimeReport(
    val shizukuReady: Boolean = false,
    val angleDriverDetected: Boolean = false,
    val angleProviderLabel: String = "Belum dicek",
    val allAngleEnabled: Boolean = false,
    val targetedPackagesCount: Int = 0,
    val activeEglFeatures: String = "",
    val logcatConfirmed: Boolean = false,
    val lastCheckSummary: String = ""
)

enum class HudPosition(val label: String) {
    LEFT("Kiri"), CENTER("Tengah"), RIGHT("Kanan")
}

data class HudConfig(
    val enabled: Boolean = false,
    val position: HudPosition = HudPosition.CENTER,
    val scalePercent: Int = 100,
    val opacityPercent: Int = 92,
    val hideOnTouch: Boolean = false,
    val updateIntervalMs: Int = 250,
    val showFps: Boolean = true,
    val showCpu: Boolean = true,
    val showRam: Boolean = false,
    val showTemp: Boolean = true,
    val showBattery: Boolean = false,
    val showPing: Boolean = false,
    val showLabels: Boolean = true,
    val compactMode: Boolean = false,
    val singleRow: Boolean = true,
    val useFahrenheit: Boolean = false
)

enum class TouchArea(val label: String) {
    ALL("Semua"), LEFT("Kiri"), RIGHT("Kanan")
}

data class TouchConfig(
    val enabled: Boolean = false,
    val speedX: Int = 0,          // -50..200%
    val speedY: Int = 0,          // -50..200%
    val responseBoost: Int = 0,   // 0..100%
    val area: TouchArea = TouchArea.ALL,
    val smoothing: Int = 0,       // 0..100%
    val deadzone: Int = 0,        // 0..50%
    val dpiBoostEnabled: Boolean = true,
    val nubiaGameTweakEnabled: Boolean = true,
    val liveAimPadEnabled: Boolean = false,
    val aimPadNormX: Float = 0.76f,
    val aimPadNormY: Float = 0.44f,
    val aimPadLocked: Boolean = false,
    val pollingPreset: TouchPollingPreset = TouchPollingPreset.ULTRA_480,
    val touchSlopReduction: Int = 40,
    val edgeRejectionOff: Boolean = true,
    val unifiedMultiTouch: Boolean = true
) {
    fun gainX(): Float = (1f + speedX / 100f + responseBoost * 0.0025f).coerceIn(0.45f, 3.25f)

    fun gainY(): Float = (1f + speedY / 100f + responseBoost * 0.0025f).coerceIn(0.45f, 3.25f)

    fun estimatedDensity(physicalDensity: Int): Int {
        val base = physicalDensity.coerceAtLeast(240)
        val weightedPct = speedX * 0.45f + speedY * 0.55f + responseBoost * 0.15f
        val scale = if (weightedPct >= 0f) {
            1f - (weightedPct / 215f) * 0.34f
        } else {
            1f + ((-weightedPct) / 50f) * 0.14f
        }
        return (base * scale).toInt().coerceIn(240, maxOf(base + 120, 640))
    }
}

enum class CrosshairShape(val label: String) {
    DOT("Titik"),
    PLUS("Plus"),
    TARGET("Target"),
    CROSS_X("Silang"),
    DIAMOND("Diamond")
}

data class CrosshairConfig(
    val enabled: Boolean = false,
    val shape: CrosshairShape = CrosshairShape.TARGET,
    val outline: Boolean = true,
    val sizeDp: Int = 14,
    val thicknessDp: Int = 2,
    val gapDp: Int = 3,
    val colorIndex: Int = 1,
    val offsetX: Int = 0,
    val offsetY: Int = 0
)

enum class FpsLockTarget(val fps: Int, val label: String, val subtitle: String) {
    DEFAULT(0, "Default", "Refresh rate bawaan sistem"),
    FPS_60(60, "60 FPS", "Kunci 60Hz stabil & hemat daya"),
    FPS_90(90, "90 FPS", "Kunci 90Hz / 90 FPS responsif"),
    FPS_120(120, "120 FPS", "Kunci 120Hz / 120 FPS ultra mulus"),
    FPS_144(144, "144 FPS", "Maksimum refresh rate layar")
}

data class FpsLockConfig(
    val target: FpsLockTarget = FpsLockTarget.DEFAULT,
    val forceSystemRefreshRate: Boolean = true,
    val applyToAllGames: Boolean = true
)

enum class MacroPattern(val label: String) {
    REPEAT("Repeat"),
    BURST("Burst"),
    HOLD("Hold"),
    SWIPE("Swipe"),
    QUICK_SWITCH("1→2 Senjata")
}

enum class MacroInjectionMode(val label: String, val subtitle: String) {
    SMART_POINTER("Smart 10-Jari", "Otomatis Kernel Slot-9 / Direct Touch anti-mouse"),
    STYLUS_HYBRID("Stylus Hybrid", "Simulasi stylus (pointer terpisah)"),
    TOUCHSCREEN_DIRECT("Touch Direct", "Hardware device touchscreen langsung")
}

data class MacroConfig(
    val enabled: Boolean = false,
    val pattern: MacroPattern = MacroPattern.REPEAT,
    val injectionMode: MacroInjectionMode = MacroInjectionMode.SMART_POINTER,
    val triggerScale: Float = 1.0f,
    val intervalMs: Int = 150,       // Unlocked down to 16ms (~60 taps/s)
    val holdDurationMs: Int = 35,
    val randomJitterPx: Int = 0,
    val burstCount: Int = 3,
    val showTarget: Boolean = true,
    val triggerNormX: Float = 0.22f,
    val triggerNormY: Float = 0.62f,
    val targetNormX: Float = 0.48f,
    val targetNormY: Float = 0.56f,
    val enableTarget2: Boolean = false,
    val target2NormX: Float = 0.68f,
    val target2NormY: Float = 0.36f,
    val switchDelayMs: Int = 120,
    val isLocked: Boolean = false,
    val holdToTrigger: Boolean = true,
    val lockedOpacity: Float = 0.30f,
    val isRunning: Boolean = false
)

data class RadialConfig(
    val enabled: Boolean = false,
    val normX: Float = 0.90f,
    val normY: Float = 0.45f
)

enum class DebloatCategory(val label: String) {
    SAFE("Aman"),
    ADVANCED("Lanjutan"),
    EXPERT("Expert"),
    UNSAFE("Berbahaya")
}

enum class CompileStatus(val label: String) {
    NOT_COMPILED("Belum di-compile"),
    COMPILING("Sedang compile..."),
    COMPILED("Sudah di-compile")
}

data class GameEntry(
    val packageName: String,
    val name: String,
    val isGameCategory: Boolean = false,
    val isAdded: Boolean = false,
    val compileStatus: CompileStatus = CompileStatus.NOT_COMPILED,
    val burikOverride: BurikPreset? = null
)

data class DebloatAppEntry(
    val packageName: String,
    val appName: String,
    val category: DebloatCategory,
    val description: String,
    val isInstalled: Boolean,
    val isSystemApp: Boolean
)

enum class ThemeMode(val label: String) {
    SYSTEM("Sistem"), DARK("Gelap"), LIGHT("Terang")
}

enum class AccentPreset(val label: String) {
    MONO("Mono"),
    VOLT_CYAN("Volt Cyan"),
    CRIMSON("Crimson"),
    ACID_LIME("Acid Lime"),
    AMBER("Amber"),
    VIOLET("Violet")
}

enum class AppLanguage(val label: String) {
    SYSTEM("Sistem"), INDONESIAN("Indonesia"), ENGLISH("English")
}

data class ShizukuStatus(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val apiVersion: Int = 0,
    val isRootAvailable: Boolean = false,
    val isRootGranted: Boolean = false,
    val rootGrantState: RootGrantState = RootGrantState.NOT_FOUND,
    val rootManagerLabel: String = "",
    val isInputServiceBound: Boolean = false,
    val autoPermissionsApplied: Boolean = false,
    val isKernelMultiTouch: Boolean = false,
    val activeEngineLabel: String = ""
) {
    val canRunShizuku: Boolean
        get() = isRunning && isPermissionGranted

    val canRunPrivileged: Boolean
        get() = canRunShizuku || isRootGranted || isRootAvailable

    val isSelectedModeReady: Boolean
        get() = canRunShizuku || isRootGranted
}

data class TelemetrySnapshot(
    val fps: Int = 60,
    val fpsMin: Int = 60,
    val fpsAvg: Int = 60,
    val fpsMax: Int = 60,
    val cpuPercent: Int = 18,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val ramPercent: Int = 0,
    val tempC: Float = 32.0f,
    val socTempC: Float = 32.0f,
    val batteryPercent: Int = 80,
    val batteryCurrentMa: Int = 0,
    val isCharging: Boolean = false,
    val pingMs: Int = 24,
    val networkLabel: String = "Wi-Fi",
    val boostScore: Int = 25,
    val lastFreedMb: Long = 0L,
    val lastKilledCount: Int = 0,
    val isBoosting: Boolean = false
)

data class CompatibilityReport(
    val overlayGranted: Boolean = false,
    val usageStatsGranted: Boolean = false,
    val writeSettingsGranted: Boolean = false,
    val dndGranted: Boolean = false,
    val shizukuStatus: ShizukuStatus = ShizukuStatus(),
    val refreshRateHz: Int = 60,
    val gameManagerSupported: Boolean = false,
    val androidVersionLabel: String = "",
    val deviceModel: String = ""
)

enum class AiTriggerActionType(val label: String, val subtitle: String) {
    HEAD_LOCK(
        "Aim Tempel Kepala",
        "Crosshair game otomatis mengikuti titik aim di kepala musuh, tetap menempel walau layar digeser"
    )
}

data class AiTriggerRule(
    val id: String = "",
    val name: String = "AI Trigger 01",
    val enabled: Boolean = true,
    val templatePath: String = "",
    val cropLeftNorm: Float = 0.475f,
    val cropTopNorm: Float = 0.39f,
    val cropRightNorm: Float = 0.525f,
    val cropBottomNorm: Float = 0.61f,
    val templateWidth: Int = 0,
    val templateHeight: Int = 0,
    val matchPrecision: Int = 82,
    val minIntervalMs: Int = 60,
    val actionType: AiTriggerActionType = AiTriggerActionType.HEAD_LOCK,
    val targetAimNormX: Float = 0.76f,
    val targetAimNormY: Float = 0.50f,
    val gameCrosshairNormX: Float = 0.50f,
    val gameCrosshairNormY: Float = 0.50f,
    val contactRadiusPercent: Int = 28,
    val headOffsetXPercent: Int = 50,
    val headOffsetPercent: Int = 18,
    val headLiftPower: Int = 125,
    val showLiveHud: Boolean = true,
    val autoTriggerAllZones: Boolean = true
) {
    fun hasValidTemplate(): Boolean = templatePath.isNotBlank()
}

data class AiTriggerRuntimeState(
    val masterEnabled: Boolean = false,
    val isCapturing: Boolean = false,
    val hasProjectionPermission: Boolean = false,
    val captureEngineLabel: String = "Belum Aktif",
    val activeRulesCount: Int = 0,
    val lastMatchScore: Int = 0,
    val isMatched: Boolean = false,
    val crosshairTouchingBody: Boolean = false,
    val isAimingToHead: Boolean = false,
    val scanLatencyMs: Int = 0,
    val matchedLeftNorm: Float = 0.44f,
    val matchedTopNorm: Float = 0.36f,
    val matchedRightNorm: Float = 0.56f,
    val matchedBottomNorm: Float = 0.64f,
    val matchedBodyNormX: Float = 0.50f,
    val matchedBodyNormY: Float = 0.50f,
    val headTargetNormX: Float = 0.50f,
    val headTargetNormY: Float = 0.42f,
    val activeCrosshairNormX: Float = 0.50f,
    val activeCrosshairNormY: Float = 0.50f,
    val activeContactRadiusPercent: Int = 28,
    val showLiveHud: Boolean = true,
    val lastBestRuleName: String = "",
    val lastTriggeredRuleName: String = "",
    val triggerCount: Long = 0L,
    val captureWidth: Int = 0,
    val captureHeight: Int = 0,
    val lastTouchEngineStatus: String = "",
    val lastError: String? = null
)
