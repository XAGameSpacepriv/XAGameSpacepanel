package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BurikPreset
import com.example.model.BypassChargingStatus
import com.example.model.FpsLockTarget
import com.example.model.GameEntry
import com.example.model.GameProfileConfig
import com.example.model.PerformanceProfile
import com.example.model.PrivilegeMode
import com.example.model.ShizukuStatus
import com.example.model.TelemetrySnapshot
import com.example.model.ThermalProfile
import com.example.ui.components.AppIconThumb
import com.example.ui.components.SectionLabel
import com.example.ui.components.TopIdHeader
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen

@Composable
fun HomeScreen(
    sessionId: String,
    telemetry: TelemetrySnapshot,
    gameSessionActive: Boolean,
    shizukuStatus: ShizukuStatus,
    privilegeMode: PrivilegeMode = PrivilegeMode.SHIZUKU,
    addedGames: List<GameEntry>,
    getAppIcon: (String) -> ImageBitmap?,
    onBoostClick: () -> Unit,
    onToggleSession: (Boolean) -> Unit,
    onGameClick: (GameEntry) -> Unit,
    onAddGameClick: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    performanceProfile: PerformanceProfile = PerformanceProfile.BALANCED,
    bypassStatus: BypassChargingStatus = BypassChargingStatus(),
    perGameProfiles: Map<String, GameProfileConfig> = emptyMap(),
    onSelectPerformanceProfile: (PerformanceProfile) -> Unit = {},
    onToggleBypassCharging: (Boolean) -> Unit = {},
    onResetFpsStats: () -> Unit = {},
    onSaveGameProfile: (String, GameProfileConfig?) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    var showFeatureInfoDialog by remember { mutableStateOf(false) }
    var editingProfileGame by remember { mutableStateOf<GameEntry?>(null) }

    val animatedProgress by animateFloatAsState(
        targetValue = (telemetry.boostScore / 100f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 550),
        label = "boost_score_progress"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopIdHeader(title = "Beranda", sessionId = sessionId)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main Boost Hero Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = buildAnnotatedString {
                                withStyle(
                                    SpanStyle(
                                        fontFamily = JetBrainsMono,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 42.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    append("${telemetry.boostScore}")
                                }
                                withStyle(
                                    SpanStyle(
                                        fontFamily = JetBrainsMono,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 18.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                ) {
                                    append(" / 100")
                                }
                            }
                        )

                        Button(
                            onClick = onBoostClick,
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                            modifier = Modifier.testTag("boost_button")
                        ) {
                            Icon(
                                imageVector = AppIcons.Bolt,
                                contentDescription = "Boost",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (telemetry.isBoosting) "Boosting..." else "Boost",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // Progress Bar
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = if (telemetry.boostScore >= 75) StatusGreen else MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        strokeCap = StrokeCap.Round
                    )

                    // Live subtle telemetry strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "RAM ${telemetry.ramUsedMb}/${telemetry.ramTotalMb} MB",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = JetBrainsMono,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${telemetry.tempC}°C  •  ${telemetry.fps} FPS",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = JetBrainsMono,
                            fontSize = 11.sp
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Sesi game toggle row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleSession(!gameSessionActive) }
                            .testTag("session_switch_row"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sesi game",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (gameSessionActive) {
                                    "Overlay HUD & panel melayang aktif"
                                } else {
                                    "Aktifkan untuk tampilkan panel di atas game"
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                        Switch(
                            checked = gameSessionActive,
                            onCheckedChange = onToggleSession,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                checkedTrackColor = MaterialTheme.colorScheme.primary,
                                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                            ),
                            modifier = Modifier.testTag("session_switch")
                        )
                    }

                    // Esport Performance Mode & Live Hardware Telemetry Strip
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = AppIcons.EsportTurbo,
                                    contentDescription = "Mode Turbo",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Mode Performa",
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "SoC ${"%.1f".format(telemetry.socTempC)}°C • ${telemetry.batteryCurrentMa}mA",
                                color = if (telemetry.socTempC >= 45f) StatusAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 11.sp
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PerformanceProfile.entries.forEach { prof ->
                                val selected = performanceProfile == prof
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (selected) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        .clickable { onSelectPerformanceProfile(prof) }
                                        .testTag("perf_profile_${prof.name}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = prof.shortLabel,
                                        color = if (selected) MaterialTheme.colorScheme.onPrimary
                                        else MaterialTheme.colorScheme.onSurface,
                                        fontSize = 11.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "FPS Min ${telemetry.fpsMin} • Avg ${telemetry.fpsAvg} • Max ${telemetry.fpsMax}",
                                color = StatusGreen,
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                modifier = Modifier.clickable { onResetFpsStats() }
                            )
                            Text(
                                text = if (bypassStatus.enabled) "Bypass ON" else if (bypassStatus.supported) "Bypass Ready" else "Charging",
                                color = if (bypassStatus.enabled) StatusCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onToggleBypassCharging(!bypassStatus.enabled) }
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                                    .testTag("home_bypass_chip")
                            )
                        }
                    }

                    // Pro Unlocked / Status Banner Pill (replaces "Update tersedia")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                            .clickable { showFeatureInfoDialog = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("pro_status_banner"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val hasActivePriv = when (privilegeMode) {
                            PrivilegeMode.ROOT -> shizukuStatus.isRootGranted
                            PrivilegeMode.SHIZUKU -> shizukuStatus.canRunShizuku
                        }
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (hasActivePriv) StatusGreen else StatusCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when {
                                privilegeMode == PrivilegeMode.ROOT && shizukuStatus.isRootGranted ->
                                    "Pro Unlocked • Opsi 1: Root (UID 0) Aktif"
                                privilegeMode == PrivilegeMode.SHIZUKU && shizukuStatus.canRunShizuku ->
                                    "Pro Unlocked • Opsi 2: Shizuku Aktif"
                                privilegeMode == PrivilegeMode.ROOT ->
                                    "Opsi 1: Mode Root • Beri Izin Root di Profil"
                                else ->
                                    "Opsi 2: Mode Shizuku • Hubungkan di Profil"
                            },
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = AppIcons.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                SectionLabel(text = "Game kamu")
            }

            if (addedGames.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = AppIcons.Gamepad,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(34.dp)
                        )
                        Text(
                            text = "Belum ada game ditambahkan",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tekan tombol + di kanan bawah untuk memilih game agar Boost, HUD, Macro, dan Burik bekerja otomatis.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                        Button(
                            onClick = onAddGameClick,
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("empty_add_game_button")
                        ) {
                            Text("Tambah game", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                items(addedGames, key = { it.packageName }) { game ->
                    val gameProfile = perGameProfiles[game.packageName]
                    val preset = gameProfile?.burikPreset ?: game.burikOverride
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                            .clickable { onGameClick(game) }
                            .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp)
                            .testTag("game_card_${game.packageName}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIconThumb(
                            iconBitmap = getAppIcon(game.packageName),
                            fallbackLabel = game.name,
                            size = 46.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = game.name,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (preset != null && preset != BurikPreset.OFF) {
                                    Text(
                                        text = preset.title,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                gameProfile?.performanceProfile?.let { pp ->
                                    Text(
                                        text = pp.shortLabel,
                                        color = StatusCyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(StatusCyan.copy(alpha = 0.14f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = buildString {
                                    append(game.packageName)
                                    gameProfile?.thermalProfile?.let { append(" • ${it.shortLabel}") }
                                    gameProfile?.fpsOverride?.let { append(" • ${it.fps}Hz") }
                                    if (gameProfile?.bypassCharging == true) append(" • Bypass")
                                    if (gameProfile?.gyroAim == true) append(" • Gyro")
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { editingProfileGame = game },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("game_profile_btn_${game.packageName}")
                        ) {
                            Icon(
                                imageVector = AppIcons.Tune,
                                contentDescription = "Atur profil ${game.name}",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Icon(
                            imageVector = AppIcons.ChevronRight,
                            contentDescription = "Buka game",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    editingProfileGame?.let { targetGame ->
        PerGameProfileDialog(
            game = targetGame,
            existing = perGameProfiles[targetGame.packageName],
            onDismiss = { editingProfileGame = null },
            onSave = { updated ->
                onSaveGameProfile(targetGame.packageName, updated)
                editingProfileGame = null
            }
        )
    }

    if (showFeatureInfoDialog) {
        AlertDialog(
            onDismissRequest = { showFeatureInfoDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("XAGameSpacepanel Pro Unlocked", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Semua fitur Pro terbuka penuh tanpa batas:\n" +
                        "• Thermal Advance 5-Mode & Thermal Max 38°C–40°C di Panel Melayang\n" +
                        "• Touch Response Engine 480Hz/Max & OEM Driver (tanpa ubah DPI)\n" +
                        "• Esport Turbo Mode, Anti-Mistouch, Dimmer OLED & Catatan Melayang\n" +
                        "• Hardware Bypass Charging, FPS Result, Stopwatch & Gyro Aim\n" +
                        "• Perizinan Root (Magisk/KernelSU/APatch), Macro 10-Jari & ANGLE Texture\n\n" +
                        when {
                            privilegeMode == PrivilegeMode.ROOT && shizukuStatus.isRootGranted ->
                                "Mode Aktif: Opsi 1 — Root (UID 0 • ${shizukuStatus.rootManagerLabel.ifBlank { "Superuser" }}). Shizuku tidak diperlukan."
                            privilegeMode == PrivilegeMode.SHIZUKU && shizukuStatus.canRunShizuku ->
                                "Mode Aktif: Opsi 2 — Shizuku (Non-Root). Akses Root tidak diperlukan."
                            privilegeMode == PrivilegeMode.ROOT ->
                                "Mode Dipilih: Opsi 1 — Root (UID 0). Berikan izin Root di Profil > Mode Akses Sistem (tanpa Shizuku)."
                            else ->
                                "Mode Dipilih: Opsi 2 — Shizuku (Non-Root). Hubungkan Shizuku atau pilih Opsi 1 (Root) di Profil > Mode Akses Sistem."
                        },
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showFeatureInfoDialog = false
                    onOpenDiagnostics()
                }) {
                    Text("Cek Diagnostik")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFeatureInfoDialog = false }) {
                    Text("Tutup")
                }
            }
        )
    }
}

@Composable
private fun PerGameProfileDialog(
    game: GameEntry,
    existing: GameProfileConfig?,
    onDismiss: () -> Unit,
    onSave: (GameProfileConfig?) -> Unit
) {
    var perf by remember(game.packageName) { mutableStateOf(existing?.performanceProfile) }
    var thermal by remember(game.packageName) { mutableStateOf(existing?.thermalProfile) }
    var fps by remember(game.packageName) { mutableStateOf(existing?.fpsOverride) }
    var touch by remember(game.packageName) { mutableStateOf(existing?.touchBoostOverride) }
    var bypass by remember(game.packageName) { mutableStateOf(existing?.bypassCharging) }
    var gyro by remember(game.packageName) { mutableStateOf(existing?.gyroAim) }
    var burik by remember(game.packageName) { mutableStateOf(existing?.burikPreset ?: game.burikOverride) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Column {
                Text("Profil: ${game.name}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(game.packageName, fontFamily = JetBrainsMono, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Mode Performa", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    val options = listOf(null) + PerformanceProfile.entries
                    options.forEach { opt ->
                        val selected = perf == opt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .clickable { perf = opt },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = opt?.shortLabel ?: "Global",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Text("Profil Thermal", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.fillMaxWidth()) {
                    val thermalOpts = listOf(null) + ThermalProfile.entries
                    thermalOpts.forEach { opt ->
                        val selected = thermal == opt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .clickable { thermal = opt }
                                .testTag("per_game_thermal_${opt?.name ?: "GLOBAL"}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = opt?.shortLabel ?: "Auto",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 9.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Text("Target FPS Game", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    val fpsOpts = listOf(null, FpsLockTarget.FPS_60, FpsLockTarget.FPS_90, FpsLockTarget.FPS_120, FpsLockTarget.FPS_144)
                    fpsOpts.forEach { opt ->
                        val selected = fps == opt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .clickable { fps = opt },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = opt?.fps?.toString() ?: "Global",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Text("ANGLE Texture", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    val burikOpts = listOf(null, BurikPreset.OFF, BurikPreset.SOFT, BurikPreset.PIXEL, BurikPreset.RETRO)
                    burikOpts.forEach { opt ->
                        val selected = burik == opt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .clickable { burik = opt },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = opt?.title ?: "Global",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TriStatePill(
                        label = "Touch",
                        value = touch,
                        modifier = Modifier.weight(1f),
                        onCycle = { touch = cycleTriState(touch) }
                    )
                    TriStatePill(
                        label = "Bypass",
                        value = bypass,
                        modifier = Modifier.weight(1f),
                        onCycle = { bypass = cycleTriState(bypass) }
                    )
                    TriStatePill(
                        label = "Gyro",
                        value = gyro,
                        modifier = Modifier.weight(1f),
                        onCycle = { gyro = cycleTriState(gyro) }
                    )
                }
            }
        },
        dismissButton = {
            OutlinedButton(onClick = { onSave(null) }) {
                Text("Reset Global")
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        GameProfileConfig(
                            packageName = game.packageName,
                            performanceProfile = perf,
                            thermalProfile = thermal,
                            fpsOverride = fps,
                            touchBoostOverride = touch,
                            bypassCharging = bypass,
                            gyroAim = gyro,
                            burikPreset = burik
                        )
                    )
                }
            ) {
                Text("Simpan", fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

private fun cycleTriState(cur: Boolean?): Boolean? = when (cur) {
    null -> true
    true -> false
    false -> null
}

@Composable
private fun TriStatePill(
    label: String,
    value: Boolean?,
    modifier: Modifier = Modifier,
    onCycle: () -> Unit
) {
    val text = when (value) {
        null -> "$label: Auto"
        true -> "$label: ON"
        false -> "$label: OFF"
    }
    Box(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                when (value) {
                    true -> MaterialTheme.colorScheme.primary
                    false -> MaterialTheme.colorScheme.errorContainer
                    null -> MaterialTheme.colorScheme.surfaceContainerHigh
                }
            )
            .clickable(onClick = onCycle),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = when (value) {
                true -> MaterialTheme.colorScheme.onPrimary
                false -> MaterialTheme.colorScheme.onErrorContainer
                null -> MaterialTheme.colorScheme.onSurface
            },
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}
