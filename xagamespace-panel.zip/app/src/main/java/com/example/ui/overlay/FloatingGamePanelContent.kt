package com.example.ui.overlay

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.TouchBoostPreset
import com.example.model.AiTriggerRule
import com.example.model.AiTriggerRuntimeState
import com.example.model.BurikConfig
import com.example.model.BurikPreset
import com.example.model.CrosshairConfig
import com.example.model.CrosshairShape
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.HudConfig
import com.example.model.HudPosition
import com.example.model.MacroConfig
import com.example.model.MacroInjectionMode
import com.example.model.MacroPattern
import com.example.model.MaxScreenResponseConfig
import com.example.model.PanelTab
import com.example.model.RadialConfig
import com.example.model.ScreenResponseLevel
import com.example.model.ScreenResponseStatus
import com.example.model.ShizukuStatus
import com.example.model.TelemetrySnapshot
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.model.TouchArea
import com.example.model.TouchConfig
import com.example.model.TouchPollingPreset
import com.example.ui.icons.AppIcons
import com.example.ui.theme.CrosshairPalette
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianTextPrimary
import com.example.ui.theme.ObsidianTextSecondary
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import kotlin.math.roundToInt

/**
 * In-game floating panel matching the 7-tab dark HUD control drawer shown in the reference video:
 * Monitor | Boost | Touch | Crosshair | Macro | Burik | Radial
 */
@Composable
fun FloatingGamePanelContent(
    telemetry: TelemetrySnapshot,
    hudConfig: HudConfig,
    touchConfig: TouchConfig,
    crosshairConfig: CrosshairConfig,
    macroConfig: MacroConfig,
    burikConfig: BurikConfig,
    fpsLockConfig: FpsLockConfig,
    radialConfig: RadialConfig,
    fastAnimEnabled: Boolean,
    shizukuStatus: ShizukuStatus,
    physicalDensityDpi: Int = 420,
    accentColor: Color,
    statusMessage: String?,
    panelWidthDp: Float = 320f,
    panelHeightDp: Float = 340f,
    onDragPanel: (dx: Float, dy: Float) -> Unit = { _, _ -> },
    onClose: () -> Unit,
    onUpdateHud: ((HudConfig) -> HudConfig) -> Unit,
    onResetHudPosition: () -> Unit,
    onBoostNow: () -> Unit,
    onSelectFpsLock: (FpsLockTarget) -> Unit,
    onToggleFastAnim: (Boolean) -> Unit,
    onUpdateTouch: ((TouchConfig) -> TouchConfig) -> Unit,
    onApplyTouchNow: () -> Unit,
    onResetTouch: () -> Unit,
    onUpdateCrosshair: ((CrosshairConfig) -> CrosshairConfig) -> Unit,
    onResetCrosshair: () -> Unit,
    onUpdateMacro: ((MacroConfig) -> MacroConfig) -> Unit,
    onOpenMacroPlacement: () -> Unit,
    onConnectShizuku: () -> Unit,
    onSelectBurikPreset: (BurikPreset) -> Unit,
    onUpdateBurikConfig: ((BurikConfig) -> BurikConfig) -> Unit,
    onApplyBurikNow: () -> Unit,
    onApplyBurikAndRestart: () -> Unit = {},
    onRestoreSession: () -> Unit,
    onUpdateRadial: ((RadialConfig) -> RadialConfig) -> Unit,
    aiTriggerMasterEnabled: Boolean = false,
    aiTriggerRules: List<AiTriggerRule> = emptyList(),
    aiDraftRule: AiTriggerRule? = null,
    aiRuntimeState: AiTriggerRuntimeState = AiTriggerRuntimeState(),
    requestedTab: PanelTab? = null,
    screenWidthPx: Int = 1080,
    screenHeightPx: Int = 2400,
    loadAiTemplateBitmap: (String) -> Bitmap? = { null },
    onConsumeRequestedTab: () -> Unit = {},
    onToggleAiMaster: (Boolean) -> Unit = {},
    onRequestAiProjection: () -> Unit = {},
    onStartCreateAiRule: () -> Unit = {},
    onEditAiRule: (AiTriggerRule) -> Unit = {},
    onToggleAiRule: (String, Boolean) -> Unit = { _, _ -> },
    onDeleteAiRule: (String) -> Unit = {},
    onUpdateAiDraft: ((AiTriggerRule) -> AiTriggerRule) -> Unit = {},
    onCancelAiDraft: () -> Unit = {},
    onSaveAiDraft: (AiTriggerRule) -> Unit = {},
    onOpenAiCropOverlay: (AiTriggerRule) -> Unit = {},
    onOpenAiTargetPicker: (AiTriggerRule) -> Unit = {},
    onSetPanelFocusable: (Boolean) -> Unit = {},
    maxScreenResponseConfig: MaxScreenResponseConfig = MaxScreenResponseConfig(),
    screenResponseStatus: ScreenResponseStatus = ScreenResponseStatus(),
    thermalConfig: ThermalConfig = ThermalConfig(),
    thermalStatus: ThermalStatus = ThermalStatus(),
    onToggleMaxScreenResponse: (Boolean) -> Unit = {},
    onSelectScreenResponseLevel: (ScreenResponseLevel) -> Unit = {},
    onApplyTouchPreset: (TouchBoostPreset) -> Unit = {},
    onSelectThermalProfile: (ThermalProfile) -> Unit = {},
    onSetThermalMaxLimit: (Boolean, Int) -> Unit = { _, _ -> }
) {
    var selectedTab by remember { mutableStateOf(requestedTab ?: PanelTab.MONITOR) }

    LaunchedEffect(requestedTab) {
        if (requestedTab != null) {
            selectedTab = requestedTab
            onConsumeRequestedTab()
        }
    }

    Row(
        modifier = Modifier
            .width(panelWidthDp.dp)
            .height(panelHeightDp.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(ObsidianSurface.copy(alpha = 0.94f))
            .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
    ) {
        // Left vertical navigation rail
        Column(
            modifier = Modifier
                .width(86.dp)
                .fillMaxHeight()
                .background(Color(0xFF0E1014).copy(alpha = 0.96f))
                .verticalScroll(rememberScrollState())
                .padding(vertical = 10.dp, horizontal = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            PanelRailItem(
                icon = AppIcons.SpeedGauge,
                label = "Monitor",
                selected = selectedTab == PanelTab.MONITOR,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.MONITOR }
            )
            PanelRailItem(
                icon = AppIcons.Bolt,
                label = "Boost",
                selected = selectedTab == PanelTab.BOOST,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.BOOST }
            )
            PanelRailItem(
                icon = AppIcons.Thermal,
                label = "Thermal",
                selected = selectedTab == PanelTab.THERMAL,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.THERMAL }
            )
            PanelRailItem(
                icon = AppIcons.Touch,
                label = "Touch",
                selected = selectedTab == PanelTab.TOUCH,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.TOUCH }
            )
            PanelRailItem(
                icon = AppIcons.Crosshair,
                label = "Crosshair",
                selected = selectedTab == PanelTab.CROSSHAIR,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.CROSSHAIR }
            )
            PanelRailItem(
                icon = AppIcons.Macro,
                label = "Macro",
                selected = selectedTab == PanelTab.MACRO,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.MACRO }
            )
            PanelRailItem(
                icon = AppIcons.AiTrigger,
                label = "AI Trigger",
                selected = selectedTab == PanelTab.AI_TRIGGER,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.AI_TRIGGER }
            )
            PanelRailItem(
                icon = AppIcons.PixelGrid,
                label = "Texture",
                selected = selectedTab == PanelTab.BURIK,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.BURIK }
            )
            PanelRailItem(
                icon = AppIcons.RadialWheel,
                label = "Radial",
                selected = selectedTab == PanelTab.RADIAL,
                accentColor = accentColor,
                onClick = { selectedTab = PanelTab.RADIAL }
            )
        }

        // Right detail pane
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(12.dp)
        ) {
            // Draggable Header row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDragPanel(dragAmount.x, dragAmount.y)
                        }
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedTab.labelId,
                        color = ObsidianTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = when (selectedTab) {
                            PanelTab.MONITOR -> "HUD overlay"
                            PanelTab.BOOST -> {
                                val fpsLabel = if (fpsLockConfig.target == FpsLockTarget.DEFAULT) "" else " • ${fpsLockConfig.target.label}"
                                "Skor ${telemetry.boostScore}/100 • RAM ${telemetry.ramPercent}%$fpsLabel"
                            }
                            PanelTab.THERMAL -> {
                                val capLabel = if (thermalConfig.thermalMaxLimitEnabled) " • Max ≤${thermalConfig.thermalMaxTargetC}°C" else ""
                                "${thermalConfig.profile.label} • SoC ${telemetry.socTempC}°C$capLabel"
                            }
                            PanelTab.TOUCH -> {
                                val respTag = if (maxScreenResponseConfig.enabled) {
                                    " • MAX ${screenResponseStatus.detectedMaxHz}Hz"
                                } else {
                                    " • ${touchConfig.pollingPreset.shortLabel}"
                                }
                                "X ${"%.2fx".format(touchConfig.gainX())} • Y ${"%.2fx".format(touchConfig.gainY())}$respTag"
                            }
                            PanelTab.CROSSHAIR -> "Overlay bidikan"
                            PanelTab.MACRO -> if (macroConfig.isLocked) "Terkunci • Tahan Trigger untuk tap" else "Mode atur posisi Trigger & Target"
                            PanelTab.AI_TRIGGER -> if (aiTriggerMasterEnabled) "AI Aktif • ${aiTriggerRules.count { it.enabled }}/5 pemicu" else "Crop musuh & Target Aim otomatis ke kepala"
                            PanelTab.BURIK -> "ANGLE Texture • ${burikConfig.preset.title} (${burikConfig.effectiveTextureQuality()}%)"
                            PanelTab.RADIAL -> "Menu cepat mengambang"
                        },
                        color = ObsidianTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(ObsidianCardElevated)
                        .testTag("overlay_panel_close")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Tutup panel",
                        tint = ObsidianTextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            if (!statusMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = statusMessage,
                    color = StatusCyan,
                    fontSize = 10.sp,
                    lineHeight = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(StatusCyan.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedTab) {
                    PanelTab.MONITOR -> MonitorTabContent(
                        config = hudConfig,
                        accentColor = accentColor,
                        onUpdate = onUpdateHud,
                        onResetPosition = onResetHudPosition
                    )
                    PanelTab.BOOST -> BoostTabContent(
                        telemetry = telemetry,
                        fpsLockConfig = fpsLockConfig,
                        fastAnimEnabled = fastAnimEnabled,
                        accentColor = accentColor,
                        onBoostNow = onBoostNow,
                        onSelectFpsLock = onSelectFpsLock,
                        onToggleFastAnim = onToggleFastAnim,
                        onRestoreSession = onRestoreSession
                    )
                    PanelTab.THERMAL -> ThermalTabContent(
                        telemetry = telemetry,
                        thermalConfig = thermalConfig,
                        thermalStatus = thermalStatus,
                        accentColor = accentColor,
                        onSelectProfile = onSelectThermalProfile,
                        onSetThermalMaxLimit = onSetThermalMaxLimit
                    )
                    PanelTab.TOUCH -> TouchTabContent(
                        config = touchConfig,
                        maxScreenResponseConfig = maxScreenResponseConfig,
                        screenResponseStatus = screenResponseStatus,
                        shizukuStatus = shizukuStatus,
                        accentColor = accentColor,
                        onToggleMaxScreenResponse = onToggleMaxScreenResponse,
                        onSelectScreenResponseLevel = onSelectScreenResponseLevel,
                        onApplyPreset = onApplyTouchPreset,
                        onUpdate = onUpdateTouch,
                        onApplyNow = onApplyTouchNow,
                        onReset = onResetTouch
                    )
                    PanelTab.CROSSHAIR -> CrosshairTabContent(
                        config = crosshairConfig,
                        accentColor = accentColor,
                        onUpdate = onUpdateCrosshair,
                        onReset = onResetCrosshair
                    )
                    PanelTab.MACRO -> MacroTabContent(
                        config = macroConfig,
                        shizukuStatus = shizukuStatus,
                        accentColor = accentColor,
                        onUpdate = onUpdateMacro,
                        onOpenPlacement = onOpenMacroPlacement,
                        onConnectShizuku = onConnectShizuku
                    )
                    PanelTab.AI_TRIGGER -> AiTriggerTabContent(
                        masterEnabled = aiTriggerMasterEnabled,
                        rules = aiTriggerRules,
                        draftRule = aiDraftRule,
                        runtimeState = aiRuntimeState,
                        shizukuStatus = shizukuStatus,
                        screenWidthPx = screenWidthPx,
                        screenHeightPx = screenHeightPx,
                        accentColor = accentColor,
                        loadTemplateBitmap = loadAiTemplateBitmap,
                        onToggleMaster = onToggleAiMaster,
                        onRequestProjection = onRequestAiProjection,
                        onConnectShizuku = onConnectShizuku,
                        onStartCreateNew = onStartCreateAiRule,
                        onEditRule = onEditAiRule,
                        onToggleRule = onToggleAiRule,
                        onDeleteRule = onDeleteAiRule,
                        onUpdateDraft = onUpdateAiDraft,
                        onCancelDraft = onCancelAiDraft,
                        onSaveDraft = onSaveAiDraft,
                        onOpenCropOverlay = onOpenAiCropOverlay,
                        onOpenTargetPicker = onOpenAiTargetPicker,
                        onSetPanelFocusable = onSetPanelFocusable
                    )
                    PanelTab.BURIK -> BurikTabContent(
                        config = burikConfig,
                        accentColor = accentColor,
                        onSelectPreset = onSelectBurikPreset,
                        onUpdateConfig = onUpdateBurikConfig,
                        onApplyNow = onApplyBurikNow,
                        onApplyAndRestart = onApplyBurikAndRestart,
                        onRestore = { onSelectBurikPreset(BurikPreset.OFF) }
                    )
                    PanelTab.RADIAL -> RadialTabContent(
                        radialConfig = radialConfig,
                        hudEnabled = hudConfig.enabled,
                        crosshairEnabled = crosshairConfig.enabled,
                        macroEnabled = macroConfig.enabled,
                        accentColor = accentColor,
                        onToggleRadial = { enabled -> onUpdateRadial { it.copy(enabled = enabled) } },
                        onBoostNow = onBoostNow,
                        onToggleHud = { onUpdateHud { it.copy(enabled = !it.enabled) } },
                        onToggleCrosshair = { onUpdateCrosshair { it.copy(enabled = !it.enabled) } },
                        onToggleMacro = { onUpdateMacro { it.copy(enabled = !it.enabled) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun PanelRailItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) ObsidianCardElevated else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) accentColor else ObsidianTextSecondary,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = label,
            color = if (selected) ObsidianTextPrimary else ObsidianTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MonitorTabContent(
    config: HudConfig,
    accentColor: Color,
    onUpdate: ((HudConfig) -> HudConfig) -> Unit,
    onResetPosition: () -> Unit
) {
    PanelSwitchRow(
        label = "Tampilkan HUD",
        checked = config.enabled,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(enabled = v) } }
    )

    Text("Posisi", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        HudPosition.entries.forEach { pos ->
            val sel = config.position == pos
            PanelPillOption(
                text = pos.label,
                selected = sel,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(position = pos) } }
            )
        }
    }

    PanelSliderRow(
        label = "Ukuran",
        valueText = "${config.scalePercent}%",
        value = config.scalePercent.toFloat(),
        range = 70f..140f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(scalePercent = v.roundToInt()) } }
    )

    PanelSliderRow(
        label = "Opasitas",
        valueText = "${config.opacityPercent}%",
        value = config.opacityPercent.toFloat(),
        range = 35f..100f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(opacityPercent = v.roundToInt()) } }
    )

    Text("Update", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf(100, 250, 500, 1000).forEach { ms ->
            val label = if (ms == 1000) "1s" else "${ms}ms"
            PanelPillOption(
                text = label,
                selected = config.updateIntervalMs == ms,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(updateIntervalMs = ms) } }
            )
        }
    }

    PanelSwitchRow("Deteksi sentuhan", config.hideOnTouch, accentColor) { v ->
        onUpdate { it.copy(hideOnTouch = v) }
    }

    Text("Tampilkan metrik", color = ObsidianTextSecondary, fontSize = 11.sp)
    PanelSwitchRow("FPS", config.showFps, accentColor) { v -> onUpdate { it.copy(showFps = v) } }
    PanelSwitchRow("CPU", config.showCpu, accentColor) { v -> onUpdate { it.copy(showCpu = v) } }
    PanelSwitchRow("RAM", config.showRam, accentColor) { v -> onUpdate { it.copy(showRam = v) } }
    PanelSwitchRow("Suhu", config.showTemp, accentColor) { v -> onUpdate { it.copy(showTemp = v) } }
    PanelSwitchRow("Baterai", config.showBattery, accentColor) { v -> onUpdate { it.copy(showBattery = v) } }
    PanelSwitchRow("Ping Jaringan", config.showPing, accentColor) { v -> onUpdate { it.copy(showPing = v) } }
    PanelSwitchRow("Tampilkan label", config.showLabels, accentColor) { v -> onUpdate { it.copy(showLabels = v) } }
    PanelSwitchRow("Format kompak", config.compactMode, accentColor) { v -> onUpdate { it.copy(compactMode = v) } }
    PanelSwitchRow("Mode satu baris", config.singleRow, accentColor) { v -> onUpdate { it.copy(singleRow = v) } }
    PanelSwitchRow("Satuan Fahrenheit (°F)", config.useFahrenheit, accentColor) { v ->
        onUpdate { it.copy(useFahrenheit = v) }
    }

    OutlinedButton(
        onClick = onResetPosition,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Reset posisi HUD", color = ObsidianTextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun BoostTabContent(
    telemetry: TelemetrySnapshot,
    fpsLockConfig: FpsLockConfig,
    fastAnimEnabled: Boolean,
    accentColor: Color,
    onBoostNow: () -> Unit,
    onSelectFpsLock: (FpsLockTarget) -> Unit,
    onToggleFastAnim: (Boolean) -> Unit,
    onRestoreSession: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ObsidianCard)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${telemetry.boostScore} / 100",
                color = ObsidianTextPrimary,
                fontFamily = JetBrainsMono,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${telemetry.tempC}°C • ${telemetry.fps} FPS",
                color = StatusGreen,
                fontFamily = JetBrainsMono,
                fontSize = 11.sp
            )
        }
        Text(
            text = "RAM terpakai: ${telemetry.ramUsedMb} / ${telemetry.ramTotalMb} MB (${telemetry.ramPercent}%)",
            color = ObsidianTextSecondary,
            fontSize = 11.sp
        )
        Button(
            onClick = onBoostNow,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color(0xFF0B0C0F)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(AppIcons.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (telemetry.isBoosting) "Boosting..." else "Boost Sekarang",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
        }
    }

    Text("FPS Lock (Refresh Rate & Game Overlay)", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        FpsLockTarget.entries.forEach { target ->
            val shortLabel = if (target == FpsLockTarget.DEFAULT) "Auto" else "${target.fps}"
            PanelPillOption(
                text = shortLabel,
                selected = fpsLockConfig.target == target,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onSelectFpsLock(target) }
            )
        }
    }
    Text(
        text = fpsLockConfig.target.subtitle,
        color = ObsidianTextSecondary,
        fontSize = 10.sp
    )

    PanelSwitchRow(
        label = "Animasi cepat (0.3x)",
        checked = fastAnimEnabled,
        accentColor = accentColor,
        onCheckedChange = onToggleFastAnim
    )

    OutlinedButton(
        onClick = onRestoreSession,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Pulihkan pengaturan sesi", color = ObsidianTextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun ThermalTabContent(
    telemetry: TelemetrySnapshot,
    thermalConfig: ThermalConfig,
    thermalStatus: ThermalStatus,
    accentColor: Color,
    onSelectProfile: (ThermalProfile) -> Unit,
    onSetThermalMaxLimit: (Boolean, Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianCard)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SoC ${telemetry.socTempC}°C • Bat ${telemetry.tempC}°C",
                color = ObsidianTextPrimary,
                fontFamily = JetBrainsMono,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = thermalStatus.systemThermalState,
                color = if (thermalStatus.maxLimitActive) StatusCyan else StatusGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Text(
            text = thermalStatus.maxLimitDetail.ifBlank { thermalStatus.activeNodeSummary },
            color = ObsidianTextSecondary,
            fontSize = 10.sp,
            lineHeight = 13.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }

    PanelSwitchRow(
        label = "Thermal Max Cap (38–40°C)",
        checked = thermalConfig.thermalMaxLimitEnabled,
        accentColor = StatusCyan,
        onCheckedChange = { enabled ->
            onSetThermalMaxLimit(enabled, thermalConfig.thermalMaxTargetC)
        }
    )

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf(38, 39, 40).forEach { targetC ->
            PanelPillOption(
                text = "≤ ${targetC}°C",
                selected = thermalConfig.thermalMaxLimitEnabled && thermalConfig.thermalMaxTargetC == targetC,
                accentColor = StatusCyan,
                modifier = Modifier
                    .weight(1f)
                    .testTag("overlay_thermal_max_$targetC"),
                onClick = { onSetThermalMaxLimit(true, targetC) }
            )
        }
    }

    Text("Profil Thermal Advance", color = ObsidianTextSecondary, fontSize = 11.sp)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ThermalProfile.entries.chunked(3).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { profile ->
                    PanelPillOption(
                        text = profile.shortLabel,
                        selected = thermalConfig.profile == profile,
                        accentColor = if (profile == ThermalProfile.DISABLE_THROTTLE) StatusAmber else accentColor,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("overlay_thermal_profile_${profile.name}"),
                        onClick = { onSelectProfile(profile) }
                    )
                }
            }
        }
    }

    Text(
        text = thermalConfig.profile.subtitle,
        color = ObsidianTextSecondary,
        fontSize = 10.sp,
        lineHeight = 13.sp
    )
}

@Composable
private fun TouchTabContent(
    config: TouchConfig,
    maxScreenResponseConfig: MaxScreenResponseConfig,
    screenResponseStatus: ScreenResponseStatus,
    shizukuStatus: ShizukuStatus,
    accentColor: Color,
    onToggleMaxScreenResponse: (Boolean) -> Unit,
    onSelectScreenResponseLevel: (ScreenResponseLevel) -> Unit,
    onApplyPreset: (TouchBoostPreset) -> Unit,
    onUpdate: ((TouchConfig) -> TouchConfig) -> Unit,
    onApplyNow: () -> Unit,
    onReset: () -> Unit
) {
    val gainX = config.gainX()
    val gainY = config.gainY()

    // Quick in-game control card for "Responsif Layar Max"
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (maxScreenResponseConfig.enabled) StatusCyan.copy(alpha = 0.14f) else ObsidianCard
            )
            .border(
                width = 1.dp,
                color = if (maxScreenResponseConfig.enabled) StatusCyan.copy(alpha = 0.55f) else ObsidianBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Responsif Layar Max",
                        color = ObsidianTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (maxScreenResponseConfig.enabled) "MAX ${screenResponseStatus.detectedMaxHz}Hz" else "OFF",
                        color = if (maxScreenResponseConfig.enabled) StatusCyan else ObsidianTextSecondary,
                        fontFamily = JetBrainsMono,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (maxScreenResponseConfig.enabled) StatusCyan.copy(alpha = 0.18f)
                                else ObsidianCardElevated
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Text(
                    text = if (maxScreenResponseConfig.enabled) {
                        "${maxScreenResponseConfig.level.label} • ${screenResponseStatus.longPressMs}ms • Slop ${screenResponseStatus.touchSlopPx}px"
                    } else {
                        "Max Hz, Zero-Delay, Polling & Low-Lat SF (Tanpa ubah DPI)"
                    },
                    color = ObsidianTextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Switch(
                checked = maxScreenResponseConfig.enabled,
                onCheckedChange = onToggleMaxScreenResponse,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF0B0C0F),
                    checkedTrackColor = StatusCyan,
                    uncheckedThumbColor = ObsidianTextSecondary,
                    uncheckedTrackColor = ObsidianCardElevated
                ),
                modifier = Modifier.testTag("overlay_toggle_max_screen_response")
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
            ScreenResponseLevel.entries.forEach { lvl ->
                val sel = maxScreenResponseConfig.enabled && maxScreenResponseConfig.level == lvl
                PanelPillOption(
                    text = lvl.shortLabel,
                    selected = sel,
                    accentColor = StatusCyan,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("overlay_screen_resp_${lvl.name}"),
                    onClick = { onSelectScreenResponseLevel(lvl) }
                )
            }
        }
    }

    PanelSwitchRow(
        label = "Touch Sensitivity X/Y Live",
        checked = config.enabled,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(enabled = v) } }
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Gain X: ${"%.2fx".format(gainX)} (${config.speedX}%)",
                color = ObsidianTextPrimary,
                fontFamily = JetBrainsMono,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Y: ${"%.2fx".format(gainY)} (${config.speedY}%)",
                color = StatusCyan,
                fontFamily = JetBrainsMono,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Polling: ${config.pollingPreset.shortLabel} • Slop -${config.touchSlopReduction}%",
                color = ObsidianTextSecondary,
                fontFamily = JetBrainsMono,
                fontSize = 10.sp
            )
            Text(
                text = "Tanpa ubah DPI",
                color = StatusGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }

    Text("Racikan Licin 1-Ketuk", color = ObsidianTextSecondary, fontSize = 11.sp)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        TouchBoostPreset.entries.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { preset ->
                    PanelPillOption(
                        text = preset.label,
                        selected = preset.matches(config),
                        accentColor = StatusCyan,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("overlay_touch_preset_${preset.name}"),
                        onClick = { onApplyPreset(preset) }
                    )
                }
            }
        }
    }

    PanelSliderRow(
        label = "Kecepatan X (Horizontal)",
        valueText = "${config.speedX}%",
        value = config.speedX.toFloat(),
        range = -50f..200f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(speedX = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Kecepatan Y (Vertikal / Headshot)",
        valueText = "${config.speedY}%",
        value = config.speedY.toFloat(),
        range = -50f..200f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(speedY = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Sentuhan / Response Boost",
        valueText = "${config.responseBoost}%",
        value = config.responseBoost.toFloat(),
        range = 0f..100f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(responseBoost = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Pangkas Touch Slop (Instan)",
        valueText = "-${config.touchSlopReduction}%",
        value = config.touchSlopReduction.toFloat(),
        range = 0f..100f,
        accentColor = StatusCyan,
        onValueChange = { v -> onUpdate { it.copy(touchSlopReduction = v.roundToInt()) } }
    )

    Text("Touch Polling Rate", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        TouchPollingPreset.entries.forEach { preset ->
            PanelPillOption(
                text = preset.shortLabel,
                selected = config.pollingPreset == preset,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(pollingPreset = preset) } }
            )
        }
    }

    Text("Area Aktif", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        TouchArea.entries.forEach { area ->
            PanelPillOption(
                text = area.label,
                selected = config.area == area,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(area = area) } }
            )
        }
    }

    PanelSliderRow(
        label = "Haluskan (Smoothing)",
        valueText = "${config.smoothing}%",
        value = config.smoothing.toFloat(),
        range = 0f..100f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(smoothing = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Deadzone",
        valueText = "${config.deadzone}%",
        value = config.deadzone.toFloat(),
        range = 0f..50f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(deadzone = v.roundToInt()) } }
    )

    PanelSwitchRow(
        label = "Nubia / OEM Touch Engine",
        checked = config.nubiaGameTweakEnabled,
        accentColor = StatusCyan,
        onCheckedChange = { v -> onUpdate { it.copy(nubiaGameTweakEnabled = v) } }
    )
    Text(
        text = if (shizukuStatus.isRootGranted) {
            "Root UID 0 aktif: Live Touch Amplifier + Polling Hardware OEM langsung tanpa ubah DPI."
        } else {
            "Zero-Stutter Companion: speed_up_touch, zero blocking & sampling cepat tanpa ubah DPI atau blokir jari."
        },
        color = ObsidianTextSecondary,
        fontSize = 10.sp,
        lineHeight = 13.sp
    )

    Button(
        onClick = onApplyNow,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("overlay_apply_touch_dpi"),
        colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color(0xFF0B0C0F)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Terapkan Sensi X/Y & Polling", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }

    OutlinedButton(
        onClick = onReset,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Reset Config", color = ObsidianTextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun CrosshairTabContent(
    config: CrosshairConfig,
    accentColor: Color,
    onUpdate: ((CrosshairConfig) -> CrosshairConfig) -> Unit,
    onReset: () -> Unit
) {
    PanelSwitchRow(
        label = "Tampilkan crosshair",
        checked = config.enabled,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(enabled = v) } }
    )

    Text("Bentuk", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        listOf(CrosshairShape.DOT, CrosshairShape.PLUS, CrosshairShape.TARGET).forEach { s ->
            PanelPillOption(
                text = s.label,
                selected = config.shape == s,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(shape = s) } }
            )
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        listOf(CrosshairShape.CROSS_X, CrosshairShape.DIAMOND).forEach { s ->
            PanelPillOption(
                text = s.label,
                selected = config.shape == s,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(shape = s) } }
            )
        }
    }

    PanelSwitchRow(
        label = "Garis luar (Outline)",
        checked = config.outline,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(outline = v) } }
    )

    PanelSliderRow(
        label = "Ukuran",
        valueText = "${config.sizeDp}dp",
        value = config.sizeDp.toFloat(),
        range = 6f..32f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(sizeDp = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Ketebalan",
        valueText = "${config.thicknessDp}dp",
        value = config.thicknessDp.toFloat(),
        range = 1f..5f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(thicknessDp = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Celah tengah",
        valueText = "${config.gapDp}dp",
        value = config.gapDp.toFloat(),
        range = 0f..12f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(gapDp = v.roundToInt()) } }
    )

    Text("Warna", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        CrosshairPalette.take(8).forEachIndexed { idx, col ->
            val selected = config.colorIndex == idx
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(col)
                    .border(
                        width = if (selected) 2.5.dp else 1.dp,
                        color = if (selected) accentColor else ObsidianBorder,
                        shape = CircleShape
                    )
                    .clickable { onUpdate { it.copy(colorIndex = idx) } }
            )
        }
    }

    PanelSliderRow(
        label = "Geser X",
        valueText = "${config.offsetX}dp",
        value = config.offsetX.toFloat(),
        range = -80f..80f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(offsetX = v.roundToInt()) } }
    )
    PanelSliderRow(
        label = "Geser Y",
        valueText = "${config.offsetY}dp",
        value = config.offsetY.toFloat(),
        range = -80f..80f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(offsetY = v.roundToInt()) } }
    )

    OutlinedButton(
        onClick = onReset,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Reset posisi ke tengah", color = ObsidianTextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun MacroTabContent(
    config: MacroConfig,
    shizukuStatus: ShizukuStatus,
    accentColor: Color,
    onUpdate: ((MacroConfig) -> MacroConfig) -> Unit,
    onOpenPlacement: () -> Unit,
    onConnectShizuku: () -> Unit
) {
    PanelSwitchRow(
        label = "Aktifkan Macro (Pro Unlocked)",
        checked = config.enabled,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(enabled = v, isRunning = if (!v) false else it.isRunning) } }
    )

    PanelSwitchRow(
        label = "Tombol 2: Auto Ganti Senjata (1 → 2)",
        checked = config.enableTarget2 || config.pattern == MacroPattern.QUICK_SWITCH,
        accentColor = StatusCyan,
        onCheckedChange = { enabled2 ->
            onUpdate {
                it.copy(
                    enableTarget2 = enabled2,
                    showTarget = if (enabled2) true else it.showTarget,
                    pattern = if (enabled2) MacroPattern.QUICK_SWITCH else if (it.pattern == MacroPattern.QUICK_SWITCH) MacroPattern.REPEAT else it.pattern
                )
            }
        }
    )

    if (shizukuStatus.canRunPrivileged) {
        val statusLabel = when {
            shizukuStatus.isRootGranted ->
                "${shizukuStatus.activeEngineLabel.ifBlank { "Root UID 0 (Kernel Slot-9)" }} • 10-Jari Aktif • Zero Stutter"
            shizukuStatus.isKernelMultiTouch ->
                "${shizukuStatus.activeEngineLabel} • 10-Jari Aktif • Zero Cancel"
            shizukuStatus.isInputServiceBound ->
                "${shizukuStatus.activeEngineLabel} • Multi-Pointer Merge Aktif"
            else ->
                "Privileged Aktif • ${shizukuStatus.activeEngineLabel}"
        }
        Text(
            text = statusLabel,
            color = StatusGreen,
            fontSize = 11.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(StatusGreen.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFFFB740).copy(alpha = 0.14f))
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "Macro berjalan mandiri via Opsi 1 (Root) atau Opsi 2 (Shizuku) — tanpa Aksesibilitas.",
                color = Color(0xFFFFB740),
                fontSize = 11.sp
            )
            OutlinedButton(
                onClick = onConnectShizuku,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = when {
                        shizukuStatus.isRootAvailable && !shizukuStatus.isRootGranted -> "Izinkan Root / Hubungkan"
                        shizukuStatus.isRunning -> "Izinkan Shizuku"
                        else -> "Hubungkan Root / Shizuku"
                    },
                    color = ObsidianTextPrimary,
                    fontSize = 11.sp
                )
            }
        }
    }

    Text("Mode Sentuhan (10-Jari Multi-Touch)", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        MacroInjectionMode.entries.forEach { mode ->
            val shortLabel = when (mode) {
                MacroInjectionMode.SMART_POINTER -> "Anti-Bentrok"
                MacroInjectionMode.STYLUS_HYBRID -> "Stylus"
                MacroInjectionMode.TOUCHSCREEN_DIRECT -> "Touch"
            }
            PanelPillOption(
                text = shortLabel,
                selected = config.injectionMode == mode,
                accentColor = StatusCyan,
                modifier = Modifier.weight(1f),
                onClick = { onUpdate { it.copy(injectionMode = mode) } }
            )
        }
    }
    Text(
        text = config.injectionMode.subtitle,
        color = ObsidianTextSecondary,
        fontSize = 10.sp
    )

    Text("Pola Macro", color = ObsidianTextSecondary, fontSize = 11.sp)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
        MacroPattern.entries.chunked(3).forEach { rowPatterns ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                rowPatterns.forEach { p ->
                    PanelPillOption(
                        text = p.label,
                        selected = config.pattern == p,
                        accentColor = if (p == MacroPattern.QUICK_SWITCH) StatusCyan else accentColor,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onUpdate {
                                if (p == MacroPattern.QUICK_SWITCH) {
                                    it.copy(pattern = p, enableTarget2 = true, showTarget = true)
                                } else {
                                    it.copy(pattern = p)
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    if (config.enableTarget2 || config.pattern == MacroPattern.QUICK_SWITCH) {
        PanelSliderRow(
            label = "Jeda Tembak (1) → Senjata (2)",
            valueText = "${config.switchDelayMs} ms",
            value = config.switchDelayMs.toFloat(),
            range = 30f..600f,
            accentColor = StatusCyan,
            onValueChange = { v -> onUpdate { it.copy(switchDelayMs = v.roundToInt()) } }
        )
    }

    val tapsPerSec = (1000f / config.intervalMs.coerceAtLeast(16)).roundToInt()
    PanelSliderRow(
        label = "Interval (${tapsPerSec} siklus/detik)",
        valueText = "${config.intervalMs} ms",
        value = config.intervalMs.toFloat(),
        range = 16f..1000f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(intervalMs = v.roundToInt()) } }
    )

    PanelSliderRow(
        label = "Lama tahan sentuhan",
        valueText = "${config.holdDurationMs} ms",
        value = config.holdDurationMs.toFloat(),
        range = 6f..400f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(holdDurationMs = v.roundToInt()) } }
    )

    PanelSliderRow(
        label = "Ukuran Trigger",
        valueText = String.format(java.util.Locale.US, "%.1fx", config.triggerScale),
        value = config.triggerScale,
        range = 0.7f..1.6f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(triggerScale = v) } }
    )

    PanelSliderRow(
        label = "Jangkauan acak (Anti-detect)",
        valueText = if (config.randomJitterPx == 0) "Off" else "${config.randomJitterPx} px",
        value = config.randomJitterPx.toFloat(),
        range = 0f..20f,
        accentColor = accentColor,
        onValueChange = { v -> onUpdate { it.copy(randomJitterPx = v.roundToInt()) } }
    )

    PanelSwitchRow(
        label = "Tampilkan titik target (1 & 2)",
        checked = config.showTarget,
        accentColor = accentColor,
        onCheckedChange = { v -> onUpdate { it.copy(showTarget = v) } }
    )

    PanelSwitchRow(
        label = "Kunci posisi & transparan",
        checked = config.isLocked,
        accentColor = accentColor,
        onCheckedChange = { locked ->
            onUpdate { it.copy(isLocked = locked, isRunning = false) }
        }
    )

    PanelSwitchRow(
        label = "Mode Tahan Trigger (Hold)",
        checked = config.holdToTrigger,
        accentColor = accentColor,
        onCheckedChange = { hold ->
            onUpdate { it.copy(holdToTrigger = hold, isRunning = false) }
        }
    )

    PanelSliderRow(
        label = "Transparansi saat dikunci",
        valueText = "${(config.lockedOpacity * 100f).roundToInt()}%",
        value = config.lockedOpacity * 100f,
        range = 15f..70f,
        accentColor = accentColor,
        onValueChange = { v ->
            onUpdate { it.copy(lockedOpacity = (v / 100f).coerceIn(0.15f, 0.70f)) }
        }
    )

    Text(
        text = if (shizukuStatus.isKernelMultiTouch) {
            "Kernel 10-Jari Slot-9 Aktif: tahan Trigger dengan 1 jari sambil bebas menggeser layar game dengan jari lainnya secara bersamaan."
        } else {
            "Multi-Touch Shizuku (Tanpa Aksesibilitas): gunakan Smart 10-Jari + lama sentuhan singkat (6–14ms) agar geser layar & brutal tap tetap responsif."
        },
        color = StatusCyan,
        fontSize = 10.sp,
        lineHeight = 13.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(StatusCyan.copy(alpha = 0.10f))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    )

    Button(
        onClick = onOpenPlacement,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = ObsidianCardElevated, contentColor = ObsidianTextPrimary),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Atur & geser posisi (D-Pad)", fontSize = 11.sp)
    }
}

@Composable
private fun BurikTabContent(
    config: BurikConfig,
    accentColor: Color,
    onSelectPreset: (BurikPreset) -> Unit,
    onUpdateConfig: ((BurikConfig) -> BurikConfig) -> Unit,
    onApplyNow: () -> Unit,
    onApplyAndRestart: () -> Unit,
    onRestore: () -> Unit
) {
    val pct = config.effectiveTextureQuality()
    val mip = config.effectiveMipmapLevel()
    val flags = config.angleFeatureFlags()

    Text("ANGLE Texture Low Graphics", color = ObsidianTextSecondary, fontSize = 11.sp)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        BurikPreset.entries.chunked(3).forEach { rowPresets ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                rowPresets.forEach { preset ->
                    PanelPillOption(
                        text = preset.title,
                        selected = config.preset == preset,
                        accentColor = accentColor,
                        modifier = Modifier.weight(1f),
                        onClick = { onSelectPreset(preset) }
                    )
                }
            }
        }
    }

    Text(
        text = if (flags.isEmpty()) {
            "Driver: OpenGL ES bawaan (ANGLE Nonaktif)"
        } else {
            "ANGLE Flags: ${flags.joinToString(":")}"
        },
        color = if (flags.isEmpty()) ObsidianTextSecondary else StatusCyan,
        fontFamily = JetBrainsMono,
        fontSize = 9.sp,
        lineHeight = 13.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ObsidianCardElevated)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    )

    PanelSwitchRow(
        label = "Terapkan ke Semua Game (ANGLE)",
        checked = config.applyAllGames,
        accentColor = accentColor,
        onCheckedChange = { all -> onUpdateConfig { it.copy(applyAllGames = all) } }
    )

    PanelSliderRow(
        label = "Kualitas Tekstur (ANGLE)",
        valueText = "$pct%",
        value = pct.toFloat(),
        range = 15f..100f,
        accentColor = accentColor,
        onValueChange = { v ->
            onUpdateConfig {
                it.copy(preset = BurikPreset.CUSTOM, customTextureQualityPercent = v.roundToInt())
            }
        }
    )

    PanelSliderRow(
        label = "Mipmap / Texture LOD",
        valueText = "Lv $mip",
        value = mip.toFloat(),
        range = 0f..4f,
        accentColor = accentColor,
        onValueChange = { v ->
            onUpdateConfig {
                it.copy(preset = BurikPreset.CUSTOM, customMipmapLevel = v.roundToInt())
            }
        }
    )

    PanelSwitchRow(
        label = "Nearest Filtering (Pixel)",
        checked = config.effectiveNearestFiltering(),
        accentColor = accentColor,
        onCheckedChange = { v ->
            onUpdateConfig {
                it.copy(preset = BurikPreset.CUSTOM, customNearestFiltering = v)
            }
        }
    )

    PanelSwitchRow(
        label = "Nonaktifkan Anisotropic",
        checked = config.effectiveDisableAnisotropic(),
        accentColor = accentColor,
        onCheckedChange = { v ->
            onUpdateConfig {
                it.copy(preset = BurikPreset.CUSTOM, customDisableAnisotropic = v)
            }
        }
    )

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = onApplyNow,
            modifier = Modifier
                .weight(1f)
                .testTag("overlay_apply_burik"),
            colors = ButtonDefaults.buttonColors(containerColor = ObsidianCardElevated, contentColor = ObsidianTextPrimary),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Terapkan", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, maxLines = 1)
        }
        Button(
            onClick = onApplyAndRestart,
            modifier = Modifier
                .weight(1f)
                .testTag("overlay_apply_restart_burik"),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color(0xFF0B0C0F)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Restart Game", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, maxLines = 1)
        }
    }

    OutlinedButton(
        onClick = onRestore,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text("Reset ANGLE Texture Default", color = ObsidianTextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun RadialTabContent(
    radialConfig: RadialConfig,
    hudEnabled: Boolean,
    crosshairEnabled: Boolean,
    macroEnabled: Boolean,
    accentColor: Color,
    onToggleRadial: (Boolean) -> Unit,
    onBoostNow: () -> Unit,
    onToggleHud: () -> Unit,
    onToggleCrosshair: () -> Unit,
    onToggleMacro: () -> Unit
) {
    PanelSwitchRow(
        label = "Tampilkan Tombol Radial",
        checked = radialConfig.enabled,
        accentColor = accentColor,
        onCheckedChange = onToggleRadial
    )

    Text("Aksi Cepat", color = ObsidianTextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        PanelPillOption("Boost RAM", false, accentColor, Modifier.weight(1f), onBoostNow)
        PanelPillOption(
            text = if (crosshairEnabled) "Crosshair ON" else "Crosshair OFF",
            selected = crosshairEnabled,
            accentColor = accentColor,
            modifier = Modifier.weight(1f),
            onClick = onToggleCrosshair
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        PanelPillOption(
            text = if (macroEnabled) "Macro ON" else "Macro OFF",
            selected = macroEnabled,
            accentColor = accentColor,
            modifier = Modifier.weight(1f),
            onClick = onToggleMacro
        )
        PanelPillOption(
            text = if (hudEnabled) "HUD ON" else "HUD OFF",
            selected = hudEnabled,
            accentColor = accentColor,
            modifier = Modifier.weight(1f),
            onClick = onToggleHud
        )
    }
}

@Composable
private fun PanelSwitchRow(
    label: String,
    checked: Boolean,
    accentColor: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = ObsidianTextPrimary,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0B0C0F),
                checkedTrackColor = accentColor,
                uncheckedThumbColor = ObsidianTextSecondary,
                uncheckedTrackColor = ObsidianCardElevated
            )
        )
    }
}

@Composable
private fun PanelSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accentColor: Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = ObsidianTextSecondary, fontSize = 11.sp)
            Text(valueText, color = ObsidianTextPrimary, fontFamily = JetBrainsMono, fontSize = 11.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = ObsidianCardElevated
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}

@Composable
private fun PanelPillOption(
    text: String,
    selected: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) accentColor else ObsidianCardElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color(0xFF0B0C0F) else ObsidianTextPrimary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
