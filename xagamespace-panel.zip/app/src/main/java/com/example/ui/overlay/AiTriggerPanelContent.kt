package com.example.ui.overlay

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.AiTriggerEngine
import com.example.data.BoosterPreferences
import com.example.model.AiTriggerRule
import com.example.model.AiTriggerRuntimeState
import com.example.model.PrivilegeMode
import com.example.model.ShizukuStatus
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianTextPrimary
import com.example.ui.theme.ObsidianTextSecondary
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val RedMagicCrimson = Color(0xFFFF3B30)

@Composable
fun AiTriggerTabContent(
    masterEnabled: Boolean,
    rules: List<AiTriggerRule>,
    draftRule: AiTriggerRule?,
    runtimeState: AiTriggerRuntimeState,
    shizukuStatus: ShizukuStatus,
    privilegeMode: PrivilegeMode = PrivilegeMode.SHIZUKU,
    isPrivilegeReady: Boolean = shizukuStatus.isSelectedModeReady,
    screenWidthPx: Int,
    screenHeightPx: Int,
    accentColor: Color,
    loadTemplateBitmap: (String) -> Bitmap?,
    onToggleMaster: (Boolean) -> Unit,
    onRequestProjection: () -> Unit,
    onRequestRoot: () -> Unit = {},
    onConnectShizuku: () -> Unit,
    onStartCreateNew: () -> Unit,
    onEditRule: (AiTriggerRule) -> Unit,
    onToggleRule: (String, Boolean) -> Unit,
    onDeleteRule: (String) -> Unit,
    onUpdateDraft: ((AiTriggerRule) -> AiTriggerRule) -> Unit,
    onCancelDraft: () -> Unit,
    onSaveDraft: (AiTriggerRule) -> Unit,
    onOpenCropOverlay: (AiTriggerRule) -> Unit,
    onOpenTargetPicker: (AiTriggerRule) -> Unit,
    onSetPanelFocusable: (Boolean) -> Unit
) {
    if (draftRule != null) {
        AiTriggerEditorView(
            draft = draftRule,
            screenWidthPx = screenWidthPx,
            screenHeightPx = screenHeightPx,
            accentColor = accentColor,
            loadTemplateBitmap = loadTemplateBitmap,
            onUpdateDraft = onUpdateDraft,
            onCancel = {
                onSetPanelFocusable(false)
                onCancelDraft()
            },
            onSave = { rule ->
                onSetPanelFocusable(false)
                onSaveDraft(rule)
            },
            onOpenCropOverlay = { rule ->
                onSetPanelFocusable(false)
                onOpenCropOverlay(rule)
            },
            onOpenTargetPicker = { rule ->
                onSetPanelFocusable(false)
                onOpenTargetPicker(rule)
            },
            onSetPanelFocusable = onSetPanelFocusable
        )
        return
    }

    DisposableEffect(Unit) {
        onDispose { onSetPanelFocusable(false) }
    }

    // --- 2-Step AI Trigger Header & List (0/5 .. 5/5) ---
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "AI Trigger",
                    color = ObsidianTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${rules.size}/5",
                    color = RedMagicCrimson,
                    fontFamily = JetBrainsMono,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(RedMagicCrimson.copy(alpha = 0.16f))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
            Text(
                text = "1) Crop musuh • 2) Luruskan aim tengah ke kepala musuh",
                color = ObsidianTextSecondary,
                fontSize = 10.sp
            )
        }
        Switch(
            checked = masterEnabled,
            onCheckedChange = onToggleMaster,
            modifier = Modifier.testTag("overlay_ai_trigger_master"),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = RedMagicCrimson,
                uncheckedThumbColor = ObsidianTextSecondary,
                uncheckedTrackColor = ObsidianCardElevated
            )
        )
    }

    // Engine & permission readiness card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated)
            .border(
                1.dp,
                when {
                    runtimeState.hasProjectionPermission && isPrivilegeReady -> StatusGreen.copy(alpha = 0.45f)
                    runtimeState.isCapturing -> StatusCyan.copy(alpha = 0.45f)
                    else -> StatusAmber.copy(alpha = 0.45f)
                },
                RoundedCornerShape(10.dp)
            )
            .padding(9.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Layar: ${runtimeState.captureEngineLabel}",
                color = if (runtimeState.hasProjectionPermission) StatusGreen else StatusAmber,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = runtimeState.lastTouchEngineStatus,
                color = if (isPrivilegeReady) StatusCyan else StatusAmber,
                fontSize = 9.sp,
                fontFamily = JetBrainsMono
            )
        }

        if (masterEnabled || runtimeState.isCapturing) {
            val latencyText = if (runtimeState.scanLatencyMs > 0) " • ${runtimeState.scanLatencyMs}ms" else ""
            Text(
                text = when {
                    runtimeState.crosshairTouchingBody || runtimeState.isAimingToHead ->
                        "LOCK KEPALA ${runtimeState.lastMatchScore}% (${runtimeState.triggerCount}x)$latencyText"
                    runtimeState.isMatched ->
                        "Musuh terdeteksi (${runtimeState.lastMatchScore}%)$latencyText • Mengunci ke kepala"
                    else ->
                        "Memindai ${runtimeState.activeRulesCount} target • Skor ${runtimeState.lastMatchScore}%$latencyText"
                },
                color = when {
                    runtimeState.crosshairTouchingBody || runtimeState.isAimingToHead -> StatusGreen
                    runtimeState.isMatched -> StatusAmber
                    else -> ObsidianTextSecondary
                },
                fontSize = 10.sp,
                fontFamily = JetBrainsMono,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (!runtimeState.lastError.isNullOrBlank()) {
            Text(
                text = runtimeState.lastError,
                color = StatusAmber,
                fontSize = 9.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (!runtimeState.hasProjectionPermission) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(RedMagicCrimson)
                    .clickable(onClick = onRequestProjection)
                    .padding(vertical = 6.dp)
                    .testTag("overlay_ai_grant_projection"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Izinkan Rekam Layar",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        if (!isPrivilegeReady) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianCard)
                        .border(
                            1.dp,
                            if (privilegeMode == PrivilegeMode.ROOT) StatusGreen.copy(alpha = 0.8f) else StatusGreen.copy(alpha = 0.45f),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(onClick = onRequestRoot)
                        .padding(vertical = 6.dp)
                        .testTag("overlay_ai_request_root"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Opsi 1: Root",
                        color = StatusGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianCard)
                        .border(
                            1.dp,
                            if (privilegeMode == PrivilegeMode.SHIZUKU) StatusCyan.copy(alpha = 0.8f) else StatusAmber.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(onClick = onConnectShizuku)
                        .padding(vertical = 6.dp)
                        .testTag("overlay_ai_connect_shizuku"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Opsi 2: Shizuku",
                        color = if (privilegeMode == PrivilegeMode.SHIZUKU) StatusCyan else StatusAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    if (rules.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ObsidianCard)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = AppIcons.AiTrigger,
                contentDescription = "AI Trigger",
                tint = RedMagicCrimson,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = "Belum ada Target Musuh",
                color = ObsidianTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Langkah 1: Crop musuh. Langkah 2: Luruskan aim merah tepat di kepala musuh agar crosshair game otomatis menempel walau layar digeser.",
                color = ObsidianTextSecondary,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rules.forEach { rule ->
                AiTriggerRuleRowCard(
                    rule = rule,
                    loadTemplateBitmap = loadTemplateBitmap,
                    onEdit = { onEditRule(rule) },
                    onToggle = { enabled -> onToggleRule(rule.id, enabled) },
                    onDelete = { onDeleteRule(rule.id) }
                )
            }
        }
    }

    Button(
        onClick = onStartCreateNew,
        enabled = rules.size < 5,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("overlay_ai_add_rule"),
        colors = ButtonDefaults.buttonColors(
            containerColor = RedMagicCrimson,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (rules.size >= 5) "Maksimum 5 AI Trigger" else "Tambah AI Trigger",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun AiTriggerRuleRowCard(
    rule: AiTriggerRule,
    loadTemplateBitmap: (String) -> Bitmap?,
    onEdit: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    val thumb = remember(rule.templatePath, rule.templateWidth, rule.templateHeight) {
        loadTemplateBitmap(rule.templatePath)?.asImageBitmap()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(
                1.dp,
                if (rule.enabled) RedMagicCrimson.copy(alpha = 0.55f) else ObsidianBorder,
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onEdit)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(ObsidianCardElevated)
                .clickable(onClick = onEdit),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Edit,
                contentDescription = "Edit ${rule.name}",
                tint = ObsidianTextSecondary,
                modifier = Modifier.size(14.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0A0C10))
                .border(1.dp, ObsidianBorder, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (thumb != null) {
                Image(
                    bitmap = thumb,
                    contentDescription = rule.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = AppIcons.AiTrigger,
                    contentDescription = rule.name,
                    tint = ObsidianTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = rule.name,
                color = ObsidianTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Presisi ${rule.matchPrecision} • Tarik ${rule.headLiftPower}%",
                color = ObsidianTextSecondary,
                fontSize = 9.sp,
                fontFamily = JetBrainsMono,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Titik Kepala (${rule.headOffsetXPercent}%, ${rule.headOffsetPercent}%)",
                color = RedMagicCrimson,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }

        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(ObsidianCardElevated)
                .clickable(onClick = onDelete),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Hapus ${rule.name}",
                tint = ObsidianTextSecondary,
                modifier = Modifier.size(13.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(if (rule.enabled) RedMagicCrimson else ObsidianCardElevated)
                .border(
                    1.5.dp,
                    if (rule.enabled) RedMagicCrimson else ObsidianBorder,
                    CircleShape
                )
                .clickable { onToggle(!rule.enabled) }
                .testTag("overlay_ai_rule_toggle_${rule.id}"),
            contentAlignment = Alignment.Center
        ) {
            if (rule.enabled) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = "Aktif",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun AiTriggerEditorView(
    draft: AiTriggerRule,
    screenWidthPx: Int,
    screenHeightPx: Int,
    accentColor: Color,
    loadTemplateBitmap: (String) -> Bitmap?,
    onUpdateDraft: ((AiTriggerRule) -> AiTriggerRule) -> Unit,
    onCancel: () -> Unit,
    onSave: (AiTriggerRule) -> Unit,
    onOpenCropOverlay: (AiTriggerRule) -> Unit,
    onOpenTargetPicker: (AiTriggerRule) -> Unit,
    onSetPanelFocusable: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) { BoosterPreferences.getInstance(context) }
    val scope = rememberCoroutineScope()
    var isTesting by remember { mutableStateOf(false) }
    var testFeedback by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    val thumb = remember(draft.templatePath, draft.templateWidth, draft.templateHeight) {
        loadTemplateBitmap(draft.templatePath)?.asImageBitmap()
    }
    val crossPxX = (draft.gameCrosshairNormX * screenWidthPx.coerceAtLeast(1)).roundToInt()
    val crossPxY = (draft.gameCrosshairNormY * screenHeightPx.coerceAtLeast(1)).roundToInt()

    Text(
        text = "Pengaturan Aim Kepala (2 Langkah)",
        color = ObsidianTextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
    )

    // Nama Rule
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Nama", color = ObsidianTextSecondary, fontSize = 11.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ObsidianCardElevated)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            BasicTextField(
                value = draft.name,
                onValueChange = { text -> onUpdateDraft { it.copy(name = text.take(28)) } },
                singleLine = true,
                textStyle = TextStyle(
                    color = ObsidianTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                ),
                cursorBrush = SolidColor(RedMagicCrimson),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { state -> onSetPanelFocusable(state.isFocused) }
            )
        }
    }

    // STEP 1: Crop Musuh
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated)
            .border(1.dp, if (thumb != null) StatusGreen.copy(alpha = 0.45f) else ObsidianBorder, RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Langkah 1: Crop Musuh",
                color = ObsidianTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(RedMagicCrimson)
                    .clickable { onOpenCropOverlay(draft) }
                    .padding(horizontal = 12.dp, vertical = 5.dp)
                    .testTag("overlay_ai_pick_crop")
            ) {
                Text(
                    text = if (thumb != null) "Crop Ulang" else "+ Crop Musuh",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0A0C10))
                    .border(
                        1.dp,
                        if (thumb != null) StatusGreen.copy(alpha = 0.65f) else StatusAmber.copy(alpha = 0.6f),
                        RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (thumb != null) {
                    Image(
                        bitmap = thumb,
                        contentDescription = "Preview Badan Musuh",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = AppIcons.AiTrigger,
                        contentDescription = "Belum Crop",
                        tint = ObsidianTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = if (thumb != null) "Gambar Musuh Siap" else "Belum Ada Crop Musuh",
                    color = if (thumb != null) StatusGreen else StatusAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (thumb != null && draft.templateWidth > 0) {
                        "${draft.templateWidth}x${draft.templateHeight} px • Siap diluruskan ke kepala"
                    } else {
                        "Ketuk '+ Crop Musuh' lalu kotakkan badan musuh"
                    },
                    color = ObsidianTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = JetBrainsMono
                )
            }
        }
    }

    // STEP 2: Luruskan Aim Tambahan ke Kepala Musuh
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated)
            .border(1.dp, RedMagicCrimson.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Langkah 2: Luruskan Aim ke Kepala Musuh",
            color = ObsidianTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Sentuh/geser titik MERAH tepat di kepala musuh agar crosshair tengah game terus mengikuti kepala walau layar digeser.",
            color = ObsidianTextSecondary,
            fontSize = 9.sp,
            lineHeight = 13.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Interactive head-alignment canvas right inside the panel
            Box(
                modifier = Modifier
                    .width(96.dp)
                    .height(132.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A0C10))
                    .border(1.5.dp, StatusGreen.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                    .pointerInput(draft.id) {
                        detectTapGestures { pos ->
                            val xPct = ((pos.x / size.width.coerceAtLeast(1)) * 100f).roundToInt().coerceIn(10, 90)
                            val yPct = ((pos.y / size.height.coerceAtLeast(1)) * 100f).roundToInt().coerceIn(5, 55)
                            onUpdateDraft { it.copy(headOffsetXPercent = xPct, headOffsetPercent = yPct) }
                        }
                    }
                    .pointerInput(draft.id) {
                        detectDragGestures { change, _ ->
                            change.consume()
                            val xPct = ((change.position.x / size.width.coerceAtLeast(1)) * 100f).roundToInt().coerceIn(10, 90)
                            val yPct = ((change.position.y / size.height.coerceAtLeast(1)) * 100f).roundToInt().coerceIn(5, 55)
                            onUpdateDraft { it.copy(headOffsetXPercent = xPct, headOffsetPercent = yPct) }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (thumb != null) {
                    Image(
                        bitmap = thumb,
                        contentDescription = "Atur Titik Kepala Musuh",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val hx = size.width * (draft.headOffsetXPercent / 100f)
                    val hy = size.height * (draft.headOffsetPercent / 100f)
                    val cx = size.width * 0.50f
                    val cy = size.height * 0.50f

                    // Dashed green alignment line from center crosshair to aligned head dot
                    drawLine(
                        color = StatusGreen,
                        start = Offset(cx, cy),
                        end = Offset(hx, hy),
                        strokeWidth = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    )
                    // Center crosshair reticle (Cyan)
                    drawCircle(color = StatusCyan, radius = 9f, center = Offset(cx, cy), style = Stroke(width = 2.5f))
                    // Red hairlines & Head-Aim dot
                    drawLine(color = RedMagicCrimson.copy(alpha = 0.85f), start = Offset(0f, hy), end = Offset(size.width, hy), strokeWidth = 2f)
                    drawLine(color = RedMagicCrimson.copy(alpha = 0.85f), start = Offset(hx, 0f), end = Offset(hx, size.height), strokeWidth = 2f)
                    drawCircle(color = RedMagicCrimson.copy(alpha = 0.35f), radius = 16f, center = Offset(hx, hy))
                    drawCircle(color = RedMagicCrimson, radius = 8f, center = Offset(hx, hy))
                    drawCircle(color = Color.White, radius = 8f, center = Offset(hx, hy), style = Stroke(width = 2f))
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Titik Kepala: X ${draft.headOffsetXPercent}% • Y ${draft.headOffsetPercent}%",
                    color = RedMagicCrimson,
                    fontFamily = JetBrainsMono,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Crosshair: ($crossPxX, $crossPxY)",
                    color = StatusCyan,
                    fontFamily = JetBrainsMono,
                    fontSize = 9.sp
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(RedMagicCrimson.copy(alpha = 0.16f))
                        .border(1.dp, RedMagicCrimson.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                        .clickable { onOpenTargetPicker(draft) }
                        .padding(horizontal = 8.dp, vertical = 7.dp)
                        .testTag("overlay_ai_pick_target"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Luruskan di Layar",
                        color = RedMagicCrimson,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isTesting) ObsidianCard else StatusGreen.copy(alpha = 0.16f))
                        .border(
                            1.dp,
                            if (isTesting) ObsidianBorder else StatusGreen.copy(alpha = 0.65f),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(enabled = !isTesting) {
                            isTesting = true
                            scope.launch {
                                testFeedback = AiTriggerEngine.testHeadTriggerSwipe(context, prefs, draft)
                                isTesting = false
                            }
                        }
                        .padding(horizontal = 8.dp, vertical = 7.dp)
                        .testTag("overlay_ai_test_swipe"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isTesting) "Menguji..." else "Tes Tarik Aim",
                        color = if (isTesting) ObsidianTextSecondary else StatusGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        testFeedback?.let { (ok, msg) ->
            Text(
                text = msg,
                color = if (ok) StatusGreen else StatusAmber,
                fontSize = 9.sp,
                lineHeight = 12.sp
            )
        }
    }

    // Calibration sliders
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Presisi Pencocokan", color = ObsidianTextSecondary, fontSize = 10.sp)
            Text("${draft.matchPrecision}", color = ObsidianTextPrimary, fontFamily = JetBrainsMono, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = draft.matchPrecision.toFloat(),
            onValueChange = { v -> onUpdateDraft { it.copy(matchPrecision = v.roundToInt().coerceIn(60, 100)) } },
            valueRange = 60f..100f,
            colors = SliderDefaults.colors(
                thumbColor = RedMagicCrimson,
                activeTrackColor = RedMagicCrimson,
                inactiveTrackColor = ObsidianCardElevated
            ),
            modifier = Modifier.height(26.dp)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Kekuatan Nempel ke Kepala", color = ObsidianTextSecondary, fontSize = 10.sp)
            Text("${draft.headLiftPower}%", color = accentColor, fontFamily = JetBrainsMono, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = draft.headLiftPower.toFloat(),
            onValueChange = { v -> onUpdateDraft { it.copy(headLiftPower = v.roundToInt().coerceIn(50, 220)) } },
            valueRange = 50f..220f,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = ObsidianCardElevated
            ),
            modifier = Modifier.height(26.dp)
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated)
            .border(
                1.dp,
                if (draft.autoTriggerAllZones) StatusGreen.copy(alpha = 0.55f) else ObsidianBorder,
                RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Magnet Zona Tengah", color = ObsidianTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(
                text = "Tetap menempel ke kepala walau layar sedang digeser",
                color = ObsidianTextSecondary,
                fontSize = 9.sp
            )
        }
        Switch(
            checked = draft.autoTriggerAllZones,
            onCheckedChange = { onUpdateDraft { d -> d.copy(autoTriggerAllZones = it) } },
            modifier = Modifier.testTag("overlay_ai_magnet_all_zones"),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0B0C0F),
                checkedTrackColor = StatusGreen,
                uncheckedThumbColor = ObsidianTextSecondary,
                uncheckedTrackColor = ObsidianCard
            )
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated)
            .border(
                1.dp,
                if (draft.showLiveHud) StatusCyan.copy(alpha = 0.5f) else ObsidianBorder,
                RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("HUD Visual Kepala", color = ObsidianTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(
                text = "Tampilkan kotak musuh & titik kepala saat terkunci",
                color = ObsidianTextSecondary,
                fontSize = 9.sp
            )
        }
        Switch(
            checked = draft.showLiveHud,
            onCheckedChange = { onUpdateDraft { d -> d.copy(showLiveHud = it) } },
            modifier = Modifier.testTag("overlay_ai_show_hud"),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0B0C0F),
                checkedTrackColor = StatusCyan,
                uncheckedThumbColor = ObsidianTextSecondary,
                uncheckedTrackColor = ObsidianCard
            )
        )
    }

    Spacer(modifier = Modifier.height(2.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Batal", color = ObsidianTextPrimary, fontSize = 12.sp)
        }
        Button(
            onClick = { onSave(draft) },
            enabled = draft.hasValidTemplate(),
            modifier = Modifier
                .weight(1f)
                .testTag("overlay_ai_save_rule"),
            colors = ButtonDefaults.buttonColors(
                containerColor = RedMagicCrimson,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Simpan", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
