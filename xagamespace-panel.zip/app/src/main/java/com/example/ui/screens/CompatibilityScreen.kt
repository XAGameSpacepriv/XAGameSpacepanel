package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CompatibilityReport
import com.example.model.PrivilegeMode
import com.example.model.RootGrantState
import com.example.ui.components.SectionLabel
import com.example.ui.components.SubScreenTopBar
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed

@Composable
fun CompatibilityScreen(
    report: CompatibilityReport,
    privilegeMode: PrivilegeMode = PrivilegeMode.SHIZUKU,
    onSelectPrivilegeMode: (PrivilegeMode) -> Unit = {},
    onRefresh: () -> Unit,
    onGrantOverlay: () -> Unit,
    onGrantUsageAccess: () -> Unit,
    onGrantShizuku: () -> Unit,
    onGrantRoot: () -> Unit = {},
    onGrantWriteSettings: () -> Unit,
    onGrantDnd: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
    ) {
        SubScreenTopBar(title = "Kompatibilitas & Diagnostik", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(report.deviceModel, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        text = "${report.androidVersionLabel}  •  ${report.refreshRateHz} Hz",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = JetBrainsMono,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "GameManager API: ${if (report.gameManagerSupported) "Didukung (Android 12+)" else "Mode Legacy"}",
                        color = if (report.gameManagerSupported) StatusGreen else StatusAmber,
                        fontSize = 12.sp
                    )
                    val activeReady = when (privilegeMode) {
                        PrivilegeMode.ROOT -> report.shizukuStatus.isRootGranted
                        PrivilegeMode.SHIZUKU -> report.shizukuStatus.canRunShizuku
                    }
                    Text(
                        text = "Mode Aktif: ${privilegeMode.label} • ${report.shizukuStatus.activeEngineLabel}",
                        color = if (activeReady) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = JetBrainsMono,
                        fontSize = 11.sp
                    )
                }
            }

            // 2-Option Selector Card (Root vs Shizuku)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Pilih Salah Satu Mode Akses",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isRootSel = privilegeMode == PrivilegeMode.ROOT
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isRootSel) StatusGreen.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .border(
                                    1.dp,
                                    if (isRootSel) StatusGreen else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectPrivilegeMode(PrivilegeMode.ROOT) }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                .testTag("compat_option_root"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Opsi 1: Root (UID 0)",
                                color = if (isRootSel) StatusGreen else MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (!isRootSel) StatusCyan.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .border(
                                    1.dp,
                                    if (!isRootSel) StatusCyan else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectPrivilegeMode(PrivilegeMode.SHIZUKU) }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                .testTag("compat_option_shizuku"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Opsi 2: Shizuku",
                                color = if (!isRootSel) StatusCyan else MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item { SectionLabel("Izin inti") }

            item {
                PermissionRowCard(
                    title = "Tampilkan di atas aplikasi lain (Overlay)",
                    subtitle = "Wajib untuk Performance HUD, Crosshair, Macro & Panel",
                    granted = report.overlayGranted,
                    actionLabel = "Izinkan",
                    onAction = onGrantOverlay,
                    testTag = "perm_row_overlay"
                )
            }
            item {
                val st = report.shizukuStatus
                val isRootSelected = privilegeMode == PrivilegeMode.ROOT
                val mgr = st.rootManagerLabel.ifBlank { "Superuser" }
                val rootStatusText = when {
                    !isRootSelected -> "TIDAK WAJIB (OPSI 1 ALTERNATIF)"
                    st.isRootGranted -> "AKTIF (UID 0 • $mgr)"
                    st.rootGrantState == RootGrantState.DENIED -> "DITOLAK"
                    st.rootGrantState == RootGrantState.AVAILABLE_NOT_GRANTED -> "PERLU IZIN"
                    else -> "BELUM AKTIF"
                }
                val rootStatusColor = when {
                    !isRootSelected -> MaterialTheme.colorScheme.onSurfaceVariant
                    st.isRootGranted -> StatusGreen
                    st.rootGrantState == RootGrantState.DENIED -> StatusRed
                    st.rootGrantState == RootGrantState.AVAILABLE_NOT_GRANTED -> StatusAmber
                    else -> StatusAmber
                }
                val rootSubtitle = when {
                    !isRootSelected ->
                        "Tidak diperlukan karena Mode Shizuku (Opsi 2) sedang dipakai. Ketuk 'Pakai Root' bila ingin beralih."
                    st.isRootGranted ->
                        "UID 0 aktif • Semua fitur (Touch, Macro, AI Trigger, Thermal Max, Bypass Charging) jalan penuh tanpa Shizuku."
                    st.rootGrantState == RootGrantState.DENIED ->
                        "Izin Root ditolak di $mgr. Buka Magisk / KernelSU / APatch lalu izinkan XAGameSpacepanel."
                    st.rootGrantState == RootGrantState.AVAILABLE_NOT_GRANTED ->
                        "$mgr terdeteksi. Ketuk Minta Root untuk membuka dialog perizinan Superuser (tanpa Shizuku)."
                    else ->
                        "Binary su belum terdeteksi. Ketuk Minta Root untuk cek ulang, atau beralih ke Opsi 2: Shizuku."
                }
                PermissionRowCard(
                    title = "Opsi 1: Akses Root (Magisk / KernelSU / APatch)",
                    subtitle = rootSubtitle,
                    granted = isRootSelected && st.isRootGranted,
                    statusLabel = rootStatusText,
                    statusColor = rootStatusColor,
                    actionLabel = when {
                        !isRootSelected -> "Pakai Root"
                        st.rootGrantState == RootGrantState.DENIED -> "Coba Lagi"
                        else -> "Minta Root"
                    },
                    onAction = onGrantRoot,
                    testTag = "perm_row_root"
                )
            }
            item {
                val isShizukuSelected = privilegeMode == PrivilegeMode.SHIZUKU
                val shizukuReady = report.shizukuStatus.canRunShizuku
                PermissionRowCard(
                    title = "Opsi 2: Shizuku Input Engine & ADB Shell",
                    subtitle = if (isShizukuSelected) {
                        "Mode Non-Root aktif: Macro 10-Jari, Touch X/Y, Thermal, Compile ART & Debloat tanpa Root."
                    } else {
                        "Tidak wajib karena Mode Root (Opsi 1) sedang dipakai. Ketuk 'Pakai Shizuku' bila ingin beralih."
                    },
                    granted = isShizukuSelected && shizukuReady,
                    statusLabel = when {
                        !isShizukuSelected -> "TIDAK WAJIB (OPSI 2 ALTERNATIF)"
                        shizukuReady -> "AKTIF (NON-ROOT)"
                        else -> "BELUM AKTIF"
                    },
                    statusColor = when {
                        !isShizukuSelected -> MaterialTheme.colorScheme.onSurfaceVariant
                        shizukuReady -> StatusGreen
                        else -> StatusAmber
                    },
                    actionLabel = if (isShizukuSelected) "Hubungkan" else "Pakai Shizuku",
                    onAction = onGrantShizuku,
                    testTag = "perm_row_shizuku"
                )
            }
            item {
                PermissionRowCard(
                    title = "Akses Penggunaan (Usage Access)",
                    subtitle = "Deteksi otomatis saat keluar dari game (otomatis diizinkan jika Root / Shizuku aktif)",
                    granted = report.usageStatsGranted,
                    actionLabel = "Aktifkan",
                    onAction = onGrantUsageAccess,
                    testTag = "perm_row_usage"
                )
            }
            item {
                PermissionRowCard(
                    title = "Akses Jangan Ganggu (DND)",
                    subtitle = "Opsional untuk memblokir notifikasi saat sesi game",
                    granted = report.dndGranted,
                    actionLabel = "Atur",
                    onAction = onGrantDnd,
                    testTag = "perm_row_dnd"
                )
            }
            item {
                PermissionRowCard(
                    title = "Ubah Pengaturan Sistem",
                    subtitle = "Opsional untuk penyesuaian layar & kecerahan cepat",
                    granted = report.writeSettingsGranted,
                    actionLabel = "Izinkan",
                    onAction = onGrantWriteSettings,
                    testTag = "perm_row_write_settings"
                )
            }

            item {
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onRefresh,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("btn_refresh_compat")
                ) {
                    Text("Periksa ulang semua status")
                }
            }
        }
    }
}

@Composable
private fun PermissionRowCard(
    title: String,
    subtitle: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
    testTag: String = "",
    statusLabel: String? = null,
    statusColor: Color? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = statusLabel ?: if (granted) "AKTIF" else "BELUM AKTIF",
                color = statusColor ?: if (granted) StatusGreen else StatusAmber,
                fontFamily = JetBrainsMono,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
        if (!granted) {
            Button(
                onClick = onAction,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.defaultMinSize(minHeight = 48.dp)
            ) {
                Text(actionLabel, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
