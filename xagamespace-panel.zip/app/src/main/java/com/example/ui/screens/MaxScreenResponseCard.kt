package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MaxScreenResponseConfig
import com.example.model.ScreenResponseLevel
import com.example.model.ScreenResponseStatus
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen

@Composable
internal fun MaxScreenResponseCard(
    config: MaxScreenResponseConfig,
    status: ScreenResponseStatus,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectLevel: (ScreenResponseLevel) -> Unit,
    onUpdateConfig: ((MaxScreenResponseConfig) -> MaxScreenResponseConfig) -> Unit,
    onApplyNow: () -> Unit,
    onProbeHardware: () -> Unit
) {
    val accent = when {
        !config.enabled -> MaterialTheme.colorScheme.primary
        config.level == ScreenResponseLevel.MAX_ULTRA -> StatusCyan
        config.level == ScreenResponseLevel.ESPORT -> StatusGreen
        else -> StatusAmber
    }
    val borderColor = if (config.enabled) accent.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(20.dp))
            .testTag("card_max_screen_response"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            accent.copy(alpha = if (config.enabled) 0.14f else 0.04f),
                            MaterialTheme.colorScheme.surfaceContainerLow
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header + Master Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(accent.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.EsportTurbo,
                            contentDescription = "Responsif Layar Max",
                            tint = accent,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Responsif Layar Max",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (config.enabled) "MAX ${status.detectedMaxHz}Hz" else "BARU",
                                color = accent,
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(accent.copy(alpha = 0.16f))
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = if (config.enabled) {
                                "${config.level.label} • ${status.longPressMs}ms • Slop ${status.touchSlopPx}px • Tanpa ubah DPI"
                            } else {
                                "Polling Max, Zero-Delay Input, ${status.detectedMaxHz}Hz & Low-Latency Display"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Switch(
                    checked = config.enabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        checkedTrackColor = accent
                    ),
                    modifier = Modifier.testTag("toggle_max_screen_response")
                )
            }

            // 3 Level Selector Pills (48dp touch targets)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ScreenResponseLevel.entries.forEach { lvl ->
                    val selected = config.enabled && config.level == lvl
                    val pillAccent = when (lvl) {
                        ScreenResponseLevel.FAST -> StatusAmber
                        ScreenResponseLevel.ESPORT -> StatusGreen
                        ScreenResponseLevel.MAX_ULTRA -> StatusCyan
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selected) pillAccent
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (selected) pillAccent
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectLevel(lvl) }
                            .padding(horizontal = 6.dp, vertical = 6.dp)
                            .testTag("screen_resp_level_${lvl.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = lvl.label,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${lvl.longPressMs}ms • ${lvl.touchSlopPx}px",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 9.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // 6 Modular Hardware Pipeline Feature Toggles (2 rows of 3)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PipelineFeatureChip(
                        label = "Max ${status.detectedMaxHz}Hz",
                        checked = config.maxRefreshSync,
                        accent = accent,
                        testTag = "chip_resp_max_hz",
                        onClick = { onUpdateConfig { it.copy(maxRefreshSync = !it.maxRefreshSync) } },
                        modifier = Modifier.weight(1f)
                    )
                    PipelineFeatureChip(
                        label = "Zero Delay",
                        checked = config.zeroTouchDelay,
                        accent = accent,
                        testTag = "chip_resp_zero_delay",
                        onClick = { onUpdateConfig { it.copy(zeroTouchDelay = !it.zeroTouchDelay) } },
                        modifier = Modifier.weight(1f)
                    )
                    PipelineFeatureChip(
                        label = "Polling Max",
                        checked = config.maxTouchPolling,
                        accent = accent,
                        testTag = "chip_resp_polling",
                        onClick = { onUpdateConfig { it.copy(maxTouchPolling = !it.maxTouchPolling) } },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PipelineFeatureChip(
                        label = "Low-Lat SF",
                        checked = config.lowLatencySurfaceFlinger,
                        accent = accent,
                        testTag = "chip_resp_sf",
                        onClick = { onUpdateConfig { it.copy(lowLatencySurfaceFlinger = !it.lowLatencySurfaceFlinger) } },
                        modifier = Modifier.weight(1f)
                    )
                    PipelineFeatureChip(
                        label = "Anti-Edge",
                        checked = config.disableEdgeRejection,
                        accent = accent,
                        testTag = "chip_resp_edge",
                        onClick = { onUpdateConfig { it.copy(disableEdgeRejection = !it.disableEdgeRejection) } },
                        modifier = Modifier.weight(1f)
                    )
                    PipelineFeatureChip(
                        label = "CPU Boost",
                        checked = config.cpuInputBoost,
                        accent = accent,
                        testTag = "chip_resp_cpu_boost",
                        onClick = { onUpdateConfig { it.copy(cpuInputBoost = !it.cpuInputBoost) } },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Live Telemetry Status Readout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) {
                Text(
                    text = status.detail.ifBlank {
                        "Panel ${status.detectedMaxHz}Hz • Mode ${config.level.label} siap diterapkan."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onProbeHardware,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("btn_probe_screen_response")
                ) {
                    Text("Cek Hardware", fontSize = 12.sp)
                }
                Button(
                    onClick = onApplyNow,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accent,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("btn_apply_screen_response")
                ) {
                    Text(
                        text = if (config.enabled) "Terapkan Ulang" else "Aktifkan Max",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PipelineFeatureChip(
    label: String,
    checked: Boolean,
    accent: androidx.compose.ui.graphics.Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (checked) accent.copy(alpha = 0.18f)
                else MaterialTheme.colorScheme.surfaceContainerHigh
            )
            .border(
                width = 1.dp,
                color = if (checked) accent.copy(alpha = 0.65f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.22f),
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (checked) "✓ $label" else label,
            color = if (checked) accent else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp,
            fontWeight = if (checked) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
