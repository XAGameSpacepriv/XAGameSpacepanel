package com.example.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Lightweight custom ImageVector icons replacing material-icons-extended (~12MB+)
 * to keep XAGameSpacepanel APK ultra-compact (under 7MB).
 */
object AppIcons {

    val Bolt: ImageVector by lazy {
        vector("Bolt") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(13f, 2f)
                lineTo(4f, 14f)
                horizontalLineTo(11f)
                lineTo(10f, 22f)
                lineTo(20f, 10f)
                horizontalLineTo(13f)
                close()
            }
        }
    }

    val HudOverlay: ImageVector by lazy {
        vector("HudOverlay") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(3f, 5f)
                horizontalLineTo(21f)
                verticalLineTo(19f)
                horizontalLineTo(3f)
                close()
                moveTo(7f, 10f)
                horizontalLineTo(17f)
                moveTo(7f, 14f)
                horizontalLineTo(12f)
            }
        }
    }

    val Touch: ImageVector by lazy {
        vector("Touch") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 11f)
                verticalLineTo(4f)
                arcTo(2f, 2f, 0f, false, true, 16f, 4f)
                verticalLineTo(12f)
                moveTo(8.5f, 13f)
                verticalLineTo(10f)
                arcTo(2f, 2f, 0f, false, true, 12f, 10f)
                moveTo(16f, 11f)
                lineTo(19f, 12.5f)
                curveTo(20f, 13f, 20.5f, 14f, 20.2f, 15.5f)
                lineTo(19f, 20f)
                horizontalLineTo(9f)
                lineTo(6.5f, 15.5f)
                curveTo(5.8f, 14.3f, 6.8f, 13f, 8.2f, 13.5f)
                lineTo(10f, 14.5f)
            }
        }
    }

    val Macro: ImageVector by lazy {
        vector("Macro") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(17f, 2f)
                lineTo(21f, 6f)
                lineTo(17f, 10f)
                moveTo(3f, 11f)
                verticalLineTo(9f)
                arcTo(4f, 4f, 0f, false, true, 7f, 5f)
                horizontalLineTo(21f)
                moveTo(7f, 22f)
                lineTo(3f, 18f)
                lineTo(7f, 14f)
                moveTo(21f, 13f)
                verticalLineTo(15f)
                arcTo(4f, 4f, 0f, false, true, 17f, 19f)
                horizontalLineTo(3f)
            }
        }
    }

    val AiTrigger: ImageVector by lazy {
        vector("AiTrigger") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 8f)
                verticalLineTo(5f)
                horizontalLineTo(8f)
                moveTo(16f, 5f)
                horizontalLineTo(20f)
                verticalLineTo(8f)
                moveTo(20f, 16f)
                verticalLineTo(19f)
                horizontalLineTo(16f)
                moveTo(8f, 19f)
                horizontalLineTo(4f)
                verticalLineTo(16f)
                moveTo(12f, 8.5f)
                lineTo(13.2f, 10.8f)
                lineTo(15.5f, 12f)
                lineTo(13.2f, 13.2f)
                lineTo(12f, 15.5f)
                lineTo(10.8f, 13.2f)
                lineTo(8.5f, 12f)
                lineTo(10.8f, 10.8f)
                close()
            }
        }
    }

    val Crosshair: ImageVector by lazy {
        vector("Crosshair") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 2f)
                verticalLineTo(6f)
                moveTo(12f, 18f)
                verticalLineTo(22f)
                moveTo(2f, 12f)
                horizontalLineTo(6f)
                moveTo(18f, 12f)
                horizontalLineTo(22f)
                moveTo(12f, 12f)
                moveTo(18f, 12f)
                arcTo(6f, 6f, 0f, true, true, 6f, 12f)
                arcTo(6f, 6f, 0f, true, true, 18f, 12f)
            }
        }
    }

    val PixelGrid: ImageVector by lazy {
        vector("PixelGrid") {
            path(fill = SolidColor(Color.Black)) {
                moveTo(4f, 4f); horizontalLineTo(11f); verticalLineTo(11f); horizontalLineTo(4f); close()
                moveTo(13f, 4f); horizontalLineTo(20f); verticalLineTo(11f); horizontalLineTo(13f); close()
                moveTo(4f, 13f); horizontalLineTo(11f); verticalLineTo(20f); horizontalLineTo(4f); close()
                moveTo(13f, 13f); horizontalLineTo(20f); verticalLineTo(20f); horizontalLineTo(13f); close()
            }
        }
    }

    val CodeCompile: ImageVector by lazy {
        vector("CodeCompile") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(8f, 7f)
                lineTo(3f, 12f)
                lineTo(8f, 17f)
                moveTo(16f, 7f)
                lineTo(21f, 12f)
                lineTo(16f, 17f)
                moveTo(13.5f, 5f)
                lineTo(10.5f, 19f)
            }
        }
    }

    val Debloat: ImageVector by lazy {
        vector("Debloat") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 7f)
                horizontalLineTo(20f)
                moveTo(9f, 7f)
                verticalLineTo(4f)
                horizontalLineTo(15f)
                verticalLineTo(7f)
                moveTo(6f, 7f)
                lineTo(7f, 20f)
                horizontalLineTo(17f)
                lineTo(18f, 7f)
                moveTo(10f, 11f)
                verticalLineTo(16f)
                moveTo(14f, 11f)
                verticalLineTo(16f)
            }
        }
    }

    val SpeedGauge: ImageVector by lazy {
        vector("SpeedGauge") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4.9f, 18.5f)
                arcTo(9.5f, 9.5f, 0f, true, true, 19.1f, 18.5f)
                moveTo(12f, 13f)
                lineTo(16.5f, 8.5f)
            }
        }
    }

    val RadialWheel: ImageVector by lazy {
        vector("RadialWheel") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 3f)
                arcTo(9f, 9f, 0f, true, true, 11.9f, 3f)
                moveTo(12f, 9f)
                arcTo(3f, 3f, 0f, true, true, 11.9f, 9f)
                moveTo(12f, 3f)
                verticalLineTo(9f)
                moveTo(19.8f, 16.5f)
                lineTo(14.6f, 13.5f)
                moveTo(4.2f, 16.5f)
                lineTo(9.4f, 13.5f)
            }
        }
    }

    val ShizukuBridge: ImageVector by lazy {
        vector("ShizukuBridge") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(5f, 17f)
                horizontalLineTo(19f)
                moveTo(7f, 13f)
                horizontalLineTo(17f)
                moveTo(9f, 9f)
                horizontalLineTo(15f)
                moveTo(12f, 4f)
                verticalLineTo(9f)
            }
        }
    }

    val WirelessDebug: ImageVector by lazy {
        vector("WirelessDebug") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(5f, 9f)
                arcTo(10f, 10f, 0f, false, true, 19f, 9f)
                moveTo(8f, 12.5f)
                arcTo(6f, 6f, 0f, false, true, 16f, 12.5f)
                moveTo(12f, 17f)
                verticalLineTo(17.1f)
            }
        }
    }

    val Palette: ImageVector by lazy {
        vector("Palette") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f)
                arcTo(9f, 9f, 0f, true, false, 21f, 12f)
                curveTo(21f, 10.2f, 19.6f, 9f, 18f, 9f)
                horizontalLineTo(15.5f)
                arcTo(1.5f, 1.5f, 0f, false, false, 14f, 10.5f)
                curveTo(14f, 11.4f, 14.7f, 12f, 14.7f, 13f)
                arcTo(1.5f, 1.5f, 0f, false, true, 13.2f, 14.5f)
                horizontalLineTo(12f)
            }
        }
    }

    val ShieldUnlock: ImageVector by lazy {
        vector("ShieldUnlock") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 2.5f)
                lineTo(19f, 5.5f)
                verticalLineTo(11.5f)
                curveTo(19f, 16.2f, 16f, 19.8f, 12f, 21.5f)
                curveTo(8f, 19.8f, 5f, 16.2f, 5f, 11.5f)
                verticalLineTo(5.5f)
                close()
                moveTo(9f, 12f)
                lineTo(11.2f, 14.2f)
                lineTo(15.5f, 9.8f)
            }
        }
    }

    val Gamepad: ImageVector by lazy {
        vector("Gamepad") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(6f, 8f)
                horizontalLineTo(18f)
                curveTo(20f, 8f, 21.5f, 10.5f, 21f, 14.5f)
                curveTo(20.6f, 17f, 19f, 18f, 17.5f, 17f)
                lineTo(15f, 15f)
                horizontalLineTo(9f)
                lineTo(6.5f, 17f)
                curveTo(5f, 18f, 3.4f, 17f, 3f, 14.5f)
                curveTo(2.5f, 10.5f, 4f, 8f, 6f, 8f)
                close()
                moveTo(7f, 11.5f)
                horizontalLineTo(10f)
                moveTo(8.5f, 10f)
                verticalLineTo(13f)
            }
        }
    }

    val Restore: ImageVector by lazy {
        vector("Restore") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(3f, 12f)
                arcTo(9f, 9f, 0f, true, false, 6f, 5.5f)
                moveTo(3f, 4f)
                verticalLineTo(9f)
                horizontalLineTo(8f)
            }
        }
    }

    val Language: ImageVector by lazy {
        vector("Language") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 3f)
                arcTo(9f, 9f, 0f, true, true, 11.9f, 3f)
                moveTo(3f, 12f)
                horizontalLineTo(21f)
                moveTo(12f, 3f)
                curveTo(15f, 6f, 15f, 18f, 12f, 21f)
                moveTo(12f, 3f)
                curveTo(9f, 6f, 9f, 18f, 12f, 21f)
            }
        }
    }

    val ChevronRight: ImageVector by lazy {
        vector("ChevronRight") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(9f, 6f)
                lineTo(15f, 12f)
                lineTo(9f, 18f)
            }
        }
    }

    val Stopwatch: ImageVector by lazy {
        vector("Stopwatch") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(9f, 3f)
                horizontalLineTo(15f)
                moveTo(12f, 3f)
                verticalLineTo(6f)
                moveTo(12f, 6f)
                arcTo(7.5f, 7.5f, 0f, true, true, 11.9f, 6f)
                moveTo(12f, 13.5f)
                lineTo(15.2f, 10.3f)
            }
        }
    }

    val Gyroscope: ImageVector by lazy {
        vector("Gyroscope") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f)
                arcTo(9f, 9f, 0f, true, true, 11.9f, 3f)
                moveTo(4f, 12f)
                curveTo(6.5f, 9f, 17.5f, 9f, 20f, 12f)
                moveTo(4f, 12f)
                curveTo(6.5f, 15f, 17.5f, 15f, 20f, 12f)
                moveTo(12f, 11.5f)
                verticalLineTo(12.5f)
            }
        }
    }

    val BatteryBypass: ImageVector by lazy {
        vector("BatteryBypass") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(6f, 6f)
                horizontalLineTo(16f)
                verticalLineTo(18f)
                horizontalLineTo(6f)
                close()
                moveTo(16f, 9.5f)
                horizontalLineTo(18.5f)
                verticalLineTo(14.5f)
                horizontalLineTo(16f)
                moveTo(11.5f, 8.5f)
                lineTo(9.5f, 12f)
                horizontalLineTo(12.5f)
                lineTo(10.5f, 15.5f)
            }
        }
    }

    val EsportTurbo: ImageVector by lazy {
        vector("EsportTurbo") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(13f, 2.5f)
                lineTo(5f, 13.5f)
                horizontalLineTo(11.5f)
                lineTo(10.5f, 21.5f)
                lineTo(19f, 10f)
                horizontalLineTo(12.5f)
                close()
            }
        }
    }

    val Tune: ImageVector by lazy {
        vector("Tune") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 7f)
                horizontalLineTo(20f)
                moveTo(4f, 12f)
                horizontalLineTo(20f)
                moveTo(4f, 17f)
                horizontalLineTo(20f)
                moveTo(8.5f, 5f)
                verticalLineTo(9f)
                moveTo(15.5f, 10f)
                verticalLineTo(14f)
                moveTo(10.5f, 15f)
                verticalLineTo(19f)
            }
        }
    }

    val Thermal: ImageVector by lazy {
        vector("Thermal") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(14f, 14.76f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, false, 10f, 5f)
                verticalLineTo(14.76f)
                arcTo(3.5f, 3.5f, 0f, true, false, 14f, 14.76f)
                close()
                moveTo(12f, 9f)
                verticalLineTo(17.5f)
            }
        }
    }

    val Note: ImageVector by lazy {
        vector("Note") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(5f, 4f)
                horizontalLineTo(19f)
                verticalLineTo(16f)
                lineTo(15f, 20f)
                horizontalLineTo(5f)
                close()
                moveTo(15f, 20f)
                verticalLineTo(16f)
                horizontalLineTo(19f)
                moveTo(8.5f, 9f)
                horizontalLineTo(15.5f)
                moveTo(8.5f, 13f)
                horizontalLineTo(13f)
            }
        }
    }

    val Shield: ImageVector by lazy {
        vector("Shield") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(12f, 3f)
                lineTo(19f, 6f)
                verticalLineTo(11.5f)
                curveTo(19f, 16f, 15.8f, 19.6f, 12f, 21f)
                curveTo(8.2f, 19.6f, 5f, 16f, 5f, 11.5f)
                verticalLineTo(6f)
                close()
                moveTo(9.5f, 12f)
                lineTo(11.3f, 13.8f)
                lineTo(14.8f, 10.2f)
            }
        }
    }

    val Dimmer: ImageVector by lazy {
        vector("Dimmer") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(20f, 14.5f)
                arcTo(8f, 8f, 0f, true, true, 10.5f, 4f)
                arcTo(6.3f, 6.3f, 0f, false, false, 20f, 14.5f)
                close()
            }
        }
    }

    val CameraShot: ImageVector by lazy {
        vector("CameraShot") {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 8f)
                horizontalLineTo(7.5f)
                lineTo(9.2f, 5.5f)
                horizontalLineTo(14.8f)
                lineTo(16.5f, 8f)
                horizontalLineTo(20f)
                verticalLineTo(18.5f)
                horizontalLineTo(4f)
                close()
                moveTo(12f, 10.2f)
                arcTo(3f, 3f, 0f, true, true, 11.9f, 10.2f)
            }
        }
    }

    private inline fun vector(
        name: String,
        block: ImageVector.Builder.() -> Unit
    ): ImageVector = ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply(block).build()
}
