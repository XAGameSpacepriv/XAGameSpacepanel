package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FpsSessionRecord
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun ThermalAdvanceCard(
    config: ThermalConfig,
    status: ThermalStatus,
    onSelectProfile: (ThermalProfile) -> Unit,
    onSetThermalMaxLimit: (Boolean, Int) -> Unit = { _, _ -> },
    onProbeThermal: () -> Unit,
    onOpenThermalPanel: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_thermal_advance"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.Thermal,
                            contentDescription = "Thermal Advance",
                            tint = if (config.profile == ThermalProfile.DISABLE_THROTTLE) StatusRed else StatusAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Thermal Advance",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (config.thermalMaxLimitEnabled) {
                                "${config.profile.label} • Max ${config.thermalMaxTargetC}°C"
                            } else {
                                "${config.profile.label} • Guard ${config.guardThresholdC}°C"
                            },
                            color = if (config.thermalMaxLimitEnabled) StatusCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Text(
                    text = status.systemThermalState,
                    color = if (status.guardTriggered) StatusRed else StatusAmber,
                    fontFamily = JetBrainsMono,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(
                            (if (status.guardTriggered) StatusRed else StatusAmber).copy(alpha = 0.14f)
                        )
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ThermalProfile.entries.forEach { prof ->
                    val selected = config.profile == prof
                    val activeColor = when (prof) {
                        ThermalProfile.DISABLE_THROTTLE -> StatusRed
                        ThermalProfile.EVALUATION -> StatusAmber
                        ThermalProfile.COOL -> StatusCyan
                        else -> MaterialTheme.colorScheme.primary
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selected) activeColor
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (selected) activeColor
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelectProfile(prof) }
                            .testTag("opt_thermal_${prof.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = prof.shortLabel,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Thermal Max 38°C - 40°C quick ceiling selector
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Thermal Max (38°C – 40°C)",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = when {
                            config.thermalMaxLimitEnabled && status.maxLimitActive -> "CAP ${config.thermalMaxTargetC}°C AKTIF"
                            config.thermalMaxLimitEnabled -> "MAX ≤ ${config.thermalMaxTargetC}°C"
                            else -> "OFF"
                        },
                        color = if (config.thermalMaxLimitEnabled) StatusCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = JetBrainsMono,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val offSelected = !config.thermalMaxLimitEnabled
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(
                                if (offSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerLow
                            )
                            .clickable { onSetThermalMaxLimit(false, config.thermalMaxTargetC) }
                            .testTag("opt_thermal_max_off"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Off",
                            color = if (offSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = if (offSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                    listOf(38, 39, 40).forEach { targetC ->
                        val selected = config.thermalMaxLimitEnabled && config.thermalMaxTargetC == targetC
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(
                                    if (selected) StatusCyan
                                    else MaterialTheme.colorScheme.surfaceContainerLow
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (selected) StatusCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                    shape = RoundedCornerShape(9.dp)
                                )
                                .clickable { onSetThermalMaxLimit(true, targetC) }
                                .testTag("opt_thermal_max_$targetC"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${targetC}°C",
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontFamily = JetBrainsMono,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Text(
                text = status.maxLimitDetail.ifBlank { status.activeNodeSummary },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onProbeThermal,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_probe_thermal")
                ) {
                    Text("Cek Node", fontSize = 11.sp)
                }
                Button(
                    onClick = onOpenThermalPanel,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_open_thermal_panel")
                ) {
                    Text("Panel Thermal", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
internal fun FpsResultHistoryCard(
    records: List<FpsSessionRecord>,
    onSaveNow: () -> Unit,
    onClearAll: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_fps_result_history"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.HudOverlay,
                            contentDescription = "FPS Result",
                            tint = StatusGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Riwayat FPS Result",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (records.isEmpty()) "Belum ada catatan sesi FPS"
                            else "${records.size} sesi tersimpan (Min/Avg/Max & Suhu SoC)",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onSaveNow,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("btn_save_fps_result")
                    ) {
                        Text("Simpan", fontSize = 11.sp)
                    }
                    if (records.isNotEmpty()) {
                        OutlinedButton(
                            onClick = onClearAll,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("btn_clear_fps_result")
                        ) {
                            Text("Hapus", fontSize = 11.sp)
                        }
                    }
                }
            }

            if (records.isNotEmpty()) {
                val timeFmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    records.take(5).forEachIndexed { index, rec ->
                        if (index > 0) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = rec.gameName,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (rec.timestampMs > 0L) timeFmt.format(Date(rec.timestampMs)) else "-",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Avg ${rec.fpsAvg} • ${rec.fpsMin}-${rec.fpsMax} FPS",
                                    color = StatusGreen,
                                    fontFamily = JetBrainsMono,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "SoC ${"%.1f".format(rec.peakSocTempC)}°C",
                                    color = if (rec.peakSocTempC >= 46f) StatusAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontFamily = JetBrainsMono,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
