package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DebloatAppEntry
import com.example.model.DebloatCategory
import com.example.ui.components.AppIconThumb
import com.example.ui.components.DotGridLoader
import com.example.ui.components.SubScreenTopBar
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed

@Composable
fun DebloatScreen(
    packages: List<DebloatAppEntry>,
    isLoading: Boolean,
    getAppIcon: (String) -> ImageBitmap?,
    onActionPackage: (DebloatAppEntry) -> Unit,
    onRefreshList: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var query by remember { mutableStateOf("") }
    var showInstalled by remember { mutableStateOf(true) }
    var selectedCategory by remember { mutableStateOf(DebloatCategory.SAFE) }
    var pendingConfirmApp by remember { mutableStateOf<DebloatAppEntry?>(null) }

    val installedCount = remember(packages) { packages.count { it.isInstalled } }
    val removedCount = remember(packages) { packages.count { !it.isInstalled } }

    val filtered = remember(packages, query, showInstalled, selectedCategory) {
        val q = query.trim().lowercase()
        packages.filter { entry ->
            entry.isInstalled == showInstalled &&
                entry.category == selectedCategory &&
                (q.isEmpty() || entry.appName.lowercase().contains(q) || entry.packageName.lowercase().contains(q))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
    ) {
        SubScreenTopBar(title = "Debloat", onBack = onBack)

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Cari aplikasi bawaan", fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Cari") },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .testTag("search_debloat")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Terpasang / Dihapus pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DebloatFilterChip(
                label = "Terpasang ($installedCount)",
                selected = showInstalled,
                modifier = Modifier.weight(1f),
                onClick = { showInstalled = true }
            )
            DebloatFilterChip(
                label = "Dihapus ($removedCount)",
                selected = !showInstalled,
                modifier = Modifier.weight(1f),
                onClick = { showInstalled = false }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Severity filter pills: Aman, Lanjutan, Expert, Berbahaya
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DebloatCategory.entries.forEach { cat ->
                DebloatFilterChip(
                    label = cat.label,
                    selected = selectedCategory == cat,
                    modifier = Modifier.weight(1f),
                    onClick = { selectedCategory = cat }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // UAD-ng info & refresh row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Daftar: UAD-ng (GPL-3.0)",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            OutlinedButton(
                onClick = onRefreshList,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("Memperbarui daftar", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isLoading && packages.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                DotGridLoader()
            }
        } else if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Tidak ada aplikasi di kategori ${selectedCategory.label}.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    val catColor = when (app.category) {
                        DebloatCategory.SAFE -> StatusGreen
                        DebloatCategory.ADVANCED -> StatusAmber
                        DebloatCategory.EXPERT -> MaterialTheme.colorScheme.primary
                        DebloatCategory.UNSAFE -> StatusRed
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIconThumb(
                            iconBitmap = getAppIcon(app.packageName),
                            fallbackLabel = app.appName,
                            size = 40.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.appName,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.packageName,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.description,
                                color = catColor,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { pendingConfirmApp = app },
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (app.isInstalled) StatusRed.copy(alpha = 0.16f) else StatusGreen.copy(alpha = 0.16f),
                                contentColor = if (app.isInstalled) StatusRed else StatusGreen
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (app.isInstalled) "Hapus" else "Pulihkan",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    pendingConfirmApp?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingConfirmApp = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = {
                Text(
                    if (target.isInstalled) "Hapus ${target.appName}?" else "Pulihkan ${target.appName}?",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    "${target.packageName}\n\nKategori UAD-ng: ${target.category.label}\n${target.description}",
                    fontSize = 13.sp
                )
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirmApp = null }) { Text("Batal") }
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingConfirmApp = null
                    onActionPackage(target)
                }) {
                    Text(
                        if (target.isInstalled) "Hapus" else "Pulihkan",
                        color = if (target.isInstalled) StatusRed else StatusGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }
}

@Composable
private fun DebloatFilterChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(
                if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant
            )
            .border(
                1.dp,
                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
