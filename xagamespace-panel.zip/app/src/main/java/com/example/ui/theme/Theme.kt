package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.model.AccentPreset
import com.example.model.ThemeMode

val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

fun accentColorFor(preset: AccentPreset, isDark: Boolean): Color = when (preset) {
    AccentPreset.MONO -> if (isDark) AccentMono else Color(0xFF151820)
    AccentPreset.VOLT_CYAN -> AccentVoltCyan
    AccentPreset.CRIMSON -> AccentCrimson
    AccentPreset.ACID_LIME -> AccentAcidLime
    AccentPreset.AMBER -> AccentAmber
    AccentPreset.VIOLET -> AccentViolet
}

@Composable
fun XAGameSpaceTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    accentPreset: AccentPreset = AccentPreset.MONO,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val accent = accentColorFor(accentPreset, isDark)
    val onAccent = if (accent == AccentMono || accent == AccentVoltCyan || accent == AccentAcidLime || accent == AccentAmber) {
        Color(0xFF0B0C0F)
    } else {
        Color.White
    }

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.16f),
            onPrimaryContainer = accent,
            secondary = ObsidianTextSecondary,
            onSecondary = ObsidianBg,
            background = ObsidianBg,
            onBackground = ObsidianTextPrimary,
            surface = ObsidianSurface,
            onSurface = ObsidianTextPrimary,
            surfaceVariant = ObsidianCard,
            onSurfaceVariant = ObsidianTextSecondary,
            surfaceContainerHigh = ObsidianCardElevated,
            outline = ObsidianBorder,
            outlineVariant = ObsidianBorder.copy(alpha = 0.6f),
            error = StatusRed,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = if (accentPreset == AccentPreset.MONO) Color.White else Color(0xFF0B0C0F),
            primaryContainer = accent.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF101319),
            secondary = LightTextSecondary,
            onSecondary = Color.White,
            background = LightBg,
            onBackground = LightTextPrimary,
            surface = LightSurface,
            onSurface = LightTextPrimary,
            surfaceVariant = LightCard,
            onSurfaceVariant = LightTextSecondary,
            surfaceContainerHigh = LightCardElevated,
            outline = LightBorder,
            outlineVariant = LightBorder.copy(alpha = 0.7f),
            error = StatusRed,
            onError = Color.White
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !isDark
                    isAppearanceLightNavigationBars = !isDark
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
