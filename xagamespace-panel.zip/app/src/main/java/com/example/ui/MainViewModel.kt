package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AiTriggerCaptureManager
import com.example.core.AiTriggerEngine
import com.example.core.GyroAimEngine
import com.example.core.ShizukuBridge
import com.example.core.SystemOptimizer
import com.example.core.TelemetryMonitor
import com.example.core.TouchBoostPreset
import com.example.core.TouchResponseEngine
import com.example.data.BoosterPreferences
import com.example.model.AccentPreset
import com.example.model.AngleRuntimeReport
import com.example.model.AntiMistouchConfig
import com.example.model.AppLanguage
import com.example.model.BurikPreset
import com.example.model.BypassChargingStatus
import com.example.model.CompatibilityReport
import com.example.model.DebloatAppEntry
import com.example.model.DebloatCategory
import com.example.model.FpsLockTarget
import com.example.model.FpsSessionRecord
import com.example.model.GameEntry
import com.example.model.GameProfileConfig
import com.example.model.GyroAimConfig
import com.example.model.MainTab
import com.example.model.PanelTab
import com.example.model.PerformanceProfile
import com.example.model.PrivilegeMode
import com.example.model.ShizukuStatus
import com.example.model.SubScreen
import com.example.model.ThemeMode
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.model.TouchDriverStatus
import com.example.service.AiTriggerProjectionService
import com.example.service.GameOverlayService
import com.example.service.ScreenCapturePermissionActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    val prefs = BoosterPreferences.getInstance(appContext)
    val telemetry = TelemetryMonitor.getInstance(appContext)
    val optimizer = SystemOptimizer(appContext, prefs)

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _subScreen = MutableStateFlow(SubScreen.NONE)
    val subScreen: StateFlow<SubScreen> = _subScreen.asStateFlow()

    private val _allApps = MutableStateFlow<List<GameEntry>>(emptyList())
    val allApps: StateFlow<List<GameEntry>> = _allApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _debloatApps = MutableStateFlow<List<DebloatAppEntry>>(emptyList())
    val debloatApps: StateFlow<List<DebloatAppEntry>> = _debloatApps.asStateFlow()

    private val _isLoadingDebloat = MutableStateFlow(false)
    val isLoadingDebloat: StateFlow<Boolean> = _isLoadingDebloat.asStateFlow()

    private val _compilingPackages = MutableStateFlow<Set<String>>(emptySet())
    val compilingPackages: StateFlow<Set<String>> = _compilingPackages.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _compatibilityReport = MutableStateFlow(optimizer.buildCompatibilityReport())
    val compatibilityReport: StateFlow<CompatibilityReport> = _compatibilityReport.asStateFlow()

    private val _angleRuntimeReport = MutableStateFlow(AngleRuntimeReport())
    val angleRuntimeReport: StateFlow<AngleRuntimeReport> = _angleRuntimeReport.asStateFlow()

    private val _bypassChargingStatus = MutableStateFlow(BypassChargingStatus())
    val bypassChargingStatus: StateFlow<BypassChargingStatus> = _bypassChargingStatus.asStateFlow()

    private val _thermalStatus = MutableStateFlow(ThermalStatus())
    val thermalStatus: StateFlow<ThermalStatus> = _thermalStatus.asStateFlow()

    private val _touchDriverStatus = MutableStateFlow(TouchDriverStatus())
    val touchDriverStatus: StateFlow<TouchDriverStatus> = _touchDriverStatus.asStateFlow()

    val hasGyroSensor: Boolean = GyroAimEngine.hasHardwareGyro(appContext)

    val shizukuStatus: StateFlow<ShizukuStatus> = ShizukuBridge.status

    val addedGameEntries = MutableStateFlow<List<GameEntry>>(emptyList())
    private var burikApplyJob: Job? = null

    init {
        ShizukuBridge.init(appContext)
        telemetry.start()
        refreshApps()
        refreshBypassCharging(silent = true)
        refreshThermalStatus(silent = true)
        refreshTouchDriverStatus(silent = true)
        if (prefs.touchConfig.value.enabled) {
            viewModelScope.launch {
                TouchResponseEngine.syncLiveOrientation(appContext, prefs.touchConfig.value)
            }
        }
        viewModelScope.launch {
            ShizukuBridge.autoProvisionBanner.collect { msg ->
                if (!msg.isNullOrBlank()) {
                    showMessage(msg)
                    ShizukuBridge.clearAutoProvisionBanner()
                    refreshCompatibility()
                }
            }
        }
        viewModelScope.launch {
            while (true) {
                delay(3000L)
                if (prefs.useShizuku.value) {
                    val st = ShizukuBridge.status.value
                    if (!prefs.canUsePrivileged(st) || (st.isRunning && st.isPermissionGranted && !st.isInputServiceBound)) {
                        ShizukuBridge.refresh(appContext, autoTriggerIfReady = true)
                    }
                }
            }
        }
        viewModelScope.launch {
            combine(
                _allApps,
                prefs.addedGames,
                prefs.compiledGames,
                prefs.perGameBurik
            ) { apps, added, compiled, burikMap ->
                apps.filter { added.contains(it.packageName) }.map { entry ->
                    entry.copy(
                        isAdded = true,
                        compileStatus = if (compiled.contains(entry.packageName)) {
                            com.example.model.CompileStatus.COMPILED
                        } else {
                            com.example.model.CompileStatus.NOT_COMPILED
                        },
                        burikOverride = burikMap[entry.packageName]
                    )
                }
            }.collect { list ->
                addedGameEntries.value = list
            }
        }
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
        _subScreen.value = SubScreen.NONE
    }

    fun openSubScreen(screen: SubScreen) {
        _subScreen.value = screen
        when (screen) {
            SubScreen.ADD_GAME, SubScreen.COMPILE -> refreshApps()
            SubScreen.BURIK -> refreshAngleReport()
            SubScreen.DEBLOAT -> refreshDebloat()
            SubScreen.COMPATIBILITY -> refreshCompatibility()
            else -> Unit
        }
    }

    fun closeSubScreen() {
        _subScreen.value = SubScreen.NONE
    }

    fun refreshApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val list = optimizer.scanLaunchableApps(prefs.addedGames.value)
            _allApps.value = list
            _isLoadingApps.value = false
        }
    }

    fun refreshDebloat() {
        viewModelScope.launch {
            _isLoadingDebloat.value = true
            val list = optimizer.scanDebloatPackages()
            _debloatApps.value = list
            _isLoadingDebloat.value = false
        }
    }

    fun refreshCompatibility() {
        ShizukuBridge.refresh(appContext, autoTriggerIfReady = true)
        _compatibilityReport.value = optimizer.buildCompatibilityReport()
    }

    fun getAppIcon(packageName: String): ImageBitmap? = optimizer.getAppIcon(packageName)

    fun toggleAddedGame(packageName: String) {
        prefs.toggleAddedGame(packageName)
        _allApps.value = _allApps.value.map {
            if (it.packageName == packageName) it.copy(isAdded = prefs.addedGames.value.contains(packageName))
            else it
        }
    }

    fun boostNow() {
        viewModelScope.launch {
            telemetry.setBoosting(true)
            delay(320)
            val res = optimizer.performBoost()
            telemetry.updateBoostStats(res.scoreAfter, res.freedMb, res.killedProcesses, false)
            showMessage(res.summary)
        }
    }

    fun toggleGameSession(enabled: Boolean) {
        if (enabled && !Settings.canDrawOverlays(appContext)) {
            showMessage("Izinkan 'Tampilkan di atas aplikasi lain' untuk mengaktifkan Sesi Game & Panel Overlay.")
            openOverlayPermissionSettings()
            return
        }
        prefs.setGameSessionActive(enabled, null)
        if (!enabled) {
            prefs.setOverlayPanelExpanded(false)
            prefs.setMacroPlacementMode(false)
            prefs.updateMacroConfig { it.copy(enabled = false, isRunning = false) }
            prefs.updateHudConfig { it.copy(enabled = false) }
            prefs.updateStopwatchConfig { it.copy(enabled = false) }
            prefs.updateGyroAimConfig { it.copy(enabled = false) }
            prefs.setScreenDimmerEnabled(false)
            prefs.updateGameNoteConfig { it.copy(pinnedOverlay = false) }
        }
        viewModelScope.launch {
            if (enabled) {
                if (prefs.fastAnimationEnabled.value) optimizer.applyFastAnimation(true)
                if (prefs.touchConfig.value.enabled) {
                    optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
                }
                val perf = prefs.performanceProfile.value
                if (perf != PerformanceProfile.BALANCED) {
                    optimizer.applyPerformanceProfile(perf)
                }
                val thermal = prefs.thermalConfig.value
                if (thermal.thermalMaxLimitEnabled) {
                    val snap = telemetry.snapshot.value
                    val engage = maxOf(snap.socTempC, snap.tempC) >= thermal.thermalMaxTargetC
                    val (tStatus, _) = optimizer.applyThermalMaxCap(thermal, engageClamp = engage)
                    _thermalStatus.value = tStatus
                } else if (thermal.profile != ThermalProfile.STOCK) {
                    val (tStatus, _) = optimizer.applyThermalConfig(thermal)
                    _thermalStatus.value = tStatus
                }
                val fpsConfig = prefs.fpsLockConfig.value
                if (fpsConfig.target != FpsLockTarget.DEFAULT) {
                    optimizer.applyFpsLock(prefs.addedGames.value.toList(), fpsConfig)
                }
                GameOverlayService.start(appContext, openPanelImmediately = false)
                showMessage("Sesi game aktif. Ketuk garis di tepi layar untuk buka panel, atau tahan untuk memindahkannya.")
            } else {
                GameOverlayService.stop(appContext)
                if (prefs.restoreAfterSession.value) {
                    val res = optimizer.restoreAngleTextureOnly()
                    prefs.updateBurikConfig { it.copy(preset = BurikPreset.OFF) }
                    showMessage(res.message)
                }
            }
        }
    }

    fun launchGameWithPanel(game: GameEntry) {
        if (!Settings.canDrawOverlays(appContext)) {
            showMessage("Izinkan Overlay terlebih dahulu agar panel melayang tampil di atas ${game.name}.")
            openOverlayPermissionSettings()
            return
        }
        viewModelScope.launch {
            val profile = prefs.profileForGame(game.packageName)
            prefs.setGameSessionActive(true, game.packageName)
            if (prefs.fastAnimationEnabled.value) {
                optimizer.applyFastAnimation(true)
            }
            val perfToUse = profile?.performanceProfile ?: prefs.performanceProfile.value
            if (perfToUse != PerformanceProfile.BALANCED) {
                optimizer.applyPerformanceProfile(perfToUse, listOf(game.packageName))
            }
            val thermalProfileToUse = profile?.thermalProfile ?: prefs.thermalConfig.value.profile
            val launchThermalCfg = prefs.thermalConfig.value.copy(profile = thermalProfileToUse)
            if (launchThermalCfg.thermalMaxLimitEnabled) {
                val snap = telemetry.snapshot.value
                val engage = maxOf(snap.socTempC, snap.tempC) >= launchThermalCfg.thermalMaxTargetC
                val (tStatus, _) = optimizer.applyThermalMaxCap(
                    launchThermalCfg,
                    engageClamp = engage,
                    targetPackages = listOf(game.packageName)
                )
                _thermalStatus.value = tStatus
            } else if (thermalProfileToUse != ThermalProfile.STOCK) {
                val (tStatus, _) = optimizer.applyThermalConfig(
                    launchThermalCfg,
                    listOf(game.packageName)
                )
                _thermalStatus.value = tStatus
            }
            val burikToUse = profile?.burikPreset ?: game.burikOverride ?: prefs.burikConfig.value.preset
            if (burikToUse != BurikPreset.OFF) {
                optimizer.applyBurik(listOf(game.packageName), prefs.burikConfig.value.copy(preset = burikToUse))
                // ANGLE only binds on cold start; force-stop cached native GLES process if running
                optimizer.forceStopPackage(game.packageName)
            }
            val touchOverride = profile?.touchBoostOverride
            if (touchOverride != null) {
                prefs.updateTouchConfig { it.copy(enabled = touchOverride, liveAimPadEnabled = false, aimPadLocked = false) }
            }
            if (prefs.touchConfig.value.enabled) {
                optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
            }
            val fpsConfig = if (profile?.fpsOverride != null) {
                prefs.fpsLockConfig.value.copy(target = profile.fpsOverride)
            } else {
                prefs.fpsLockConfig.value
            }
            if (fpsConfig.target != FpsLockTarget.DEFAULT) {
                optimizer.applyFpsLock(listOf(game.packageName), fpsConfig)
            }
            if (profile?.bypassCharging != null) {
                val (bpStatus, _) = optimizer.setBypassCharging(profile.bypassCharging)
                _bypassChargingStatus.value = bpStatus
            }
            if (profile?.gyroAim != null && hasGyroSensor) {
                prefs.updateGyroAimConfig { it.copy(enabled = profile.gyroAim) }
            }
            GameOverlayService.start(appContext, openPanelImmediately = true)
            val launched = optimizer.launchGame(game.packageName)
            if (!launched) {
                showMessage("Tidak dapat meluncurkan ${game.name}.")
            }
        }
    }

    fun togglePerformanceHud(enabled: Boolean) {
        if (enabled && !Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk menampilkan Performance HUD.")
            openOverlayPermissionSettings()
            return
        }
        prefs.updateHudConfig { it.copy(enabled = enabled) }
        if (enabled) {
            GameOverlayService.start(appContext, openPanelImmediately = false)
        }
    }

    fun toggleSensitivity(enabled: Boolean) {
        prefs.updateTouchConfig { cur ->
            if (enabled && cur.speedX == 0 && cur.speedY == 0 && cur.responseBoost == 0) {
                TouchBoostPreset.LICIN_PRO.applyTo(cur)
            } else {
                cur.copy(enabled = enabled, liveAimPadEnabled = false, aimPadLocked = false)
            }
        }
        viewModelScope.launch {
            val res = optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
            refreshTouchDriverStatus(silent = true)
            showMessage(res.message)
        }
    }

    fun applyTouchPreset(preset: TouchBoostPreset) {
        prefs.updateTouchConfig { preset.applyTo(it) }
        viewModelScope.launch {
            val res = optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
            refreshTouchDriverStatus(silent = true)
            showMessage("Racikan ${preset.label} diterapkan • ${res.message}")
        }
    }

    fun toggleMacro(enabled: Boolean) {
        if (enabled && !Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk menampilkan tombol Macro.")
            openOverlayPermissionSettings()
            return
        }
        prefs.updateMacroConfig { it.copy(enabled = enabled, isRunning = false) }
        if (enabled) {
            GameOverlayService.start(appContext, openPanelImmediately = false)
            val st = ShizukuBridge.refresh(appContext, autoTriggerIfReady = true)
            if (prefs.canUsePrivileged(st)) {
                if (prefs.useShizuku.value) {
                    ShizukuBridge.ensureInputServiceBound()
                }
                val engine = if (prefs.privilegeMode.value == PrivilegeMode.ROOT) "Root UID 0" else "Shizuku"
                showMessage("Macro 10-Jari siap via $engine (tanpa Aksesibilitas). Kunci posisi lalu tahan Trigger sambil geser layar.")
            } else if (prefs.privilegeMode.value == PrivilegeMode.ROOT) {
                showMessage("Macro tampil di layar. Mode Root aktif — tekan 'Minta Root' agar ketukan otomatis bekerja (tanpa Shizuku).")
            } else if (st.isRunning && !st.isPermissionGranted) {
                showMessage("Macro tampil. Berikan izin Shizuku yang muncul agar Macro 10-Jari aktif.")
            } else {
                showMessage("Macro tampil di layar. Aktifkan Shizuku atau pilih Opsi 1 (Root) di Profil agar ketukan otomatis bekerja.")
            }
        }
    }

    fun toggleAiTrigger(enabled: Boolean) {
        if (enabled && !Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk menggunakan AI Trigger di atas game.")
            openOverlayPermissionSettings()
            return
        }
        prefs.setAiTriggerMasterEnabled(enabled)
        if (enabled) {
            GameOverlayService.start(appContext, openPanelImmediately = false)
            if (!AiTriggerCaptureManager.isProjectionActive()) {
                ScreenCapturePermissionActivity.launch(
                    context = appContext,
                    enableMasterOnGrant = true
                ) { granted ->
                    AiTriggerEngine.syncLoop(appContext, prefs)
                    if (granted) {
                        showMessage("AI Trigger aktif & siap memindai layar game.")
                    } else if (prefs.canUsePrivileged(ShizukuBridge.status.value)) {
                        val modeLabel = if (prefs.privilegeMode.value == PrivilegeMode.ROOT) "Root (UID 0)" else "Shizuku"
                        showMessage("AI Trigger aktif via $modeLabel backup capture.")
                    } else {
                        showMessage("Izinkan Rekam Layar agar AI Trigger dapat membaca gambar di game.")
                    }
                }
            } else {
                AiTriggerEngine.syncLoop(appContext, prefs)
                showMessage("AI Trigger aktif memindai layar.")
            }
        } else {
            AiTriggerEngine.stopLoop(prefs)
            AiTriggerProjectionService.stop(appContext)
        }
    }

    fun openAiTriggerPanel() {
        if (!Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk membuka panel AI Trigger.")
            openOverlayPermissionSettings()
            return
        }
        prefs.requestPanelTab(PanelTab.AI_TRIGGER)
        GameOverlayService.start(appContext, openPanelImmediately = true)
    }

    fun selectFpsLock(target: FpsLockTarget) {
        prefs.updateFpsLockConfig { it.copy(target = target) }
        viewModelScope.launch {
            val targets = prefs.addedGames.value.toList()
            val res = optimizer.applyFpsLock(targets, prefs.fpsLockConfig.value)
            showMessage(res.message)
        }
    }

    fun toggleFastAnimation(enabled: Boolean) {
        prefs.setFastAnimation(enabled)
        viewModelScope.launch {
            val res = optimizer.applyFastAnimation(enabled)
            showMessage(res.message)
        }
    }

    fun refreshAngleReport() {
        viewModelScope.launch {
            _angleRuntimeReport.value = optimizer.buildAngleRuntimeReport(prefs.burikConfig.value)
        }
    }

    fun selectBurikPreset(preset: BurikPreset) {
        burikApplyJob?.cancel()
        prefs.updateBurikConfig { it.copy(preset = preset) }
        burikApplyJob = viewModelScope.launch {
            val targets = prefs.addedGames.value.toList()
            val res = optimizer.applyBurik(targets, prefs.burikConfig.value)
            _angleRuntimeReport.value = optimizer.buildAngleRuntimeReport(prefs.burikConfig.value)
            showMessage(res.message)
        }
    }

    fun updateBurikCustom(
        textureQualityPercent: Int? = null,
        mipmapLevel: Int? = null,
        nearestFiltering: Boolean? = null,
        disableAnisotropic: Boolean? = null,
        applyAllGames: Boolean? = null
    ) {
        prefs.updateBurikConfig { cur ->
            val keepPreset = if (
                textureQualityPercent == null &&
                mipmapLevel == null &&
                nearestFiltering == null &&
                disableAnisotropic == null
            ) cur.preset else BurikPreset.CUSTOM
            cur.copy(
                preset = keepPreset,
                customTextureQualityPercent = textureQualityPercent ?: cur.customTextureQualityPercent,
                customMipmapLevel = mipmapLevel ?: cur.customMipmapLevel,
                customNearestFiltering = nearestFiltering ?: cur.customNearestFiltering,
                customDisableAnisotropic = disableAnisotropic ?: cur.customDisableAnisotropic,
                applyAllGames = applyAllGames ?: cur.applyAllGames
            )
        }
        val immediate = applyAllGames != null ||
            nearestFiltering != null ||
            disableAnisotropic != null
        burikApplyJob?.cancel()
        burikApplyJob = viewModelScope.launch {
            if (!immediate) delay(280L)
            val res = optimizer.applyBurik(prefs.addedGames.value.toList(), prefs.burikConfig.value)
            _angleRuntimeReport.value = optimizer.buildAngleRuntimeReport(prefs.burikConfig.value)
            if (immediate) showMessage(res.message)
        }
    }

    fun applyAndRestartGameForBurik() {
        burikApplyJob?.cancel()
        burikApplyJob = viewModelScope.launch {
            val targets = prefs.addedGames.value.toList()
            val applyRes = optimizer.applyBurik(targets, prefs.burikConfig.value)
            _angleRuntimeReport.value = optimizer.buildAngleRuntimeReport(prefs.burikConfig.value)
            if (applyRes.success) {
                val restartRes = optimizer.restartTargetGameForAngle()
                showMessage(restartRes.message)
            } else {
                showMessage(applyRes.message)
            }
        }
    }

    fun checkBurikCompatibility() {
        viewModelScope.launch {
            val report = optimizer.buildAngleRuntimeReport(prefs.burikConfig.value)
            _angleRuntimeReport.value = report
            val res = optimizer.inspectAngleStatus(prefs.burikConfig.value)
            showMessage(res.message)
        }
    }

    fun compileSingleGame(packageName: String) {
        viewModelScope.launch {
            _compilingPackages.value = _compilingPackages.value + packageName
            val res = optimizer.compilePackage(packageName, fullSpeed = true)
            _compilingPackages.value = _compilingPackages.value - packageName
            showMessage(res.message)
        }
    }

    fun compileAllGames() {
        val targets = addedGameEntries.value.map { it.packageName }
        if (targets.isEmpty()) {
            showMessage("Tambahkan game terlebih dahulu dari tombol +.")
            return
        }
        viewModelScope.launch {
            var ok = 0
            for (pkg in targets) {
                _compilingPackages.value = _compilingPackages.value + pkg
                val res = optimizer.compilePackage(pkg, fullSpeed = true)
                if (res.success) ok++
                _compilingPackages.value = _compilingPackages.value - pkg
            }
            if (ok > 0) {
                showMessage("$ok/${targets.size} game selesai di-compile penuh.")
            } else {
                showMessage("Aktifkan Opsi 1 (Root) atau Opsi 2 (Shizuku) di Profil untuk menjalankan compile ART.")
            }
        }
    }

    fun debloatApp(entry: DebloatAppEntry) {
        viewModelScope.launch {
            val res = if (entry.isInstalled) {
                optimizer.debloatPackage(entry.packageName)
            } else {
                optimizer.restoreDebloatPackage(entry.packageName)
            }
            showMessage(res.message)
            if (res.success) refreshDebloat()
        }
    }

    fun selectPerformanceProfile(profile: PerformanceProfile) {
        prefs.setPerformanceProfile(profile)
        viewModelScope.launch {
            val res = optimizer.applyPerformanceProfile(profile)
            showMessage(res.message)
        }
    }

    fun refreshBypassCharging(silent: Boolean = false) {
        viewModelScope.launch {
            val probed = optimizer.probeBypassChargingSupport()
            _bypassChargingStatus.value = probed
            if (!silent) showMessage(probed.detail)
        }
    }

    fun toggleBypassCharging(enable: Boolean) {
        viewModelScope.launch {
            val (status, feedback) = optimizer.setBypassCharging(enable)
            _bypassChargingStatus.value = status
            showMessage(feedback.message)
        }
    }

    fun resetFpsSessionStats() {
        telemetry.resetFpsSessionStats()
        showMessage("Statistik FPS Min/Avg/Max direset.")
    }

    fun toggleStopwatch(enabled: Boolean) {
        if (enabled && !Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk menampilkan Stopwatch mengambang.")
            openOverlayPermissionSettings()
            return
        }
        prefs.updateStopwatchConfig { it.copy(enabled = enabled) }
        if (enabled) {
            GameOverlayService.start(appContext, openPanelImmediately = false)
            showMessage("Stopwatch tampil di layar (ketuk untuk Mulai/Jeda, tahan untuk Reset).")
        }
    }

    fun toggleGyroAim(enabled: Boolean) {
        if (enabled && !hasGyroSensor) {
            showMessage("Perangkat ini tidak memiliki sensor fisik Gyroscope.")
            return
        }
        prefs.updateGyroAimConfig { it.copy(enabled = enabled) }
        if (enabled) {
            if (Settings.canDrawOverlays(appContext)) {
                GameOverlayService.start(appContext, openPanelImmediately = false)
            }
            val msg = if (prefs.canUsePrivileged(ShizukuBridge.status.value)) {
                val engine = if (prefs.privilegeMode.value == PrivilegeMode.ROOT) "Root UID 0" else "Shizuku"
                "Gyroscope Camera Aim aktif via $engine."
            } else {
                val needed = if (prefs.privilegeMode.value == PrivilegeMode.ROOT) "Opsi 1 (Root)" else "Opsi 2 (Shizuku)"
                "Gyroscope Aim diaktifkan (izinkan $needed agar injeksi sentuhan berjalan)."
            }
            showMessage(msg)
        }
    }

    fun updateGyroAimConfig(transform: (GyroAimConfig) -> GyroAimConfig) {
        prefs.updateGyroAimConfig(transform)
    }

    fun selectThermalProfile(profile: ThermalProfile) {
        prefs.updateThermalConfig { it.copy(profile = profile) }
        viewModelScope.launch {
            val (status, feedback) = optimizer.applyThermalConfig(prefs.thermalConfig.value)
            _thermalStatus.value = status
            showMessage(feedback.message)
        }
    }

    fun updateThermalConfig(transform: (ThermalConfig) -> ThermalConfig) {
        prefs.updateThermalConfig(transform)
    }

    fun setThermalMaxLimit(enabled: Boolean, targetC: Int? = null) {
        val clamped = (targetC ?: prefs.thermalConfig.value.thermalMaxTargetC).coerceIn(38, 40)
        prefs.updateThermalConfig {
            it.copy(thermalMaxLimitEnabled = enabled, thermalMaxTargetC = clamped)
        }
        viewModelScope.launch {
            val cfgNow = prefs.thermalConfig.value
            val snap = telemetry.snapshot.value
            val engage = enabled && maxOf(snap.socTempC, snap.tempC) >= clamped.toFloat()
            val (status, feedback) = optimizer.applyThermalMaxCap(cfgNow, engageClamp = engage)
            _thermalStatus.value = status
            showMessage(feedback.message)
        }
    }

    fun refreshThermalStatus(silent: Boolean = false) {
        viewModelScope.launch {
            val probed = optimizer.probeThermalStatus()
            _thermalStatus.value = probed
            if (!silent) showMessage(probed.activeNodeSummary)
        }
    }

    fun restoreThermalDefault() {
        selectThermalProfile(ThermalProfile.STOCK)
    }

    fun openThermalFloatingPanel() {
        if (!Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk membuka panel Thermal melayang.")
            openOverlayPermissionSettings()
            return
        }
        prefs.requestPanelTab(PanelTab.THERMAL)
        GameOverlayService.start(appContext, openPanelImmediately = true)
    }

    fun openTouchFloatingPanel() {
        if (!Settings.canDrawOverlays(appContext)) {
            showMessage("Aktifkan izin Overlay untuk membuka panel Touch Response melayang.")
            openOverlayPermissionSettings()
            return
        }
        prefs.requestPanelTab(PanelTab.TOUCH)
        GameOverlayService.start(appContext, openPanelImmediately = true)
    }

    fun refreshTouchDriverStatus(silent: Boolean = false) {
        viewModelScope.launch {
            val probed = optimizer.probeTouchDriverNodes()
            _touchDriverStatus.value = probed
            if (!silent) showMessage(probed.activeSummary)
        }
    }

    fun toggleAntiMistouch(enabled: Boolean) {
        prefs.updateAntiMistouchConfig { it.copy(enabled = enabled) }
        viewModelScope.launch {
            val res = optimizer.applyAntiMistouch(prefs.antiMistouchConfig.value)
            showMessage(res.message)
        }
    }

    fun updateAntiMistouchConfig(transform: (AntiMistouchConfig) -> AntiMistouchConfig) {
        prefs.updateAntiMistouchConfig(transform)
        if (prefs.antiMistouchConfig.value.enabled) {
            viewModelScope.launch {
                val res = optimizer.applyAntiMistouch(prefs.antiMistouchConfig.value)
                showMessage(res.message)
            }
        }
    }

    fun saveCurrentFpsRecord() {
        val snap = telemetry.snapshot.value
        val activePkg = prefs.activeSessionGamePkg.value
        val gameName = addedGameEntries.value.firstOrNull { it.packageName == activePkg }?.name
            ?: activePkg?.substringAfterLast('.')
            ?: "Sesi Game"
        prefs.addFpsSessionRecord(
            FpsSessionRecord(
                id = "fps_${System.currentTimeMillis()}",
                gameName = gameName,
                timestampMs = System.currentTimeMillis(),
                fpsMin = snap.fpsMin,
                fpsAvg = snap.fpsAvg,
                fpsMax = snap.fpsMax,
                peakSocTempC = snap.socTempC
            )
        )
        showMessage("Hasil FPS ($gameName: Avg ${snap.fpsAvg} FPS) tersimpan.")
    }

    fun clearFpsSessionRecords() {
        prefs.clearFpsSessionRecords()
        showMessage("Riwayat hasil FPS dibersihkan.")
    }

    fun saveGameProfile(packageName: String, config: GameProfileConfig?) {
        prefs.setGameProfileConfig(packageName, config)
        showMessage(if (config == null) "Profil game dikembalikan ke global." else "Profil khusus game disimpan.")
    }

    fun restoreAllAfterSession() {
        viewModelScope.launch {
            prefs.setOverlayPanelExpanded(false)
            prefs.setMacroPlacementMode(false)
            prefs.updateMacroConfig { it.copy(enabled = false, isRunning = false) }
            prefs.updateHudConfig { it.copy(enabled = false) }
            prefs.updateStopwatchConfig { it.copy(enabled = false) }
            prefs.updateGyroAimConfig { it.copy(enabled = false) }
            prefs.setScreenDimmerEnabled(false)
            prefs.updateGameNoteConfig { it.copy(pinnedOverlay = false) }
            GameOverlayService.stop(appContext)
            val res = optimizer.restoreAngleTextureOnly()
            prefs.updateBurikConfig { it.copy(preset = BurikPreset.OFF) }
            showMessage(res.message)
        }
    }

    fun selectPrivilegeMode(mode: PrivilegeMode) {
        when (mode) {
            PrivilegeMode.ROOT -> {
                val st = ShizukuBridge.switchToRootMode(appContext)
                if (!st.isRootGranted) {
                    requestRootAccess()
                } else {
                    viewModelScope.launch {
                        if (prefs.touchConfig.value.enabled) {
                            optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
                        }
                        refreshCompatibility()
                        refreshThermalStatus(silent = true)
                        refreshBypassCharging(silent = true)
                        refreshTouchDriverStatus(silent = true)
                    }
                    showMessage("Opsi 1 aktif: Mode Root (UID 0). Shizuku tidak diwajibkan.")
                }
            }
            PrivilegeMode.SHIZUKU -> {
                val st = ShizukuBridge.switchToShizukuMode(appContext)
                viewModelScope.launch {
                    if (prefs.touchConfig.value.enabled) {
                        optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
                    }
                    refreshCompatibility()
                    refreshThermalStatus(silent = true)
                    refreshBypassCharging(silent = true)
                    refreshTouchDriverStatus(silent = true)
                }
                when {
                    st.canRunShizuku -> showMessage("Opsi 2 aktif: Mode Shizuku (Non-Root). Root tidak diwajibkan.")
                    st.isRunning && !st.isPermissionGranted -> {
                        ShizukuBridge.requestPermission()
                        showMessage("Mode Shizuku dipilih (tanpa Root). Berikan izin Shizuku yang muncul.")
                    }
                    else -> showMessage("Opsi 2 dipilih: Mode Shizuku (Non-Root). Hubungkan Shizuku via Wireless Debugging.")
                }
            }
        }
    }

    fun requestShizukuOrCheck() {
        val st = ShizukuBridge.switchToShizukuMode(appContext)
        when {
            st.isRunning && st.isPermissionGranted -> {
                viewModelScope.launch {
                    if (prefs.touchConfig.value.enabled) {
                        optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
                    }
                    refreshThermalStatus(silent = true)
                    refreshBypassCharging(silent = true)
                    refreshTouchDriverStatus(silent = true)
                }
                showMessage("Mode Shizuku aktif (API v${st.apiVersion}). Semua fitur jalan tanpa Root!")
            }
            st.isRunning && !st.isPermissionGranted -> {
                ShizukuBridge.requestPermission()
                showMessage("Meminta izin Shizuku (Opsi 2 — Non-Root)...")
            }
            st.isInstalled -> {
                val launchIntent = appContext.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(launchIntent)
                }
                showMessage("Jalankan layanan Shizuku via Wireless Debugging (tanpa Root).")
            }
            else -> {
                showMessage("Shizuku belum terpasang. Pasang Shizuku atau pilih Opsi 1 (Root) jika perangkat sudah di-root.")
            }
        }
        refreshCompatibility()
    }

    fun toggleUseShizuku(enabled: Boolean) {
        if (enabled) {
            selectPrivilegeMode(PrivilegeMode.SHIZUKU)
        } else {
            prefs.setUseShizuku(false)
            ShizukuBridge.unbindShizukuOnly()
            ShizukuBridge.refresh(appContext, autoTriggerIfReady = false)
            refreshCompatibility()
            showMessage("Mode Shizuku dinonaktifkan.")
        }
    }

    fun requestRootAccess() {
        viewModelScope.launch {
            ShizukuBridge.switchToRootMode(appContext)
            showMessage("Meminta izin Root (Superuser) — Shizuku tidak dibutuhkan...")
            val res = ShizukuBridge.requestRootPermission(appContext)
            if (res.granted && prefs.touchConfig.value.enabled) {
                optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
            }
            refreshCompatibility()
            refreshThermalStatus(silent = true)
            refreshBypassCharging(silent = true)
            refreshTouchDriverStatus(silent = true)
            showMessage(res.message)
        }
    }

    fun toggleUseRoot(enabled: Boolean) {
        if (enabled) {
            selectPrivilegeMode(PrivilegeMode.ROOT)
        } else {
            prefs.setUseRoot(false)
            ShizukuBridge.revokeLocalRootSession()
            ShizukuBridge.refresh(appContext, autoTriggerIfReady = false)
            refreshCompatibility()
            refreshThermalStatus(silent = true)
            refreshBypassCharging(silent = true)
            refreshTouchDriverStatus(silent = true)
            showMessage("Penggunaan Root dinonaktifkan untuk sesi ini.")
        }
    }

    fun openOverlayPermissionSettings() {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${appContext.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
        }
    }

    fun openUsageAccessSettings() {
        runCatching {
            val intent = Intent(
                Settings.ACTION_USAGE_ACCESS_SETTINGS,
                Uri.parse("package:${appContext.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
        }.onFailure {
            runCatching {
                appContext.startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }

    fun openWirelessDebuggingSettings() {
        runCatching {
            appContext.startActivity(
                Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }.onFailure {
            runCatching {
                appContext.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }

    fun openWriteSettings() {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:${appContext.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
        }
    }

    fun openDndSettings() {
        runCatching {
            appContext.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) = prefs.setThemeMode(mode)
    fun setAccentPreset(preset: AccentPreset) = prefs.setAccentPreset(preset)
    fun setLanguage(lang: AppLanguage) = prefs.setLanguage(lang)

    fun showMessage(msg: String) {
        _toastMessage.value = msg
    }

    fun clearMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        // Keep TelemetryMonitor alive only if overlay service is still running
        if (!GameOverlayService.isRunning) {
            telemetry.stop()
        }
    }
}
