package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian base palette matching precision game-space aesthetics
val ObsidianBg = Color(0xFF0B0C0F)
val ObsidianSurface = Color(0xFF14161B)
val ObsidianCard = Color(0xFF1A1D24)
val ObsidianCardElevated = Color(0xFF222630)
val ObsidianBorder = Color(0xFF2B303C)
val ObsidianTextPrimary = Color(0xFFF3F5F8)
val ObsidianTextSecondary = Color(0xFF9AA2B2)
val ObsidianTextMuted = Color(0xFF666E7E)

// Light mode crisp slate palette
val LightBg = Color(0xFFF4F6F9)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFECEFF4)
val LightCardElevated = Color(0xFFE2E6EE)
val LightBorder = Color(0xFFD2D8E3)
val LightTextPrimary = Color(0xFF101319)
val LightTextSecondary = Color(0xFF565F70)

// Semantic status colors
val StatusGreen = Color(0xFF2CE59B)
val StatusAmber = Color(0xFFFFB740)
val StatusRed = Color(0xFFFF5263)
val StatusCyan = Color(0xFF00E5FF)

// Unlocked Pro Accent Colors
val AccentMono = Color(0xFFF3F5F8)
val AccentVoltCyan = Color(0xFF00E5FF)
val AccentCrimson = Color(0xFFFF3B5C)
val AccentAcidLime = Color(0xFFA6FF1A)
val AccentAmber = Color(0xFFFFB020)
val AccentViolet = Color(0xFF9D6BFF)

val CrosshairPalette = listOf(
    Color(0xFFFFFFFF), // White
    Color(0xFF00E5FF), // Cyan
    Color(0xFF2CE59B), // Emerald
    Color(0xFFA6FF1A), // Lime
    Color(0xFFFFEB3B), // Yellow
    Color(0xFFFF9800), // Orange
    Color(0xFFFF3B5C), // Crimson
    Color(0xFFE040FB), // Magenta
    Color(0xFF448AFF), // Blue
    Color(0xFF14161B)  // Stealth Black
)
