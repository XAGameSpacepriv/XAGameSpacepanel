package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AngleRuntimeReport
import com.example.model.BurikConfig
import com.example.model.BurikPreset
import com.example.model.GameEntry
import com.example.ui.components.AppIconThumb
import com.example.ui.components.SectionLabel
import com.example.ui.components.SubScreenTopBar
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import kotlin.math.roundToInt

@Composable
fun BurikScreen(
    config: BurikConfig,
    angleReport: AngleRuntimeReport = AngleRuntimeReport(),
    addedGames: List<GameEntry>,
    getAppIcon: (String) -> androidx.compose.ui.graphics.ImageBitmap?,
    onSelectPreset: (BurikPreset) -> Unit,
    onUpdateCustom: (
        textureQualityPercent: Int?,
        mipmapLevel: Int?,
        nearestFiltering: Boolean?,
        disableAnisotropic: Boolean?,
        applyAllGames: Boolean?
    ) -> Unit,
    onApplyAndRestart: () -> Unit = {},
    onCheckBurik: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
    ) {
        SubScreenTopBar(title = "Texture (ANGLE)", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Before / After Texture Quality Comparison Preview
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        BurikPreviewCanvas(
                            preset = BurikPreset.OFF,
                            textureQualityPercent = 100,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(104.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Asli (100%)",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        BurikPreviewCanvas(
                            preset = config.preset,
                            textureQualityPercent = config.effectiveTextureQuality(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(104.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${config.preset.title} (${config.effectiveTextureQuality()}%)",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }

            // ANGLE Runtime Status Card
            item {
                val activeFlags = config.angleFeatureFlags()
                val statusTint = when {
                    !angleReport.shizukuReady -> Color(0xFFFFB740)
                    angleReport.logcatConfirmed || angleReport.angleDriverDetected -> StatusGreen
                    else -> Color(0xFFFF6B6B)
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, statusTint.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Status Driver ANGLE",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = angleReport.angleProviderLabel,
                            color = statusTint,
                            fontFamily = JetBrainsMono,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusTint.copy(alpha = 0.14f))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = angleReport.lastCheckSummary.ifBlank {
                            "ANGLE hanya dimuat saat proses game dibuka ulang (cold start)."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                    if (activeFlags.isNotEmpty()) {
                        Text(
                            text = "Flags: ${activeFlags.joinToString(":")}",
                            color = StatusCyan,
                            fontFamily = JetBrainsMono,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            // Global All Games ANGLE Toggle
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .clickable { onUpdateCustom(null, null, null, null, !config.applyAllGames) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Terapkan ke Semua Game (All Games)",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Aktifkan driver ANGLE & penurunan tekstur rendah di seluruh game",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = config.applyAllGames,
                        onCheckedChange = { onUpdateCustom(null, null, null, null, it) }
                    )
                }
            }

            item { SectionLabel("Preset Tekstur ANGLE (Semua Terbuka)") }

            items(BurikPreset.entries) { preset ->
                val selected = config.preset == preset
                val previewQuality = if (preset == BurikPreset.CUSTOM) config.customTextureQualityPercent else preset.textureQualityPercent
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { onSelectPreset(preset) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("burik_preset_${preset.name}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BurikPreviewCanvas(
                        preset = preset,
                        textureQualityPercent = previewQuality,
                        modifier = Modifier
                            .size(width = 56.dp, height = 40.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = preset.title,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (preset in listOf(BurikPreset.FLAT, BurikPreset.RETRO, BurikPreset.CUSTOM)) {
                                Text(
                                    text = "PRO UNLOCKED",
                                    color = StatusGreen,
                                    fontFamily = JetBrainsMono,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(StatusGreen.copy(alpha = 0.14f))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = preset.subtitle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                    RadioButton(
                        selected = selected,
                        onClick = { onSelectPreset(preset) }
                    )
                }
            }

            if (config.preset == BurikPreset.CUSTOM) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Kualitas Tekstur ANGLE", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("${config.customTextureQualityPercent}%", fontFamily = JetBrainsMono, fontSize = 13.sp)
                        }
                        Slider(
                            value = config.customTextureQualityPercent.toFloat(),
                            onValueChange = { onUpdateCustom(it.roundToInt(), null, null, null, null) },
                            valueRange = 15f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            )
                        )

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mipmap / Texture LOD Level", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Level ${config.customMipmapLevel}", fontFamily = JetBrainsMono, fontSize = 13.sp)
                        }
                        Slider(
                            value = config.customMipmapLevel.toFloat(),
                            onValueChange = { onUpdateCustom(null, it.roundToInt(), null, null, null) },
                            valueRange = 0f..4f,
                            steps = 3
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Nearest Mip Filtering", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("Ganti filter tekstur halus ke blok piksel ringan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = config.customNearestFiltering,
                                onCheckedChange = { onUpdateCustom(null, null, it, null, null) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Nonaktifkan Anisotropic Filtering", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("Kurangi beban shader sampling tekstur jarak jauh", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = config.customDisableAnisotropic,
                                onCheckedChange = { onUpdateCustom(null, null, null, it, null) }
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Mengaktifkan driver ANGLE (OpenGL ES via Vulkan) dan flag angle_egl_features untuk grafik low. Jika game sudah terbuka, tekan Terapkan & Restart Game agar ANGLE termuat penuh.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApplyAndRestart,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_apply_restart_burik")
                    ) {
                        Text("Terapkan & Restart", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onCheckBurik,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_cek_burik")
                    ) {
                        Text("Cek Status ANGLE", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }

            item { SectionLabel(if (config.applyAllGames) "Target Aktif (All Games + Daftar Game)" else "Target Game Terpilih") }

            if (addedGames.isEmpty()) {
                item {
                    Text(
                        text = if (config.applyAllGames) {
                            "Mode All Games aktif: ANGLE otomatis diterapkan ke seluruh paket game di perangkat."
                        } else {
                            "Belum ada game yang ditambahkan. Tambahkan game dari tombol + di Beranda."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            } else {
                items(addedGames, key = { it.packageName }) { game ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIconThumb(
                            iconBitmap = getAppIcon(game.packageName),
                            fallbackLabel = game.name,
                            size = 38.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = game.name,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (config.preset == BurikPreset.OFF) {
                                    "Normal (Default)"
                                } else {
                                    "ANGLE ${config.preset.title} • Texture ${config.effectiveTextureQuality()}% • Mip ${config.effectiveMipmapLevel()}"
                                },
                                color = if (config.preset == BurikPreset.OFF) MaterialTheme.colorScheme.onSurfaceVariant else StatusGreen,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Procedural GPU texture/mipmap preview canvas so users immediately see
 * the texture LOD & nearest-filtering difference across presets.
 */
@Composable
private fun BurikPreviewCanvas(
    preset: BurikPreset,
    textureQualityPercent: Int,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cellStep = when (preset) {
            BurikPreset.OFF -> 1
            BurikPreset.SOFT -> 5
            BurikPreset.PIXEL -> 10
            BurikPreset.FLAT -> 16
            BurikPreset.RETRO -> 22
            BurikPreset.CUSTOM -> (((105 - textureQualityPercent) / 100f) * 24f).roundToInt().coerceIn(2, 24)
        }

        if (cellStep <= 2) {
            // Crisp sky + mountain + asphalt road horizon
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF1F2A38), Color(0xFF3E526A), Color(0xFF14181F))
                )
            )
            val mountain = Path().apply {
                moveTo(0f, h * 0.62f)
                lineTo(w * 0.28f, h * 0.34f)
                lineTo(w * 0.56f, h * 0.54f)
                lineTo(w * 0.82f, h * 0.28f)
                lineTo(w, h * 0.58f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(mountain, Color(0xFF283344))
            drawRect(
                color = Color(0xFF1B1F27),
                topLeft = Offset(0f, h * 0.62f),
                size = Size(w, h * 0.38f)
            )
            // Crisp road stripes
            drawLine(
                color = Color(0xFFE0E5EE),
                start = Offset(w * 0.5f, h * 0.64f),
                end = Offset(w * 0.5f, h),
                strokeWidth = 2.5f
            )
            drawLine(
                color = Color(0xFF00E5FF),
                start = Offset(w * 0.12f, h),
                end = Offset(w * 0.44f, h * 0.62f),
                strokeWidth = 2f
            )
            drawLine(
                color = Color(0xFF00E5FF),
                start = Offset(w * 0.88f, h),
                end = Offset(w * 0.56f, h * 0.62f),
                strokeWidth = 2f
            )
        } else {
            // Pixelated / Low-LOD block sampling
            val step = cellStep.toFloat()
            var y = 0f
            while (y < h) {
                var x = 0f
                while (x < w) {
                    val ny = (y + step * 0.5f) / h
                    val nx = (x + step * 0.5f) / w
                    val color = when {
                        ny > 0.62f && kotlin.math.abs(nx - 0.5f) < 0.04f -> Color(0xFFD5DCE6)
                        ny > 0.62f -> Color(0xFF1D222B)
                        ny > 0.34f && (nx < 0.45f || nx > 0.65f) -> Color(0xFF2C384B)
                        else -> Color(0xFF3A4D65)
                    }
                    val shaded = if (preset == BurikPreset.FLAT || preset == BurikPreset.RETRO) {
                        color.copy(alpha = 0.92f)
                    } else color
                    drawRect(
                        color = shaded,
                        topLeft = Offset(x, y),
                        size = Size(step + 0.5f, step + 0.5f)
                    )
                    x += step
                }
                y += step
            }
        }
    }
}
