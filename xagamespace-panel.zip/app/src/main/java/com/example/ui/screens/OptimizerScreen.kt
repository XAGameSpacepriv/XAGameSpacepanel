package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.TouchBoostPreset
import com.example.model.AiTriggerRule
import com.example.model.AntiMistouchConfig
import com.example.model.BurikConfig
import com.example.model.BypassChargingStatus
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.FpsSessionRecord
import com.example.model.GyroAimConfig
import com.example.model.HudConfig
import com.example.model.MacroConfig
import com.example.model.MaxScreenResponseConfig
import com.example.model.PerformanceProfile
import com.example.model.ScreenResponseLevel
import com.example.model.ScreenResponseStatus
import com.example.model.StopwatchConfig
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.model.TouchConfig
import com.example.model.TouchDriverStatus
import com.example.ui.components.SectionLabel
import com.example.ui.components.SettingNavCard
import com.example.ui.components.SettingToggleCard
import com.example.ui.components.TopIdHeader
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import kotlin.math.roundToInt

@Composable
fun OptimizerScreen(
    sessionId: String,
    hudConfig: HudConfig,
    touchConfig: TouchConfig,
    macroConfig: MacroConfig,
    burikConfig: BurikConfig,
    fpsLockConfig: FpsLockConfig,
    fastAnimEnabled: Boolean,
    onToggleHud: (Boolean) -> Unit,
    onToggleSensitivity: (Boolean) -> Unit,
    onToggleMacro: (Boolean) -> Unit,
    onSelectFpsLock: (FpsLockTarget) -> Unit,
    onOpenBurik: () -> Unit,
    onOpenCompile: () -> Unit,
    onOpenDebloat: () -> Unit,
    onToggleFastAnim: (Boolean) -> Unit,
    aiTriggerMasterEnabled: Boolean = false,
    aiTriggerRules: List<AiTriggerRule> = emptyList(),
    onToggleAiTrigger: (Boolean) -> Unit = {},
    onOpenAiTriggerPanel: () -> Unit = {},
    performanceProfile: PerformanceProfile = PerformanceProfile.BALANCED,
    bypassStatus: BypassChargingStatus = BypassChargingStatus(),
    stopwatchConfig: StopwatchConfig = StopwatchConfig(),
    gyroAimConfig: GyroAimConfig = GyroAimConfig(),
    hasGyroSensor: Boolean = true,
    onSelectPerformanceProfile: (PerformanceProfile) -> Unit = {},
    onToggleBypassCharging: (Boolean) -> Unit = {},
    onProbeBypassCharging: () -> Unit = {},
    onToggleStopwatch: (Boolean) -> Unit = {},
    onToggleGyroAim: (Boolean) -> Unit = {},
    onUpdateGyroAimConfig: ((GyroAimConfig) -> GyroAimConfig) -> Unit = {},
    thermalConfig: ThermalConfig = ThermalConfig(),
    thermalStatus: ThermalStatus = ThermalStatus(),
    touchDriverStatus: TouchDriverStatus = TouchDriverStatus(),
    antiMistouchConfig: AntiMistouchConfig = AntiMistouchConfig(),
    fpsSessionRecords: List<FpsSessionRecord> = emptyList(),
    onSelectThermalProfile: (ThermalProfile) -> Unit = {},
    onSetThermalMaxLimit: (Boolean, Int) -> Unit = { _, _ -> },
    onProbeThermal: () -> Unit = {},
    onOpenThermalPanel: () -> Unit = {},
    onOpenTouchPanel: () -> Unit = {},
    onProbeTouchDriver: () -> Unit = {},
    onApplyTouchPreset: (TouchBoostPreset) -> Unit = {},
    onToggleAntiMistouch: (Boolean) -> Unit = {},
    onSaveFpsRecord: () -> Unit = {},
    onClearFpsRecords: () -> Unit = {},
    maxScreenResponseConfig: MaxScreenResponseConfig = MaxScreenResponseConfig(),
    screenResponseStatus: ScreenResponseStatus = ScreenResponseStatus(),
    onToggleMaxScreenResponse: (Boolean) -> Unit = {},
    onSelectScreenResponseLevel: (ScreenResponseLevel) -> Unit = {},
    onUpdateMaxScreenResponseConfig: ((MaxScreenResponseConfig) -> MaxScreenResponseConfig) -> Unit = {},
    onApplyMaxScreenResponseNow: () -> Unit = {},
    onProbeScreenResponse: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var confirmSensitivityDialog by remember { mutableStateOf(false) }
    var confirmMacroDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopIdHeader(title = "Optimizer", sessionId = sessionId)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // New headline feature: Responsif Layar Max
            item { SectionLabel("Responsif Layar Max") }
            item {
                MaxScreenResponseCard(
                    config = maxScreenResponseConfig,
                    status = screenResponseStatus,
                    onToggleEnabled = onToggleMaxScreenResponse,
                    onSelectLevel = onSelectScreenResponseLevel,
                    onUpdateConfig = onUpdateMaxScreenResponseConfig,
                    onApplyNow = onApplyMaxScreenResponseNow,
                    onProbeHardware = onProbeScreenResponse
                )
            }

            item { SectionLabel("Performa & Thermal") }
            item {
                PerformanceProfileCard(
                    selected = performanceProfile,
                    onSelect = onSelectPerformanceProfile
                )
            }
            item {
                ThermalAdvanceCard(
                    config = thermalConfig,
                    status = thermalStatus,
                    onSelectProfile = onSelectThermalProfile,
                    onSetThermalMaxLimit = onSetThermalMaxLimit,
                    onProbeThermal = onProbeThermal,
                    onOpenThermalPanel = onOpenThermalPanel
                )
            }
            item {
                BypassChargingCard(
                    status = bypassStatus,
                    onToggle = onToggleBypassCharging,
                    onProbe = onProbeBypassCharging
                )
            }

            item { SectionLabel("Overlay & Statistik") }
            item {
                SettingToggleCard(
                    icon = AppIcons.HudOverlay,
                    title = "Performance HUD",
                    subtitle = "FPS Min/Avg/Max, CPU, RAM dan suhu SoC",
                    checked = hudConfig.enabled,
                    testTag = "toggle_performance_hud",
                    onCheckedChange = onToggleHud
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.Stopwatch,
                    title = "Stopwatch Mengambang",
                    subtitle = "Timer cepat di atas game (ketuk Mulai/Jeda, tahan Reset)",
                    checked = stopwatchConfig.enabled,
                    testTag = "toggle_stopwatch",
                    onCheckedChange = onToggleStopwatch
                )
            }
            item {
                FpsResultHistoryCard(
                    records = fpsSessionRecords,
                    onSaveNow = onSaveFpsRecord,
                    onClearAll = onClearFpsRecords
                )
            }

            item { SectionLabel("Touch & Kontrol") }
            item {
                TouchResponseCard(
                    config = touchConfig,
                    driverStatus = touchDriverStatus,
                    onRequestToggle = { wantEnable ->
                        if (wantEnable) confirmSensitivityDialog = true
                        else onToggleSensitivity(false)
                    },
                    onApplyPreset = onApplyTouchPreset,
                    onOpenTouchPanel = onOpenTouchPanel,
                    onProbeDriver = onProbeTouchDriver
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.Macro,
                    title = "Macro 10-Jari",
                    subtitle = "Zero-Stutter Async • tahan sambil geser kamera lancar",
                    badge = "Full",
                    checked = macroConfig.enabled,
                    testTag = "toggle_macro",
                    onCheckedChange = { wantEnable ->
                        if (wantEnable) confirmMacroDialog = true
                        else onToggleMacro(false)
                    }
                )
            }
            item {
                GyroAimCard(
                    config = gyroAimConfig,
                    hasSensor = hasGyroSensor,
                    onToggle = onToggleGyroAim,
                    onUpdate = onUpdateGyroAimConfig
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.AiTrigger,
                    title = "AI Trigger",
                    subtitle = if (aiTriggerRules.isEmpty()) {
                        "Crop musuh & Target Aim • Crosshair sentuh badan otomatis ke kepala"
                    } else {
                        "${aiTriggerRules.count { it.enabled }}/${aiTriggerRules.size} pemicu aktif • Auto Head Trigger"
                    },
                    badge = "RedMagic Mode",
                    checked = aiTriggerMasterEnabled,
                    testTag = "toggle_ai_trigger",
                    onCheckedChange = onToggleAiTrigger
                )
            }
            item {
                SettingNavCard(
                    icon = AppIcons.AiTrigger,
                    title = "Atur AI Trigger di Overlay",
                    subtitle = "Crop musuh, tambah Target Aim merah & auto-trigger ke kepala",
                    testTag = "nav_ai_trigger_panel",
                    onClick = onOpenAiTriggerPanel
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.Shield,
                    title = "Anti-Mistouch",
                    subtitle = "Blokir gestur tepi & notifikasi pop-up saat bermain",
                    checked = antiMistouchConfig.enabled,
                    testTag = "toggle_anti_mistouch",
                    onCheckedChange = onToggleAntiMistouch
                )
            }

            item { SectionLabel("Grafis & Texture (ANGLE)") }
            item {
                SettingNavCard(
                    icon = AppIcons.PixelGrid,
                    title = "Texture (ANGLE)",
                    subtitle = "${burikConfig.preset.title} (${burikConfig.effectiveTextureQuality()}%)" +
                        if (burikConfig.applyAllGames) " • All Games" else "",
                    badge = "All Unlocked",
                    testTag = "nav_burik",
                    onClick = onOpenBurik
                )
            }
            item {
                FpsLockCard(
                    config = fpsLockConfig,
                    onSelectTarget = onSelectFpsLock
                )
            }

            item { SectionLabel("Sistem") }
            item {
                SettingNavCard(
                    icon = AppIcons.CodeCompile,
                    title = "Compile ART",
                    subtitle = "Game lebih cepat dimuat tanpa stuttering shader",
                    testTag = "nav_compile",
                    onClick = onOpenCompile
                )
            }
            item {
                SettingNavCard(
                    icon = AppIcons.Debloat,
                    title = "Debloat",
                    subtitle = "Hapus aplikasi bawaan (UAD-ng)",
                    testTag = "nav_debloat",
                    onClick = onOpenDebloat
                )
            }

            item { SectionLabel("Saat main") }
            item {
                SettingToggleCard(
                    icon = AppIcons.SpeedGauge,
                    title = "Animasi cepat",
                    subtitle = "Animasi sistem 0.3x saat main",
                    checked = fastAnimEnabled,
                    testTag = "toggle_fast_anim",
                    onCheckedChange = onToggleFastAnim
                )
            }
            item {
                Text(
                    text = "Aktif selama sesi game berjalan. Pilih Opsi 1 (Root) atau Opsi 2 (Shizuku) di tab Profil sesuai kebutuhan.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }

    if (confirmSensitivityDialog) {
        AlertDialog(
            onDismissRequest = { confirmSensitivityDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Nyalakan Touch Sensitivity?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Aktifkan Touch X/Y Live Amplifier & driver touchpanel tanpa mengubah ukuran DPI layar.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                    Text(
                        "Berjalan via Opsi 1 (Root Kernel Evdev) atau Opsi 2 (Shizuku Live Touch Boost).",
                        color = StatusCyan,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusCyan.copy(alpha = 0.12f))
                            .padding(10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Gain X / Y", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(
                            "X ${"%.2fx".format(touchConfig.gainX())} • Y ${"%.2fx".format(touchConfig.gainY())}",
                            fontFamily = JetBrainsMono,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Polling", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(touchConfig.pollingPreset.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmSensitivityDialog = false }) {
                    Text("Batal")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmSensitivityDialog = false
                        onToggleSensitivity(true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Nyalakan", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }

    if (confirmMacroDialog) {
        AlertDialog(
            onDismissRequest = { confirmMacroDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Nyalakan Macro 10-Jari?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Berlaku di game yang kamu pilih. Atur Trigger & Target dari panel di dalam game.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                    Text(
                        "Berjalan mandiri via Opsi 1 (Root Slot-9 Hardware) atau Opsi 2 (Shizuku Multi-Pointer Merge) tanpa Aksesibilitas agar geser kamera tetap mulus.",
                        color = StatusAmber,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusAmber.copy(alpha = 0.12f))
                            .padding(10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pola", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(macroConfig.pattern.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Interval", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(
                            "${macroConfig.intervalMs} ms",
                            fontFamily = JetBrainsMono,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmMacroDialog = false }) {
                    Text("Batal")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmMacroDialog = false
                        onToggleMacro(true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Nyalakan", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun PerformanceProfileCard(
    selected: PerformanceProfile,
    onSelect: (PerformanceProfile) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_performance_profile"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Profil Performa",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = selected.subtitle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = selected.label,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = JetBrainsMono,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PerformanceProfile.entries.forEach { profile ->
                    val isSel = profile == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSel) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSel) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelect(profile) }
                            .testTag("perf_profile_${profile.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = profile.shortLabel,
                            color = if (isSel) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BypassChargingCard(
    status: BypassChargingStatus,
    onToggle: (Boolean) -> Unit,
    onProbe: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_bypass_charging"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.BatteryBypass,
                            contentDescription = "Bypass Charging",
                            tint = if (status.enabled) StatusGreen else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Bypass Charging",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = status.detail,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Switch(
                    checked = status.enabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("toggle_bypass_charging")
                )
            }
            OutlinedButton(
                onClick = onProbe,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_probe_bypass")
            ) {
                Text("Pindai Node Bypass Kernel", fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun TouchResponseCard(
    config: TouchConfig,
    driverStatus: TouchDriverStatus,
    onRequestToggle: (Boolean) -> Unit,
    onApplyPreset: (TouchBoostPreset) -> Unit,
    onOpenTouchPanel: () -> Unit,
    onProbeDriver: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_touch_response"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.Touch,
                            contentDescription = "Sensitivity X/Y",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Touch Sensitivity X & Y",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "X ${"%.2fx".format(config.gainX())} • Y ${"%.2fx".format(config.gainY())} • ${config.pollingPreset.shortLabel}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = JetBrainsMono,
                            fontSize = 11.sp
                        )
                    }
                }
                Switch(
                    checked = config.enabled,
                    onCheckedChange = onRequestToggle,
                    modifier = Modifier.testTag("toggle_sensitivity")
                )
            }

            // One-tap Racikan Licin presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TouchBoostPreset.entries.forEach { preset ->
                    val matched = preset.matches(config)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (matched) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (matched) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.24f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { onApplyPreset(preset) }
                            .testTag("preset_touch_${preset.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = preset.label,
                            color = if (matched) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            fontSize = 10.sp,
                            fontWeight = if (matched) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Text(
                text = driverStatus.activeSummary,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onProbeDriver,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_probe_touch_driver")
                ) {
                    Text("Cek Driver", fontSize = 11.sp)
                }
                Button(
                    onClick = onOpenTouchPanel,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_open_touch_panel")
                ) {
                    Text("Panel Touch", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun GyroAimCard(
    config: GyroAimConfig,
    hasSensor: Boolean,
    onToggle: (Boolean) -> Unit,
    onUpdate: ((GyroAimConfig) -> GyroAimConfig) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_gyro_aim"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.Gyroscope,
                            contentDescription = "Gyroscope Aim",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Gyroscope Camera Aim",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (hasSensor) {
                                "Sensi X ${config.sensitivityX} • Y ${config.sensitivityY}"
                            } else {
                                "Sensor fisik Gyroscope tidak terdeteksi"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
                Switch(
                    checked = config.enabled,
                    enabled = hasSensor,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("toggle_gyro_aim")
                )
            }

            if (config.enabled && hasSensor) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sensitivitas Gyro X", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${config.sensitivityX}", fontFamily = JetBrainsMono, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = config.sensitivityX.toFloat(),
                        onValueChange = { v -> onUpdate { it.copy(sensitivityX = v.roundToInt()) } },
                        valueRange = 10f..150f,
                        modifier = Modifier.heightIn(min = 36.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sensitivitas Gyro Y", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${config.sensitivityY}", fontFamily = JetBrainsMono, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = config.sensitivityY.toFloat(),
                        onValueChange = { v -> onUpdate { it.copy(sensitivityY = v.roundToInt()) } },
                        valueRange = 10f..150f,
                        modifier = Modifier.heightIn(min = 36.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FpsLockCard(
    config: FpsLockConfig,
    onSelectTarget: (FpsLockTarget) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_fps_lock"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.SpeedGauge,
                            contentDescription = "FPS Lock",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "FPS Lock",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = config.target.subtitle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Text(
                    text = config.target.label,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = JetBrainsMono,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FpsLockTarget.entries.forEach { target ->
                    val selected = config.target == target
                    val chipText = if (target == FpsLockTarget.DEFAULT) "Auto" else "${target.fps} FPS"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelectTarget(target) }
                            .testTag("fps_lock_${target.fps}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = chipText,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
