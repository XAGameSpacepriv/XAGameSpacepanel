package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiTriggerRule
import com.example.model.BurikConfig
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.HudConfig
import com.example.model.MacroConfig
import com.example.model.TouchConfig
import com.example.ui.components.SectionLabel
import com.example.ui.components.SettingNavCard
import com.example.ui.components.SettingToggleCard
import com.example.ui.components.TopIdHeader
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber

@Composable
fun OptimizerScreen(
    sessionId: String,
    hudConfig: HudConfig,
    touchConfig: TouchConfig,
    macroConfig: MacroConfig,
    burikConfig: BurikConfig,
    fpsLockConfig: FpsLockConfig,
    fastAnimEnabled: Boolean,
    onToggleHud: (Boolean) -> Unit,
    onToggleSensitivity: (Boolean) -> Unit,
    onToggleMacro: (Boolean) -> Unit,
    onSelectFpsLock: (FpsLockTarget) -> Unit,
    onOpenBurik: () -> Unit,
    onOpenCompile: () -> Unit,
    onOpenDebloat: () -> Unit,
    onToggleFastAnim: (Boolean) -> Unit,
    aiTriggerMasterEnabled: Boolean = false,
    aiTriggerRules: List<AiTriggerRule> = emptyList(),
    onToggleAiTrigger: (Boolean) -> Unit = {},
    onOpenAiTriggerPanel: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var confirmSensitivityDialog by remember { mutableStateOf(false) }
    var confirmMacroDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopIdHeader(title = "Optimizer", sessionId = sessionId)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionLabel("Overlay") }
            item {
                SettingToggleCard(
                    icon = AppIcons.HudOverlay,
                    title = "Performance HUD",
                    subtitle = "FPS, CPU, RAM dan suhu",
                    checked = hudConfig.enabled,
                    testTag = "toggle_performance_hud",
                    onCheckedChange = onToggleHud
                )
            }

            item { SectionLabel("Touch") }
            item {
                SettingToggleCard(
                    icon = AppIcons.Touch,
                    title = "Sensitivity",
                    subtitle = if (touchConfig.nubiaGameTweakEnabled) {
                        "Nubia Touch Engine • X ${touchConfig.speedX}%, Y ${touchConfig.speedY}%"
                    } else {
                        "X ${touchConfig.speedX}%, Y ${touchConfig.speedY}%"
                    },
                    badge = "Nubia Tweak",
                    checked = touchConfig.enabled,
                    testTag = "toggle_sensitivity",
                    onCheckedChange = { wantEnable ->
                        if (wantEnable) confirmSensitivityDialog = true
                        else onToggleSensitivity(false)
                    }
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.Macro,
                    title = "Macro",
                    subtitle = "Zero-Stutter Async • hingga 60 tap/dtk tanpa macet",
                    badge = "Full",
                    checked = macroConfig.enabled,
                    testTag = "toggle_macro",
                    onCheckedChange = { wantEnable ->
                        if (wantEnable) confirmMacroDialog = true
                        else onToggleMacro(false)
                    }
                )
            }
            item {
                SettingToggleCard(
                    icon = AppIcons.AiTrigger,
                    title = "AI Trigger",
                    subtitle = if (aiTriggerRules.isEmpty()) {
                        "Crop musuh & Target Aim • Crosshair sentuh badan otomatis ke kepala"
                    } else {
                        "${aiTriggerRules.count { it.enabled }}/${aiTriggerRules.size} pemicu aktif • Auto Head Trigger"
                    },
                    badge = "RedMagic Mode",
                    checked = aiTriggerMasterEnabled,
                    testTag = "toggle_ai_trigger",
                    onCheckedChange = onToggleAiTrigger
                )
            }
            item {
                SettingNavCard(
                    icon = AppIcons.AiTrigger,
                    title = "Atur AI Trigger di Overlay",
                    subtitle = "Crop musuh, tambah Target Aim merah & auto-trigger ke kepala",
                    testTag = "nav_ai_trigger_panel",
                    onClick = onOpenAiTriggerPanel
                )
            }
            item {
                Text(
                    text = "Atur kecepatan, zona, dan posisi macro/AI trigger dari panel XAGameSpacepanel di atas game.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            item { SectionLabel("Grafis & Texture (ANGLE)") }
            item {
                SettingNavCard(
                    icon = AppIcons.PixelGrid,
                    title = "Texture (ANGLE)",
                    subtitle = "${burikConfig.preset.title} (${burikConfig.effectiveTextureQuality()}%)" +
                        if (burikConfig.applyAllGames) " • All Games" else "",
                    badge = "All Unlocked",
                    testTag = "nav_burik",
                    onClick = onOpenBurik
                )
            }
            item {
                FpsLockCard(
                    config = fpsLockConfig,
                    onSelectTarget = onSelectFpsLock
                )
            }

            item { SectionLabel("Sistem") }
            item {
                SettingNavCard(
                    icon = AppIcons.CodeCompile,
                    title = "Compile",
                    subtitle = "Game lebih cepat dimuat",
                    testTag = "nav_compile",
                    onClick = onOpenCompile
                )
            }
            item {
                SettingNavCard(
                    icon = AppIcons.Debloat,
                    title = "Debloat",
                    subtitle = "Hapus aplikasi bawaan (UAD-ng)",
                    testTag = "nav_debloat",
                    onClick = onOpenDebloat
                )
            }

            item { SectionLabel("Saat main") }
            item {
                SettingToggleCard(
                    icon = AppIcons.SpeedGauge,
                    title = "Animasi cepat",
                    subtitle = "Animasi sistem 0.3x saat main",
                    checked = fastAnimEnabled,
                    testTag = "toggle_fast_anim",
                    onCheckedChange = onToggleFastAnim
                )
            }
            item {
                Text(
                    text = "Aktif selama game yang dipilih terbuka, lalu otomatis balik normal saat kamu keluar.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }

    if (confirmSensitivityDialog) {
        AlertDialog(
            onDismissRequest = { confirmSensitivityDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Nyalakan Sensitivity?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Berlaku di game yang kamu pilih. Atur dari panel di dalam game.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                    Text(
                        "Kalibrasi touch sensitivity, response latency, dan DPI Sensitivity Boost (via Shizuku) akan diaktifkan.",
                        color = StatusAmber,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusAmber.copy(alpha = 0.12f))
                            .padding(10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kecepatan", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(
                            "X ${touchConfig.speedX}%, Y ${touchConfig.speedY}%",
                            fontFamily = JetBrainsMono,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Area", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(touchConfig.area.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmSensitivityDialog = false }) {
                    Text("Batal")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmSensitivityDialog = false
                        onToggleSensitivity(true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Nyalakan", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }

    if (confirmMacroDialog) {
        AlertDialog(
            onDismissRequest = { confirmMacroDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Nyalakan Macro?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Berlaku di game yang kamu pilih. Atur Trigger & Target dari panel di dalam game.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                    Text(
                        "Berjalan via Shizuku Input Injection (tanpa Aksesibilitas) & mendukung 10 jari agar layar tetap bisa digeser saat Trigger ditekan.",
                        color = StatusAmber,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusAmber.copy(alpha = 0.12f))
                            .padding(10.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pola", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(macroConfig.pattern.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Interval", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text(
                            "${macroConfig.intervalMs} ms",
                            fontFamily = JetBrainsMono,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmMacroDialog = false }) {
                    Text("Batal")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmMacroDialog = false
                        onToggleMacro(true)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Nyalakan", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun FpsLockCard(
    config: FpsLockConfig,
    onSelectTarget: (FpsLockTarget) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_fps_lock"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.SpeedGauge,
                            contentDescription = "FPS Lock",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "FPS Lock",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = config.target.subtitle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Text(
                    text = config.target.label,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = JetBrainsMono,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FpsLockTarget.entries.forEach { target ->
                    val selected = config.target == target
                    val chipText = if (target == FpsLockTarget.DEFAULT) "Auto" else "${target.fps} FPS"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                            .border(
                                width = 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelectTarget(target) }
                            .testTag("fps_lock_${target.fps}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = chipText,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
