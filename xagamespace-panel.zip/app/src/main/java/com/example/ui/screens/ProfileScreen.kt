package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AccentPreset
import com.example.model.AppLanguage
import com.example.model.PrivilegeMode
import com.example.model.RootGrantState
import com.example.model.ShizukuStatus
import com.example.model.ThemeMode
import com.example.ui.components.SectionLabel
import com.example.ui.components.SettingNavCard
import com.example.ui.components.SettingToggleCard
import com.example.ui.components.TopIdHeader
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.accentColorFor

@Composable
fun ProfileScreen(
    sessionId: String,
    shizukuStatus: ShizukuStatus,
    privilegeMode: PrivilegeMode = PrivilegeMode.SHIZUKU,
    useShizuku: Boolean,
    useRoot: Boolean = false,
    themeMode: ThemeMode,
    accentPreset: AccentPreset,
    language: AppLanguage,
    restoreAfterSession: Boolean,
    onSelectPrivilegeMode: (PrivilegeMode) -> Unit = {},
    onCheckWirelessDebugging: () -> Unit,
    onToggleUseShizuku: (Boolean) -> Unit,
    onRequestShizuku: () -> Unit,
    onToggleUseRoot: (Boolean) -> Unit = {},
    onRequestRoot: () -> Unit = {},
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectAccent: (AccentPreset) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onOpenCompatibility: () -> Unit,
    onToggleRestoreAfterSession: (Boolean) -> Unit,
    onRestoreNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showThemeDialog by remember { mutableStateOf(false) }
    var showAccentDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showTroubleshootDialog by remember { mutableStateOf(false) }
    var showWirelessDialog by remember { mutableStateOf(false) }
    var showRootDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .widthIn(max = 600.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopIdHeader(title = "Profil", sessionId = sessionId)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 2-Option Privilege Mode Selector (Root vs Shizuku — mutually independent)
            item {
                val isRootMode = privilegeMode == PrivilegeMode.ROOT
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(14.dp)
                        .testTag("privilege_mode_selector"),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "Mode Akses Sistem (Pilih Salah Satu)",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Gunakan Root saja tanpa perlu Shizuku, atau Shizuku saja tanpa perlu Root.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PrivilegeOptionTile(
                            optionTag = "OPSI 1",
                            title = "Mode Root",
                            subtitle = if (shizukuStatus.isRootGranted) "UID 0 Aktif" else "Tanpa Shizuku",
                            selected = isRootMode,
                            accentColor = StatusGreen,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("option_privilege_root"),
                            onClick = { onSelectPrivilegeMode(PrivilegeMode.ROOT) }
                        )
                        PrivilegeOptionTile(
                            optionTag = "OPSI 2",
                            title = "Mode Shizuku",
                            subtitle = if (shizukuStatus.canRunShizuku) "Terhubung" else "Non-Root",
                            selected = !isRootMode,
                            accentColor = StatusCyan,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("option_privilege_shizuku"),
                            onClick = { onSelectPrivilegeMode(PrivilegeMode.SHIZUKU) }
                        )
                    }

                    Text(
                        text = if (isRootMode) {
                            "Aktif: Opsi 1 (Root UID 0) • Shizuku TIDAK diwajibkan."
                        } else {
                            "Aktif: Opsi 2 (Shizuku Non-Root) • Akses Root TIDAK diwajibkan."
                        },
                        color = if (isRootMode) StatusGreen else StatusCyan,
                        fontFamily = JetBrainsMono,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background((if (isRootMode) StatusGreen else StatusCyan).copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }

            if (privilegeMode == PrivilegeMode.ROOT) {
                // OPSI 1 (AKTIF): Akses Root (Superuser)
                item {
                    val rootState = shizukuStatus.rootGrantState
                    val mgr = shizukuStatus.rootManagerLabel.ifBlank { "Superuser" }
                    val badgeText = when {
                        shizukuStatus.isRootGranted -> "UID 0 AKTIF"
                        rootState == RootGrantState.DENIED -> "DITOLAK"
                        rootState == RootGrantState.AVAILABLE_NOT_GRANTED -> "PERLU IZIN"
                        else -> "CEK ROOT"
                    }
                    val badgeColor = when {
                        shizukuStatus.isRootGranted -> StatusGreen
                        rootState == RootGrantState.DENIED -> StatusRed
                        rootState == RootGrantState.AVAILABLE_NOT_GRANTED -> StatusAmber
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    val rootSubtitle = when {
                        shizukuStatus.isRootGranted ->
                            "$mgr Aktif • Semua fitur (Touch Licin, Macro, AI Trigger, Thermal Max, Bypass Charging) berjalan penuh tanpa Shizuku."
                        rootState == RootGrantState.DENIED ->
                            "Ditolak di $mgr • Ketuk 'Minta Root' lalu izinkan di pengelola Root (Shizuku tidak diperlukan)."
                        rootState == RootGrantState.AVAILABLE_NOT_GRANTED ->
                            "$mgr terdeteksi • Ketuk 'Minta Root' untuk mengizinkan Superuser (tanpa Shizuku)."
                        else ->
                            "Binary su belum terdeteksi • Ketuk 'Minta Root' untuk cek ulang Magisk/KernelSU/APatch, atau pilih Opsi 2 (Shizuku)."
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(
                                1.5.dp,
                                if (shizukuStatus.isRootGranted) StatusGreen.copy(alpha = 0.6f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                                RoundedCornerShape(18.dp)
                            )
                            .clickable { showRootDialog = true }
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                            .testTag("root_permission_card"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (shizukuStatus.isRootGranted) StatusGreen.copy(alpha = 0.16f)
                                        else MaterialTheme.colorScheme.surfaceContainerHigh
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = AppIcons.ShieldUnlock,
                                    contentDescription = "Akses Root Superuser",
                                    tint = if (shizukuStatus.isRootGranted) StatusGreen else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "Opsi 1: Akses Root",
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = badgeText,
                                        color = badgeColor,
                                        fontFamily = JetBrainsMono,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = rootSubtitle,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = useRoot,
                                onCheckedChange = onToggleUseRoot,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                    checkedTrackColor = StatusGreen,
                                    uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                ),
                                modifier = Modifier.testTag("toggle_use_root")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (shizukuStatus.isRootGranted) {
                                    "Engine: ${shizukuStatus.activeEngineLabel}"
                                } else {
                                    "Magisk • KernelSU • APatch (Tanpa Shizuku)"
                                },
                                color = if (shizukuStatus.isRootGranted) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = JetBrainsMono,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = onRequestRoot,
                                shape = RoundedCornerShape(50),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (shizukuStatus.isRootGranted) {
                                        MaterialTheme.colorScheme.surfaceContainerHigh
                                    } else {
                                        MaterialTheme.colorScheme.primary
                                    },
                                    contentColor = if (shizukuStatus.isRootGranted) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onPrimary
                                    }
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("btn_request_root")
                            ) {
                                Text(
                                    text = when {
                                        shizukuStatus.isRootGranted -> "Verifikasi"
                                        rootState == RootGrantState.DENIED -> "Coba Lagi"
                                        else -> "Minta Root"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // OPSI 2 (TIDAK WAJIB / ALTERNATIF): Shizuku Non-Root
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .clickable { showWirelessDialog = true }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("wireless_debugging_card"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = AppIcons.ShizukuBridge,
                                contentDescription = "Opsi alternatif Shizuku",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Opsi 2: Shizuku (Tidak Wajib)",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Nonaktif otomatis karena Mode Root sedang dipakai.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSelectPrivilegeMode(PrivilegeMode.SHIZUKU) },
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("btn_switch_to_shizuku")
                        ) {
                            Text("Ganti", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                // OPSI 2 (AKTIF): Shizuku & Wireless Debugging (Non-Root)
                item {
                    val shizukuReady = shizukuStatus.canRunShizuku
                    val badgeText = when {
                        shizukuReady -> "AKTIF (NON-ROOT)"
                        shizukuStatus.isRunning -> "PERLU IZIN"
                        shizukuStatus.isInstalled -> "BELUM JALAN"
                        else -> "BELUM PASANG"
                    }
                    val badgeColor = when {
                        shizukuReady -> StatusGreen
                        shizukuStatus.isRunning -> StatusAmber
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(
                                1.5.dp,
                                if (shizukuReady) StatusGreen.copy(alpha = 0.6f)
                                else StatusCyan.copy(alpha = 0.5f),
                                RoundedCornerShape(18.dp)
                            )
                            .clickable { showWirelessDialog = true }
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                            .testTag("wireless_debugging_card"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (shizukuReady) StatusGreen.copy(alpha = 0.16f)
                                        else MaterialTheme.colorScheme.surfaceContainerHigh
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = AppIcons.ShizukuBridge,
                                    contentDescription = "Mode Shizuku Non-Root",
                                    tint = if (shizukuReady) StatusGreen else StatusCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "Opsi 2: Shizuku",
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = badgeText,
                                        color = badgeColor,
                                        fontFamily = JetBrainsMono,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = when {
                                        shizukuReady ->
                                            "API v${shizukuStatus.apiVersion} • Semua fitur jalan penuh tanpa Root."
                                        shizukuStatus.isRunning ->
                                            "Shizuku terdeteksi • Ketuk 'Hubungkan' untuk memberikan izin (tanpa Root)."
                                        shizukuStatus.isInstalled ->
                                            "Jalankan Shizuku via Wireless Debugging lalu kembali ke aplikasi."
                                        else ->
                                            "Pasang Shizuku & aktifkan Wireless Debugging (atau pilih Opsi 1 jika HP sudah Root)."
                                    },
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = useShizuku,
                                onCheckedChange = {
                                    onToggleUseShizuku(it)
                                    if (it) onRequestShizuku()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                    checkedTrackColor = StatusCyan,
                                    uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                ),
                                modifier = Modifier.testTag("toggle_shizuku")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = onRequestShizuku,
                                shape = RoundedCornerShape(50),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (shizukuReady) {
                                        MaterialTheme.colorScheme.surfaceContainerHigh
                                    } else {
                                        MaterialTheme.colorScheme.primary
                                    },
                                    contentColor = if (shizukuReady) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onPrimary
                                    }
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("btn_connect_shizuku")
                            ) {
                                Text(
                                    text = if (shizukuReady) "Cek Shizuku" else "Hubungkan Shizuku",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                            Button(
                                onClick = onCheckWirelessDebugging,
                                shape = RoundedCornerShape(50),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 48.dp)
                                    .testTag("btn_cek_wireless")
                            ) {
                                Text("Wireless", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                // OPSI 1 (TIDAK WAJIB / ALTERNATIF): Akses Root
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .clickable { showRootDialog = true }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("root_permission_card"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = AppIcons.ShieldUnlock,
                                contentDescription = "Opsi alternatif Root",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Opsi 1: Akses Root (Tidak Wajib)",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Nonaktif otomatis karena Mode Shizuku (Non-Root) sedang dipakai.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSelectPrivilegeMode(PrivilegeMode.ROOT) },
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("btn_request_root")
                        ) {
                            Text("Ganti", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            item { SectionLabel("Lisensi") }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .testTag("pro_unlocked_card"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.ShieldUnlock,
                            contentDescription = "Pro Unlocked",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "XAGameSpacepanel Pro",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Unlocked • Semua fitur terbuka penuh",
                            color = StatusGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Text(
                        text = "AKTIF",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontFamily = JetBrainsMono,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            item { SectionLabel("Tampilan") }
            item {
                SettingNavCard(
                    icon = AppIcons.SpeedGauge,
                    title = "Tema",
                    subtitle = themeMode.label,
                    testTag = "nav_theme",
                    onClick = { showThemeDialog = true }
                )
            }
            item {
                SettingNavCard(
                    icon = AppIcons.Palette,
                    title = "Accent",
                    subtitle = accentPreset.label,
                    badge = "Unlocked",
                    testTag = "nav_accent",
                    onClick = { showAccentDialog = true }
                )
            }

            item { SectionLabel("Bahasa") }
            item {
                SettingNavCard(
                    icon = AppIcons.Language,
                    title = "Bahasa",
                    subtitle = language.label,
                    testTag = "nav_language",
                    onClick = { showLanguageDialog = true }
                )
            }

            item { SectionLabel("Pemulihan & diagnostik") }
            item {
                SettingNavCard(
                    icon = AppIcons.Touch,
                    title = "Cek kompatibilitas input",
                    subtitle = "Periksa Akses Root, Shizuku, Overlay & Usage Access",
                    testTag = "nav_compatibility",
                    onClick = onOpenCompatibility
                )
            }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .clickable { onRestoreNow() }
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .testTag("restore_session_card"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = AppIcons.Restore,
                            contentDescription = "Pulihkan",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Pulihkan setelah sesi",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Pulihkan ANGLE Texture saat keluar game (tweak FPS & lainnya tetap aktif)",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = restoreAfterSession,
                        onCheckedChange = onToggleRestoreAfterSession,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
            item {
                SettingNavCard(
                    icon = AppIcons.ShieldUnlock,
                    title = "Kenapa ada kendala di HP tertentu?",
                    subtitle = "Panduan MIUI/HyperOS, ColorOS & OneUI",
                    testTag = "nav_troubleshoot",
                    onClick = { showTroubleshootDialog = true }
                )
            }

            item { SectionLabel("Tentang") }
            item {
                SettingNavCard(
                    icon = AppIcons.Bolt,
                    title = "Versi",
                    subtitle = "1.0.0 • XAGameSpacepanel Compact Build",
                    testTag = "about_version",
                    onClick = { showTroubleshootDialog = true }
                )
            }
        }
    }

    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Pilih Tema", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (themeMode == mode) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable {
                                    onSelectTheme(mode)
                                    showThemeDialog = false
                                }
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(mode.label, fontWeight = FontWeight.Medium)
                            if (themeMode == mode) Text("Dipilih", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showAccentDialog) {
        AlertDialog(
            onDismissRequest = { showAccentDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Pilih Accent (Semua Terbuka)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AccentPreset.entries.forEach { preset ->
                        val swatch = accentColorFor(preset, true)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (accentPreset == preset) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable {
                                    onSelectAccent(preset)
                                    showAccentDialog = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(swatch)
                                    .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(preset.label, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (accentPreset == preset) {
                                Text("Aktif", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccentDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Pilih Bahasa", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (language == lang) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable {
                                    onSelectLanguage(lang)
                                    showLanguageDialog = false
                                }
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(lang.label, fontWeight = FontWeight.Medium)
                            if (language == lang) Text("Aktif", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showWirelessDialog) {
        AlertDialog(
            onDismissRequest = { showWirelessDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Wireless Debugging & Shizuku", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Untuk mengaktifkan Compile ART penuh, Debloat 1-klik, Animasi 0.3x global, dan Game Downscale tanpa root:\n\n" +
                        "1. Aktifkan Opsi Pengembang > Wireless Debugging di Pengaturan Android.\n" +
                        "2. Jalankan Shizuku via Wireless Debugging.\n" +
                        "3. Kembali ke XAGameSpacepanel dan ketuk 'Pakai Shizuku' untuk memberi izin.",
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showWirelessDialog = false
                    onCheckWirelessDebugging()
                }) {
                    Text("Buka Developer Options")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWirelessDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showRootDialog) {
        AlertDialog(
            onDismissRequest = { showRootDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Perizinan Root (Superuser)", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Dengan akses Root (UID 0 via Magisk, KernelSU, atau APatch), XAGameSpacepanel dapat bekerja tanpa Shizuku dan membuka kontrol kernel penuh:\n\n" +
                        "• Thermal Max 38°C–40°C (clamp frekuensi CPU & node thermal OEM)\n" +
                        "• Bypass Charging langsung via sysfs kernel\n" +
                        "• Driver Touchpanel OEM (Xiaomi, OPLUS, Samsung, Novatek, Goodix)\n" +
                        "• Macro 10-Jari Kernel Slot-9 & auto-grant izin Overlay/Usage Access\n\n" +
                        "Catatan: Pada KernelSU / APatch, pastikan XAGameSpacepanel sudah diizinkan di daftar Superuser aplikasi pengelola Root Anda.",
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showRootDialog = false
                    onRequestRoot()
                }) {
                    Text("Minta Izin Root")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRootDialog = false }) { Text("Tutup") }
            }
        )
    }

    if (showTroubleshootDialog) {
        AlertDialog(
            onDismissRequest = { showTroubleshootDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Tips Kompatibilitas Perangkat", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "• Xiaomi / POCO (MIUI/HyperOS): Aktifkan 'Autostart' & 'Tampilkan jendela pop-up saat di latar belakang' di Info Aplikasi.\n" +
                        "• Oppo / Realme (ColorOS): Matikan pengoptimalan baterai untuk XAGameSpacepanel.\n" +
                        "• Perangkat Root (Magisk / KernelSU / APatch): Ketuk 'Minta Root' di halaman Profil agar Thermal Max 38–40°C, Bypass Charging, dan Macro Kernel Slot-9 berjalan langsung di UID 0.\n" +
                        "• Mode Non-Root: Jalankan Shizuku via Wireless Debugging untuk Macro 10-Jari & Compile ART tanpa Aksesibilitas.",
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showTroubleshootDialog = false }) { Text("Mengerti") }
            }
        )
    }
}

@Composable
private fun PrivilegeOptionTile(
    optionTag: String,
    title: String,
    subtitle: String,
    selected: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .defaultMinSize(minHeight = 64.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (selected) accentColor.copy(alpha = 0.16f)
                else MaterialTheme.colorScheme.surfaceContainerHigh
            )
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) accentColor else MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = optionTag,
                color = if (selected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                fontFamily = JetBrainsMono,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            if (selected) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )
            }
        }
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            color = if (selected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
