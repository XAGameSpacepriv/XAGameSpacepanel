package com.example.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AntiMistouchConfig
import com.example.model.BypassChargingStatus
import com.example.model.GameNoteConfig
import com.example.model.ShizukuStatus
import com.example.model.TelemetrySnapshot
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.ui.icons.AppIcons
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianTextPrimary
import com.example.ui.theme.ObsidianTextSecondary
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import kotlin.math.roundToInt

/**
 * ZKMNEXT-inspired Thermal Advance tab inside the Floating Game Panel.
 */
@Composable
fun ThermalTabContent(
    telemetry: TelemetrySnapshot,
    thermalConfig: ThermalConfig,
    thermalStatus: ThermalStatus,
    bypassStatus: BypassChargingStatus,
    shizukuStatus: ShizukuStatus,
    isPrivilegeReady: Boolean = shizukuStatus.isSelectedModeReady,
    accentColor: Color,
    onSelectThermalProfile: (ThermalProfile) -> Unit,
    onUpdateThermalConfig: ((ThermalConfig) -> ThermalConfig) -> Unit,
    onSetThermalMaxLimit: (Boolean, Int) -> Unit = { _, _ -> },
    onProbeThermal: () -> Unit,
    onApplyThermalNow: () -> Unit,
    onRestoreThermalDefault: () -> Unit,
    onToggleBypassCharging: (Boolean) -> Unit,
    onProbeBypassCharging: () -> Unit
) {
    val peakTemp = maxOf(telemetry.socTempC, telemetry.tempC)
    val effectiveCeiling = if (thermalConfig.thermalMaxLimitEnabled) {
        thermalConfig.thermalMaxTargetC.coerceIn(38, 40)
    } else {
        thermalConfig.guardThresholdC
    }
    val tempTint = when {
        peakTemp >= effectiveCeiling -> StatusRed
        peakTemp >= (effectiveCeiling - 2) -> StatusAmber
        else -> StatusGreen
    }

    // Live Thermal Telemetry Card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianCard)
            .border(1.dp, tempTint.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(tempTint)
                )
                Text(
                    text = "Thermal Advance",
                    color = ObsidianTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = thermalStatus.systemThermalState,
                color = tempTint,
                fontFamily = JetBrainsMono,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ThermalMetricChip("SoC", "${"%.1f".format(telemetry.socTempC)}°C", tempTint, Modifier.weight(1f))
            Spacer(modifier = Modifier.width(6.dp))
            ThermalMetricChip("Baterai", "${"%.1f".format(telemetry.tempC)}°C", StatusCyan, Modifier.weight(1f))
            Spacer(modifier = Modifier.width(6.dp))
            ThermalMetricChip("Arus", "${telemetry.batteryCurrentMa}mA", ObsidianTextPrimary, Modifier.weight(1f))
        }

        if (thermalStatus.zones.isNotEmpty()) {
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.35f))
            thermalStatus.zones.take(4).chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    pair.forEach { z ->
                        Text(
                            text = "${z.name}: ${"%.1f".format(z.tempC)}°C",
                            color = ObsidianTextSecondary,
                            fontFamily = JetBrainsMono,
                            fontSize = 9.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (thermalStatus.maxLimitActive) {
            Text(
                text = thermalStatus.maxLimitDetail.ifBlank {
                    "Thermal Max ${thermalConfig.thermalMaxTargetC}°C aktif — menahan panas SoC/Baterai."
                },
                color = StatusCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                lineHeight = 13.sp
            )
        }

        if (thermalStatus.guardTriggered) {
            Text(
                text = "Thermal Guard aktif! Suhu mencapai batas ${thermalConfig.guardThresholdC}°C — profil diturunkan ke aman.",
                color = StatusRed,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                lineHeight = 13.sp
            )
        }
    }

    // Thermal Max Cap 38°C - 40°C (Strict Cooling Ceiling)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianCard)
            .border(
                width = 1.dp,
                color = if (thermalConfig.thermalMaxLimitEnabled) StatusCyan.copy(alpha = 0.45f) else ObsidianBorder.copy(alpha = 0.45f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ExtraSwitchRow(
            label = "Thermal Max (38°C – 40°C)",
            checked = thermalConfig.thermalMaxLimitEnabled,
            accentColor = StatusCyan,
            testTag = "overlay_thermal_max_switch",
            onCheckedChange = { enabled ->
                onSetThermalMaxLimit(enabled, thermalConfig.thermalMaxTargetC.coerceIn(38, 40))
            }
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            listOf(
                38 to "38°C Dingin",
                39 to "39°C Stabil",
                40 to "40°C Maks"
            ).forEach { (tempC, label) ->
                val selected = thermalConfig.thermalMaxLimitEnabled && thermalConfig.thermalMaxTargetC == tempC
                ExtraPillOption(
                    text = label,
                    selected = selected,
                    accentColor = StatusCyan,
                    modifier = Modifier.weight(1f),
                    testTag = "overlay_thermal_max_$tempC",
                    onClick = { onSetThermalMaxLimit(true, tempC) }
                )
            }
        }
        Text(
            text = when {
                thermalConfig.thermalMaxLimitEnabled && thermalStatus.maxLimitActive ->
                    "Cooling Cap AKTIF • Menahan suhu perangkat agar tetap ≤ ${thermalConfig.thermalMaxTargetC}°C."
                thermalConfig.thermalMaxLimitEnabled ->
                    "Standby ≤ ${thermalConfig.thermalMaxTargetC}°C • Otomatis menahan suhu bila menyentuh ${thermalConfig.thermalMaxTargetC}°C (rilis di ${thermalConfig.thermalMaxTargetC - 1.5f}°C)."
                else ->
                    "Aktifkan atau ketuk 38°C / 39°C / 40°C untuk membatasi suhu maksimal saat bermain."
            },
            color = if (thermalConfig.thermalMaxLimitEnabled) StatusCyan else ObsidianTextSecondary,
            fontSize = 9.5.sp,
            lineHeight = 13.sp
        )
    }

    // 5-Mode Thermal Profile Selector
    Text("Profil Thermal (ZKMNEXT)", color = ObsidianTextSecondary, fontSize = 11.sp)
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(ThermalProfile.STOCK, ThermalProfile.COOL, ThermalProfile.DYNAMIC).forEach { prof ->
                ExtraPillOption(
                    text = prof.shortLabel,
                    selected = thermalConfig.profile == prof,
                    accentColor = accentColor,
                    modifier = Modifier.weight(1f),
                    testTag = "overlay_thermal_${prof.name.lowercase()}",
                    onClick = { onSelectThermalProfile(prof) }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(ThermalProfile.EVALUATION, ThermalProfile.DISABLE_THROTTLE).forEach { prof ->
                ExtraPillOption(
                    text = prof.label,
                    selected = thermalConfig.profile == prof,
                    accentColor = if (prof == ThermalProfile.DISABLE_THROTTLE) StatusAmber else accentColor,
                    modifier = Modifier.weight(1f),
                    testTag = "overlay_thermal_${prof.name.lowercase()}",
                    onClick = { onSelectThermalProfile(prof) }
                )
            }
        }
    }
    Text(
        text = thermalConfig.profile.subtitle,
        color = ObsidianTextSecondary,
        fontSize = 10.sp,
        lineHeight = 13.sp
    )

    if (thermalConfig.profile == ThermalProfile.DISABLE_THROTTLE) {
        ExtraSwitchRow(
            label = "Hentikan Thermal Daemon (Khusus Root)",
            checked = thermalConfig.stopThermalDaemonsOnRoot,
            accentColor = StatusAmber,
            onCheckedChange = { stop -> onUpdateThermalConfig { it.copy(stopThermalDaemonsOnRoot = stop) } }
        )
    }

    // Node Status & Apply Actions
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ObsidianCardElevated)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = thermalStatus.activeNodeSummary,
            color = if (thermalStatus.isRootVerified) StatusGreen else if (isPrivilegeReady) StatusCyan else ObsidianTextSecondary,
            fontFamily = JetBrainsMono,
            fontSize = 9.sp,
            lineHeight = 12.sp,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "Cek Node",
            color = accentColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(ObsidianCard)
                .clickable(onClick = onProbeThermal)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }

    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = onApplyThermalNow,
            modifier = Modifier
                .weight(1f)
                .testTag("overlay_apply_thermal"),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color(0xFF0B0C0F)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Terapkan", fontWeight = FontWeight.SemiBold, fontSize = 11.sp, maxLines = 1)
        }
        OutlinedButton(
            onClick = onRestoreThermalDefault,
            modifier = Modifier
                .weight(1f)
                .testTag("overlay_restore_thermal"),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Default", color = ObsidianTextPrimary, fontSize = 11.sp, maxLines = 1)
        }
    }

    HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))

    // Thermal Guard Safety Cutoff
    ExtraSwitchRow(
        label = "Thermal Guard (Proteksi Overheat)",
        checked = thermalConfig.guardEnabled,
        accentColor = StatusGreen,
        onCheckedChange = { enabled -> onUpdateThermalConfig { it.copy(guardEnabled = enabled) } }
    )
    if (thermalConfig.guardEnabled) {
        ExtraSliderRow(
            label = "Batas Aman Suhu",
            valueText = "${thermalConfig.guardThresholdC}°C",
            value = thermalConfig.guardThresholdC.toFloat(),
            range = 38f..55f,
            accentColor = StatusAmber,
            onValueChange = { v -> onUpdateThermalConfig { it.copy(guardThresholdC = v.roundToInt().coerceIn(38, 55)) } }
        )
    }

    HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))

    // Integrated Bypass Charging
    ExtraSwitchRow(
        label = "Bypass Charging (Kurangi Panas)",
        checked = bypassStatus.enabled,
        accentColor = StatusCyan,
        onCheckedChange = onToggleBypassCharging
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = bypassStatus.detail,
            color = if (bypassStatus.supported) StatusCyan else ObsidianTextSecondary,
            fontSize = 9.5.sp,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "Cek",
            color = accentColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(ObsidianCardElevated)
                .clickable(onClick = onProbeBypassCharging)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

/**
 * ZKMNEXT Energy Cube / Utility Extras section rendered inside ToolsTabContent:
 * - Quick Screen Brightness & Media Volume Sliders
 * - 1-Tap Screenshot + AFK Screen Dimmer
 * - Anti-Mistouch Shield (Immersive / No Heads-Up / Lock Auto-Brightness / DND)
 * - In-Game Floating Notes (Cube Memo)
 */
@Composable
fun ZkmnextQuickToolsSection(
    brightnessPercent: Int,
    volumePercent: Int,
    screenDimmerEnabled: Boolean,
    antiMistouchConfig: AntiMistouchConfig,
    gameNoteConfig: GameNoteConfig,
    accentColor: Color,
    onChangeBrightness: (Int) -> Unit,
    onChangeVolume: (Int) -> Unit,
    onTakeScreenshot: () -> Unit,
    onToggleScreenDimmer: (Boolean) -> Unit,
    onUpdateAntiMistouch: ((AntiMistouchConfig) -> AntiMistouchConfig) -> Unit,
    onUpdateGameNote: ((GameNoteConfig) -> GameNoteConfig) -> Unit,
    onSaveFpsRecord: () -> Unit
) {
    // Quick Display, Audio, Screenshot & AFK Dimmer
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianCard)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Layar, Audio & Aksi Cepat", color = ObsidianTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        ExtraSliderRow(
            label = "Kecerahan Layar",
            valueText = "$brightnessPercent%",
            value = brightnessPercent.toFloat(),
            range = 5f..100f,
            accentColor = accentColor,
            onValueChange = { onChangeBrightness(it.roundToInt()) }
        )
        ExtraSliderRow(
            label = "Volume Media Game",
            valueText = "$volumePercent%",
            value = volumePercent.toFloat(),
            range = 0f..100f,
            accentColor = StatusCyan,
            onValueChange = { onChangeVolume(it.roundToInt()) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = onTakeScreenshot,
                modifier = Modifier
                    .weight(1f)
                    .testTag("overlay_quick_screenshot"),
                colors = ButtonDefaults.buttonColors(containerColor = ObsidianCardElevated, contentColor = ObsidianTextPrimary),
                shape = RoundedCornerShape(9.dp)
            ) {
                Icon(AppIcons.CameraShot, contentDescription = "Screenshot", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Screenshot", fontSize = 10.sp, maxLines = 1)
            }
            Button(
                onClick = onSaveFpsRecord,
                modifier = Modifier
                    .weight(1f)
                    .testTag("overlay_save_fps_record"),
                colors = ButtonDefaults.buttonColors(containerColor = ObsidianCardElevated, contentColor = StatusGreen),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("Simpan FPS", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
        ExtraSwitchRow(
            label = "Mode AFK Layar Gelap (Hemat OLED)",
            checked = screenDimmerEnabled,
            accentColor = accentColor,
            onCheckedChange = onToggleScreenDimmer
        )
    }

    HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))

    // Anti-Mistouch Shield
    ExtraSwitchRow(
        label = "Anti-Mistouch Shield",
        checked = antiMistouchConfig.enabled,
        accentColor = accentColor,
        onCheckedChange = { on -> onUpdateAntiMistouch { it.copy(enabled = on) } }
    )
    if (antiMistouchConfig.enabled) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
            ExtraPillOption(
                text = "Immersive",
                selected = antiMistouchConfig.immersiveFull,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdateAntiMistouch { it.copy(immersiveFull = !it.immersiveFull) } }
            )
            ExtraPillOption(
                text = "Blok Pop-Up",
                selected = antiMistouchConfig.blockHeadsUp,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdateAntiMistouch { it.copy(blockHeadsUp = !it.blockHeadsUp) } }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
            ExtraPillOption(
                text = "Kunci Terang",
                selected = antiMistouchConfig.lockAutoBrightness,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdateAntiMistouch { it.copy(lockAutoBrightness = !it.lockAutoBrightness) } }
            )
            ExtraPillOption(
                text = "Mode DND",
                selected = antiMistouchConfig.enableDnd,
                accentColor = accentColor,
                modifier = Modifier.weight(1f),
                onClick = { onUpdateAntiMistouch { it.copy(enableDnd = !it.enableDnd) } }
            )
        }
    }

    HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))

    // Floating Game Notes (ZKMNEXT Cube Notes)
    Text("Catatan Game (Floating Notes)", color = ObsidianTextSecondary, fontSize = 11.sp)
    OutlinedTextField(
        value = gameNoteConfig.text,
        onValueChange = { txt -> onUpdateGameNote { it.copy(text = txt.take(400)) } },
        placeholder = {
            Text(
                "Tulis combo, kode redeem, atau setting sensitivitas...",
                color = ObsidianTextSecondary,
                fontSize = 10.sp
            )
        },
        textStyle = androidx.compose.ui.text.TextStyle(
            color = ObsidianTextPrimary,
            fontSize = 11.sp,
            lineHeight = 14.sp
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = ObsidianBorder,
            focusedContainerColor = ObsidianCard,
            unfocusedContainerColor = ObsidianCard,
            cursorColor = accentColor
        ),
        maxLines = 4,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("overlay_game_note_input")
    )
    ExtraSwitchRow(
        label = "Sematkan Catatan Mengambang di Game",
        checked = gameNoteConfig.pinnedOverlay,
        accentColor = accentColor,
        onCheckedChange = { pin -> onUpdateGameNote { it.copy(pinnedOverlay = pin) } }
    )
}

@Composable
private fun ThermalMetricChip(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(ObsidianCardElevated)
            .padding(horizontal = 6.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = ObsidianTextSecondary, fontSize = 9.sp)
        Text(
            text = value,
            color = valueColor,
            fontFamily = JetBrainsMono,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun ExtraSwitchRow(
    label: String,
    checked: Boolean,
    accentColor: Color,
    testTag: String? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = ObsidianTextPrimary,
            fontSize = 11.5.sp,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF0B0C0F),
                checkedTrackColor = accentColor,
                uncheckedThumbColor = ObsidianTextSecondary,
                uncheckedTrackColor = ObsidianCardElevated
            )
        )
    }
}

@Composable
private fun ExtraSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accentColor: Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = ObsidianTextSecondary, fontSize = 11.sp)
            Text(valueText, color = ObsidianTextPrimary, fontFamily = JetBrainsMono, fontSize = 11.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = ObsidianCardElevated
            ),
            modifier = Modifier.height(28.dp)
        )
    }
}

@Composable
private fun ExtraPillOption(
    text: String,
    selected: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
    testTag: String? = null,
    onClick: () -> Unit
) {
    val baseMod = modifier
        .clip(RoundedCornerShape(8.dp))
        .background(if (selected) accentColor else ObsidianCardElevated)
        .clickable(onClick = onClick)
        .padding(horizontal = 6.dp, vertical = 7.dp)
    Box(
        modifier = if (testTag != null) baseMod.testTag(testTag) else baseMod,
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color(0xFF0B0C0F) else ObsidianTextPrimary,
            fontSize = 10.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
