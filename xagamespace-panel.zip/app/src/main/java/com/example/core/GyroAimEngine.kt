package com.example.core

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.view.MotionEvent
import android.view.Surface
import com.example.data.BoosterPreferences
import com.example.model.GyroAimConfig
import com.example.model.MacroInjectionMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Hardware Gyroscope Camera Aim Engine (inspired by ZKMNEXT GameSpace Gyro Manipulation).
 * Uses real SensorManager (Sensor.TYPE_GYROSCOPE) + Shizuku/Root virtual pointer slotOffset=2
 * to convert physical device tilt into smooth relative camera drags without affecting real fingers.
 */
object GyroAimEngine {
    private const val GYRO_POINTER_SLOT = 2
    private const val IDLE_LIFT_MS = 120L

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _sensorAvailable = MutableStateFlow(true)
    val sensorAvailable: StateFlow<Boolean> = _sensorAvailable.asStateFlow()

    private var sensorManager: SensorManager? = null
    private var gyroSensor: Sensor? = null
    private var listener: SensorEventListener? = null
    private var prefsRef: BoosterPreferences? = null
    private var screenSizeProvider: (() -> Pair<Int, Int>)? = null
    private var rotationProvider: (() -> Int)? = null

    @Volatile
    private var isTouching = false
    @Volatile
    private var downTimeMs = 0L
    @Volatile
    private var curX = 0f
    @Volatile
    private var curY = 0f
    @Volatile
    private var lastEventNs = 0L
    @Volatile
    private var lastMotionMs = 0L

    fun hasHardwareGyro(context: Context): Boolean {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return false
        val has = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        _sensorAvailable.value = has
        return has
    }

    fun start(
        context: Context,
        prefs: BoosterPreferences,
        getScreenSize: () -> Pair<Int, Int>,
        getRotation: () -> Int
    ): Boolean {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return false
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        _sensorAvailable.value = sensor != null
        if (sensor == null) {
            stop()
            return false
        }

        if (_isRunning.value && listener != null) return true

        sensorManager = sm
        gyroSensor = sensor
        prefsRef = prefs
        screenSizeProvider = getScreenSize
        rotationProvider = getRotation
        lastEventNs = 0L
        lastMotionMs = 0L

        val evListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type != Sensor.TYPE_GYROSCOPE) return
                val p = prefsRef ?: return
                val cfg = p.gyroAimConfig.value
                if (!cfg.enabled) return
                if (!p.canUsePrivileged(ShizukuBridge.status.value)) return

                val nowNs = event.timestamp
                if (lastEventNs == 0L) {
                    lastEventNs = nowNs
                    return
                }
                val dt = ((nowNs - lastEventNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastEventNs = nowNs

                val rot = rotationProvider?.invoke() ?: Surface.ROTATION_0
                val (dxPx, dyPx) = computeDeltaPx(
                    gyroX = event.values[0],
                    gyroY = event.values[1],
                    gyroZ = event.values[2],
                    rotation = rot,
                    dtSec = dt,
                    config = cfg
                )

                val nowMs = SystemClock.uptimeMillis()
                if (dxPx == 0f && dyPx == 0f) {
                    if (isTouching && nowMs - lastMotionMs >= IDLE_LIFT_MS) {
                        liftPointer()
                    }
                    return
                }

                lastMotionMs = nowMs
                val (sw, sh) = screenSizeProvider?.invoke() ?: (1080 to 2400)
                val anchorX = (cfg.anchorNormX * sw).coerceIn(80f, (sw - 80).toFloat())
                val anchorY = (cfg.anchorNormY * sh).coerceIn(80f, (sh - 80).toFloat())

                engineScope.launch {
                    dispatchGyroDelta(dxPx, dyPx, anchorX, anchorY, sw, sh, rot)
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        listener = evListener
        val registered = sm.registerListener(evListener, sensor, SensorManager.SENSOR_DELAY_GAME)
        _isRunning.value = registered
        return registered
    }

    fun stop() {
        listener?.let { l ->
            runCatching { sensorManager?.unregisterListener(l) }
        }
        listener = null
        _isRunning.value = false
        lastEventNs = 0L
        if (isTouching) {
            liftPointer()
        }
    }

    @Synchronized
    private fun dispatchGyroDelta(
        dx: Float,
        dy: Float,
        anchorX: Float,
        anchorY: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ) {
        val margin = 72f
        val nextX = curX + dx
        val nextY = curY + dy

        val needReAnchor = isTouching && (
            nextX < margin || nextX > screenW - margin ||
                nextY < margin || nextY > screenH - margin ||
                hypot((nextX - anchorX).toDouble(), (nextY - anchorY).toDouble()) > 260.0
            )

        if (needReAnchor) {
            ShizukuBridge.tryBlockingLift(curX, curY, downTimeMs, screenW, screenH, rotation, GYRO_POINTER_SLOT)
            isTouching = false
        }

        if (!isTouching) {
            curX = anchorX
            curY = anchorY
            downTimeMs = SystemClock.uptimeMillis()
            val okDown = kotlinx.coroutines.runBlocking {
                ShizukuBridge.injectMotion(
                    action = MotionEvent.ACTION_DOWN,
                    x = curX,
                    y = curY,
                    downTime = downTimeMs,
                    mode = MacroInjectionMode.SMART_POINTER,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation,
                    slotOffset = GYRO_POINTER_SLOT
                )
            }
            if (!okDown) return
            isTouching = true
        }

        curX = (curX + dx).coerceIn(margin, (screenW - margin).coerceAtLeast(margin + 1f))
        curY = (curY + dy).coerceIn(margin, (screenH - margin).coerceAtLeast(margin + 1f))
        kotlinx.coroutines.runBlocking {
            ShizukuBridge.injectMotion(
                action = MotionEvent.ACTION_MOVE,
                x = curX,
                y = curY,
                downTime = downTimeMs,
                mode = MacroInjectionMode.SMART_POINTER,
                screenW = screenW,
                screenH = screenH,
                rotation = rotation,
                slotOffset = GYRO_POINTER_SLOT
            )
        }
    }

    @Synchronized
    private fun liftPointer() {
        if (!isTouching) return
        val (sw, sh) = screenSizeProvider?.invoke() ?: (1080 to 2400)
        val rot = rotationProvider?.invoke() ?: Surface.ROTATION_0
        val upX = curX
        val upY = curY
        val dt = downTimeMs
        isTouching = false
        engineScope.launch {
            ShizukuBridge.injectMotion(
                action = MotionEvent.ACTION_UP,
                x = upX,
                y = upY,
                downTime = dt,
                mode = MacroInjectionMode.SMART_POINTER,
                screenW = sw,
                screenH = sh,
                rotation = rot,
                slotOffset = GYRO_POINTER_SLOT
            )
        }
    }

    private fun ShizukuBridge.tryBlockingLift(
        x: Float,
        y: Float,
        downTime: Long,
        sw: Int,
        sh: Int,
        rot: Int,
        slotOffset: Int
    ) {
        kotlinx.coroutines.runBlocking {
            injectMotion(
                action = MotionEvent.ACTION_UP,
                x = x,
                y = y,
                downTime = downTime,
                mode = MacroInjectionMode.SMART_POINTER,
                screenW = sw,
                screenH = sh,
                rotation = rot,
                slotOffset = slotOffset
            )
        }
    }

    fun computeDeltaPx(
        gyroX: Float,
        gyroY: Float,
        gyroZ: Float,
        rotation: Int,
        dtSec: Float,
        config: GyroAimConfig
    ): Pair<Float, Float> {
        val (rawYawRad, rawPitchRad) = when (rotation) {
            Surface.ROTATION_90 -> (-gyroX) to (-gyroY)
            Surface.ROTATION_270 -> gyroX to gyroY
            Surface.ROTATION_180 -> gyroY to gyroX
            else -> (-gyroY) to (-gyroX)
        }
        val yawDeg = Math.toDegrees(rawYawRad.toDouble()).toFloat()
        val pitchDeg = Math.toDegrees(rawPitchRad.toDouble()).toFloat()

        val activeYaw = if (abs(yawDeg) <= config.deadzoneDeg) 0f else {
            yawDeg - (if (yawDeg > 0) config.deadzoneDeg else -config.deadzoneDeg)
        }
        val activePitch = if (abs(pitchDeg) <= config.deadzoneDeg) 0f else {
            pitchDeg - (if (pitchDeg > 0) config.deadzoneDeg else -config.deadzoneDeg)
        }
        if (activeYaw == 0f && activePitch == 0f) return 0f to 0f

        val signX = if (config.invertX) -1f else 1f
        val signY = if (config.invertY) -1f else 1f
        val scaleX = (config.sensitivityX / 50f) * 3.4f * signX
        val scaleY = (config.sensitivityY / 50f) * 3.4f * signY

        val dx = (activeYaw * dtSec * scaleX).coerceIn(-48f, 48f)
        val dy = (activePitch * dtSec * scaleY).coerceIn(-48f, 48f)
        return dx to dy
    }
}
