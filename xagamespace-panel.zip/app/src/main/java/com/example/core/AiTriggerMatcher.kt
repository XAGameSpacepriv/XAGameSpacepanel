package com.example.core

import android.graphics.Bitmap
import com.example.model.AiTriggerRule
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Pure Kotlin RedMagic-style enemy body detector & crosshair-to-body head-trigger matcher.
 * - Searches the active combat zone around `(gameCrosshairNormX, gameCrosshairNormY)` across multi-scale
 *   footprints (`0.82x, 1.0x, 1.22x`) using edge-gradient silhouette + zero-mean NCC + color correlation.
 * - Returns both the localized enemy body bounding box and the computed enemy head point
 *   (`bestTop + footprintH * headOffsetPercent / 100f`), plus `touchingCrosshair` indicating whether
 *   the game's crosshair currently touches or enters the enemy body hitbox.
 */
object AiTriggerMatcher {

    data class SearchRect(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    ) {
        val width: Int get() = (right - left).coerceAtLeast(0)
        val height: Int get() = (bottom - top).coerceAtLeast(0)
    }

    data class PreparedTemplate(
        val width: Int,
        val height: Int,
        val frameRefWidth: Int,
        val frameRefHeight: Int,
        val luma: FloatArray,
        val edge: FloatArray,
        val edgeMean: Float,
        val hasStrongEdges: Boolean,
        val lumaMean: Float,
        val lumaStdNorm: Float,
        val r: IntArray,
        val g: IntArray,
        val b: IntArray,
        val weights: FloatArray,
        val coarseIndices: IntArray,
        val coarseCenteredLuma: FloatArray,
        val coarseLumaStdNorm: Float,
        val fineIndices: IntArray,
        val coreIndices: IntArray,
        val isFlatColor: Boolean
    )

    data class MatchResult(
        val matched: Boolean,
        val touchingCrosshair: Boolean,
        val scorePercent: Int,
        val bestLeftNorm: Float,
        val bestTopNorm: Float,
        val bestRightNorm: Float,
        val bestBottomNorm: Float,
        val bestBodyNormX: Float,
        val bestBodyNormY: Float,
        val headNormX: Float,
        val headNormY: Float
    )

    fun mapPrecisionToThreshold(matchPrecision: Int): Int {
        val clamped = matchPrecision.coerceIn(60, 100)
        return (40f + (clamped - 60) * 0.70f).roundToInt().coerceIn(40, 68)
    }

    private val roiLumaThreadLocal = object : ThreadLocal<FloatArray>() {
        override fun initialValue(): FloatArray = FloatArray(0)
    }

    fun rgbaBytesToArgbPixels(
        bytes: ByteArray,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int,
        outPixels: IntArray = IntArray(width * height)
    ): IntArray {
        val safeW = width.coerceAtLeast(0)
        val safeH = height.coerceAtLeast(0)
        if (safeW == 0 || safeH == 0 || bytes.isEmpty()) return outPixels
        val maxOff = bytes.size - 4
        var dst = 0
        if (pixelStride == 4) {
            for (y in 0 until safeH) {
                var offset = y * rowStride
                val rowEndOffset = offset + (safeW - 1) * 4
                if (offset >= 0 && rowEndOffset <= maxOff) {
                    for (x in 0 until safeW) {
                        val r = bytes[offset].toInt() and 0xFF
                        val g = bytes[offset + 1].toInt() and 0xFF
                        val b = bytes[offset + 2].toInt() and 0xFF
                        val a = bytes[offset + 3].toInt() and 0xFF
                        outPixels[dst++] = (a shl 24) or (r shl 16) or (g shl 8) or b
                        offset += 4
                    }
                } else {
                    for (x in 0 until safeW) {
                        if (offset in 0..maxOff) {
                            val r = bytes[offset].toInt() and 0xFF
                            val g = bytes[offset + 1].toInt() and 0xFF
                            val b = bytes[offset + 2].toInt() and 0xFF
                            val a = bytes[offset + 3].toInt() and 0xFF
                            outPixels[dst++] = (a shl 24) or (r shl 16) or (g shl 8) or b
                        } else {
                            outPixels[dst++] = 0xFF000000.toInt()
                        }
                        offset += 4
                    }
                }
            }
            return outPixels
        }

        for (y in 0 until safeH) {
            var offset = y * rowStride
            for (x in 0 until safeW) {
                if (offset in 0..maxOff) {
                    val r = bytes[offset].toInt() and 0xFF
                    val g = bytes[offset + 1].toInt() and 0xFF
                    val b = bytes[offset + 2].toInt() and 0xFF
                    val a = bytes[offset + 3].toInt() and 0xFF
                    outPixels[dst] = (a shl 24) or (r shl 16) or (g shl 8) or b
                } else {
                    outPixels[dst] = 0xFF000000.toInt()
                }
                dst++
                offset += pixelStride
            }
        }
        return outPixels
    }

    fun prepareFromBitmap(
        bitmap: Bitmap,
        cropWidthNorm: Float,
        cropHeightNorm: Float,
        frameW: Int,
        frameH: Int
    ): PreparedTemplate? {
        val safeFrameW = frameW.coerceAtLeast(32)
        val safeFrameH = frameH.coerceAtLeast(32)
        val expectedW = (cropWidthNorm.coerceIn(0.015f, 0.9f) * safeFrameW).roundToInt().coerceAtLeast(6)
        val expectedH = (cropHeightNorm.coerceIn(0.015f, 0.9f) * safeFrameH).roundToInt().coerceAtLeast(6)

        val maxSide = max(expectedW, expectedH)
        val scale = if (maxSide > 36) 36f / maxSide.toFloat() else 1f
        val tw = (expectedW * scale).roundToInt().coerceIn(6, 36)
        val th = (expectedH * scale).roundToInt().coerceIn(6, 36)

        val scaled = if (bitmap.width == tw && bitmap.height == th) {
            bitmap
        } else {
            Bitmap.createScaledBitmap(bitmap, tw, th, true)
        }
        val pixels = IntArray(tw * th)
        scaled.getPixels(pixels, 0, tw, 0, 0, tw, th)
        if (scaled !== bitmap) scaled.recycle()

        return prepareFromPixels(pixels, tw, th, safeFrameW, safeFrameH)
    }

    fun prepareFromPixels(
        argbPixels: IntArray,
        width: Int,
        height: Int,
        frameRefWidth: Int = width,
        frameRefHeight: Int = height
    ): PreparedTemplate? {
        val n = width * height
        if (width < 4 || height < 4 || argbPixels.size < n) return null

        val luma = FloatArray(n)
        val edge = FloatArray(n)
        val rArr = IntArray(n)
        val gArr = IntArray(n)
        val bArr = IntArray(n)
        val weights = FloatArray(n)
        val coreList = ArrayList<Int>(n / 2 + 4)

        val halfW = (width - 1).coerceAtLeast(1) / 2f
        val halfH = (height - 1).coerceAtLeast(1) / 2f

        var sum = 0.0
        var borderR = 0L
        var borderG = 0L
        var borderB = 0L
        var borderCount = 0

        for (y in 0 until height) {
            for (x in 0 until width) {
                val i = y * width + x
                val px = argbPixels[i]
                val r = (px ushr 16) and 0xFF
                val g = (px ushr 8) and 0xFF
                val b = px and 0xFF
                rArr[i] = r
                gArr[i] = g
                bArr[i] = b
                val yLum = 0.299f * r + 0.587f * g + 0.114f * b
                luma[i] = yLum
                sum += yLum

                // Sample left, right, and top perimeter as background reference (boots often touch bottom edge)
                if (x == 0 || x == width - 1 || y == 0) {
                    borderR += r
                    borderG += g
                    borderB += b
                    borderCount++
                }
            }
        }

        val safeBorderCount = borderCount.coerceAtLeast(1)
        val bgR = (borderR / safeBorderCount).toInt()
        val bgG = (borderG / safeBorderCount).toInt()
        val bgB = (borderB / safeBorderCount).toInt()

        var edgeSum = 0.0
        for (y in 0 until height) {
            val yUp = if (y > 0) y - 1 else 0
            val yDn = if (y < height - 1) y + 1 else height - 1
            for (x in 0 until width) {
                val xLt = if (x > 0) x - 1 else 0
                val xRt = if (x < width - 1) x + 1 else width - 1
                val gx = abs(luma[y * width + xRt] - luma[y * width + xLt])
                val gy = abs(luma[yDn * width + x] - luma[yUp * width + x])
                val e = gx + gy
                edge[y * width + x] = e
                edgeSum += e
            }
        }
        val edgeMean = (edgeSum / n).toFloat()
        val mean = (sum / n).toFloat()
        var sqSum = 0.0
        for (i in 0 until n) {
            val d = luma[i] - mean
            sqSum += (d * d).toDouble()
        }
        val stdNorm = sqrt(sqSum).toFloat()
        val isFlat = (stdNorm / sqrt(n.toDouble()).toFloat()) < 5.5f

        // Background-separated upright human silhouette weights:
        // Rejects perimeter wall/pillar/floor pixels that change completely when enemies move across surfaces.
        for (y in 0 until height) {
            val ny = (y - halfH) / max(1f, halfH)
            val absNy = abs(ny)
            for (x in 0 until width) {
                val i = y * width + x
                val nx = (x - halfW) / max(1f, halfW)
                val absNx = abs(nx)
                val ellipSq = (nx * nx) / 0.56f + (ny * ny) / 0.92f
                val bgDiff = abs(rArr[i] - bgR) + abs(gArr[i] - bgG) + abs(bArr[i] - bgB)
                val strongEdge = edgeMean >= 8f && edge[i] >= edgeMean * 1.10f

                val w = when {
                    isFlat -> 1.0f
                    absNx <= 0.42f && absNy <= 0.88f -> {
                        coreList.add(i)
                        if (bgDiff >= 38 || strongEdge) 3.0f else 2.2f
                    }
                    ellipSq <= 1.08f && (bgDiff >= 42 || strongEdge) -> {
                        coreList.add(i)
                        2.5f
                    }
                    absNx <= 0.72f && absNy <= 0.90f && bgDiff >= 58 -> {
                        coreList.add(i)
                        1.7f
                    }
                    ellipSq <= 0.75f -> {
                        coreList.add(i)
                        0.95f
                    }
                    else -> 0.08f
                }
                weights[i] = w
            }
        }

        // Foreground-focused coarse grid: prioritize interior body/head silhouette pixels so swapped backgrounds
        // don't distort coarse ZNCC rankings.
        val stepX = when {
            width <= 14 -> 1
            width <= 26 -> 2
            else -> 3
        }
        val stepY = when {
            height <= 16 -> 1
            height <= 28 -> 2
            else -> 3
        }
        val xStart = if (width >= 10) 1 else 0
        val xEnd = if (width >= 10) width - 1 else width
        val yStart = if (height >= 10) 1 else 0
        val yEnd = if (height >= 10) height - 1 else height

        val fgCoarse = ArrayList<Int>(48)
        val allCoarse = ArrayList<Int>(48)
        for (y in yStart until yEnd step stepY) {
            for (x in xStart until xEnd step stepX) {
                val idx = y * width + x
                allCoarse.add(idx)
                if (weights[idx] >= 1.2f) {
                    fgCoarse.add(idx)
                }
            }
        }
        val rawCoarse = when {
            isFlat -> allCoarse
            fgCoarse.size >= 12 -> fgCoarse
            coreList.size >= 12 -> {
                val stride = (coreList.size / 36f).coerceAtLeast(1f)
                val sampled = ArrayList<Int>(40)
                var pos = 0f
                while (pos < coreList.size && sampled.size < 40) {
                    sampled.add(coreList[pos.toInt()])
                    pos += stride
                }
                sampled
            }
            else -> allCoarse
        }
        val coarseArr = if (rawCoarse.size > 48) {
            val decimated = ArrayList<Int>(48)
            val stride = rawCoarse.size / 44f
            var pos = 0f
            while (pos < rawCoarse.size && decimated.size < 46) {
                decimated.add(rawCoarse[pos.toInt()])
                pos += stride
            }
            decimated.toIntArray()
        } else {
            rawCoarse.toIntArray()
        }

        val coarseCount = coarseArr.size.coerceAtLeast(1)
        var coarseSum = 0.0
        for (idx in coarseArr) coarseSum += luma[idx]
        val coarseMean = (coarseSum / coarseCount).toFloat()
        val coarseCentered = FloatArray(coarseArr.size)
        var coarseSq = 0.0
        for (k in coarseArr.indices) {
            val c = luma[coarseArr[k]] - coarseMean
            coarseCentered[k] = c
            coarseSq += (c * c).toDouble()
        }
        val coarseStdNorm = sqrt(coarseSq).toFloat().coerceAtLeast(1e-3f)

        val fineList = if (n <= 460) {
            IntArray(n) { it }
        } else {
            val list = ArrayList<Int>(n / 2 + 4)
            for (i in 0 until n step 2) list.add(i)
            list.toIntArray()
        }
        val finalCore = if (coreList.size >= 6) coreList.toIntArray() else fineList

        return PreparedTemplate(
            width = width,
            height = height,
            frameRefWidth = frameRefWidth,
            frameRefHeight = frameRefHeight,
            luma = luma,
            edge = edge,
            edgeMean = edgeMean,
            hasStrongEdges = edgeMean >= 12f,
            lumaMean = mean,
            lumaStdNorm = stdNorm,
            r = rArr,
            g = gArr,
            b = bArr,
            weights = weights,
            coarseIndices = coarseArr,
            coarseCenteredLuma = coarseCentered,
            coarseLumaStdNorm = coarseStdNorm,
            fineIndices = fineList,
            coreIndices = finalCore,
            isFlatColor = isFlat
        )
    }

    /**
     * Focused search zone centered around the in-game crosshair `(gameCrosshairNormX, gameCrosshairNormY)`
     * tightly excluding HUD icons (Medkit, weapons, scoreboard) and the player's own left avatar
     * while reliably catching standing/crouching enemies near the crosshair.
     */
    fun computeCrosshairSearchRect(
        rule: AiTriggerRule,
        frameW: Int,
        frameH: Int,
        footprintW: Int,
        footprintH: Int
    ): SearchRect {
        val maxLeft = (frameW - footprintW).coerceAtLeast(0)
        val maxTop = (frameH - footprintH).coerceAtLeast(0)
        val cx = (rule.gameCrosshairNormX.coerceIn(0.15f, 0.85f) * frameW).roundToInt()
        val cy = (rule.gameCrosshairNormY.coerceIn(0.15f, 0.85f) * frameH).roundToInt()
        val contactFraction = (rule.contactRadiusPercent.coerceIn(5, 60) / 100f)
        val zoneScale = if (rule.autoTriggerAllZones) 1.18f else 1.0f
        val halfSpanX = max(
            footprintW + 14,
            ((frameW * 0.135f * zoneScale) + footprintW * (0.30f + contactFraction * 0.35f)).roundToInt()
        )
        val halfSpanY = max(
            footprintH + 14,
            ((frameH * 0.175f * zoneScale) + footprintH * (0.30f + contactFraction * 0.35f)).roundToInt()
        )

        val l = (cx - halfSpanX).coerceIn(0, maxLeft)
        val t = (cy - halfSpanY).coerceIn(0, maxTop)
        val r = (cx + halfSpanX - footprintW).coerceIn(l, maxLeft) + 1
        val b = (cy + halfSpanY - footprintH).coerceIn(t, maxTop) + 1
        return SearchRect(left = l, top = t, right = r, bottom = b)
    }

    fun match(
        framePixels: IntArray,
        frameW: Int,
        frameH: Int,
        template: PreparedTemplate,
        rule: AiTriggerRule
    ): MatchResult {
        val crossX = rule.gameCrosshairNormX.coerceIn(0.15f, 0.85f)
        val crossY = rule.gameCrosshairNormY.coerceIn(0.15f, 0.85f)
        if (frameW < template.width || frameH < template.height || framePixels.size < frameW * frameH) {
            return MatchResult(
                matched = false,
                touchingCrosshair = false,
                scorePercent = 0,
                bestLeftNorm = crossX - 0.05f,
                bestTopNorm = crossY - 0.10f,
                bestRightNorm = crossX + 0.05f,
                bestBottomNorm = crossY + 0.10f,
                bestBodyNormX = crossX,
                bestBodyNormY = crossY,
                headNormX = crossX,
                headNormY = (crossY - 0.06f).coerceAtLeast(0.02f)
            )
        }

        val roiW = max(template.width, ((rule.cropRightNorm - rule.cropLeftNorm) * frameW).roundToInt())
        val roiH = max(template.height, ((rule.cropBottomNorm - rule.cropTopNorm) * frameH).roundToInt())
        val scaleFactors = floatArrayOf(0.76f, 0.94f, 1.15f)

        var unionLeft = frameW
        var unionTop = frameH
        var unionRight = 0
        var unionBottom = 0
        val scaleRects = Array(scaleFactors.size) { idx ->
            val sc = scaleFactors[idx]
            val fwSc = (roiW * sc).roundToInt().coerceIn(template.width, frameW)
            val fhSc = (roiH * sc).roundToInt().coerceIn(template.height, frameH)
            val sr = computeCrosshairSearchRect(rule, frameW, frameH, fwSc, fhSc)
            if (sr.width > 0 && sr.height > 0) {
                if (sr.left < unionLeft) unionLeft = sr.left
                if (sr.top < unionTop) unionTop = sr.top
                val endX = (sr.right - 1 + fwSc + 4).coerceAtMost(frameW)
                val endY = (sr.bottom - 1 + fhSc + 4).coerceAtMost(frameH)
                if (endX > unionRight) unionRight = endX
                if (endY > unionBottom) unionBottom = endY
            }
            sr
        }
        val bufLeft = (unionLeft - 4).coerceAtLeast(0)
        val bufTop = (unionTop - 4).coerceAtLeast(0)
        val bufRight = unionRight.coerceIn(bufLeft + 1, frameW)
        val bufBottom = unionBottom.coerceIn(bufTop + 1, frameH)
        val bufW = (bufRight - bufLeft).coerceAtLeast(1)
        val bufH = (bufBottom - bufTop).coerceAtLeast(1)
        val neededRoi = bufW * bufH
        var roiLuma = roiLumaThreadLocal.get() ?: FloatArray(0)
        if (roiLuma.size < neededRoi) {
            roiLuma = FloatArray(neededRoi)
            roiLumaThreadLocal.set(roiLuma)
        }
        for (ry in 0 until bufH) {
            val srcRow = (bufTop + ry) * frameW + bufLeft
            val dstRow = ry * bufW
            for (rx in 0 until bufW) {
                val px = framePixels[srcRow + rx]
                val r = (px ushr 16) and 0xFF
                val g = (px ushr 8) and 0xFF
                val b = px and 0xFF
                roiLuma[dstRow + rx] = 0.299f * r + 0.587f * g + 0.114f * b
            }
        }

        var globalBestScore = 0f
        var globalBestSelectionScore = -1f
        var globalBestRx = (frameW - template.width) / 2
        var globalBestRy = (frameH - template.height) / 2
        var globalBestFootprintW = roiW.coerceIn(template.width, frameW)
        var globalBestFootprintH = roiH.coerceIn(template.height, frameH)
        var globalBestStepX = (globalBestFootprintW.toFloat() / template.width.toFloat()).coerceIn(0.55f, 5.0f)
        var globalBestStepY = (globalBestFootprintH.toFloat() / template.height.toFloat()).coerceIn(0.55f, 5.0f)

        val fwFloat = frameW.coerceAtLeast(1).toFloat()
        val fhFloat = frameH.coerceAtLeast(1).toFloat()

        for (sIdx in scaleFactors.indices) {
            val scale = scaleFactors[sIdx]
            val rect = scaleRects[sIdx]
            if (rect.width <= 0 || rect.height <= 0) continue

            val footprintW = (roiW * scale).roundToInt().coerceIn(template.width, frameW)
            val footprintH = (roiH * scale).roundToInt().coerceIn(template.height, frameH)
            val sampleStepX = (footprintW.toFloat() / template.width.toFloat()).coerceIn(0.55f, 5.0f)
            val sampleStepY = (footprintH.toFloat() / template.height.toFloat()).coerceIn(0.55f, 5.0f)

            val scanStep = if (footprintW >= 34 && footprintH >= 64) 3 else 2
            val topK = 8
            val topX = IntArray(topK)
            val topY = IntArray(topK)
            val topCoarseScore = FloatArray(topK) { -1f }

            for (sy in rect.top until rect.bottom step scanStep) {
                for (sx in rect.left until rect.right step scanStep) {
                    val s = evaluateCoarseFastLuma(
                        roiLuma = roiLuma,
                        bufLeft = bufLeft,
                        bufTop = bufTop,
                        bufW = bufW,
                        bufH = bufH,
                        startX = sx,
                        startY = sy,
                        stepX = sampleStepX,
                        stepY = sampleStepY,
                        template = template
                    )
                    if (s > topCoarseScore[topK - 1]) {
                        var insert = topK - 1
                        while (insert > 0 && s > topCoarseScore[insert - 1]) {
                            topCoarseScore[insert] = topCoarseScore[insert - 1]
                            topX[insert] = topX[insert - 1]
                            topY[insert] = topY[insert - 1]
                            insert--
                        }
                        topCoarseScore[insert] = s
                        topX[insert] = sx
                        topY[insert] = sy
                    }
                }
            }

            val maxAllowedX = (frameW - footprintW).coerceAtLeast(0)
            val maxAllowedY = (frameH - footprintH).coerceAtLeast(0)

            for (k in 0 until topK) {
                if (topCoarseScore[k] < 0f) continue
                val cx = topX[k]
                val cy = topY[k]
                val rLeft = (cx - scanStep).coerceIn(0, maxAllowedX)
                val rRight = (cx + scanStep).coerceIn(0, maxAllowedX)
                val rTop = (cy - scanStep).coerceIn(0, maxAllowedY)
                val rBottom = (cy + scanStep).coerceIn(0, maxAllowedY)

                for (ry in rTop..rBottom) {
                    for (rx in rLeft..rRight) {
                        val finalScore = evaluateFineHybrid(
                            framePixels = framePixels,
                            frameW = frameW,
                            frameH = frameH,
                            startX = rx,
                            startY = ry,
                            stepX = sampleStepX,
                            stepY = sampleStepY,
                            template = template
                        )
                        val candCx = (rx + footprintW * 0.5f) / fwFloat
                        val candCy = (ry + footprintH * 0.5f) / fhFloat
                        val distPenalty = (hypot((candCx - crossX).toDouble(), ((candCy - crossY) * 1.15f).toDouble()).toFloat() * 0.14f)
                            .coerceIn(0f, 0.032f)
                        val selectionScore = finalScore - distPenalty
                        if (selectionScore > globalBestSelectionScore) {
                            globalBestSelectionScore = selectionScore
                            globalBestScore = finalScore
                            globalBestRx = rx
                            globalBestRy = ry
                            globalBestFootprintW = footprintW
                            globalBestFootprintH = footprintH
                            globalBestStepX = sampleStepX
                            globalBestStepY = sampleStepY
                        }
                    }
                }
            }
        }

        if (globalBestScore <= 0f) {
            return MatchResult(
                matched = false,
                touchingCrosshair = false,
                scorePercent = 0,
                bestLeftNorm = crossX - 0.05f,
                bestTopNorm = crossY - 0.10f,
                bestRightNorm = crossX + 0.05f,
                bestBottomNorm = crossY + 0.10f,
                bestBodyNormX = crossX,
                bestBodyNormY = crossY,
                headNormX = crossX,
                headNormY = (crossY - 0.06f).coerceAtLeast(0.02f)
            )
        }

        // 3x3 sub-pixel refinement around winning box
        var refinedRx = globalBestRx.toFloat()
        var refinedRy = globalBestRy.toFloat()
        if (globalBestScore > 0.35f) {
            val maxAllowedX = (frameW - globalBestFootprintW).coerceAtLeast(0)
            val maxAllowedY = (frameH - globalBestFootprintH).coerceAtLeast(0)
            var sumW = 0f
            var sumX = 0f
            var sumY = 0f
            val baseFloor = globalBestScore * 0.88f
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val nx = (globalBestRx + dx).coerceIn(0, maxAllowedX)
                    val ny = (globalBestRy + dy).coerceIn(0, maxAllowedY)
                    val ns = if (dx == 0 && dy == 0) {
                        globalBestScore
                    } else {
                        evaluateFineHybrid(
                            framePixels = framePixels,
                            frameW = frameW,
                            frameH = frameH,
                            startX = nx,
                            startY = ny,
                            stepX = globalBestStepX,
                            stepY = globalBestStepY,
                            template = template
                        )
                    }
                    val w = (ns - baseFloor).coerceAtLeast(0f)
                    sumW += w
                    sumX += w * nx
                    sumY += w * ny
                }
            }
            if (sumW > 1e-4f) {
                refinedRx = sumX / sumW
                refinedRy = sumY / sumW
            }
        }

        val leftNorm = (refinedRx / fwFloat).coerceIn(0f, 0.98f)
        val topNorm = (refinedRy / fhFloat).coerceIn(0f, 0.98f)
        val footWNorm = (globalBestFootprintW / fwFloat).coerceIn(0.015f, 1f)
        val footHNorm = (globalBestFootprintH / fhFloat).coerceIn(0.02f, 1f)
        val rightNorm = (leftNorm + footWNorm).coerceIn(leftNorm + 0.015f, 1f)
        val bottomNorm = (topNorm + footHNorm).coerceIn(topNorm + 0.02f, 1f)

        val bodyCenterX = ((leftNorm + rightNorm) * 0.5f).coerceIn(0.01f, 0.99f)
        val bodyCenterY = ((topNorm + bottomNorm) * 0.5f).coerceIn(0.01f, 0.99f)

        val headOffsetXFrac = rule.headOffsetXPercent.coerceIn(10, 90) / 100f
        val headOffsetYFrac = rule.headOffsetPercent.coerceIn(5, 55) / 100f
        val headX = (leftNorm + footWNorm * headOffsetXFrac).coerceIn(0.01f, 0.99f)
        val headY = (topNorm + footHNorm * headOffsetYFrac).coerceIn(0.01f, 0.99f)

        val scorePct = (globalBestScore * 100f).roundToInt().coerceIn(0, 100)
        val threshold = mapPrecisionToThreshold(rule.matchPrecision)
        val matched = scorePct >= threshold

        // Crosshair-to-enemy-body contact check (with floor margin for very slender distant characters)
        val contactMarginFrac = rule.contactRadiusPercent.coerceIn(5, 60) / 100f
        val padX = max(footWNorm * contactMarginFrac + 0.016f, 0.026f)
        val padY = max(footHNorm * contactMarginFrac + 0.016f, 0.026f)
        val touchingCrosshair = matched &&
            (crossX in (leftNorm - padX)..(rightNorm + padX)) &&
            (crossY in (topNorm - padY)..(bottomNorm + padY))

        return MatchResult(
            matched = matched,
            touchingCrosshair = touchingCrosshair,
            scorePercent = scorePct,
            bestLeftNorm = leftNorm,
            bestTopNorm = topNorm,
            bestRightNorm = rightNorm,
            bestBottomNorm = bottomNorm,
            bestBodyNormX = bodyCenterX,
            bestBodyNormY = bodyCenterY,
            headNormX = headX,
            headNormY = headY
        )
    }

    private fun hypot(a: Double, b: Double): Double = kotlin.math.hypot(a, b)

    private fun evaluateCoarseFastLuma(
        roiLuma: FloatArray,
        bufLeft: Int,
        bufTop: Int,
        bufW: Int,
        bufH: Int,
        startX: Int,
        startY: Int,
        stepX: Float,
        stepY: Float,
        template: PreparedTemplate
    ): Float {
        val tw = template.width
        val indices = template.coarseIndices
        val centeredT = template.coarseCenteredLuma
        val count = indices.size
        if (count == 0) return 0f

        var fSum = 0f
        var fSqSum = 0f
        var ftNum = 0f
        var sumEdgeMatch = 0f
        var absLumaDiffSum = 0f

        val relStartX = startX - bufLeft
        val relStartY = startY - bufTop
        val gdx = max(1, stepX.roundToInt())
        val gdy = max(1, stepY.roundToInt())
        val maxBx = bufW - 1
        val maxBy = bufH - 1
        val hasEdges = template.hasStrongEdges

        for (i in 0 until count) {
            val idx = indices[i]
            val tx = idx % tw
            val ty = idx / tw
            val bx = (relStartX + (tx * stepX).toInt()).coerceIn(0, maxBx)
            val by = (relStartY + (ty * stepY).toInt()).coerceIn(0, maxBy)
            val fLum = roiLuma[by * bufW + bx]
            fSum += fLum
            fSqSum += fLum * fLum
            ftNum += fLum * centeredT[i]
            absLumaDiffSum += abs(fLum - template.luma[idx])

            if (hasEdges) {
                val xL = (bx - gdx).coerceAtLeast(0)
                val xR = (bx + gdx).coerceAtMost(maxBx)
                val yU = (by - gdy).coerceAtLeast(0)
                val yD = (by + gdy).coerceAtMost(maxBy)
                val fEdge = abs(roiLuma[by * bufW + xR] - roiLuma[by * bufW + xL]) +
                    abs(roiLuma[yD * bufW + bx] - roiLuma[yU * bufW + bx])
                val tEdge = template.edge[idx]
                sumEdgeMatch += (1f - abs(fEdge - tEdge) / (max(fEdge, tEdge) + 28f)).coerceIn(0f, 1f)
            }
        }

        val lumaSim = (1f - absLumaDiffSum / (count * 255f)).coerceIn(0f, 1f)
        if (template.isFlatColor) return lumaSim

        val fMean = fSum / count.toFloat()
        val denF = (fSqSum - fSum * fMean).coerceAtLeast(0f)
        if ((denF / count.toFloat()) < 7.0f) {
            return (lumaSim * 0.35f).coerceAtMost(0.32f)
        }
        val coarseZncc = (ftNum / (sqrt(denF.toDouble()).toFloat() * template.coarseLumaStdNorm)).coerceIn(0f, 1f)
        if (!hasEdges) {
            return (coarseZncc * 0.68f + lumaSim * 0.32f).coerceIn(0f, 1f)
        }
        val edgeSim = (sumEdgeMatch / count.toFloat()).coerceIn(0f, 1f)
        return (coarseZncc * 0.56f + edgeSim * 0.24f + lumaSim * 0.20f).coerceIn(0f, 1f)
    }

    private fun evaluateFineHybrid(
        framePixels: IntArray,
        frameW: Int,
        frameH: Int,
        startX: Int,
        startY: Int,
        stepX: Float,
        stepY: Float,
        template: PreparedTemplate
    ): Float {
        val fullScore = scoreSubset(
            framePixels = framePixels,
            frameW = frameW,
            frameH = frameH,
            startX = startX,
            startY = startY,
            stepX = stepX,
            stepY = stepY,
            template = template,
            indices = template.fineIndices,
            useWeights = true
        )
        if (template.isFlatColor) {
            return fullScore
        }
        val coreScore = scoreSubset(
            framePixels = framePixels,
            frameW = frameW,
            frameH = frameH,
            startX = startX,
            startY = startY,
            stepX = stepX,
            stepY = stepY,
            template = template,
            indices = template.coreIndices,
            useWeights = true
        )
        return max(fullScore, coreScore)
    }

    private fun sampleEdgeMagnitude(
        framePixels: IntArray,
        frameW: Int,
        frameH: Int,
        fx: Int,
        fy: Int,
        gdx: Int,
        gdy: Int
    ): Float {
        val xL = (fx - gdx).coerceAtLeast(0)
        val xR = (fx + gdx).coerceAtMost(frameW - 1)
        val yU = (fy - gdy).coerceAtLeast(0)
        val yD = (fy + gdy).coerceAtMost(frameH - 1)

        val lPx = framePixels[fy * frameW + xL]
        val rPx = framePixels[fy * frameW + xR]
        val uPx = framePixels[yU * frameW + fx]
        val dPx = framePixels[yD * frameW + fx]

        val lLum = 0.299f * ((lPx ushr 16) and 0xFF) + 0.587f * ((lPx ushr 8) and 0xFF) + 0.114f * (lPx and 0xFF)
        val rLum = 0.299f * ((rPx ushr 16) and 0xFF) + 0.587f * ((rPx ushr 8) and 0xFF) + 0.114f * (rPx and 0xFF)
        val uLum = 0.299f * ((uPx ushr 16) and 0xFF) + 0.587f * ((uPx ushr 8) and 0xFF) + 0.114f * (uPx and 0xFF)
        val dLum = 0.299f * ((dPx ushr 16) and 0xFF) + 0.587f * ((dPx ushr 8) and 0xFF) + 0.114f * (dPx and 0xFF)
        return abs(rLum - lLum) + abs(dLum - uLum)
    }

    private fun scoreSubset(
        framePixels: IntArray,
        frameW: Int,
        frameH: Int,
        startX: Int,
        startY: Int,
        stepX: Float,
        stepY: Float,
        template: PreparedTemplate,
        indices: IntArray,
        useWeights: Boolean
    ): Float {
        val tw = template.width
        val count = indices.size
        if (count == 0) return 0f

        var weightedColorDiff = 0f
        var weightTotal = 0f
        var fWeightedLuma = 0f
        var tWeightedLuma = 0f
        var fWeightedEdge = 0f
        var tWeightedEdge = 0f

        val gdx = max(1, stepX.roundToInt())
        val gdy = max(1, stepY.roundToInt())
        val maxFx = (frameW - 1).coerceAtLeast(0)
        val maxFy = (frameH - 1).coerceAtLeast(0)

        for (i in 0 until count) {
            val idx = indices[i]
            val tx = idx % tw
            val ty = idx / tw
            val fx = (startX + (tx * stepX).toInt()).coerceIn(0, maxFx)
            val fy = (startY + (ty * stepY).toInt()).coerceIn(0, maxFy)
            val px = framePixels[fy * frameW + fx]
            val fr = (px ushr 16) and 0xFF
            val fg = (px ushr 8) and 0xFF
            val fb = px and 0xFF
            val w = if (useWeights) template.weights[idx] else 1f
            val diff = abs(fr - template.r[idx]) + abs(fg - template.g[idx]) + abs(fb - template.b[idx])
            weightedColorDiff += diff * w
            fWeightedLuma += (0.299f * fr + 0.587f * fg + 0.114f * fb) * w
            tWeightedLuma += template.luma[idx] * w
            if (template.hasStrongEdges) {
                val fe = sampleEdgeMagnitude(framePixels, frameW, frameH, fx, fy, gdx, gdy)
                fWeightedEdge += fe * w
                tWeightedEdge += template.edge[idx] * w
            }
            weightTotal += w
        }

        if (weightTotal <= 0f) return 0f
        val colorScore = (1f - weightedColorDiff / (weightTotal * 3f * 255f)).coerceIn(0f, 1f)
        if (template.isFlatColor) {
            return colorScore
        }

        val fMean = fWeightedLuma / weightTotal
        val tMean = tWeightedLuma / weightTotal
        val fEdgeMean = if (template.hasStrongEdges) fWeightedEdge / weightTotal else 0f
        val tEdgeMean = if (template.hasStrongEdges) tWeightedEdge / weightTotal else 0f

        var num = 0f
        var denF = 0f
        var denT = 0f
        var fAbsDev = 0f

        var eNum = 0f
        var eDenF = 0f
        var eDenT = 0f

        for (i in 0 until count) {
            val idx = indices[i]
            val tx = idx % tw
            val ty = idx / tw
            val fx = (startX + (tx * stepX).toInt()).coerceIn(0, maxFx)
            val fy = (startY + (ty * stepY).toInt()).coerceIn(0, maxFy)
            val px = framePixels[fy * frameW + fx]
            val fr = (px ushr 16) and 0xFF
            val fg = (px ushr 8) and 0xFF
            val fb = px and 0xFF
            val w = if (useWeights) template.weights[idx] else 1f
            val fVal = (0.299f * fr + 0.587f * fg + 0.114f * fb) - fMean
            val tVal = template.luma[idx] - tMean
            num += w * fVal * tVal
            denF += w * fVal * fVal
            denT += w * tVal * tVal
            fAbsDev += abs(fVal) * w

            if (template.hasStrongEdges) {
                val fe = sampleEdgeMagnitude(framePixels, frameW, frameH, fx, fy, gdx, gdy) - fEdgeMean
                val te = template.edge[idx] - tEdgeMean
                eNum += w * fe * te
                eDenF += w * fe * fe
                eDenT += w * te * te
            }
        }

        // Guard against flat uniform walls matching structured enemy silhouettes
        val avgDev = fAbsDev / weightTotal
        if (avgDev < 3.0f) {
            return (colorScore * 0.40f).coerceAtMost(0.36f)
        }

        val denom = sqrt((denF * denT).toDouble()).toFloat()
        val zncc = if (denom > 1e-3f) (num / denom).coerceIn(0f, 1f) else 0f

        if (!template.hasStrongEdges) {
            return (zncc * 0.62f + colorScore * 0.38f).coerceIn(0f, 1f)
        }

        val eDenom = sqrt((eDenF * eDenT).toDouble()).toFloat()
        val edgeScore = if (eDenom > 1e-3f) (eNum / eDenom).coerceIn(0f, 1f) else 0f

        return (zncc * 0.50f + edgeScore * 0.24f + colorScore * 0.26f).coerceIn(0f, 1f)
    }
}
