package com.example.core

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.example.data.BoosterPreferences
import com.example.model.ThermalConfig
import com.example.model.ThermalProfile
import com.example.model.ThermalStatus
import com.example.model.ThermalZoneReading
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * ZKMNEXT-inspired Thermal Advance Engine.
 * - Reads real Android PowerManager thermal status (API 29+) and hardware thermal zones.
 * - Probes real writable OEM thermal nodes (Xiaomi sconfig, Qualcomm msm_thermal,
 *   MediaTek PPM, OPLUS thermal_level, Android thermalservice).
 * - Verifies root UID before attempting low-level thermal daemon or sysfs bypass writes.
 * - Includes Thermal Guard threshold monitoring to prevent hardware overheating.
 */
enum class ThermalMaxAction {
    NONE,
    ENGAGE_COOL_CAP,
    RELEASE_COOL_CAP
}

object ThermalEngine {

    const val THERMAL_MAX_MIN_C = 38
    const val THERMAL_MAX_MAX_C = 40
    const val THERMAL_MAX_HYSTERESIS_C = 1.5f

    private val oemThermalNodePaths = listOf(
        "/sys/class/thermal/thermal_message/sconfig",
        "/sys/class/thermal/thermal_message/balance_mode",
        "/sys/module/msm_thermal/parameters/enabled",
        "/sys/module/msm_thermal/core_control/enabled",
        "/proc/ppm/policy/thermal_limit",
        "/proc/oplus_thermal/thermal_level",
        "/sys/devices/virtual/thermal/thermal_message/sconfig"
    )

    fun readSystemThermalStatusLabel(context: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Normal"
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "Normal"
        return when (runCatching { pm.currentThermalStatus }.getOrDefault(PowerManager.THERMAL_STATUS_NONE)) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal (0)"
            PowerManager.THERMAL_STATUS_LIGHT -> "Hangat (Ringan)"
            PowerManager.THERMAL_STATUS_MODERATE -> "Throttle Sedang"
            PowerManager.THERMAL_STATUS_SEVERE -> "Throttle Berat"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Kritis!"
            PowerManager.THERMAL_STATUS_EMERGENCY,
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Darurat Panas!"
            else -> "Normal"
        }
    }

    fun shouldTriggerThermalGuard(
        socTempC: Float,
        batteryTempC: Float,
        config: ThermalConfig
    ): Boolean {
        if (!config.guardEnabled) return false
        if (config.profile != ThermalProfile.EVALUATION && config.profile != ThermalProfile.DISABLE_THROTTLE) {
            return false
        }
        val peak = maxOf(socTempC, batteryTempC)
        return peak >= config.guardThresholdC.coerceIn(THERMAL_MAX_MIN_C, 60).toFloat()
    }

    /**
     * Closed-loop evaluator for Thermal Max Cap (38°C - 40°C).
     * Uses 1.5°C hysteresis so cooling cap doesn't rapidly toggle around the boundary.
     */
    fun evaluateThermalMaxAction(
        socTempC: Float,
        batteryTempC: Float,
        config: ThermalConfig,
        currentlyClamping: Boolean
    ): ThermalMaxAction {
        if (!config.thermalMaxLimitEnabled) {
            return if (currentlyClamping) ThermalMaxAction.RELEASE_COOL_CAP else ThermalMaxAction.NONE
        }
        val targetC = config.thermalMaxTargetC.coerceIn(THERMAL_MAX_MIN_C, THERMAL_MAX_MAX_C)
        val peak = maxOf(socTempC, batteryTempC)
        return when {
            !currentlyClamping && peak >= targetC.toFloat() -> ThermalMaxAction.ENGAGE_COOL_CAP
            currentlyClamping && peak <= (targetC.toFloat() - THERMAL_MAX_HYSTERESIS_C) -> ThermalMaxAction.RELEASE_COOL_CAP
            else -> ThermalMaxAction.NONE
        }
    }

    /**
     * Returns gentle CPU max frequency scaling percentage for active 38-40°C thermal capping.
     */
    fun cpuCapPercentForTarget(targetC: Int): Int = when (targetC.coerceIn(THERMAL_MAX_MIN_C, THERMAL_MAX_MAX_C)) {
        38 -> 75
        39 -> 82
        else -> 88
    }

    suspend fun scanThermalZones(usePrivileged: Boolean): List<ThermalZoneReading> =
        withContext(Dispatchers.IO) {
            val direct = readZonesDirect()
            if (direct.isNotEmpty() || !usePrivileged) return@withContext direct
            readZonesViaPrivileged()
        }

    private fun readZonesDirect(): List<ThermalZoneReading> {
        val list = mutableListOf<ThermalZoneReading>()
        for (i in 0..32) {
            val tempFile = File("/sys/class/thermal/thermal_zone$i/temp")
            if (!tempFile.exists() || !tempFile.canRead()) continue
            val raw = runCatching { tempFile.readText().trim().toFloat() }.getOrNull() ?: continue
            val tempC = normalizeThermalMilliC(raw)
            if (tempC !in 15f..110f) continue
            val typeStr = runCatching {
                File("/sys/class/thermal/thermal_zone$i/type").readText().trim()
            }.getOrDefault("zone$i").ifBlank { "zone$i" }
            val friendly = classifyZoneLabel(typeStr) ?: continue
            if (list.none { it.name == friendly }) {
                list.add(ThermalZoneReading(name = friendly, type = typeStr, tempC = tempC))
            }
            if (list.size >= 6) break
        }
        return list.sortedByDescending { it.tempC }
    }

    private suspend fun readZonesViaPrivileged(): List<ThermalZoneReading> {
        val cmd = "for z in /sys/class/thermal/thermal_zone*; do " +
            "[ -r \"\$z/temp\" ] && [ -r \"\$z/type\" ] && " +
            "echo \"\$(cat \"\$z/type\" 2>/dev/null)=\$(cat \"\$z/temp\" 2>/dev/null)\"; done | head -n 32"
        val res = ShizukuBridge.execPrivileged(cmd)
        if (res.output.isBlank()) return emptyList()
        val list = mutableListOf<ThermalZoneReading>()
        res.output.lineSequence().forEach { line ->
            val idx = line.indexOf('=')
            if (idx <= 0) return@forEach
            val typeStr = line.substring(0, idx).trim()
            val raw = line.substring(idx + 1).trim().toFloatOrNull() ?: return@forEach
            val tempC = normalizeThermalMilliC(raw)
            if (tempC !in 15f..110f) return@forEach
            val friendly = classifyZoneLabel(typeStr) ?: return@forEach
            if (list.none { it.name == friendly }) {
                list.add(ThermalZoneReading(name = friendly, type = typeStr, tempC = tempC))
            }
        }
        return list.sortedByDescending { it.tempC }.take(6)
    }

    fun normalizeThermalMilliC(raw: Float): Float = when {
        raw > 1000f -> raw / 1000f
        raw > 150f -> raw / 10f
        else -> raw
    }

    private fun classifyZoneLabel(rawType: String): String? {
        val t = rawType.lowercase()
        return when {
            t.contains("cpu") || t.contains("mtktscpu") || t.contains("tsens") || t.contains("soc") -> "CPU / SoC"
            t.contains("gpu") || t.contains("gpuss") -> "GPU"
            t.contains("bat") || t.contains("bms") -> "Baterai"
            t.contains("chg") || t.contains("charger") || t.contains("pmic") -> "Charger / PMIC"
            t.contains("skin") || t.contains("quiet") || t.contains("xo") || t.contains("shell") -> "Body / Skin"
            t.contains("ddr") || t.contains("mem") -> "RAM / DDR"
            else -> null
        }
    }

    suspend fun probeThermalStatus(
        context: Context,
        prefs: BoosterPreferences,
        guardTriggered: Boolean = false
    ): ThermalStatus = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val sysState = readSystemThermalStatusLabel(appContext)
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)
        val zones = scanThermalZones(canPriv)

        if (!canPriv) {
            return@withContext ThermalStatus(
                systemThermalState = sysState,
                supportedNodes = emptyList(),
                activeNodeSummary = "Hubungkan Shizuku / Root untuk pindai & ubah profil thermal kernel.",
                isRootVerified = false,
                zones = zones,
                guardTriggered = guardTriggered
            )
        }

        val probeCmd = buildString {
            append("echo UID=$(id -u) ; ")
            append("cmd thermalservice status 2>/dev/null | head -n 1 | sed 's/^/TS=/' ; ")
            oemThermalNodePaths.forEach { path ->
                append("if [ -w '$path' ]; then echo WNODE=$path=$(cat '$path' 2>/dev/null | head -n 1); fi ; ")
            }
            append("if [ -w /sys/class/thermal/thermal_zone0/mode ]; then echo WNODE=thermal_zone_mode; fi")
        }
        val res = ShizukuBridge.execPrivileged(probeCmd)
        val uid = Regex("UID=(\\d+)").find(res.output)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -1
        val isRootVerified = uid == 0 || (prefs.useRoot.value && status.isRootGranted)
        val foundNodes = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            foundNodes.add("Android ThermalService")
        }
        Regex("WNODE=([^=\\n]+)").findAll(res.output).forEach { m ->
            val path = m.groupValues[1].trim()
            val label = when {
                path.contains("sconfig") -> "Xiaomi sconfig"
                path.contains("balance_mode") -> "Xiaomi balance_mode"
                path.contains("msm_thermal") -> "Qualcomm msm_thermal"
                path.contains("ppm") -> "MediaTek PPM thermal"
                path.contains("oplus_thermal") -> "OPLUS thermal_level"
                path == "thermal_zone_mode" -> "Kernel thermal_zone mode"
                else -> path.substringAfterLast('/')
            }
            if (!foundNodes.contains(label)) foundNodes.add(label)
        }

        val summary = when {
            isRootVerified && foundNodes.size > 1 ->
                "Root Terverifikasi (UID 0) • ${foundNodes.joinToString(", ")}"
            isRootVerified ->
                "Root Terverifikasi (UID 0) • Android ThermalService & Daemon siap"
            foundNodes.isNotEmpty() ->
                "Shizuku Shell • ${foundNodes.joinToString(", ")} (Root dibutuhkan untuk bypass daemon)"
            else ->
                "Hanya baca sensor thermal (butuh Shizuku / Root)"
        }

        ThermalStatus(
            systemThermalState = sysState,
            supportedNodes = foundNodes,
            activeNodeSummary = summary,
            isRootVerified = isRootVerified,
            zones = zones,
            guardTriggered = guardTriggered
        )
    }

    suspend fun applyThermalProfile(
        context: Context,
        prefs: BoosterPreferences,
        config: ThermalConfig,
        targetPackages: List<String> = emptyList()
    ): Pair<ThermalStatus, ActionFeedback> = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!canPriv) {
            val probed = probeThermalStatus(appContext, prefs)
            return@withContext probed to ActionFeedback(
                false,
                "Profil Thermal ${config.profile.label} disimpan. Aktifkan Shizuku / Root untuk menerapkannya."
            )
        }

        val cmds = mutableListOf<String>()
        val pkgs = (targetPackages + prefs.addedGames.value).distinct().take(25)

        when (config.profile) {
            ThermalProfile.STOCK -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cmds.add("cmd thermalservice reset 2>/dev/null ; true")
                }
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "0"))
                cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "0"))
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/balance_mode", "0"))
                cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/enabled", "Y"))
                cmds.add(writeIfWritable("/sys/module/msm_thermal/core_control/enabled", "1"))
                cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "0"))
                cmds.add(
                    "for m in /sys/class/thermal/thermal_zone*/mode; do " +
                        "[ -w \"\$m\" ] && echo enabled > \"\$m\" 2>/dev/null; done; true"
                )
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add("start thermal-engine 2>/dev/null ; start mi_thermald 2>/dev/null ; true")
                }
            }

            ThermalProfile.COOL -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cmds.add("cmd thermalservice reset 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled false 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { pkg -> cmds.add("cmd game mode battery $pkg 2>/dev/null ; true") }
                }
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "12"))
                cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "12"))
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/balance_mode", "1"))
                cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "1"))
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add("start thermal-engine 2>/dev/null ; start mi_thermald 2>/dev/null ; true")
                }
            }

            ThermalProfile.DYNAMIC -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cmds.add("cmd thermalservice override-status 0 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { pkg -> cmds.add("cmd game mode performance $pkg 2>/dev/null ; true") }
                }
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "9"))
                cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "9"))
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/balance_mode", "0"))
                cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "0"))
            }

            ThermalProfile.EVALUATION -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cmds.add("cmd thermalservice override-status 0 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { pkg -> cmds.add("cmd game mode performance $pkg 2>/dev/null ; true") }
                }
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "10"))
                cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "10"))
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/balance_mode", "0"))
                cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "0"))
            }

            ThermalProfile.DISABLE_THROTTLE -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cmds.add("cmd thermalservice override-status 0 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { pkg -> cmds.add("cmd game mode performance $pkg 2>/dev/null ; true") }
                }
                cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "20"))
                cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "20"))
                cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/enabled", "N"))
                cmds.add(writeIfWritable("/sys/module/msm_thermal/core_control/enabled", "0"))
                cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "0"))
                if (prefs.useRoot.value && status.isRootGranted && config.stopThermalDaemonsOnRoot) {
                    cmds.add("stop thermal-engine 2>/dev/null ; stop mi_thermald 2>/dev/null ; true")
                }
            }
        }

        if (config.thermalMaxLimitEnabled) {
            val capC = config.thermalMaxTargetC.coerceIn(THERMAL_MAX_MIN_C, THERMAL_MAX_MAX_C)
            cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/temp_threshold", "$capC"))
            cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/limit_temp_degC", "$capC"))
        }

        val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        val updatedStatus = probeThermalStatus(appContext, prefs).copy(
            maxLimitActive = false,
            maxLimitDetail = if (config.thermalMaxLimitEnabled) {
                "Thermal Max ≤ ${config.thermalMaxTargetC.coerceIn(THERMAL_MAX_MIN_C, THERMAL_MAX_MAX_C)}°C (Standby)"
            } else ""
        )
        val ok = res.success || res.usedShizuku || res.usedRoot
        val engineLabel = if (res.usedRoot) "Root" else "Shizuku"
        val extra = if (config.profile == ThermalProfile.DISABLE_THROTTLE && !updatedStatus.isRootVerified) {
            " (ThermalService override aktif; Root dibutuhkan untuk bypass sysfs/daemon penuh)"
        } else ""
        updatedStatus to ActionFeedback(
            ok,
            "Thermal ${config.profile.label} diterapkan via $engineLabel.$extra"
        )
    }

    /**
     * Enforces or releases the strict 38°C - 40°C Thermal Max Cap.
     * - When engageClamp = true & thermalMaxLimitEnabled = true:
     *   Applies cool OEM thermal policy (sconfig 12, msm_thermal temp_threshold 38-40, OPLUS level 2),
     *   Android thermalservice hint (Light/Moderate), disables fixed-performance boost, and gently caps
     *   writable cpufreq scaling_max_freq so SoC/battery stays within 38-40°C.
     * - When engageClamp = false or disabled:
     *   Restores writable cpufreq scaling_max_freq to hardware cpuinfo_max_freq and re-applies
     *   the user's active ThermalProfile cleanly.
     */
    suspend fun applyThermalMaxCap(
        context: Context,
        prefs: BoosterPreferences,
        config: ThermalConfig,
        engageClamp: Boolean,
        targetPackages: List<String> = emptyList()
    ): Pair<ThermalStatus, ActionFeedback> = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val targetC = config.thermalMaxTargetC.coerceIn(THERMAL_MAX_MIN_C, THERMAL_MAX_MAX_C)
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!config.thermalMaxLimitEnabled || !engageClamp) {
            if (canPriv) {
                val restoreFreqCmd =
                    "for p in /sys/devices/system/cpu/cpufreq/policy*; do " +
                        "[ -r \"\$p/cpuinfo_max_freq\" ] && [ -w \"\$p/scaling_max_freq\" ] && " +
                        "cat \"\$p/cpuinfo_max_freq\" > \"\$p/scaling_max_freq\" 2>/dev/null; done; true"
                ShizukuBridge.execPrivileged(restoreFreqCmd)
            }
            val (reappliedStatus, _) = applyThermalProfile(appContext, prefs, config, targetPackages)
            val detail = if (config.thermalMaxLimitEnabled) {
                "Standby menjaga suhu ≤ ${targetC}°C"
            } else {
                ""
            }
            val msg = if (config.thermalMaxLimitEnabled) {
                "Thermal Max ${targetC}°C aktif (Standby — auto-cool saat suhu ≥ ${targetC}°C)."
            } else {
                "Thermal Max 38–40°C dimatikan — profil ${config.profile.label} dipulihkan."
            }
            return@withContext reappliedStatus.copy(
                maxLimitActive = false,
                maxLimitDetail = detail
            ) to ActionFeedback(true, msg)
        }

        if (!canPriv) {
            val probed = probeThermalStatus(appContext, prefs)
            return@withContext probed.copy(
                maxLimitActive = true,
                maxLimitDetail = "Mode Pantau ≤ ${targetC}°C (hubungkan Shizuku/Root untuk clamp otomatis)"
            ) to ActionFeedback(
                false,
                "Thermal Max ${targetC}°C aktif (pantau). Hubungkan Shizuku / Root untuk pendinginan sistem."
            )
        }

        val pkgs = (targetPackages + prefs.addedGames.value).distinct().take(25)
        val capPct = cpuCapPercentForTarget(targetC)
        val overrideLevel = if (targetC <= 38) 2 else 1 // 2=MODERATE for strict 38°C, 1=LIGHT for 39-40°C
        val cmds = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cmds.add("cmd thermalservice override-status $overrideLevel 2>/dev/null ; true")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            cmds.add("cmd power set-fixed-performance-mode-enabled false 2>/dev/null ; true")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            pkgs.forEach { pkg -> cmds.add("cmd game mode battery $pkg 2>/dev/null ; true") }
        }

        // OEM thermal limit & cool curve nodes
        cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/sconfig", "12"))
        cmds.add(writeIfWritable("/sys/devices/virtual/thermal/thermal_message/sconfig", "12"))
        cmds.add(writeIfWritable("/sys/class/thermal/thermal_message/balance_mode", "1"))
        cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/enabled", "Y"))
        cmds.add(writeIfWritable("/sys/module/msm_thermal/core_control/enabled", "1"))
        cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/temp_threshold", "$targetC"))
        cmds.add(writeIfWritable("/sys/module/msm_thermal/parameters/limit_temp_degC", "$targetC"))
        cmds.add(writeIfWritable("/proc/oplus_thermal/thermal_level", "2"))

        // Gentle CPU frequency cap on writable cpufreq policies (restored when cooled below target - 1.5°C)
        cmds.add(
            "for p in /sys/devices/system/cpu/cpufreq/policy*; do " +
                "if [ -r \"\$p/cpuinfo_max_freq\" ] && [ -w \"\$p/scaling_max_freq\" ]; then " +
                "mx=\$(cat \"\$p/cpuinfo_max_freq\" 2>/dev/null); " +
                "mn=\$(cat \"\$p/cpuinfo_min_freq\" 2>/dev/null); " +
                "tgt=\$((mx * $capPct / 100)); " +
                "[ -n \"\$mn\" ] && [ \"\$tgt\" -lt \"\$mn\" ] && tgt=\$mn; " +
                "echo \$tgt > \"\$p/scaling_max_freq\" 2>/dev/null; " +
                "fi; done; true"
        )
        if (prefs.useRoot.value && status.isRootGranted) {
            cmds.add("start thermal-engine 2>/dev/null ; start mi_thermald 2>/dev/null ; true")
        }

        val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        val updated = probeThermalStatus(appContext, prefs).copy(
            maxLimitActive = true,
            maxLimitDetail = "Cooling Cap aktif — menahan suhu ≤ ${targetC}°C (CPU ${capPct}%)"
        )
        val engineLabel = if (res.usedRoot) "Root" else "Shizuku"
        updated to ActionFeedback(
            res.success || res.usedShizuku || res.usedRoot,
            "Thermal Max ${targetC}°C aktif via $engineLabel (menahan suhu ≤ ${targetC}°C)."
        )
    }

    private fun writeIfWritable(path: String, value: String): String =
        "[ -w '$path' ] && echo $value > '$path' 2>/dev/null; true"
}
