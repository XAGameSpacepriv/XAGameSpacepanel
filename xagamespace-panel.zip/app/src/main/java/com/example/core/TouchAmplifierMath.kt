package com.example.core

import android.os.SystemClock
import android.view.MotionEvent
import android.view.Surface
import com.example.model.TouchArea
import com.example.model.TouchConfig
import com.example.model.TouchPollingPreset
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Runtime configuration pushed to RootTouchDaemon (UID 0) or ShizukuInputUserService (UID 2000)
 * for real-time hardware/companion X & Y touch sensitivity amplification.
 */
data class TouchAmplifierConfig(
    val enabled: Boolean = false,
    val gainX: Float = 1.0f,
    val gainY: Float = 1.0f,
    val responseBoost: Int = 0,
    val touchSlopReduction: Int = 40,
    val smoothing: Int = 0,
    val deadzone: Int = 0,
    val areaCode: Int = 0, // 0 = ALL, 1 = LEFT, 2 = RIGHT
    val screenW: Int = 1080,
    val screenH: Int = 2400,
    val rotation: Int = Surface.ROTATION_0
) {
    fun hasEffectiveBoost(): Boolean =
        enabled && (gainX > 1.01f || gainY > 1.01f || responseBoost > 0)

    fun toDaemonCommand(): String {
        val en = if (enabled) 1 else 0
        return "BOOST_CFG $en ${"%.4f".format(java.util.Locale.US, gainX)} " +
            "${"%.4f".format(java.util.Locale.US, gainY)} " +
            "$responseBoost $touchSlopReduction $smoothing $deadzone $areaCode $screenW $screenH $rotation"
    }

    companion object {
        fun fromDaemonArgs(parts: List<String>): TouchAmplifierConfig? {
            if (parts.size < 12) return null
            return TouchAmplifierConfig(
                enabled = (parts[1].toIntOrNull() ?: 0) == 1,
                gainX = (parts[2].toFloatOrNull() ?: 1.0f).coerceIn(0.45f, 3.50f),
                gainY = (parts[3].toFloatOrNull() ?: 1.0f).coerceIn(0.45f, 3.50f),
                responseBoost = (parts[4].toIntOrNull() ?: 0).coerceIn(0, 100),
                touchSlopReduction = (parts[5].toIntOrNull() ?: 40).coerceIn(0, 100),
                smoothing = (parts[6].toIntOrNull() ?: 0).coerceIn(0, 100),
                deadzone = (parts[7].toIntOrNull() ?: 0).coerceIn(0, 50),
                areaCode = (parts[8].toIntOrNull() ?: 0).coerceIn(0, 2),
                screenW = (parts[9].toIntOrNull() ?: 1080).coerceAtLeast(100),
                screenH = (parts[10].toIntOrNull() ?: 2400).coerceAtLeast(100),
                rotation = (parts[11].toIntOrNull() ?: Surface.ROTATION_0).coerceIn(0, 3)
            )
        }
    }
}

/**
 * One-tap "Racikan Licin" sensitivity presets designed for immediate, unmistakable slickness
 * without modifying screen DPI or adding any floating aim-pad overlays.
 */
enum class TouchBoostPreset(
    val label: String,
    val subtitle: String,
    val speedX: Int,
    val speedY: Int,
    val responseBoost: Int,
    val touchSlopReduction: Int,
    val smoothing: Int,
    val deadzone: Int,
    val pollingPreset: TouchPollingPreset
) {
    NORMAL(
        label = "Normal",
        subtitle = "Licin ringan & terkendali",
        speedX = 40,
        speedY = 55,
        responseBoost = 40,
        touchSlopReduction = 60,
        smoothing = 15,
        deadzone = 0,
        pollingPreset = TouchPollingPreset.HIGH_240
    ),
    LICIN_PRO(
        label = "Licin Pro",
        subtitle = "Licin seimbang harian & game",
        speedX = 85,
        speedY = 135,
        responseBoost = 75,
        touchSlopReduction = 85,
        smoothing = 12,
        deadzone = 0,
        pollingPreset = TouchPollingPreset.ULTRA_480
    ),
    HEADSHOT_Y(
        label = "Headshot Y+",
        subtitle = "Tarik vertikal Y super ringan",
        speedX = 75,
        speedY = 185,
        responseBoost = 90,
        touchSlopReduction = 95,
        smoothing = 8,
        deadzone = 0,
        pollingPreset = TouchPollingPreset.MAX_HARDWARE
    ),
    SUPER_LICIN(
        label = "Super Licin",
        subtitle = "Maksimal X & Y licin kaca",
        speedX = 160,
        speedY = 200,
        responseBoost = 100,
        touchSlopReduction = 100,
        smoothing = 5,
        deadzone = 0,
        pollingPreset = TouchPollingPreset.MAX_HARDWARE
    );

    fun applyTo(current: TouchConfig): TouchConfig = current.copy(
        enabled = true,
        speedX = speedX,
        speedY = speedY,
        responseBoost = responseBoost,
        touchSlopReduction = touchSlopReduction,
        smoothing = smoothing,
        deadzone = deadzone,
        pollingPreset = pollingPreset,
        edgeRejectionOff = true,
        unifiedMultiTouch = true,
        dpiBoostEnabled = false,
        liveAimPadEnabled = false,
        aimPadLocked = false
    )

    fun matches(config: TouchConfig): Boolean =
        config.enabled &&
            config.speedX == speedX &&
            config.speedY == speedY &&
            config.responseBoost == responseBoost
}

/**
 * Pure, deterministic touch coordinate & velocity-acceleration math shared by RootTouchDaemon,
 * ShizukuInputUserService, and Robolectric unit tests.
 */
object TouchAmplifierMath {

    /**
     * Converts raw digitizer coordinates (ABS_MT_POSITION_X / Y) into rotated display pixel
     * coordinates — exact algebraic inverse of KernelTouchEngine.mapToSensor().
     */
    fun sensorToScreen(
        spec: TouchDeviceSpec,
        rawX: Int,
        rawY: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Pair<Float, Float> {
        val spanX = (spec.absMaxX - spec.absMinX).coerceAtLeast(1).toFloat()
        val spanY = (spec.absMaxY - spec.absMinY).coerceAtLeast(1).toFloat()
        val nx = ((rawX - spec.absMinX) / spanX).coerceIn(0f, 1f)
        val ny = ((rawY - spec.absMinY) / spanY).coerceIn(0f, 1f)

        val (lx, ly) = when (rotation) {
            Surface.ROTATION_90 -> ny to (1f - nx)
            Surface.ROTATION_180 -> (1f - nx) to (1f - ny)
            Surface.ROTATION_270 -> (1f - ny) to nx
            else -> nx to ny
        }
        val safeW = screenW.coerceAtLeast(1).toFloat()
        val safeH = screenH.coerceAtLeast(1).toFloat()
        return (lx * safeW) to (ly * safeH)
    }

    /**
     * Exact forward mapping from rotated display pixels to raw touchscreen sensor coordinates.
     */
    fun screenToSensor(
        spec: TouchDeviceSpec,
        x: Float,
        y: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Pair<Int, Int> {
        val safeW = screenW.coerceAtLeast(1).toFloat()
        val safeH = screenH.coerceAtLeast(1).toFloat()
        val lx = (x / safeW).coerceIn(0f, 1f)
        val ly = (y / safeH).coerceIn(0f, 1f)

        val (nx, ny) = when (rotation) {
            Surface.ROTATION_90 -> (1f - ly) to lx
            Surface.ROTATION_180 -> (1f - lx) to (1f - ly)
            Surface.ROTATION_270 -> ly to (1f - lx)
            else -> lx to ly
        }
        val spanX = (spec.absMaxX - spec.absMinX).coerceAtLeast(1)
        val spanY = (spec.absMaxY - spec.absMinY).coerceAtLeast(1)
        val rawX = (spec.absMinX + (nx * spanX).roundToInt()).coerceIn(spec.absMinX, spec.absMaxX)
        val rawY = (spec.absMinY + (ny * spanY).roundToInt()).coerceIn(spec.absMinY, spec.absMaxY)
        return rawX to rawY
    }

    /**
     * Minimum cumulative travel (px) before the companion boost engages so taps on buttons stay 100% crisp.
     * Higher touchSlopReduction (0..100%) lowers threshold from 6.5px down to 2.0px for instant swipe pickup.
     */
    fun activationThresholdPx(touchSlopReduction: Int): Float {
        val norm = touchSlopReduction.coerceIn(0, 100) / 100f
        return 6.5f - norm * 4.5f
    }

    fun areaCodeOf(area: TouchArea): Int = when (area) {
        TouchArea.ALL -> 0
        TouchArea.LEFT -> 1
        TouchArea.RIGHT -> 2
    }

    /**
     * Checks whether a touch starting at [startX] falls in the configured active area.
     */
    fun isInActiveArea(startX: Float, screenW: Int, areaCode: Int): Boolean {
        val w = screenW.coerceAtLeast(100).toFloat()
        return when (areaCode) {
            1 -> startX <= w * 0.52f // LEFT
            2 -> startX >= w * 0.48f // RIGHT
            else -> true             // ALL
        }
    }

    /**
     * Picks an open-screen companion anchor point separated by at least ~110px from the user's physical
     * finger so the companion pointer never collides with the physical finger, never presses the left
     * joystick when swiping on the right half, and stays safely inside screen margins.
     */
    fun chooseSafeCompanionAnchor(
        startX: Float,
        startY: Float,
        screenW: Int,
        screenH: Int
    ): Pair<Float, Float> {
        val w = screenW.coerceAtLeast(240).toFloat()
        val h = screenH.coerceAtLeast(240).toFloat()
        val marginX = (w * 0.10f).coerceIn(68f, 160f)
        val marginY = (h * 0.14f).coerceIn(76f, 180f)
        val isRightHalf = startX >= w * 0.50f

        // Stay on the same half when on the right half (camera aim zone) so we never touch a left joystick
        val preferredX = if (isRightHalf) {
            if (startX > w * 0.74f) startX - 135f else startX + 135f
        } else {
            if (startX < w * 0.28f) startX + 135f else startX - 135f
        }
        val minAnchorX = if (isRightHalf) (w * 0.52f).coerceAtMost(w - marginX) else marginX
        val maxAnchorX = if (isRightHalf) (w - marginX).coerceAtLeast(minAnchorX) else (w * 0.48f).coerceAtLeast(marginX)
        var ax = preferredX.coerceIn(minAnchorX, maxAnchorX)

        val preferredY = if (startY > h * 0.56f) startY - 125f else startY + 125f
        var ay = preferredY.coerceIn(marginY, (h - marginY).coerceAtLeast(marginY))

        // Guarantee at least 110px Euclidean separation from the physical finger
        val dist = hypot((ax - startX).toDouble(), (ay - startY).toDouble()).toFloat()
        if (dist < 110f) {
            val altY = if (startY > h * 0.50f) (startY - 140f) else (startY + 140f)
            ay = altY.coerceIn(marginY, (h - marginY).coerceAtLeast(marginY))
            val dist2 = hypot((ax - startX).toDouble(), (ay - startY).toDouble()).toFloat()
            if (dist2 < 110f) {
                val altX = if (ax >= startX) startX + 125f else startX - 125f
                ax = altX.coerceIn(marginX, (w - marginX).coerceAtLeast(marginX))
            }
        }
        return ax to ay
    }

    /**
     * Computes the extra companion delta `(extraDx, extraDy)` for one raw finger movement frame `(dx, dy)`.
     *
     * Key properties:
     * - Physical finger natively moves `1.0x`; companion injects ONLY the surplus `(effectiveGain - 1.0x)`
     *   in the EXACT SAME direction (never opposite, preventing accidental pinch-zoom).
     * - Axis independence: boosting Y only (`gainX == 1.0f, gainY > 1.0f`) yields `extraDx == 0f`.
     * - Velocity-adaptive flick curve: fast flicks receive an additional boost driven by `responseBoost`
     *   so headshot drags & 180-degree turns feel ultra-slick ("licin kaca"), while micro-aim stays controlled.
     */
    fun computeStepDelta(
        dx: Float,
        dy: Float,
        dtMs: Long,
        config: TouchAmplifierConfig,
        prevSmoothDx: Float = 0f,
        prevSmoothDy: Float = 0f
    ): Pair<Float, Float> {
        if (!config.hasEffectiveBoost()) return 0f to 0f
        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (dist < 0.15f) return 0f to 0f

        // Deadzone in pixels (0..50% -> 0..5.0px per frame)
        val deadzonePx = (config.deadzone.coerceIn(0, 50) / 50f) * 5.0f
        val effectiveScale = if (deadzonePx > 0f) {
            if (dist <= deadzonePx) return 0f to 0f
            ((dist - deadzonePx) / dist).coerceIn(0f, 1f)
        } else 1f

        val dzDx = dx * effectiveScale
        val dzDy = dy * effectiveScale

        // Optional EMA smoothing (0 = raw instant response, 100 = smooth glide)
        val smoothWeight = (config.smoothing.coerceIn(0, 100) / 100f) * 0.52f
        val sDx = dzDx * (1f - smoothWeight) + prevSmoothDx * smoothWeight
        val sDy = dzDy * (1f - smoothWeight) + prevSmoothDy * smoothWeight

        // Velocity-adaptive flick multiplier (px/ms)
        val safeDtMs = dtMs.coerceIn(2L, 40L).toFloat()
        val velocityPxPerMs = hypot(sDx.toDouble(), sDy.toDouble()).toFloat() / safeDtMs
        val respNorm = config.responseBoost.coerceIn(0, 100) / 100f
        // Smoothly ramps from 0 at slow aim (<0.35 px/ms) up to +0.85x on crisp flicks (>=3.2 px/ms)
        val flickNorm = ((velocityPxPerMs - 0.35f) / 2.85f).coerceIn(0f, 1f)
        val flickBonus = flickNorm * respNorm * 0.85f

        val baseSurplusX = (config.gainX - 1.0f).coerceAtLeast(0f)
        val baseSurplusY = (config.gainY - 1.0f).coerceAtLeast(0f)

        // Apply velocity flick bonus strictly proportional to active axes (preserves strict X/Y independence!)
        val extraFactorX = if (baseSurplusX > 0.005f) {
            (baseSurplusX + flickBonus * (baseSurplusX / (baseSurplusX + 0.5f))).coerceIn(0f, 3.25f)
        } else if (config.gainX >= 1.0f && respNorm > 0f && baseSurplusY <= 0.005f) {
            (flickBonus * 0.65f).coerceIn(0f, 1.5f)
        } else {
            0f
        }

        val extraFactorY = if (baseSurplusY > 0.005f) {
            (baseSurplusY + flickBonus * (baseSurplusY / (baseSurplusY + 0.5f))).coerceIn(0f, 3.50f)
        } else if (config.gainY >= 1.0f && respNorm > 0f && baseSurplusX <= 0.005f) {
            (flickBonus * 0.65f).coerceIn(0f, 1.5f)
        } else {
            0f
        }

        val maxStepX = (config.screenW * 0.24f).coerceIn(60f, 420f)
        val maxStepY = (config.screenH * 0.24f).coerceIn(60f, 420f)

        val extraDx = (sDx * extraFactorX).coerceIn(-maxStepX, maxStepX)
        val extraDy = (sDy * extraFactorY).coerceIn(-maxStepY, maxStepY)

        if (abs(extraDx) < 0.2f && abs(extraDy) < 0.2f) return 0f to 0f
        return extraDx to extraDy
    }

    /**
     * Generates 2 short decaying micro-glide steps when a fast flick ends so momentum feels frictionless
     * even on launchers or games that gate secondary pointer deltas during finger-0 hold.
     */
    fun computeLiftGlideSteps(
        lastExtraDx: Float,
        lastExtraDy: Float,
        responseBoost: Int
    ): List<Pair<Float, Float>> {
        val speed = hypot(lastExtraDx.toDouble(), lastExtraDy.toDouble()).toFloat()
        if (speed < 4.5f) return emptyList()
        val respFactor = 0.55f + (responseBoost.coerceIn(0, 100) / 100f) * 0.45f
        val step1X = (lastExtraDx * 0.48f * respFactor).coerceIn(-120f, 120f)
        val step1Y = (lastExtraDy * 0.48f * respFactor).coerceIn(-120f, 120f)
        val step2X = (lastExtraDx * 0.22f * respFactor).coerceIn(-70f, 70f)
        val step2Y = (lastExtraDy * 0.22f * respFactor).coerceIn(-70f, 70f)
        return listOf(step1X to step1Y, step2X to step2Y)
    }
}

/**
 * Immutable snapshot of one active physical finger tracked from `/dev/input/eventX` or `getevent`.
 * Shared between KernelTouchEngine, ShizukuInputUserService (Non-Root Multi-Pointer Merge), and unit tests.
 */
data class PhysicalPointerPoint(
    val slot: Int,
    val pointerId: Int,
    val screenX: Float,
    val screenY: Float
)

data class ActivePhysicalTouchSnapshot(
    val downTimeMs: Long,
    val pointers: List<PhysicalPointerPoint>
)

/**
 * Stateful, thread-safe companion touch boost controller fed by physical touchscreen frames
 * (either directly from `/dev/input/eventX` or from `getevent` stream) and emitting zero-latency
 * companion events on dedicated Slot 6 (`slotOffset = 3`).
 */
class TouchBoostController(
    private val dispatchEvent: (
        action: Int,
        x: Float,
        y: Float,
        downTimeMs: Long,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ) -> Boolean,
    private val sleepMs: (Long) -> Unit = { ms -> SystemClock.sleep(ms) },
    private val nowMsProvider: () -> Long = { SystemClock.uptimeMillis() }
) {
    private val lock = Any()

    private class PendingFingerState {
        var active: Boolean = false
        var lastX: Float = 0f
        var lastY: Float = 0f
        var lastMs: Long = 0L
        var cumTravelPx: Float = 0f
    }

    @Volatile
    private var config: TouchAmplifierConfig = TouchAmplifierConfig()

    @Volatile
    var boostedFramesCount: Long = 0L
        private set

    // Per-slot standby trackers (slots 0..5) so holding Finger 0 stationary on Macro Trigger
    // or Fire button never prevents Finger 1 from claiming boost as soon as Finger 1 drags the camera!
    private val pendingFingers = Array(8) { PendingFingerState() }

    // Tracked primary physical finger slot
    private var trackedSlot: Int = -1
    private var startScreenX: Float = 0f
    private var startScreenY: Float = 0f
    private var lastScreenX: Float = 0f
    private var lastScreenY: Float = 0f
    private var lastFrameMs: Long = 0L
    private var cumTravelPx: Float = 0f
    private var smoothDx: Float = 0f
    private var smoothDy: Float = 0f
    private var lastExtraDx: Float = 0f
    private var lastExtraDy: Float = 0f

    // Active companion boost pointer state
    private var boostActive: Boolean = false
    private var boostDownTimeMs: Long = 0L
    private var boostAnchorX: Float = 0f
    private var boostAnchorY: Float = 0f
    private var boostCurX: Float = 0f
    private var boostCurY: Float = 0f

    fun updateConfig(newConfig: TouchAmplifierConfig) {
        synchronized(lock) {
            val wasActive = boostActive
            val oldCfg = config
            config = newConfig
            if (!newConfig.hasEffectiveBoost() && wasActive) {
                releaseCompanionLocked(oldCfg, withGlide = false)
                resetTrackedFingerLocked()
            }
        }
    }

    fun currentConfig(): TouchAmplifierConfig = config

    fun onPhysicalFingerDown(slot: Int, screenX: Float, screenY: Float) {
        synchronized(lock) {
            val cfg = config
            if (!cfg.hasEffectiveBoost()) return
            if (!TouchAmplifierMath.isInActiveArea(screenX, cfg.screenW, cfg.areaCode)) return

            val nowMs = nowMsProvider()
            if (slot in pendingFingers.indices) {
                pendingFingers[slot].apply {
                    active = true
                    lastX = screenX
                    lastY = screenY
                    lastMs = nowMs
                    cumTravelPx = 0f
                }
            }

            // Only lock immediately onto trackedSlot if no finger is currently tracked
            if (trackedSlot != -1 && trackedSlot != slot) return

            trackedSlot = slot
            startScreenX = screenX
            startScreenY = screenY
            lastScreenX = screenX
            lastScreenY = screenY
            lastFrameMs = nowMs
            cumTravelPx = 0f
            smoothDx = 0f
            smoothDy = 0f
            lastExtraDx = 0f
            lastExtraDy = 0f
        }
    }

    fun onPhysicalFingerMove(slot: Int, screenX: Float, screenY: Float) {
        synchronized(lock) {
            val cfg = config
            if (!cfg.hasEffectiveBoost()) {
                if (boostActive) releaseCompanionLocked(cfg, withGlide = false)
                resetTrackedFingerLocked()
                return
            }

            val nowMs = nowMsProvider()
            val threshold = TouchAmplifierMath.activationThresholdPx(cfg.touchSlopReduction)

            // If another finger (e.g. camera swipe thumb on Slot 1) starts dragging past threshold
            // while trackedSlot (e.g. stationary Macro Trigger thumb on Slot 0) hasn't triggered boost yet,
            // seamlessly hand off trackedSlot to the actually swiping finger!
            if (trackedSlot != -1 && slot != trackedSlot && !boostActive && slot in pendingFingers.indices) {
                val pf = pendingFingers[slot]
                if (!pf.active) {
                    if (TouchAmplifierMath.isInActiveArea(screenX, cfg.screenW, cfg.areaCode)) {
                        pf.active = true
                        pf.lastX = screenX
                        pf.lastY = screenY
                        pf.lastMs = nowMs
                        pf.cumTravelPx = 0f
                    }
                    return
                }
                val pdx = screenX - pf.lastX
                val pdy = screenY - pf.lastY
                val pDist = hypot(pdx.toDouble(), pdy.toDouble()).toFloat()
                pf.cumTravelPx += pDist
                if (pf.cumTravelPx >= threshold) {
                    trackedSlot = slot
                    startScreenX = pf.lastX
                    startScreenY = pf.lastY
                    lastScreenX = pf.lastX
                    lastScreenY = pf.lastY
                    lastFrameMs = pf.lastMs
                    cumTravelPx = pf.cumTravelPx
                    smoothDx = 0f
                    smoothDy = 0f
                    lastExtraDx = 0f
                    lastExtraDy = 0f
                } else {
                    pf.lastX = screenX
                    pf.lastY = screenY
                    pf.lastMs = nowMs
                    return
                }
            }

            // Late-attach if finger was already down when Touch Sensitivity was toggled ON
            if (trackedSlot == -1) {
                if (!TouchAmplifierMath.isInActiveArea(screenX, cfg.screenW, cfg.areaCode)) return
                trackedSlot = slot
                startScreenX = screenX
                startScreenY = screenY
                lastScreenX = screenX
                lastScreenY = screenY
                lastFrameMs = nowMs
                cumTravelPx = 0f
                smoothDx = 0f
                smoothDy = 0f
                lastExtraDx = 0f
                lastExtraDy = 0f
                return
            }

            if (slot != trackedSlot) return

            val dx = screenX - lastScreenX
            val dy = screenY - lastScreenY
            val dtMs = (nowMs - lastFrameMs).coerceIn(2L, 40L)
            lastScreenX = screenX
            lastScreenY = screenY
            lastFrameMs = nowMs

            val stepDist = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (stepDist < 0.25f) return

            cumTravelPx += stepDist
            if (cumTravelPx < threshold) {
                return
            }

            val (extraDx, extraDy) = TouchAmplifierMath.computeStepDelta(
                dx = dx,
                dy = dy,
                dtMs = dtMs,
                config = cfg,
                prevSmoothDx = smoothDx,
                prevSmoothDy = smoothDy
            )
            smoothDx = dx
            smoothDy = dy

            if (extraDx == 0f && extraDy == 0f) return

            val margin = 56f
            val maxX = (cfg.screenW - margin).coerceAtLeast(margin + 1f)
            val maxY = (cfg.screenH - margin).coerceAtLeast(margin + 1f)

            // Re-anchor cleanly when approaching screen edge so 360-degree spins never hit a wall
            if (boostActive) {
                val nextX = boostCurX + extraDx
                val nextY = boostCurY + extraDy
                val nearEdge = nextX < margin || nextX > maxX || nextY < margin || nextY > maxY
                val farFromAnchor = hypot(
                    (nextX - boostAnchorX).toDouble(),
                    (nextY - boostAnchorY).toDouble()
                ) > (minOf(cfg.screenW, cfg.screenH) * 0.42f)
                if (nearEdge || farFromAnchor) {
                    dispatchEvent(
                        MotionEvent.ACTION_UP,
                        boostCurX,
                        boostCurY,
                        boostDownTimeMs,
                        cfg.screenW,
                        cfg.screenH,
                        cfg.rotation
                    )
                    boostActive = false
                }
            }

            if (!boostActive) {
                val (ax, ay) = TouchAmplifierMath.chooseSafeCompanionAnchor(
                    startX = screenX,
                    startY = screenY,
                    screenW = cfg.screenW,
                    screenH = cfg.screenH
                )
                boostAnchorX = ax
                boostAnchorY = ay
                boostCurX = ax
                boostCurY = ay
                boostDownTimeMs = nowMs
                val okDown = dispatchEvent(
                    MotionEvent.ACTION_DOWN,
                    boostCurX,
                    boostCurY,
                    boostDownTimeMs,
                    cfg.screenW,
                    cfg.screenH,
                    cfg.rotation
                )
                if (!okDown) return
                boostActive = true
            }

            boostCurX = (boostCurX + extraDx).coerceIn(margin, maxX)
            boostCurY = (boostCurY + extraDy).coerceIn(margin, maxY)
            lastExtraDx = extraDx
            lastExtraDy = extraDy

            if (dispatchEvent(
                    MotionEvent.ACTION_MOVE,
                    boostCurX,
                    boostCurY,
                    boostDownTimeMs,
                    cfg.screenW,
                    cfg.screenH,
                    cfg.rotation
                )
            ) {
                boostedFramesCount++
            }
        }
    }

    fun onPhysicalFingerUp(slot: Int) {
        synchronized(lock) {
            if (slot in pendingFingers.indices) {
                pendingFingers[slot].active = false
                pendingFingers[slot].cumTravelPx = 0f
            }
            if (slot != trackedSlot) return
            val cfg = config
            if (boostActive) {
                releaseCompanionLocked(cfg, withGlide = true)
            }
            resetTrackedFingerLocked()
        }
    }

    fun forceRelease() {
        synchronized(lock) {
            for (pf in pendingFingers) {
                pf.active = false
                pf.cumTravelPx = 0f
            }
            if (boostActive) {
                releaseCompanionLocked(config, withGlide = false)
            }
            resetTrackedFingerLocked()
        }
    }

    private fun releaseCompanionLocked(cfg: TouchAmplifierConfig, withGlide: Boolean) {
        if (!boostActive) return
        val margin = 56f
        val maxX = (cfg.screenW - margin).coerceAtLeast(margin + 1f)
        val maxY = (cfg.screenH - margin).coerceAtLeast(margin + 1f)

        if (withGlide) {
            val glideSteps = TouchAmplifierMath.computeLiftGlideSteps(
                lastExtraDx = lastExtraDx,
                lastExtraDy = lastExtraDy,
                responseBoost = cfg.responseBoost
            )
            for ((gx, gy) in glideSteps) {
                val nextX = (boostCurX + gx).coerceIn(margin, maxX)
                val nextY = (boostCurY + gy).coerceIn(margin, maxY)
                if (abs(nextX - boostCurX) >= 0.5f || abs(nextY - boostCurY) >= 0.5f) {
                    sleepMs(5L)
                    boostCurX = nextX
                    boostCurY = nextY
                    dispatchEvent(
                        MotionEvent.ACTION_MOVE,
                        boostCurX,
                        boostCurY,
                        boostDownTimeMs,
                        cfg.screenW,
                        cfg.screenH,
                        cfg.rotation
                    )
                    boostedFramesCount++
                }
            }
        }

        dispatchEvent(
            MotionEvent.ACTION_UP,
            boostCurX,
            boostCurY,
            boostDownTimeMs,
            cfg.screenW,
            cfg.screenH,
            cfg.rotation
        )
        boostActive = false
    }

    private fun resetTrackedFingerLocked() {
        trackedSlot = -1
        cumTravelPx = 0f
        smoothDx = 0f
        smoothDy = 0f
        lastExtraDx = 0f
        lastExtraDy = 0f
    }
}
