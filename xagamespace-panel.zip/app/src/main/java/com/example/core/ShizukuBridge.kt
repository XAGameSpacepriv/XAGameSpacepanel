package com.example.core

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import com.example.BuildConfig
import com.example.data.BoosterPreferences
import com.example.model.MacroInjectionMode
import com.example.model.PrivilegeMode
import com.example.model.RootGrantState
import com.example.model.ShizukuStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

data class ShellResult(
    val success: Boolean,
    val output: String,
    val error: String,
    val usedShizuku: Boolean = false,
    val usedRoot: Boolean = false
)

data class RootPermissionResult(
    val granted: Boolean,
    val state: RootGrantState,
    val managerLabel: String,
    val message: String
)

/**
 * Independent 2-Option Privileged Command & Multi-Tier 10-Finger Input Injection Bridge:
 * - Opsi 1 (PrivilegeMode.ROOT): Runs purely via `su` (UID 0) + persistent `RootTouchDaemon`
 *   (/dev/input/eventX Slot-9..6 hardware multi-touch). Never requires Shizuku!
 * - Opsi 2 (PrivilegeMode.SHIZUKU): Runs purely via Shizuku UserService (UID 2000) +
 *   Non-Root Multi-Pointer Merge + Direct ShizukuBinderWrapper. Never invokes `su`!
 */
object ShizukuBridge {
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val REQUEST_CODE_SHIZUKU = 4109

    private val mainHandler = Handler(Looper.getMainLooper())
    private val bridgeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _autoProvisionBanner = MutableStateFlow<String?>(null)
    val autoProvisionBanner: StateFlow<String?> = _autoProvisionBanner.asStateFlow()

    private val _touchAmplifierEngine = MutableStateFlow("Nonaktif")
    val touchAmplifierEngine: StateFlow<String> = _touchAmplifierEngine.asStateFlow()

    private var listenersRegistered = false
    private var cachedAppContext: Context? = null

    @Volatile
    private var inputServiceBinder: IBinder? = null

    @Volatile
    private var isBindingInputService = false

    @Volatile
    private var userServiceCapMask: Int = 0

    @Volatile
    private var lastAutoPermRequestAtMs = 0L

    @Volatile
    private var autoProvisionedForBinder = false

    @Volatile
    private var rootGrantState: RootGrantState = RootGrantState.NOT_FOUND

    @Volatile
    private var rootGrantedSession: Boolean = false

    @Volatile
    private var detectedRootManagerLabel: String = "Superuser"

    @Volatile
    private var pendingAmplifierConfig: TouchAmplifierConfig? = null

    @Volatile
    var lastInjectionAtMs: Long = 0L
        private set

    @Volatile
    var binderMotionBlocked: Boolean = false
        private set

    @Volatile
    var lastInjectionError: String? = null
        private set

    @Volatile
    private var consecutiveBinderFailCount: Int = 0

    @Volatile
    private var binderBlockedUntilMs: Long = 0L

    @Volatile
    private var lastDirectBinderSecurityError: Boolean = false

    @Volatile
    private var lastShellSwipeAtMs: Long = 0L

    private data class DirectStreamProfile(
        val pointerId: Int,
        val toolType: Int,
        val source: Int,
        val deviceId: Int
    )

    // Direct ShizukuBinderWrapper -> IInputManager backup (instant <1.5ms without waiting for UserService bind)
    private val directBinderLock = Any()
    private var directInputManager: Any? = null
    private var directInjectMethod: Method? = null
    private var directTouchDeviceId: Int = 0
    private val activeDirectStreams = ConcurrentHashMap<Int, DirectStreamProfile>()
    private val preferredDirectProfiles = ConcurrentHashMap<Int, DirectStreamProfile>()

    // Persistent RootTouchDaemon (true hardware Slot-9 10-finger concurrency)
    private val rootDaemonLock = Any()
    private var rootProcess: Process? = null
    private var rootWriter: BufferedWriter? = null

    @Volatile
    private var rootDaemonReady = false

    @Volatile
    private var rootDaemonStarting = false

    @Volatile
    private var rootDaemonUnavailable = false

    private val userServiceArgs: Shizuku.UserServiceArgs?
        get() {
            val ctx = cachedAppContext ?: return null
            return Shizuku.UserServiceArgs(
                ComponentName(ctx.packageName, ShizukuInputUserService::class.java.name)
            )
                .daemon(false)
                .processNameSuffix("input")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
        }

    private val inputServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            isBindingInputService = false
            inputServiceBinder = service
            binderMotionBlocked = false
            consecutiveBinderFailCount = 0
            lastInjectionError = null
            bridgeScope.launch {
                queryUserServiceCaps(service)
                pendingAmplifierConfig?.let { cfg ->
                    if (isShizukuModeSelected()) {
                        syncTouchAmplifierConfig(cfg)
                    }
                }
                refreshStatusInternal()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBindingInputService = false
            inputServiceBinder = null
            userServiceCapMask = 0
            refreshStatusInternal()
        }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener {
        autoProvisionedForBinder = false
        binderMotionBlocked = false
        consecutiveBinderFailCount = 0
        lastInjectionError = null
        clearDirectBinderProxy()
        val st = refreshStatusInternal()
        if (isShizukuModeSelected()) {
            handleAutoDetectAndProvision(st, allowPermissionPrompt = true)
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        inputServiceBinder = null
        isBindingInputService = false
        userServiceCapMask = 0
        autoProvisionedForBinder = false
        binderMotionBlocked = false
        consecutiveBinderFailCount = 0
        clearDirectBinderProxy()
        refreshStatusInternal()
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            val st = refreshStatusInternal()
            if (grantResult == PackageManager.PERMISSION_GRANTED && isShizukuModeSelected()) {
                handleAutoDetectAndProvision(st, allowPermissionPrompt = false)
            }
        }
    }

    private fun currentPrefs(): BoosterPreferences? =
        cachedAppContext?.let { runCatching { BoosterPreferences.getInstance(it) }.getOrNull() }

    private fun activePrivilegeMode(): PrivilegeMode =
        currentPrefs()?.privilegeMode?.value ?: PrivilegeMode.SHIZUKU

    private fun isRootModeSelected(): Boolean {
        val p = currentPrefs() ?: return false
        return p.privilegeMode.value == PrivilegeMode.ROOT && p.useRoot.value
    }

    private fun isShizukuModeSelected(): Boolean {
        val p = currentPrefs() ?: return true
        return p.privilegeMode.value == PrivilegeMode.SHIZUKU && p.useShizuku.value
    }

    fun init(context: Context) {
        cachedAppContext = context.applicationContext
        if (!listenersRegistered) {
            listenersRegistered = true
            runCatching {
                Shizuku.addBinderReceivedListenerSticky(binderListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionListener)
            }
        }
        detectedRootManagerLabel = detectRootManagerLabel(context.applicationContext)
        val st = refreshStatusInternal()
        if (isShizukuModeSelected()) {
            handleAutoDetectAndProvision(st, allowPermissionPrompt = true)
        } else if (isRootModeSelected() && rootGrantedSession && !rootDaemonReady && !rootDaemonStarting && !rootDaemonUnavailable) {
            bridgeScope.launch { ensureRootTouchDaemon() }
        }
    }

    fun refresh(context: Context? = null, autoTriggerIfReady: Boolean = false): ShizukuStatus {
        if (context != null) {
            cachedAppContext = context.applicationContext
            detectedRootManagerLabel = detectRootManagerLabel(context.applicationContext)
        }
        val st = refreshStatusInternal()
        if (autoTriggerIfReady && isShizukuModeSelected()) {
            handleAutoDetectAndProvision(st, allowPermissionPrompt = true)
        }
        if (isRootModeSelected() && rootGrantedSession && st.isRootAvailable && !rootDaemonReady && !rootDaemonStarting && !rootDaemonUnavailable) {
            bridgeScope.launch { ensureRootTouchDaemon() }
        }
        return st
    }

    fun switchToRootMode(context: Context): ShizukuStatus {
        cachedAppContext = context.applicationContext
        detectedRootManagerLabel = detectRootManagerLabel(context.applicationContext)
        BoosterPreferences.getInstance(context.applicationContext).setPrivilegeMode(PrivilegeMode.ROOT)
        unbindShizukuOnly()
        val st = refreshStatusInternal()
        if (rootGrantedSession && st.isRootAvailable && !rootDaemonReady && !rootDaemonStarting) {
            rootDaemonUnavailable = false
            bridgeScope.launch {
                ensureRootTouchDaemon()
                pendingAmplifierConfig?.let { syncTouchAmplifierConfig(it) }
            }
        }
        return st
    }

    fun switchToShizukuMode(context: Context): ShizukuStatus {
        cachedAppContext = context.applicationContext
        BoosterPreferences.getInstance(context.applicationContext).setPrivilegeMode(PrivilegeMode.SHIZUKU)
        stopRootTouchDaemon()
        val st = refreshStatusInternal()
        handleAutoDetectAndProvision(st, allowPermissionPrompt = false)
        return st
    }

    suspend fun requestRootPermission(context: Context): RootPermissionResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        cachedAppContext = appCtx
        BoosterPreferences.getInstance(appCtx).setPrivilegeMode(PrivilegeMode.ROOT)
        unbindShizukuOnly()

        val hasSuBinary = checkRootBinary()
        val managerLabel = detectRootManagerLabel(appCtx)
        detectedRootManagerLabel = managerLabel

        if (!hasSuBinary) {
            rootGrantedSession = false
            rootGrantState = RootGrantState.NOT_FOUND
            refreshStatusInternal()
            return@withContext RootPermissionResult(
                granted = false,
                state = RootGrantState.NOT_FOUND,
                managerLabel = managerLabel,
                message = "Binary 'su' tidak ditemukan di perangkat ini. Gunakan Opsi 2 (Shizuku Non-Root)."
            )
        }

        // Verify real UID 0 via su (allow up to 12s so Superuser prompt can be accepted by user)
        val idRes = runViaSu("id -u ; su -v 2>/dev/null || true", timeoutSec = 12L)
        val firstToken = idRes.output.lineSequence().firstOrNull()?.trim().orEmpty()
        val granted = idRes.success && firstToken == "0"
        val suVer = idRes.output.lineSequence().drop(1).firstOrNull()?.trim().orEmpty()
        val refinedManager = when {
            suVer.contains("magisk", ignoreCase = true) -> "Magisk"
            suVer.contains("kernelsu", ignoreCase = true) || suVer.contains("ksu", ignoreCase = true) -> "KernelSU"
            suVer.contains("apatch", ignoreCase = true) -> "APatch"
            else -> managerLabel
        }
        detectedRootManagerLabel = refinedManager

        if (granted) {
            rootGrantedSession = true
            rootGrantState = RootGrantState.GRANTED
            rootDaemonUnavailable = false

            // Auto-provision appops via Root UID 0 so overlay / usage / write settings work immediately
            val pkg = appCtx.packageName
            val provisionCmd = buildString {
                append("appops set ").append(pkg).append(" SYSTEM_ALERT_WINDOW allow ; ")
                append("appops set ").append(pkg).append(" GET_USAGE_STATS allow ; ")
                append("appops set ").append(pkg).append(" WRITE_SETTINGS allow ; ")
                append("appops set ").append(pkg).append(" PROJECT_MEDIA allow 2>/dev/null ; ")
                append("pm grant ").append(pkg).append(" android.permission.POST_NOTIFICATIONS 2>/dev/null ; true")
            }
            runViaSu(provisionCmd, timeoutSec = 6L)

            ensureRootTouchDaemon()
            pendingAmplifierConfig?.let { syncTouchAmplifierConfig(it) }
            refreshStatusInternal()

            RootPermissionResult(
                granted = true,
                state = RootGrantState.GRANTED,
                managerLabel = refinedManager,
                message = "Root ($refinedManager • UID 0) aktif! Semua fitur jalan mandiri tanpa Shizuku."
            )
        } else {
            rootGrantedSession = false
            rootGrantState = RootGrantState.DENIED
            stopRootTouchDaemon()
            refreshStatusInternal()
            RootPermissionResult(
                granted = false,
                state = RootGrantState.DENIED,
                managerLabel = refinedManager,
                message = "Permintaan Root ditolak oleh $refinedManager atau habis waktu. Cek aplikasi $refinedManager lalu coba lagi."
            )
        }
    }

    fun unbindShizukuOnly() {
        val args = userServiceArgs
        if (args != null) {
            mainHandler.post {
                runCatching { Shizuku.unbindUserService(args, inputServiceConnection, true) }
            }
        }
        inputServiceBinder = null
        isBindingInputService = false
        userServiceCapMask = 0
        clearDirectBinderProxy()
    }

    fun revokeLocalRootSession() {
        stopRootTouchDaemon()
        rootGrantedSession = false
        rootGrantState = if (checkRootBinary()) RootGrantState.AVAILABLE_NOT_GRANTED else RootGrantState.NOT_FOUND
        _touchAmplifierEngine.value = "Nonaktif"
        refreshStatusInternal()
    }

    fun unbindInputService() {
        unbindShizukuOnly()
        stopRootTouchDaemon()
        _touchAmplifierEngine.value = "Nonaktif"
    }

    fun clearAutoProvisionBanner() {
        _autoProvisionBanner.value = null
    }

    fun isKernelMultiTouchActive(): Boolean = when (activePrivilegeMode()) {
        PrivilegeMode.ROOT -> rootGrantedSession && rootDaemonReady
        PrivilegeMode.SHIZUKU -> (userServiceCapMask and 2) != 0 && inputServiceBinder?.isBinderAlive == true
    }

    fun wasRecentInjection(windowMs: Long = 280L): Boolean =
        (SystemClock.uptimeMillis() - lastInjectionAtMs) in 0L..windowMs

    private fun detectRootManagerLabel(ctx: Context): String {
        val pm = ctx.packageManager
        fun hasPkg(pkg: String): Boolean = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            true
        }.getOrDefault(false)

        return when {
            hasPkg("com.topjohnwu.magisk") || hasPkg("io.github.huskydg.magisk") -> "Magisk"
            hasPkg("me.weishu.kernelsu") || hasPkg("com.rifsxd.ksunext") -> "KernelSU"
            hasPkg("me.bmax.apatch") -> "APatch"
            else -> "Superuser"
        }
    }

    private fun refreshStatusInternal(): ShizukuStatus {
        val ctx = cachedAppContext
        val installed = if (ctx != null) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    ctx.packageManager.getPackageInfo(SHIZUKU_PACKAGE, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    ctx.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
                }
                true
            }.getOrDefault(false)
        } else false

        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = if (running) {
            runCatching {
                !Shizuku.isPreV11() &&
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
        } else false

        val version = if (running) runCatching { Shizuku.getVersion() }.getOrDefault(0) else 0
        val hasRoot = checkRootBinary()
        if (!hasRoot) {
            rootGrantedSession = false
            rootGrantState = RootGrantState.NOT_FOUND
        } else if (rootGrantedSession) {
            rootGrantState = RootGrantState.GRANTED
        }

        val binderAlive = running && granted && (inputServiceBinder?.isBinderAlive == true)
        val mode = activePrivilegeMode()
        val kernelMultiTouch = isKernelMultiTouchActive()
        val engineLabel = when (mode) {
            PrivilegeMode.ROOT -> when {
                rootGrantedSession && rootDaemonReady -> "Root Kernel Slot-9 (10-Jari Hardware)"
                rootGrantedSession -> "Root UID 0 ($detectedRootManagerLabel)"
                hasRoot -> "Root ($detectedRootManagerLabel) • Belum Diizinkan"
                else -> "Root Tidak Tersedia"
            }
            PrivilegeMode.SHIZUKU -> when {
                binderAlive && (userServiceCapMask and 2) != 0 -> "Shizuku Kernel Slot-9 (10-Jari)"
                binderAlive -> "Shizuku UserService Direct Touch"
                running && granted -> "Shizuku Binder Proxy Direct"
                running -> "Shizuku Berjalan • Butuh Izin"
                installed -> "Shizuku Terpasang • Belum Aktif"
                else -> "Shizuku Belum Terhubung"
            }
        }

        val updated = ShizukuStatus(
            isInstalled = installed,
            isRunning = running,
            isPermissionGranted = granted,
            apiVersion = version,
            isRootAvailable = hasRoot,
            isRootGranted = rootGrantedSession && hasRoot,
            rootGrantState = rootGrantState,
            rootManagerLabel = detectedRootManagerLabel,
            isInputServiceBound = binderAlive,
            autoPermissionsApplied = autoProvisionedForBinder || rootGrantedSession,
            isKernelMultiTouch = kernelMultiTouch,
            activeEngineLabel = engineLabel
        )
        _status.value = updated
        return updated
    }

    private fun handleAutoDetectAndProvision(st: ShizukuStatus, allowPermissionPrompt: Boolean) {
        val ctx = cachedAppContext ?: return
        if (!isShizukuModeSelected()) return

        if (st.isRunning && !st.isPermissionGranted && allowPermissionPrompt) {
            val now = System.currentTimeMillis()
            if (now - lastAutoPermRequestAtMs > 25_000L) {
                lastAutoPermRequestAtMs = now
                requestPermission()
            }
            return
        }

        if (st.isRunning && st.isPermissionGranted) {
            ensureInputServiceBound()
            if (!autoProvisionedForBinder) {
                autoProvisionedForBinder = true
                bridgeScope.launch {
                    val pkg = ctx.packageName
                    val cmds = buildString {
                        append("appops set ").append(pkg).append(" SYSTEM_ALERT_WINDOW allow ; ")
                        append("appops set ").append(pkg).append(" GET_USAGE_STATS allow ; ")
                        append("appops set ").append(pkg).append(" WRITE_SETTINGS allow ; ")
                        append("appops set ").append(pkg).append(" PROJECT_MEDIA allow 2>/dev/null ; ")
                        append("pm grant ").append(pkg).append(" android.permission.POST_NOTIFICATIONS 2>/dev/null ; true")
                    }
                    val res = runViaShizukuReflection(cmds)
                    refreshStatusInternal()
                    if (res.success || res.usedShizuku) {
                        _autoProvisionBanner.value =
                            "Shizuku (Non-Root) terhubung otomatis! Izin Overlay, Usage Access & Macro 10-Jari aktif."
                    }
                }
            }
        }
    }

    fun ensureInputServiceBound(): Boolean {
        if (!isShizukuModeSelected()) return false
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (!running || !granted) return false
        if (inputServiceBinder?.isBinderAlive == true) return true
        if (isBindingInputService) return false

        val args = userServiceArgs ?: return false
        isBindingInputService = true
        val bindBlock = Runnable {
            runCatching {
                if (inputServiceBinder?.isBinderAlive != true) {
                    Shizuku.bindUserService(args, inputServiceConnection)
                } else {
                    isBindingInputService = false
                }
            }.onFailure {
                isBindingInputService = false
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            bindBlock.run()
        } else {
            mainHandler.post(bindBlock)
        }
        return true
    }

    fun requestPermission(): Boolean {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!running) return false
        return runCatching {
            if (!Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
            ) {
                Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                true
            } else {
                val st = refreshStatusInternal()
                handleAutoDetectAndProvision(st, allowPermissionPrompt = false)
                true
            }
        }.getOrDefault(false)
    }

    /**
     * Pushes live Touch Sensitivity X/Y Amplifier parameters to the active privileged backend:
     * - Opsi 1 (Root): RootTouchDaemon (hardware evdev Slot-6 live companion)
     * - Opsi 2 (Shizuku): ShizukuInputUserService (TX_SYNC_BOOST_CFG)
     */
    fun syncTouchAmplifierConfig(cfg: TouchAmplifierConfig): String {
        pendingAmplifierConfig = cfg

        if (!cfg.enabled || !cfg.hasEffectiveBoost()) {
            if (rootDaemonReady) {
                sendRootDaemonCmd(cfg.copy(enabled = false).toDaemonCommand())
            }
            val binder = inputServiceBinder?.takeIf { it.isBinderAlive }
            if (binder != null) {
                transactBoostConfig(binder, cfg.copy(enabled = false))
            }
            _touchAmplifierEngine.value = "Nonaktif"
            return "Nonaktif"
        }

        return when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (isRootModeSelected() && rootGrantedSession && checkRootBinary()) {
                    if (!rootDaemonReady && !rootDaemonStarting && !rootDaemonUnavailable) {
                        ensureRootTouchDaemon()
                    }
                    if (rootDaemonReady && sendRootDaemonCmd(cfg.toDaemonCommand())) {
                        "Root Kernel Evdev Live".also { _touchAmplifierEngine.value = it }
                    } else {
                        "Root Sysfs & Driver".also { _touchAmplifierEngine.value = it }
                    }
                } else {
                    "Perlu Izin Root".also { _touchAmplifierEngine.value = it }
                }
            }
            PrivilegeMode.SHIZUKU -> {
                if (isShizukuModeSelected()) {
                    val binder = inputServiceBinder?.takeIf { it.isBinderAlive }
                    if (binder != null) {
                        val liveReader = transactBoostConfig(binder, cfg)
                        val label = if (liveReader) "Shizuku Live Touch Boost" else "Shizuku Input Framework"
                        label.also { _touchAmplifierEngine.value = it }
                    } else {
                        ensureInputServiceBound()
                        "Shizuku Input Framework".also { _touchAmplifierEngine.value = it }
                    }
                } else {
                    "Perlu Izin Shizuku".also { _touchAmplifierEngine.value = it }
                }
            }
        }
    }

    private fun transactBoostConfig(binder: IBinder, cfg: TouchAmplifierConfig): Boolean {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
            data.writeInt(if (cfg.enabled) 1 else 0)
            data.writeFloat(cfg.gainX)
            data.writeFloat(cfg.gainY)
            data.writeInt(cfg.responseBoost)
            data.writeInt(cfg.touchSlopReduction)
            data.writeInt(cfg.smoothing)
            data.writeInt(cfg.deadzone)
            data.writeInt(cfg.areaCode)
            data.writeInt(cfg.screenW)
            data.writeInt(cfg.screenH)
            data.writeInt(cfg.rotation)
            if (binder.transact(ShizukuInputUserService.TX_SYNC_BOOST_CFG, data, reply, 0)) {
                reply.readException()
                reply.readInt() == 1
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    /**
     * Notifies the active privileged touch backend when Macro starts/stops firing so non-root
     * passive physical finger tracking wakes up immediately and never competes with Touch Boost.
     */
    fun setMacroActive(active: Boolean) {
        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (rootDaemonReady) {
                    sendRootDaemonCmd("MACRO_ACTIVE ${if (active) 1 else 0}")
                }
            }
            PrivilegeMode.SHIZUKU -> {
                val binder = inputServiceBinder?.takeIf { it.isBinderAlive } ?: return
                val data = Parcel.obtain()
                val reply = Parcel.obtain()
                try {
                    data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
                    data.writeInt(if (active) 1 else 0)
                    binder.transact(ShizukuInputUserService.TX_SET_MACRO_ACTIVE, data, reply, 0)
                    reply.readException()
                } catch (_: Throwable) {
                    // Non-fatal
                } finally {
                    data.recycle()
                    reply.recycle()
                }
            }
        }
    }

    private fun queryUserServiceCaps(binder: IBinder?) {
        val b = binder?.takeIf { it.isBinderAlive } ?: return
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
            if (b.transact(ShizukuInputUserService.TX_PING, data, reply, 0)) {
                reply.readException()
                userServiceCapMask = reply.readInt()
            }
        } catch (_: Throwable) {
            userServiceCapMask = 0
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    private fun ensureRootTouchDaemon(): Boolean {
        if (!isRootModeSelected() || !rootGrantedSession) return false
        if (rootDaemonReady && rootWriter != null) return true
        if (rootDaemonUnavailable || rootDaemonStarting || !checkRootBinary()) return false
        val ctx = cachedAppContext ?: return false

        synchronized(rootDaemonLock) {
            if (rootDaemonReady && rootWriter != null) return true
            if (rootDaemonUnavailable || rootDaemonStarting) return false
            rootDaemonStarting = true
            return try {
                val apkPath = ctx.packageCodePath
                val daemonClass = RootTouchDaemon::class.java.name
                val proc = ProcessBuilder(
                    "su",
                    "-c",
                    "CLASSPATH=$apkPath /system/bin/app_process / $daemonClass"
                ).start()
                val reader = BufferedReader(InputStreamReader(proc.inputStream))
                val writer = BufferedWriter(OutputStreamWriter(proc.outputStream))
                val firstLine = reader.readLine()?.trim().orEmpty()
                if (firstLine.startsWith("READY")) {
                    rootProcess = proc
                    rootWriter = writer
                    rootDaemonReady = true
                    Thread({
                        runCatching {
                            while (reader.readLine() != null) {
                                // consume stdout cleanly
                            }
                        }
                        rootDaemonReady = false
                    }, "xa-root-touch-drain").apply {
                        isDaemon = true
                        start()
                    }
                    refreshStatusInternal()
                    true
                } else {
                    rootDaemonUnavailable = true
                    runCatching { writer.close() }
                    runCatching { proc.destroyForcibly() }
                    false
                }
            } catch (_: Throwable) {
                rootDaemonUnavailable = true
                false
            } finally {
                rootDaemonStarting = false
            }
        }
    }

    private fun stopRootTouchDaemon() {
        synchronized(rootDaemonLock) {
            rootDaemonReady = false
            runCatching {
                rootWriter?.write("EXIT\n")
                rootWriter?.flush()
            }
            runCatching { rootWriter?.close() }
            runCatching { rootProcess?.destroyForcibly() }
            rootWriter = null
            rootProcess = null
        }
    }

    private fun sendRootDaemonCmd(cmd: String): Boolean {
        if (!rootDaemonReady) return false
        synchronized(rootDaemonLock) {
            val w = rootWriter ?: return false
            return try {
                w.write(cmd)
                w.write("\n")
                w.flush()
                lastInjectionAtMs = SystemClock.uptimeMillis()
                true
            } catch (_: Throwable) {
                rootDaemonReady = false
                runCatching { w.close() }
                runCatching { rootProcess?.destroyForcibly() }
                rootWriter = null
                rootProcess = null
                false
            }
        }
    }

    private fun clearDirectBinderProxy() {
        synchronized(directBinderLock) {
            directInputManager = null
            directInjectMethod = null
            preferredDirectProfiles.clear()
        }
    }

    private fun injectViaDirectBinderWrapper(
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        mode: MacroInjectionMode,
        slotOffset: Int
    ): Boolean {
        if (!isShizukuModeSelected()) return false
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (!running || !granted) return false

        synchronized(directBinderLock) {
            if (directInputManager == null || directInjectMethod == null) {
                runCatching {
                    val rawBinder = SystemServiceHelper.getSystemService("input") ?: return@runCatching
                    val wrapped = ShizukuBinderWrapper(rawBinder)
                    val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
                    val asInterface = stubClass.getMethod("asInterface", IBinder::class.java)
                    val im = asInterface.invoke(null, wrapped) ?: return@runCatching
                    val method = im.javaClass.getMethod(
                        "injectInputEvent",
                        InputEvent::class.java,
                        Int::class.javaPrimitiveType
                    )
                    directInputManager = im
                    directInjectMethod = method
                    if (directTouchDeviceId == 0) {
                        for (id in InputDevice.getDeviceIds()) {
                            val dev = InputDevice.getDevice(id) ?: continue
                            if ((dev.sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN &&
                                !dev.isVirtual
                            ) {
                                directTouchDeviceId = id
                                break
                            }
                        }
                    }
                }
            }
        }

        val target = directInputManager ?: return false
        val method = directInjectMethod ?: return false

        val isTouchDirect = mode == MacroInjectionMode.TOUCHSCREEN_DIRECT
        val (source, toolType) = when (mode) {
            MacroInjectionMode.SMART_POINTER -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.STYLUS_HYBRID -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> InputDevice.SOURCE_TOUCHSCREEN to MotionEvent.TOOL_TYPE_FINGER
        }
        val pointerId = when (mode) {
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> if (slotOffset == 0) 0 else 8
            else -> (9 - slotOffset.coerceIn(0, 3)).coerceIn(1, 9)
        }
        val injectMode = 0 // INJECT_MODE_ASYNC
        val slotKey = slotOffset.coerceIn(0, 3)

        fun sendProfile(profile: DirectStreamProfile): Boolean {
            val isUpOrCancel = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL
            val props = arrayOf(
                MotionEvent.PointerProperties().apply {
                    id = profile.pointerId
                    this.toolType = profile.toolType
                }
            )
            val coords = arrayOf(
                MotionEvent.PointerCoords().apply {
                    this.x = x
                    this.y = y
                    pressure = if (isUpOrCancel) 0f else 1f
                    size = if (isUpOrCancel) 0f else 0.1f
                    touchMajor = if (isUpOrCancel) 0f else 12f
                    touchMinor = if (isUpOrCancel) 0f else 12f
                }
            )
            val eventTime = SystemClock.uptimeMillis()
            val safeDown = if (downTime > 0L) downTime else eventTime
            val event = MotionEvent.obtain(
                safeDown,
                eventTime,
                action,
                1,
                props,
                coords,
                0,
                0,
                1f,
                1f,
                profile.deviceId,
                0,
                profile.source,
                0
            )
            return try {
                val res = method.invoke(target, event, injectMode)
                val ok = (res as? Boolean) ?: true
                if (ok) {
                    lastInjectionAtMs = SystemClock.uptimeMillis()
                    lastInjectionError = null
                    lastDirectBinderSecurityError = false
                }
                ok
            } catch (t: Throwable) {
                val msg = (t.cause?.message ?: t.message).orEmpty()
                if (msg.contains("SecurityException", ignoreCase = true) ||
                    msg.contains("INJECT_EVENTS", ignoreCase = true) ||
                    msg.contains("permission", ignoreCase = true)
                ) {
                    lastDirectBinderSecurityError = true
                    lastInjectionError = "Butuh 'Debugging USB (Setelan Keamanan)' di Opsi Developer."
                } else if (msg.isNotBlank()) {
                    lastInjectionError = "Binder touch gagal: ${msg.take(64)}"
                }
                clearDirectBinderProxy()
                false
            } finally {
                event.recycle()
            }
        }

        if (action != MotionEvent.ACTION_DOWN) {
            val active = activeDirectStreams[slotKey]
            if (active != null) {
                val ok = sendProfile(active)
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    activeDirectStreams.remove(slotKey)
                }
                if (ok) return true
            }
        }

        val prefKey = (mode.ordinal shl 4) or slotKey
        val cachedProfile = preferredDirectProfiles[prefKey]
        if (cachedProfile != null) {
            if (sendProfile(cachedProfile)) {
                if (action == MotionEvent.ACTION_DOWN) {
                    activeDirectStreams[slotKey] = cachedProfile
                }
                return true
            }
            preferredDirectProfiles.remove(prefKey)
        }

        val candidates = buildList {
            add(DirectStreamProfile(pointerId, toolType, source, 0))
            if (!isTouchDirect && pointerId != 8) {
                add(DirectStreamProfile(8, MotionEvent.TOOL_TYPE_STYLUS, InputDevice.SOURCE_STYLUS, 0))
            }
            if (isTouchDirect && directTouchDeviceId != 0) {
                add(DirectStreamProfile(pointerId, toolType, source, directTouchDeviceId))
            }
            if (source != InputDevice.SOURCE_TOUCHSCREEN) {
                add(DirectStreamProfile(pointerId, MotionEvent.TOOL_TYPE_FINGER, InputDevice.SOURCE_TOUCHSCREEN, 0))
            }
            if (isTouchDirect && pointerId != 0) {
                add(DirectStreamProfile(0, toolType, source, 0))
            }
        }

        for (candidate in candidates) {
            if (sendProfile(candidate)) {
                preferredDirectProfiles[prefKey] = candidate
                if (action == MotionEvent.ACTION_DOWN) {
                    activeDirectStreams[slotKey] = candidate
                }
                return true
            }
        }
        return false
    }

    suspend fun injectPulse(
        x: Float,
        y: Float,
        pressMs: Long,
        mode: MacroInjectionMode,
        screenW: Int = 1080,
        screenH: Int = 2400,
        rotation: Int = 0,
        slotOffset: Int = 0,
        physicalFingerHint: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val safePressMs = pressMs.coerceIn(4L, 1200L)
        val physBit = if (physicalFingerHint) 1 else 0

        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (!isRootModeSelected() || !rootGrantedSession) return@withContext false
                if (rootDaemonReady || ensureRootTouchDaemon()) {
                    val cmd = "PULSE ${slotOffset.coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)} " +
                        "$x $y $screenW $screenH $rotation $safePressMs $physBit"
                    if (sendRootDaemonCmd(cmd)) {
                        SystemClock.sleep(safePressMs)
                        return@withContext true
                    }
                }
                // Root shell fallback if /dev/input/eventX daemon unavailable
                val res = runViaSu("input touchscreen tap ${x.roundToInt()} ${y.roundToInt()}", timeoutSec = 3L)
                if (res.success) lastInjectionAtMs = SystemClock.uptimeMillis()
                return@withContext res.success
            }

            PrivilegeMode.SHIZUKU -> {
                if (!isShizukuModeSelected()) return@withContext false
                // 1. Shizuku UserService single-IPC TX_INJECT_PULSE (with Multi-Pointer Merge)
                val binder = inputServiceBinder?.takeIf { it.isBinderAlive }
                if (binder != null) {
                    val data = Parcel.obtain()
                    val reply = Parcel.obtain()
                    try {
                        data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
                        data.writeFloat(x)
                        data.writeFloat(y)
                        data.writeLong(safePressMs)
                        data.writeInt(mode.ordinal)
                        data.writeInt(screenW)
                        data.writeInt(screenH)
                        data.writeInt(rotation)
                        data.writeInt(slotOffset)
                        data.writeInt(physBit)
                        if (binder.transact(ShizukuInputUserService.TX_INJECT_PULSE, data, reply, 0)) {
                            reply.readException()
                            if (reply.readInt() == 1) {
                                lastInjectionAtMs = SystemClock.uptimeMillis()
                                return@withContext true
                            }
                        }
                    } catch (_: Throwable) {
                        inputServiceBinder = null
                        userServiceCapMask = 0
                        ensureInputServiceBound()
                    } finally {
                        data.recycle()
                        reply.recycle()
                    }
                } else {
                    ensureInputServiceBound()
                }

                // 2. Hot-standby direct ShizukuBinderWrapper -> IInputManager
                val downTime = SystemClock.uptimeMillis()
                if (injectViaDirectBinderWrapper(MotionEvent.ACTION_DOWN, x, y, downTime, mode, slotOffset)) {
                    SystemClock.sleep(safePressMs)
                    injectViaDirectBinderWrapper(MotionEvent.ACTION_UP, x, y, downTime, mode, slotOffset)
                    return@withContext true
                }
                return@withContext false
            }
        }
    }

    suspend fun injectMotion(
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        mode: MacroInjectionMode,
        screenW: Int = 1080,
        screenH: Int = 2400,
        rotation: Int = 0,
        slotOffset: Int = 0,
        physicalFingerHint: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val physBit = if (physicalFingerHint) 1 else 0

        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (!isRootModeSelected() || !rootGrantedSession) return@withContext false
                if (rootDaemonReady || ensureRootTouchDaemon()) {
                    val slot = slotOffset.coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
                    val cmd = when (action) {
                        MotionEvent.ACTION_DOWN -> "DOWN $slot $x $y $screenW $screenH $rotation $physBit"
                        MotionEvent.ACTION_MOVE -> "MOVE $slot $x $y $screenW $screenH $rotation"
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> "UP $slot $physBit"
                        else -> null
                    }
                    if (cmd != null && sendRootDaemonCmd(cmd)) {
                        return@withContext true
                    }
                }
                return@withContext false
            }

            PrivilegeMode.SHIZUKU -> {
                if (!isShizukuModeSelected()) return@withContext false
                val binder = inputServiceBinder?.takeIf { it.isBinderAlive }
                if (binder != null) {
                    val data = Parcel.obtain()
                    val reply = Parcel.obtain()
                    try {
                        data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
                        data.writeInt(action)
                        data.writeFloat(x)
                        data.writeFloat(y)
                        data.writeLong(downTime)
                        data.writeInt(mode.ordinal)
                        data.writeInt(screenW)
                        data.writeInt(screenH)
                        data.writeInt(rotation)
                        data.writeInt(slotOffset)
                        data.writeInt(physBit)
                        val transacted = binder.transact(ShizukuInputUserService.TX_INJECT_MOTION, data, reply, 0)
                        if (transacted) {
                            reply.readException()
                            if (reply.readInt() == 1) {
                                lastInjectionAtMs = SystemClock.uptimeMillis()
                                binderMotionBlocked = false
                                consecutiveBinderFailCount = 0
                                lastInjectionError = null
                                return@withContext true
                            }
                        }
                    } catch (_: Throwable) {
                        inputServiceBinder = null
                        userServiceCapMask = 0
                        ensureInputServiceBound()
                    } finally {
                        data.recycle()
                        reply.recycle()
                    }
                } else {
                    ensureInputServiceBound()
                }

                val ok = injectViaDirectBinderWrapper(action, x, y, downTime, mode, slotOffset)
                if (ok) {
                    binderMotionBlocked = false
                    binderBlockedUntilMs = 0L
                    consecutiveBinderFailCount = 0
                    lastDirectBinderSecurityError = false
                    lastInjectionError = null
                } else if (action == MotionEvent.ACTION_DOWN) {
                    val nowMs = SystemClock.uptimeMillis()
                    if (lastDirectBinderSecurityError) {
                        consecutiveBinderFailCount++
                        if (consecutiveBinderFailCount >= 3) {
                            binderMotionBlocked = true
                            binderBlockedUntilMs = nowMs + 5000L
                        }
                    } else if (binderMotionBlocked && nowMs >= binderBlockedUntilMs) {
                        binderMotionBlocked = false
                        consecutiveBinderFailCount = 0
                    }
                }
                return@withContext ok
            }
        }
    }

    suspend fun injectSwipe(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        mode: MacroInjectionMode,
        screenW: Int = 1080,
        screenH: Int = 2400,
        rotation: Int = 0,
        slotOffset: Int = 0
    ): Boolean = withContext(Dispatchers.IO) {
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val sx1 = x1.coerceIn(2f, (safeW - 2).toFloat())
        val sy1 = y1.coerceIn(2f, (safeH - 2).toFloat())
        val sx2 = x2.coerceIn(2f, (safeW - 2).toFloat())
        val sy2 = y2.coerceIn(2f, (safeH - 2).toFloat())
        val safeSlot = slotOffset.coerceIn(0, KernelTouchEngine.MAX_SLOT_OFFSET)
        val safeDurationMs = durationMs.coerceIn(24L, 1200L)
        val steps = (safeDurationMs / 8L).toInt().coerceIn(5, 24)
        val stepDelay = (safeDurationMs / steps).coerceAtLeast(4L)

        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (!isRootModeSelected() || !rootGrantedSession) return@withContext false
                if (rootDaemonReady || ensureRootTouchDaemon()) {
                    if (sendRootDaemonCmd("DOWN $safeSlot $sx1 $sy1 $safeW $safeH $rotation 0")) {
                        SystemClock.sleep(10L)
                        for (i in 1..steps) {
                            val t = i.toFloat() / steps.toFloat()
                            val eased = 1f - (1f - t) * (1f - t)
                            sendRootDaemonCmd(
                                "MOVE $safeSlot ${sx1 + (sx2 - sx1) * eased} ${sy1 + (sy2 - sy1) * eased} $safeW $safeH $rotation"
                            )
                            SystemClock.sleep(stepDelay)
                        }
                        if (sendRootDaemonCmd("UP $safeSlot 0")) return@withContext true
                    }
                }
            }

            PrivilegeMode.SHIZUKU -> {
                if (!isShizukuModeSelected()) return@withContext false
                if (!binderMotionBlocked) {
                    val binder = inputServiceBinder?.takeIf { it.isBinderAlive }
                    if (binder != null) {
                        if (safeSlot == 0) {
                            val data = Parcel.obtain()
                            val reply = Parcel.obtain()
                            try {
                                data.writeInterfaceToken(ShizukuInputUserService.DESCRIPTOR)
                                data.writeFloat(sx1)
                                data.writeFloat(sy1)
                                data.writeFloat(sx2)
                                data.writeFloat(sy2)
                                data.writeLong(safeDurationMs)
                                data.writeInt(mode.ordinal)
                                data.writeInt(safeW)
                                data.writeInt(safeH)
                                data.writeInt(rotation)
                                val transacted = binder.transact(ShizukuInputUserService.TX_INJECT_SWIPE, data, reply, 0)
                                if (transacted) {
                                    reply.readException()
                                    if (reply.readInt() == 1) {
                                        lastInjectionAtMs = SystemClock.uptimeMillis()
                                        return@withContext true
                                    }
                                }
                            } catch (_: Throwable) {
                                inputServiceBinder = null
                                userServiceCapMask = 0
                                ensureInputServiceBound()
                            } finally {
                                data.recycle()
                                reply.recycle()
                            }
                        } else {
                            val downTime = SystemClock.uptimeMillis()
                            if (injectMotion(MotionEvent.ACTION_DOWN, sx1, sy1, downTime, mode, safeW, safeH, rotation, safeSlot)) {
                                SystemClock.sleep(10L)
                                for (i in 1..steps) {
                                    val t = i.toFloat() / steps.toFloat()
                                    val eased = 1f - (1f - t) * (1f - t)
                                    injectMotion(
                                        MotionEvent.ACTION_MOVE,
                                        sx1 + (sx2 - sx1) * eased,
                                        sy1 + (sy2 - sy1) * eased,
                                        downTime,
                                        mode,
                                        safeW,
                                        safeH,
                                        rotation,
                                        safeSlot
                                    )
                                    SystemClock.sleep(stepDelay)
                                }
                                if (injectMotion(MotionEvent.ACTION_UP, sx2, sy2, downTime, mode, safeW, safeH, rotation, safeSlot)) {
                                    return@withContext true
                                }
                            }
                        }
                    } else {
                        ensureInputServiceBound()
                    }

                    val downTime = SystemClock.uptimeMillis()
                    if (injectViaDirectBinderWrapper(MotionEvent.ACTION_DOWN, sx1, sy1, downTime, mode, safeSlot)) {
                        SystemClock.sleep(10L)
                        for (i in 1..steps) {
                            val t = i.toFloat() / steps.toFloat()
                            val eased = 1f - (1f - t) * (1f - t)
                            injectViaDirectBinderWrapper(
                                MotionEvent.ACTION_MOVE,
                                sx1 + (sx2 - sx1) * eased,
                                sy1 + (sy2 - sy1) * eased,
                                downTime,
                                mode,
                                safeSlot
                            )
                            SystemClock.sleep(stepDelay)
                        }
                        if (injectViaDirectBinderWrapper(MotionEvent.ACTION_UP, sx2, sy2, downTime, mode, safeSlot)) {
                            return@withContext true
                        }
                    }
                }
            }
        }

        val now = SystemClock.uptimeMillis()
        if (now - lastShellSwipeAtMs < 260L) {
            return@withContext false
        }
        lastShellSwipeAtMs = now
        injectShellSwipe(sx1, sy1, sx2, sy2, safeDurationMs, safeW, safeH)
    }

    suspend fun injectShellSwipe(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        screenW: Int = 1080,
        screenH: Int = 2400
    ): Boolean = withContext(Dispatchers.IO) {
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val ix1 = x1.roundToInt().coerceIn(2, safeW - 2)
        val iy1 = y1.roundToInt().coerceIn(2, safeH - 2)
        val ix2 = x2.roundToInt().coerceIn(2, safeW - 2)
        val iy2 = y2.roundToInt().coerceIn(2, safeH - 2)
        val dur = durationMs.coerceIn(30L, 1200L)
        val res = execPrivileged("input touchscreen swipe $ix1 $iy1 $ix2 $iy2 $dur")
        if (res.success) {
            lastInjectionAtMs = SystemClock.uptimeMillis()
        }
        res.success
    }

    suspend fun injectTapFallback(x: Float, y: Float, holdMs: Long = 0L): Boolean = withContext(Dispatchers.IO) {
        val ix = x.roundToInt()
        val iy = y.roundToInt()
        val cmd = if (holdMs > 60L) {
            "input touchscreen swipe $ix $iy $ix $iy $holdMs"
        } else {
            "input touchscreen tap $ix $iy"
        }
        execPrivileged(cmd).success
    }

    suspend fun getForegroundPackageViaShizuku(): String? = withContext(Dispatchers.IO) {
        val current = refreshStatusInternal()
        val canPriv = currentPrefs()?.canUsePrivileged(current) ?: current.canRunPrivileged
        if (!canPriv) return@withContext null
        val res = execPrivileged(
            "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity' | head -n 3"
        )
        if (!res.success || res.output.isBlank()) return@withContext null
        val match = Regex("([a-zA-Z0-9_]+(?:\\.[a-zA-Z0-9_]+)+)/[a-zA-Z0-9_.$]+")
            .find(res.output)
        match?.groupValues?.getOrNull(1)
    }

    suspend fun captureScreenPngToFile(destFile: File): Boolean = withContext(Dispatchers.IO) {
        val current = refreshStatusInternal()
        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (!isRootModeSelected() || !current.isRootGranted) return@withContext false
                runCatching {
                    val proc = ProcessBuilder("su", "-c", "screencap -p").start()
                    try {
                        destFile.parentFile?.mkdirs()
                        destFile.outputStream().use { out -> proc.inputStream.copyTo(out) }
                        val finished = proc.waitFor(5, TimeUnit.SECONDS)
                        val code = if (finished) proc.exitValue() else -1
                        if (!finished) proc.destroyForcibly()
                        code == 0 && destFile.exists() && destFile.length() > 1024L
                    } finally {
                        runCatching { proc.destroyForcibly() }
                    }
                }.getOrDefault(false)
            }
            PrivilegeMode.SHIZUKU -> {
                if (!isShizukuModeSelected() || !current.canRunShizuku) return@withContext false
                runCatching {
                    val shizukuClass = Class.forName("rikka.shizuku.Shizuku")
                    val method = shizukuClass.getDeclaredMethod(
                        "newProcess",
                        Array<String>::class.java,
                        Array<String>::class.java,
                        String::class.java
                    )
                    method.isAccessible = true
                    val process = method.invoke(null, arrayOf("screencap", "-p"), null, null) ?: return@runCatching false
                    try {
                        val inStream = process.javaClass.getMethod("getInputStream").invoke(process) as InputStream
                        destFile.parentFile?.mkdirs()
                        destFile.outputStream().use { out -> inStream.copyTo(out) }
                        val exitCode = (process.javaClass.getMethod("waitFor").invoke(process) as? Int) ?: -1
                        exitCode == 0 && destFile.exists() && destFile.length() > 1024L
                    } finally {
                        runCatching { process.javaClass.getMethod("destroy").invoke(process) }
                    }
                }.getOrDefault(false)
            }
        }
    }

    private fun checkRootBinary(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/su/bin/su",
            "/data/adb/magisk/su",
            "/data/adb/ksu/bin/su",
            "/data/adb/ap/bin/su"
        )
        return paths.any { runCatching { File(it).exists() }.getOrDefault(false) }
    }

    /**
     * Strictly honors the user's selected PrivilegeMode:
     * - Opsi 1 (ROOT): executes via `su` ONLY, never requires Shizuku.
     * - Opsi 2 (SHIZUKU): executes via Shizuku ONLY, never invokes `su`.
     */
    suspend fun execPrivileged(command: String): ShellResult = withContext(Dispatchers.IO) {
        val current = refreshStatusInternal()
        when (activePrivilegeMode()) {
            PrivilegeMode.ROOT -> {
                if (isRootModeSelected() && current.isRootGranted) {
                    return@withContext runViaSu(command)
                }
                ShellResult(
                    success = false,
                    output = "",
                    error = if (!current.isRootAvailable) {
                        "Mode Root aktif, tetapi binary 'su' tidak ditemukan. Beralihlah ke Opsi 2 (Shizuku)."
                    } else {
                        "Mode Root aktif — tekan 'Minta Root' terlebih dahulu (Shizuku tidak diperlukan)."
                    }
                )
            }
            PrivilegeMode.SHIZUKU -> {
                if (isShizukuModeSelected() && current.canRunShizuku) {
                    return@withContext runViaShizukuReflection(command)
                }
                ShellResult(
                    success = false,
                    output = "",
                    error = if (!current.isInstalled) {
                        "Mode Shizuku (Non-Root) aktif — pasang Shizuku atau pilih Opsi 1 (Root)."
                    } else if (!current.isRunning) {
                        "Layanan Shizuku belum berjalan. Jalankan via Wireless Debugging atau ADB."
                    } else {
                        "Izin Shizuku belum diberikan."
                    }
                )
            }
        }
    }

    private fun runViaShizukuReflection(command: String): ShellResult {
        return runCatching {
            val shizukuClass = Class.forName("rikka.shizuku.Shizuku")
            val method = shizukuClass.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null)
                ?: return ShellResult(false, "", "Gagal membuat proses Shizuku")

            val inStream = process.javaClass.getMethod("getInputStream").invoke(process) as InputStream
            val errStream = process.javaClass.getMethod("getErrorStream").invoke(process) as InputStream
            val out = inStream.bufferedReader().use { it.readText().trim() }
            val err = errStream.bufferedReader().use { it.readText().trim() }
            val exitCode = (process.javaClass.getMethod("waitFor").invoke(process) as? Int) ?: -1
            runCatching { process.javaClass.getMethod("destroy").invoke(process) }

            ShellResult(
                success = exitCode == 0,
                output = out,
                error = err,
                usedShizuku = true
            )
        }.getOrElse { e ->
            ShellResult(false, "", e.message ?: "Error eksekusi Shizuku", usedShizuku = true)
        }
    }

    private fun runViaSu(command: String, timeoutSec: Long = 8L): ShellResult {
        return runCatching {
            val proc = ProcessBuilder("su", "-c", command).start()
            val finished = proc.waitFor(timeoutSec, TimeUnit.SECONDS)
            val out = proc.inputStream.bufferedReader().use { it.readText().trim() }
            val err = proc.errorStream.bufferedReader().use { it.readText().trim() }
            val code = if (finished) proc.exitValue() else -1
            if (!finished) proc.destroyForcibly()
            ShellResult(success = code == 0, output = out, error = err, usedRoot = true)
        }.getOrElse { e ->
            ShellResult(false, "", e.message ?: "Root tidak tersedia")
        }
    }
}
