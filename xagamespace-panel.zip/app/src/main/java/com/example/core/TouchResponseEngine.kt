package com.example.core

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import com.example.data.BoosterPreferences
import com.example.model.TouchConfig
import com.example.model.TouchDriverStatus
import com.example.model.TouchPollingPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

data class TouchTuningParams(
    val pointerSpeed: Int,
    val longPressMs: Int,
    val multiPressMs: Int,
    val touchSlopPx: Int,
    val xiaomiAimSens: Int,
    val xiaomiTapSens: Int,
    val xiaomiTolerance: Int,
    val oplusSensitive: Int,
    val oplusSmooth: Int,
    val pollingFlag: Int
)

/**
 * ZKMNEXT-inspired Touch Response & Polling Engine.
 * Works DIRECTLY on the Android touchscreen pipeline & OEM kernel touch drivers
 * WITHOUT modifying screen DPI (wm density) and WITHOUT adding blocking floating pads.
 */
object TouchResponseEngine {

    private val oemTouchDriverNodes = listOf(
        "/sys/class/touch/touch_dev/bump_sample_rate" to "Xiaomi SampleRate",
        "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" to "Xiaomi Virtual SampleRate",
        "/sys/class/touch/tp_dev/bump_sample_rate" to "Xiaomi TP SampleRate",
        "/sys/class/touch/touch_dev/touch_aim_sensitivity" to "Xiaomi AimSens",
        "/sys/class/touch/touch_dev/touch_tap_sensitivity" to "Xiaomi TapSens",
        "/sys/class/touch/touch_dev/touch_tolerance" to "Xiaomi Tolerance",
        "/proc/touchpanel/game_switch_enable" to "OPLUS GameSwitch",
        "/proc/touchpanel/tp_report_rate" to "OPLUS ReportRate",
        "/proc/touchpanel/sensitive_level" to "OPLUS Sensitive",
        "/proc/touchpanel/smooth_level" to "OPLUS Smooth",
        "/proc/nvt_game_mode" to "Novatek GameMode",
        "/sys/devices/platform/goodix_ts.0/game_mode" to "Goodix GameMode",
        "/proc/focaltech/game_mode" to "FocalTech GameMode",
        "/proc/ilitek/game_mode" to "Ilitek GameMode",
        "/sys/class/sec/tsp/cmd" to "Samsung TSP",
        "/sys/module/cpu_boost/parameters/input_boost_enabled" to "CPU InputBoost",
        "/sys/devices/system/cpu/cpu_boost/input_boost_enabled" to "SoC InputBoost",
        "/sys/kernel/msm_performance/parameters/touchboost" to "MSM TouchBoost"
    )

    fun queryDisplayGeometry(context: Context): Triple<Int, Int, Int> {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        val rotation = runCatching { display?.rotation ?: Surface.ROTATION_0 }.getOrDefault(Surface.ROTATION_0)
        if (display != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            val ok = runCatching { display.getRealMetrics(metrics); metrics.widthPixels > 0 && metrics.heightPixels > 0 }.getOrDefault(false)
            if (ok) {
                return Triple(metrics.widthPixels, metrics.heightPixels, rotation)
            }
        }
        val (w, h, _) = AiTriggerCaptureManager.queryDisplayMetrics(context)
        return Triple(w, h, rotation)
    }

    fun buildAmplifierConfig(
        context: Context,
        config: TouchConfig,
        overrideW: Int? = null,
        overrideH: Int? = null,
        overrideRotation: Int? = null
    ): TouchAmplifierConfig {
        val (geoW, geoH, geoRot) = queryDisplayGeometry(context)
        return TouchAmplifierConfig(
            enabled = config.enabled,
            gainX = config.gainX(),
            gainY = config.gainY(),
            responseBoost = config.responseBoost,
            touchSlopReduction = config.touchSlopReduction,
            smoothing = config.smoothing,
            deadzone = config.deadzone,
            areaCode = TouchAmplifierMath.areaCodeOf(config.area),
            screenW = (overrideW ?: geoW).coerceAtLeast(100),
            screenH = (overrideH ?: geoH).coerceAtLeast(100),
            rotation = (overrideRotation ?: geoRot).coerceIn(0, 3)
        )
    }

    /**
     * Lightweight real-time orientation & parameter resync (no shell spawn) used when
     * switching between Portrait and Landscape games so X and Y axes stay 100% aligned.
     */
    fun syncLiveOrientation(
        context: Context,
        config: TouchConfig,
        screenW: Int? = null,
        screenH: Int? = null,
        rotation: Int? = null
    ): String {
        val ampCfg = buildAmplifierConfig(
            context = context.applicationContext,
            config = config,
            overrideW = screenW,
            overrideH = screenH,
            overrideRotation = rotation
        )
        return ShizukuBridge.syncTouchAmplifierConfig(ampCfg)
    }

    fun computeScrollFriction(config: TouchConfig): String {
        // Lower scroll friction (down to 0.003) makes list flings and swipe glides noticeably slicker
        val intensity = ((config.speedX.coerceAtLeast(0) + config.speedY.coerceAtLeast(0)) / 400f * 0.65f +
            (config.responseBoost / 100f) * 0.35f).coerceIn(0f, 1f)
        val friction = (0.015f - intensity * 0.012f).coerceIn(0.003f, 0.015f)
        return String.format(Locale.US, "%.4f", friction)
    }

    fun computeTouchTuningParams(config: TouchConfig): TouchTuningParams {
        val weighted = config.speedX * 0.45f + config.speedY * 0.55f + config.responseBoost * 0.50f
        val pointerSpeed = when {
            weighted > 0f -> (2f + (weighted / 195f) * 5f).roundToInt().coerceIn(2, 7)
            weighted < 0f -> ((weighted / 50f) * 7f).roundToInt().coerceIn(-7, -1)
            else -> 2
        }
        val smoothOffset = (config.smoothing * 0.22f).toInt()
        val pollBoostMs = config.pollingPreset.level * 12
        val longPressMs = (300f - config.responseBoost * 1.85f - (config.speedX + config.speedY) * 0.14f - pollBoostMs + config.deadzone * 1.2f + smoothOffset)
            .toInt()
            .coerceIn(90, 420)
        val multiPressMs = (230f - config.responseBoost * 1.35f - pollBoostMs * 0.6f + config.deadzone * 0.7f)
            .toInt()
            .coerceIn(80, 300)

        // Lower touch slop = instant swipe pickup with zero drag lag (2..16 px)
        val slopReduction = config.touchSlopReduction.coerceIn(0, 100)
        val touchSlopPx = (16f - (slopReduction / 100f) * 14f).roundToInt().coerceIn(2, 16)

        // OEM touchpanel calibration values (0..4 scale used by Xiaomi TouchFeature & OPLUS TouchPanel)
        val normSpeed = ((config.speedX + config.speedY) / 2f + 50f).coerceIn(0f, 250f) / 250f
        val xiaomiAimSens = (normSpeed * 4f).roundToInt().coerceIn(0, 4)
        val xiaomiTapSens = ((config.responseBoost / 100f) * 4f).roundToInt().coerceIn(0, 4)
        val xiaomiTolerance = ((1f - (config.deadzone / 50f)) * 4f).roundToInt().coerceIn(0, 4)
        val oplusSensitive = ((config.responseBoost * 0.5f + normSpeed * 50f) / 25f).roundToInt().coerceIn(1, 4)
        val oplusSmooth = ((config.smoothing / 100f) * 4f).roundToInt().coerceIn(0, 4)
        val pollingFlag = if (config.pollingPreset == TouchPollingPreset.DEFAULT) 0 else 1

        return TouchTuningParams(
            pointerSpeed = pointerSpeed,
            longPressMs = longPressMs,
            multiPressMs = multiPressMs,
            touchSlopPx = touchSlopPx,
            xiaomiAimSens = xiaomiAimSens,
            xiaomiTapSens = xiaomiTapSens,
            xiaomiTolerance = xiaomiTolerance,
            oplusSensitive = oplusSensitive,
            oplusSmooth = oplusSmooth,
            pollingFlag = pollingFlag
        )
    }

    suspend fun probeTouchDriverNodes(
        context: Context,
        prefs: BoosterPreferences
    ): TouchDriverStatus = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(context.applicationContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext TouchDriverStatus(
                detectedNodes = emptyList(),
                activeSummary = "Android Input Framework (hubungkan Root / Shizuku untuk pindai driver touchpanel OEM)"
            )
        }
        val cmd = oemTouchDriverNodes.joinToString(" ; ") { (path, label) ->
            "if [ -w '$path' ]; then echo TNODE=$label; fi"
        }
        val res = ShizukuBridge.execPrivileged(cmd)
        val found = Regex("TNODE=([^\\n]+)").findAll(res.output)
            .map { it.groupValues[1].trim() }
            .distinct()
            .toList()
        val engineLabel = when {
            res.usedRoot || status.isRootGranted -> "Root UID 0"
            status.canRunShizuku -> "Shizuku"
            else -> "Root"
        }
        val liveEngine = ShizukuBridge.touchAmplifierEngine.value
        val summary = if (found.isNotEmpty()) {
            "$liveEngine • Driver ($engineLabel): ${found.take(3).joinToString(", ")}"
        } else {
            "$liveEngine ($engineLabel) • Polling & X/Y Boost siap"
        }
        TouchDriverStatus(detectedNodes = found, activeSummary = summary)
    }

    suspend fun applyTouchResponse(
        context: Context,
        prefs: BoosterPreferences,
        config: TouchConfig,
        activeGamePkg: String?
    ): ActionFeedback = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!config.enabled) {
            return@withContext resetTouchResponse(appContext, canPriv)
        }

        val gainX = config.gainX()
        val gainY = config.gainY()
        val params = computeTouchTuningParams(config)
        val scrollFriction = computeScrollFriction(config)

        // Layer 1 (Real-Time Live X/Y Companion Touch Amplifier — Root Evdev Slot-6 / Shizuku Input Boost)
        val liveAmpCfg = buildAmplifierConfig(appContext, config)
        val liveEngineLabel = if (canPriv) {
            ShizukuBridge.syncTouchAmplifierConfig(liveAmpCfg)
        } else {
            ShizukuBridge.syncTouchAmplifierConfig(liveAmpCfg.copy(enabled = false))
            "Perlu Root / Shizuku"
        }

        var wroteDirectSettings = false
        if (Settings.System.canWrite(appContext)) {
            wroteDirectSettings = runCatching {
                Settings.System.putInt(appContext.contentResolver, "pointer_speed", params.pointerSpeed)
                Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 1)
                Settings.System.putInt(appContext.contentResolver, "high_touch_sensitivity_enabled", 1)
                true
            }.getOrDefault(false)
        }

        if (canPriv) {
            val pollVal = params.pollingFlag
            val oplusRateVal = when (config.pollingPreset) {
                TouchPollingPreset.DEFAULT -> 0
                TouchPollingPreset.HIGH_240 -> 1
                TouchPollingPreset.ULTRA_480 -> 2
                TouchPollingPreset.MAX_HARDWARE -> 2
            }
            val oemSensLevel = ((params.xiaomiAimSens + params.xiaomiTapSens) / 2).coerceIn(1, 4)
            val inputBoostMs = (60 + config.responseBoost).coerceIn(60, 160)

            val cmds = mutableListOf(
                // Layer 2: Core Android + Multi-OEM touch responsiveness settings (ZERO wm density change!)
                "settings put system pointer_speed ${params.pointerSpeed}",
                "settings put system touch_sensitivity 1",
                "settings put system high_touch_sensitivity_enabled 1",
                "settings put system auto_adjust_touch 1",
                "settings put system increase_touch_sensitivity 1",
                "settings put system touch_response_level ${params.xiaomiTapSens}",
                "settings put system touch_sensitivity_level $oemSensLevel",
                "settings put system touch_response_rate $oplusRateVal",
                "settings put system game_touch_sensitivity ${params.oplusSensitive}",
                "settings put system vivo_touch_sensitivity 1",
                "settings put system touch_boost_enable 1",
                "settings put system game_touch_boost 1",
                "settings put secure touch_sensitivity 1",
                "settings put secure gb_boosting 1",
                "settings put secure long_press_timeout ${params.longPressMs}",
                "settings put secure multi_press_timeout ${params.multiPressMs}",
                "settings put secure tap_duration_threshold 0.0",
                "settings put secure touch_blocking_period 0.0",
                "settings put secure accessibility_interactive_ui_timeout_ms 0",
                "settings put global block_untrusted_touches_mode 0",
                // Low-latency input resampling, zero backpressure & low scroll friction (safe no-op if read-only)
                "setprop touch.pressure.scale 0.001 2>/dev/null; " +
                    "setprop debug.input.vsync_resample 0 2>/dev/null; " +
                    "setprop debug.sf.latch_unsignaled 1 2>/dev/null; " +
                    "setprop debug.sf.disable_backpressure 1 2>/dev/null; " +
                    "setprop view.scroll_friction $scrollFriction 2>/dev/null; " +
                    "setprop persist.sys.touch.sensitivity ${oemSensLevel + 1} 2>/dev/null; true"
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !activeGamePkg.isNullOrBlank()) {
                cmds.add("cmd game mode performance $activeGamePkg 2>/dev/null ; true")
            }

            // Layer 3: Multi-OEM Hardware Touch Polling & CPU Input Boost Kernel Drivers
            cmds.add(
                "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                    "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                    "/sys/class/touch/tp_dev/bump_sample_rate " +
                    "/proc/touchpanel/game_switch_enable " +
                    "/proc/nvt_game_mode " +
                    "/proc/nvt_sensitivity_switch " +
                    "/proc/focaltech/game_mode " +
                    "/proc/ilitek/game_mode " +
                    "/sys/devices/platform/goodix_ts.0/game_mode " +
                    "/sys/class/touch/touch_dev/touch_active_status " +
                    "/sys/class/touch/touch_dev/touch_sensitivity; do " +
                    "[ -w \"\$p\" ] && echo $pollVal > \"\$p\" 2>/dev/null; done; true"
            )
            cmds.add(
                "[ -w /sys/class/touch/touch_dev/touch_aim_sensitivity ] && echo ${params.xiaomiAimSens} > /sys/class/touch/touch_dev/touch_aim_sensitivity 2>/dev/null; " +
                    "[ -w /sys/class/touch/touch_dev/touch_tap_sensitivity ] && echo ${params.xiaomiTapSens} > /sys/class/touch/touch_dev/touch_tap_sensitivity 2>/dev/null; " +
                    "[ -w /sys/class/touch/touch_dev/touch_tolerance ] && echo ${params.xiaomiTolerance} > /sys/class/touch/touch_dev/touch_tolerance 2>/dev/null; " +
                    "[ -w /proc/touchpanel/tp_report_rate ] && echo $oplusRateVal > /proc/touchpanel/tp_report_rate 2>/dev/null; " +
                    "[ -w /proc/touchpanel/sensitive_level ] && echo ${params.oplusSensitive} > /proc/touchpanel/sensitive_level 2>/dev/null; " +
                    "[ -w /proc/touchpanel/smooth_level ] && echo ${params.oplusSmooth} > /proc/touchpanel/smooth_level 2>/dev/null; " +
                    "[ -w /sys/module/tpd_setting/parameters/tpd_em_sample_cnt ] && echo 1 > /sys/module/tpd_setting/parameters/tpd_em_sample_cnt 2>/dev/null; " +
                    "if [ -w /sys/class/sec/tsp/cmd ]; then " +
                    "echo 'set_game_mode,$pollVal' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'glove_mode,1' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'set_scan_rate,1' > /sys/class/sec/tsp/cmd 2>/dev/null; fi; true"
            )
            cmds.add(
                // CPU Touch Input Boost so frame pacing never hitches mid-swipe
                "for p in /sys/module/cpu_boost/parameters/input_boost_enabled " +
                    "/sys/devices/system/cpu/cpu_boost/input_boost_enabled " +
                    "/sys/kernel/msm_performance/parameters/touchboost " +
                    "/sys/module/msm_performance/parameters/touchboost; do " +
                    "[ -w \"\$p\" ] && echo 1 > \"\$p\" 2>/dev/null; done; " +
                    "for ms in /sys/module/cpu_boost/parameters/input_boost_ms " +
                    "/sys/devices/system/cpu/cpu_boost/input_boost_ms; do " +
                    "[ -w \"\$ms\" ] && echo $inputBoostMs > \"\$ms\" 2>/dev/null; done; true"
            )
            if (config.edgeRejectionOff) {
                cmds.add(
                    "for p in /proc/touchpanel/oplus_tp_limit_enable " +
                        "/sys/class/touch/touch_dev/touch_edge_filter " +
                        "/sys/class/touch/touch_dev/edge_filter " +
                        "/sys/class/touch/touch_dev/grip_zone; do " +
                        "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; true"
                )
            }

            val sysRes = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
            if (sysRes.success || sysRes.usedShizuku || sysRes.usedRoot) {
                val boostTag = if (liveAmpCfg.hasEffectiveBoost()) {
                    "X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} • $liveEngineLabel"
                } else {
                    "${config.pollingPreset.shortLabel} • Slop ${params.touchSlopPx}px"
                }
                return@withContext ActionFeedback(
                    true,
                    "Touch Licin aktif ($boostTag • ${params.longPressMs}ms) tanpa ubah DPI."
                )
            }
        }

        if (wroteDirectSettings) {
            return@withContext ActionFeedback(
                true,
                "Touch X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} aktif terbatas (hubungkan Root / Shizuku agar X/Y Live Amplifier jalan penuh)."
            )
        }

        ActionFeedback(
            true,
            "Profil Touch X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} tersimpan. Hubungkan Root / Shizuku agar layar benar-benar super licin."
        )
    }

    private suspend fun resetTouchResponse(appContext: Context, canPriv: Boolean): ActionFeedback {
        ShizukuBridge.syncTouchAmplifierConfig(TouchAmplifierConfig(enabled = false))
        if (canPriv) {
            val cmds = listOf(
                "settings put system pointer_speed 0",
                "settings put system touch_sensitivity 0",
                "settings put system high_touch_sensitivity_enabled 0",
                "settings put system auto_adjust_touch 0",
                "settings put system increase_touch_sensitivity 0",
                "settings put system touch_response_level 0",
                "settings put system touch_sensitivity_level 0",
                "settings put system touch_response_rate 0",
                "settings put system game_touch_sensitivity 0",
                "settings put system vivo_touch_sensitivity 0",
                "settings put system touch_boost_enable 0",
                "settings put system game_touch_boost 0",
                "settings put secure touch_sensitivity 0",
                "settings put secure gb_boosting 0",
                "settings put secure long_press_timeout 400",
                "settings put secure multi_press_timeout 300",
                "settings delete secure tap_duration_threshold",
                "settings delete secure touch_blocking_period",
                "settings delete secure accessibility_interactive_ui_timeout_ms",
                "settings delete global block_untrusted_touches_mode",
                "setprop debug.input.vsync_resample 1 2>/dev/null; " +
                    "setprop view.scroll_friction 0.015 2>/dev/null; true",
                "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                    "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                    "/sys/class/touch/tp_dev/bump_sample_rate " +
                    "/proc/touchpanel/game_switch_enable " +
                    "/proc/touchpanel/tp_report_rate " +
                    "/proc/nvt_game_mode " +
                    "/proc/nvt_sensitivity_switch " +
                    "/proc/focaltech/game_mode " +
                    "/proc/ilitek/game_mode " +
                    "/sys/devices/platform/goodix_ts.0/game_mode; do " +
                    "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; " +
                    "if [ -w /sys/class/sec/tsp/cmd ]; then " +
                    "echo 'set_game_mode,0' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'glove_mode,0' > /sys/class/sec/tsp/cmd 2>/dev/null; fi; true"
            )
            ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        } else if (Settings.System.canWrite(appContext)) {
            runCatching {
                Settings.System.putInt(appContext.contentResolver, "pointer_speed", 0)
                Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 0)
                Settings.System.putInt(appContext.contentResolver, "high_touch_sensitivity_enabled", 0)
            }
        }
        return ActionFeedback(true, "Touch response & X/Y Amplifier dimatikan (DPI tetap standar).")
    }
}
