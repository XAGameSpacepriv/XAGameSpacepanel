package com.example.core

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import com.example.data.BoosterPreferences
import com.example.model.FpsLockTarget
import com.example.model.MaxScreenResponseConfig
import com.example.model.ScreenResponseLevel
import com.example.model.ScreenResponseStatus
import com.example.model.TouchConfig
import com.example.model.TouchDriverStatus
import com.example.model.TouchPollingPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

data class TouchTuningParams(
    val pointerSpeed: Int,
    val longPressMs: Int,
    val multiPressMs: Int,
    val touchSlopPx: Int,
    val xiaomiAimSens: Int,
    val xiaomiTapSens: Int,
    val xiaomiTolerance: Int,
    val oplusSensitive: Int,
    val oplusSmooth: Int,
    val pollingFlag: Int
)

/**
 * Touch Response, Polling & "Responsif Layar Max" Hardware Pipeline Engine.
 * Works DIRECTLY on the Android display refresh pipeline, input framework, SurfaceFlinger
 * low-latency phase props, and OEM kernel touchpanel/CPU input-boost drivers
 * WITHOUT modifying screen DPI (wm density) and WITHOUT adding blocking floating pads.
 */
object TouchResponseEngine {

    private val oemTouchDriverNodes = listOf(
        "/sys/class/touch/touch_dev/bump_sample_rate" to "Xiaomi SampleRate",
        "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" to "Xiaomi Virtual SampleRate",
        "/sys/class/touch/tp_dev/bump_sample_rate" to "Xiaomi TP SampleRate",
        "/sys/class/touch/touch_dev/touch_aim_sensitivity" to "Xiaomi AimSens",
        "/sys/class/touch/touch_dev/touch_tap_sensitivity" to "Xiaomi TapSens",
        "/sys/class/touch/touch_dev/touch_tolerance" to "Xiaomi Tolerance",
        "/proc/touchpanel/game_switch_enable" to "OPLUS GameSwitch",
        "/proc/touchpanel/tp_report_rate" to "OPLUS ReportRate",
        "/proc/touchpanel/sensitive_level" to "OPLUS Sensitive",
        "/proc/touchpanel/smooth_level" to "OPLUS Smooth",
        "/proc/nvt_game_mode" to "Novatek GameMode",
        "/sys/devices/platform/goodix_ts.0/game_mode" to "Goodix GameMode",
        "/proc/focaltech/game_mode" to "FocalTech GameMode",
        "/proc/ilitek/game_mode" to "Ilitek GameMode",
        "/sys/class/sec/tsp/cmd" to "Samsung TSP",
        "/sys/devices/platform/nubia_goodix_tp/gamemode" to "Nubia Goodix",
        "/sys/devices/platform/nubia_synaptics_tp/gamemode" to "Nubia Synaptics",
        "/sys/module/cpu_boost/parameters/input_boost_enabled" to "CPU InputBoost",
        "/sys/devices/system/cpu/cpu_boost/input_boost_enabled" to "SoC InputBoost",
        "/sys/kernel/msm_performance/parameters/touchboost" to "MSM TouchBoost"
    )

    fun queryDisplayGeometry(context: Context): Triple<Int, Int, Int> {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        val rotation = runCatching { display?.rotation ?: Surface.ROTATION_0 }.getOrDefault(Surface.ROTATION_0)
        if (display != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            val ok = runCatching {
                display.getRealMetrics(metrics)
                metrics.widthPixels > 0 && metrics.heightPixels > 0
            }.getOrDefault(false)
            if (ok) {
                return Triple(metrics.widthPixels, metrics.heightPixels, rotation)
            }
        }
        val (w, h, _) = AiTriggerCaptureManager.queryDisplayMetrics(context)
        return Triple(w, h, rotation)
    }

    /**
     * Queries the real physical display's highest supported refresh rate (e.g., 60 / 90 / 120 / 144 / 165 Hz).
     */
    fun detectMaxHardwareRefreshRateHz(context: Context): Int {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY) ?: return 60
        val modesMax = runCatching {
            display.supportedModes.maxOfOrNull { it.refreshRate.roundToInt() } ?: 60
        }.getOrDefault(60)
        val current = runCatching { display.refreshRate.roundToInt() }.getOrDefault(60)
        return maxOf(modesMax, current).coerceIn(60, 240)
    }

    fun computeMaxResponseScrollFriction(level: ScreenResponseLevel): String =
        String.format(Locale.US, "%.4f", level.scrollFriction)

    fun buildAmplifierConfig(
        context: Context,
        config: TouchConfig,
        overrideW: Int? = null,
        overrideH: Int? = null,
        overrideRotation: Int? = null
    ): TouchAmplifierConfig {
        val (geoW, geoH, geoRot) = queryDisplayGeometry(context)
        return TouchAmplifierConfig(
            enabled = config.enabled,
            gainX = config.gainX(),
            gainY = config.gainY(),
            responseBoost = config.responseBoost,
            touchSlopReduction = config.touchSlopReduction,
            smoothing = config.smoothing,
            deadzone = config.deadzone,
            areaCode = TouchAmplifierMath.areaCodeOf(config.area),
            screenW = (overrideW ?: geoW).coerceAtLeast(100),
            screenH = (overrideH ?: geoH).coerceAtLeast(100),
            rotation = (overrideRotation ?: geoRot).coerceIn(0, 3)
        )
    }

    /**
     * Lightweight real-time orientation & parameter resync (no shell spawn) used when
     * switching between Portrait and Landscape games so X and Y axes stay 100% aligned.
     */
    fun syncLiveOrientation(
        context: Context,
        config: TouchConfig,
        screenW: Int? = null,
        screenH: Int? = null,
        rotation: Int? = null
    ): String {
        val ampCfg = buildAmplifierConfig(
            context = context.applicationContext,
            config = config,
            overrideW = screenW,
            overrideH = screenH,
            overrideRotation = rotation
        )
        return ShizukuBridge.syncTouchAmplifierConfig(ampCfg)
    }

    fun computeScrollFriction(config: TouchConfig): String {
        val intensity = ((config.speedX.coerceAtLeast(0) + config.speedY.coerceAtLeast(0)) / 400f * 0.65f +
            (config.responseBoost / 100f) * 0.35f).coerceIn(0f, 1f)
        val friction = (0.015f - intensity * 0.012f).coerceIn(0.003f, 0.015f)
        return String.format(Locale.US, "%.4f", friction)
    }

    fun computeTouchTuningParams(config: TouchConfig): TouchTuningParams {
        val weighted = config.speedX * 0.45f + config.speedY * 0.55f + config.responseBoost * 0.50f
        val pointerSpeed = when {
            weighted > 0f -> (2f + (weighted / 195f) * 5f).roundToInt().coerceIn(2, 7)
            weighted < 0f -> ((weighted / 50f) * 7f).roundToInt().coerceIn(-7, -1)
            else -> 2
        }
        val smoothOffset = (config.smoothing * 0.22f).toInt()
        val pollBoostMs = config.pollingPreset.level * 12
        val longPressMs = (300f - config.responseBoost * 1.85f - (config.speedX + config.speedY) * 0.14f - pollBoostMs + config.deadzone * 1.2f + smoothOffset)
            .toInt()
            .coerceIn(90, 420)
        val multiPressMs = (230f - config.responseBoost * 1.35f - pollBoostMs * 0.6f + config.deadzone * 0.7f)
            .toInt()
            .coerceIn(80, 300)

        val slopReduction = config.touchSlopReduction.coerceIn(0, 100)
        val touchSlopPx = (16f - (slopReduction / 100f) * 14f).roundToInt().coerceIn(2, 16)

        val normSpeed = ((config.speedX + config.speedY) / 2f + 50f).coerceIn(0f, 250f) / 250f
        val xiaomiAimSens = (normSpeed * 4f).roundToInt().coerceIn(0, 4)
        val xiaomiTapSens = ((config.responseBoost / 100f) * 4f).roundToInt().coerceIn(0, 4)
        val xiaomiTolerance = ((1f - (config.deadzone / 50f)) * 4f).roundToInt().coerceIn(0, 4)
        val oplusSensitive = ((config.responseBoost * 0.5f + normSpeed * 50f) / 25f).roundToInt().coerceIn(1, 4)
        val oplusSmooth = ((config.smoothing / 100f) * 4f).roundToInt().coerceIn(0, 4)
        val pollingFlag = if (config.pollingPreset == TouchPollingPreset.DEFAULT) 0 else 1

        return TouchTuningParams(
            pointerSpeed = pointerSpeed,
            longPressMs = longPressMs,
            multiPressMs = multiPressMs,
            touchSlopPx = touchSlopPx,
            xiaomiAimSens = xiaomiAimSens,
            xiaomiTapSens = xiaomiTapSens,
            xiaomiTolerance = xiaomiTolerance,
            oplusSensitive = oplusSensitive,
            oplusSmooth = oplusSmooth,
            pollingFlag = pollingFlag
        )
    }

    suspend fun probeTouchDriverNodes(
        context: Context,
        prefs: BoosterPreferences
    ): TouchDriverStatus = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(context.applicationContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext TouchDriverStatus(
                detectedNodes = emptyList(),
                activeSummary = "Android Input Framework (hubungkan Root / Shizuku untuk pindai driver touchpanel OEM)"
            )
        }
        val cmd = oemTouchDriverNodes.joinToString(" ; ") { (path, label) ->
            "if [ -w '$path' ]; then echo TNODE=$label; fi"
        }
        val res = ShizukuBridge.execPrivileged(cmd)
        val found = Regex("TNODE=([^\\n]+)").findAll(res.output)
            .map { it.groupValues[1].trim() }
            .distinct()
            .toList()
        val engineLabel = when {
            res.usedRoot || status.isRootGranted -> "Root UID 0"
            status.canRunShizuku -> "Shizuku"
            else -> "Privileged"
        }
        val liveEngine = ShizukuBridge.touchAmplifierEngine.value
        val summary = if (found.isNotEmpty()) {
            "$liveEngine • Driver ($engineLabel): ${found.take(3).joinToString(", ")}"
        } else {
            "$liveEngine ($engineLabel) • Polling & X/Y Boost siap"
        }
        TouchDriverStatus(detectedNodes = found, activeSummary = summary)
    }

    /**
     * Probes hardware capabilities and active state for "Responsif Layar Max".
     */
    suspend fun probeScreenResponseStatus(
        context: Context,
        prefs: BoosterPreferences,
        config: MaxScreenResponseConfig
    ): ScreenResponseStatus = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val maxHz = detectMaxHardwareRefreshRateHz(appContext)
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!canPriv) {
            val writeOk = Settings.System.canWrite(appContext)
            val engine = if (writeOk) "Write Settings" else "Terbatas"
            val detail = if (config.enabled) {
                "Aktif terbatas ($engine) • Panel ${maxHz}Hz • Hubungkan Root / Shizuku untuk SurfaceFlinger & Driver Max."
            } else {
                "Panel ${maxHz}Hz terdeteksi • Hubungkan Root / Shizuku untuk respons sentuhan & display maksimal."
            }
            return@withContext ScreenResponseStatus(
                active = config.enabled,
                detectedMaxHz = maxHz,
                writableDriverNodes = 0,
                longPressMs = if (config.enabled) config.level.longPressMs else 400,
                touchSlopPx = if (config.enabled) config.level.touchSlopPx else 16,
                activeEngineLabel = engine,
                detail = detail
            )
        }

        val cmd = oemTouchDriverNodes.joinToString(" ; ") { (path, label) ->
            "if [ -w '$path' ]; then echo TNODE=$label; fi"
        }
        val res = ShizukuBridge.execPrivileged(cmd)
        val found = Regex("TNODE=([^\\n]+)").findAll(res.output)
            .map { it.groupValues[1].trim() }
            .distinct()
            .toList()
        val engineLabel = when {
            res.usedRoot || (prefs.useRoot.value && status.isRootGranted) -> "Root UID 0"
            res.usedShizuku || status.canRunShizuku -> "Shizuku"
            else -> "Privileged"
        }
        val detail = if (config.enabled) {
            val driverPart = if (found.isNotEmpty()) "${found.size} node driver" else "Pipeline Display + Input"
            "${config.level.label} aktif ($engineLabel) • ${maxHz}Hz • ${config.level.longPressMs}ms • $driverPart"
        } else {
            "Siap ($engineLabel) • Panel ${maxHz}Hz • ${found.size} node driver OEM terdeteksi"
        }
        ScreenResponseStatus(
            active = config.enabled,
            detectedMaxHz = maxHz,
            writableDriverNodes = found.size,
            longPressMs = if (config.enabled) config.level.longPressMs else 400,
            touchSlopPx = if (config.enabled) config.level.touchSlopPx else 16,
            activeEngineLabel = engineLabel,
            detail = detail
        )
    }

    /**
     * Applies or restores the "Responsif Layar Max" pipeline:
     * 1. Max Hardware Refresh Rate Sync (locks display to max physical Hz without DPI distortion)
     * 2. Zero-Touch-Delay Input Pipeline (long_press_timeout, multi_press_timeout, pointer_speed, scroll_friction)
     * 3. Max OEM Touchpanel Polling Rate & Sensitivity nodes
     * 4. Low-Latency SurfaceFlinger & Zero-Backpressure Display Pipeline
     * 5. Edge-Rejection / Grip-Zone Suppression
     * 6. CPU Input TouchBoost for zero-hitch swipe transitions
     */
    suspend fun applyMaxScreenResponse(
        context: Context,
        prefs: BoosterPreferences,
        config: MaxScreenResponseConfig,
        activeGamePkg: String?
    ): Pair<ScreenResponseStatus, ActionFeedback> = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val maxHz = detectMaxHardwareRefreshRateHz(appContext)
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!config.enabled) {
            val keepFpsLock = prefs.fpsLockConfig.value.target != FpsLockTarget.DEFAULT
            if (canPriv) {
                val restoreCmds = mutableListOf<String>()
                if (!keepFpsLock) {
                    restoreCmds.add("settings delete system min_refresh_rate")
                    restoreCmds.add("settings delete system peak_refresh_rate")
                    restoreCmds.add("settings delete system user_refresh_rate")
                }
                restoreCmds.add("setprop debug.input.vsync_resample 1 2>/dev/null ; true")
                restoreCmds.add("setprop debug.sf.disable_backpressure 0 2>/dev/null ; true")
                restoreCmds.add("setprop debug.sf.latch_unsignaled 0 2>/dev/null ; true")
                restoreCmds.add("setprop view.scroll_friction 0.015 2>/dev/null ; true")
                if (!prefs.touchConfig.value.enabled) {
                    restoreCmds.add("settings put system pointer_speed 0")
                    restoreCmds.add("settings put system touch_sensitivity 0")
                    restoreCmds.add("settings put system high_touch_sensitivity_enabled 0")
                    restoreCmds.add("settings delete system speed_up_touch")
                    restoreCmds.add("settings put secure long_press_timeout 400")
                    restoreCmds.add("settings put secure multi_press_timeout 300")
                    restoreCmds.add("settings delete secure tap_duration_threshold")
                    restoreCmds.add("settings delete secure touch_blocking_period")
                    restoreCmds.add(
                        "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                            "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                            "/sys/class/touch/tp_dev/bump_sample_rate " +
                            "/proc/touchpanel/game_switch_enable " +
                            "/proc/touchpanel/tp_report_rate " +
                            "/proc/nvt_game_mode /proc/focaltech/game_mode /proc/ilitek/game_mode " +
                            "/sys/devices/platform/goodix_ts.0/game_mode; do " +
                            "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; true"
                    )
                }
                ShizukuBridge.execPrivileged(restoreCmds.joinToString(" ; "))
            } else if (Settings.System.canWrite(appContext)) {
                runCatching {
                    if (!keepFpsLock) {
                        Settings.System.putFloat(appContext.contentResolver, "min_refresh_rate", 0f)
                        Settings.System.putFloat(appContext.contentResolver, "peak_refresh_rate", 0f)
                    }
                    if (!prefs.touchConfig.value.enabled) {
                        Settings.System.putInt(appContext.contentResolver, "pointer_speed", 0)
                        Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 0)
                    }
                }
            }
            if (prefs.touchConfig.value.enabled) {
                applyTouchResponse(appContext, prefs, prefs.touchConfig.value, activeGamePkg)
            }
            val updated = probeScreenResponseStatus(appContext, prefs, config)
            return@withContext updated to ActionFeedback(true, "Responsif Layar Max dimatikan — display & input kembali normal.")
        }

        val level = config.level
        val friction = computeMaxResponseScrollFriction(level)
        val oemLevel = when (level) {
            ScreenResponseLevel.FAST -> 2
            ScreenResponseLevel.ESPORT -> 3
            ScreenResponseLevel.MAX_ULTRA -> 4
        }
        val oplusRate = when (level) {
            ScreenResponseLevel.FAST -> 1
            ScreenResponseLevel.ESPORT -> 2
            ScreenResponseLevel.MAX_ULTRA -> 2
        }
        val phaseOffsetNs = when (level) {
            ScreenResponseLevel.FAST -> -2_000_000L
            ScreenResponseLevel.ESPORT -> -4_000_000L
            ScreenResponseLevel.MAX_ULTRA -> -6_000_000L
        }

        var wroteDirectSettings = false
        if (Settings.System.canWrite(appContext)) {
            wroteDirectSettings = runCatching {
                if (config.maxRefreshSync) {
                    Settings.System.putFloat(appContext.contentResolver, "min_refresh_rate", maxHz.toFloat())
                    Settings.System.putFloat(appContext.contentResolver, "peak_refresh_rate", maxHz.toFloat())
                }
                if (config.zeroTouchDelay) {
                    Settings.System.putInt(appContext.contentResolver, "pointer_speed", 7)
                    Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 1)
                    Settings.System.putInt(appContext.contentResolver, "high_touch_sensitivity_enabled", 1)
                }
                true
            }.getOrDefault(false)
        }

        if (canPriv) {
            val cmds = mutableListOf<String>()

            // 1. Max Refresh Rate Sync (respects hardware max Hz; zero DPI mutation)
            if (config.maxRefreshSync) {
                cmds.add("settings put system min_refresh_rate $maxHz")
                cmds.add("settings put system peak_refresh_rate $maxHz")
                cmds.add("settings put system user_refresh_rate $maxHz")
            }

            // 2. Zero-Touch-Delay Input Pipeline
            if (config.zeroTouchDelay) {
                cmds.add("settings put system pointer_speed 7")
                cmds.add("settings put system touch_sensitivity 1")
                cmds.add("settings put system high_touch_sensitivity_enabled 1")
                cmds.add("settings put system speed_up_touch 1")
                cmds.add("settings put system auto_adjust_touch 1")
                cmds.add("settings put system increase_touch_sensitivity 1")
                cmds.add("settings put system touch_boost_enable 1")
                cmds.add("settings put system game_touch_boost 1")
                cmds.add("settings put system touch_response_level $oemLevel")
                cmds.add("settings put system touch_sensitivity_level $oemLevel")
                cmds.add("settings put system touch_response_rate $oplusRate")
                cmds.add("settings put system game_touch_sensitivity $oemLevel")
                cmds.add("settings put system vivo_touch_sensitivity 1")
                cmds.add("settings put secure touch_sensitivity 1")
                cmds.add("settings put secure gb_boosting 1")
                cmds.add("settings put secure long_press_timeout ${level.longPressMs}")
                cmds.add("settings put secure multi_press_timeout ${level.multiPressMs}")
                cmds.add("settings put secure tap_duration_threshold 0.0")
                cmds.add("settings put secure touch_blocking_period 0.0")
                cmds.add("settings put secure accessibility_interactive_ui_timeout_ms 0")
                cmds.add("settings put global block_untrusted_touches_mode 0")
                cmds.add("setprop view.scroll_friction $friction 2>/dev/null ; true")
                cmds.add("setprop persist.sys.touch.sensitivity ${oemLevel + 1} 2>/dev/null ; true")
            }

            // 3. Max OEM Touchpanel Polling & Firmware Sensitivity Nodes
            if (config.maxTouchPolling) {
                cmds.add(
                    "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                        "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                        "/sys/class/touch/tp_dev/bump_sample_rate " +
                        "/proc/touchpanel/game_switch_enable " +
                        "/proc/nvt_game_mode /proc/nvt_sensitivity_switch " +
                        "/proc/focaltech/game_mode /proc/ilitek/game_mode " +
                        "/sys/devices/platform/goodix_ts.0/game_mode " +
                        "/sys/devices/platform/nubia_goodix_tp/gamemode " +
                        "/sys/devices/platform/nubia_synaptics_tp/gamemode " +
                        "/sys/class/touch/touch_dev/touch_active_status " +
                        "/sys/class/touch/touch_dev/touch_sensitivity; do " +
                        "[ -w \"\$p\" ] && echo 1 > \"\$p\" 2>/dev/null; done; true"
                )
                cmds.add(
                    "[ -w /sys/class/touch/touch_dev/touch_aim_sensitivity ] && echo $oemLevel > /sys/class/touch/touch_dev/touch_aim_sensitivity 2>/dev/null; " +
                        "[ -w /sys/class/touch/touch_dev/touch_tap_sensitivity ] && echo $oemLevel > /sys/class/touch/touch_dev/touch_tap_sensitivity 2>/dev/null; " +
                        "[ -w /sys/class/touch/touch_dev/touch_tolerance ] && echo $oemLevel > /sys/class/touch/touch_dev/touch_tolerance 2>/dev/null; " +
                        "[ -w /proc/touchpanel/tp_report_rate ] && echo $oplusRate > /proc/touchpanel/tp_report_rate 2>/dev/null; " +
                        "[ -w /proc/touchpanel/sensitive_level ] && echo $oemLevel > /proc/touchpanel/sensitive_level 2>/dev/null; " +
                        "[ -w /proc/touchpanel/smooth_level ] && echo 0 > /proc/touchpanel/smooth_level 2>/dev/null; " +
                        "[ -w /sys/module/tpd_setting/parameters/tpd_em_sample_cnt ] && echo 1 > /sys/module/tpd_setting/parameters/tpd_em_sample_cnt 2>/dev/null; " +
                        "if [ -w /sys/class/sec/tsp/cmd ]; then " +
                        "echo 'set_game_mode,1' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                        "echo 'glove_mode,1' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                        "echo 'set_scan_rate,1' > /sys/class/sec/tsp/cmd 2>/dev/null; fi; true"
                )
            }

            // 4. Low-Latency SurfaceFlinger & Zero-Backpressure Display Pipeline
            if (config.lowLatencySurfaceFlinger) {
                cmds.add(
                    "setprop touch.pressure.scale 0.001 2>/dev/null; " +
                        "setprop debug.input.vsync_resample 0 2>/dev/null; " +
                        "setprop debug.sf.latch_unsignaled 1 2>/dev/null; " +
                        "setprop debug.sf.disable_backpressure 1 2>/dev/null; " +
                        "setprop debug.sf.early_phase_offset_ns $phaseOffsetNs 2>/dev/null; " +
                        "setprop debug.sf.early_app_phase_offset_ns $phaseOffsetNs 2>/dev/null; true"
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !activeGamePkg.isNullOrBlank()) {
                    cmds.add("cmd game mode performance $activeGamePkg 2>/dev/null ; true")
                }
            }

            // 5. Disable OEM Edge-Rejection / Grip-Zone Filtering
            if (config.disableEdgeRejection) {
                cmds.add(
                    "for p in /proc/touchpanel/oplus_tp_limit_enable " +
                        "/sys/class/touch/touch_dev/touch_edge_filter " +
                        "/sys/class/touch/touch_dev/edge_filter " +
                        "/sys/class/touch/touch_dev/grip_zone; do " +
                        "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; true"
                )
            }

            // 6. CPU Input TouchBoost
            if (config.cpuInputBoost) {
                cmds.add(
                    "for p in /sys/module/cpu_boost/parameters/input_boost_enabled " +
                        "/sys/devices/system/cpu/cpu_boost/input_boost_enabled " +
                        "/sys/kernel/msm_performance/parameters/touchboost " +
                        "/sys/module/msm_performance/parameters/touchboost; do " +
                        "[ -w \"\$p\" ] && echo 1 > \"\$p\" 2>/dev/null; done; " +
                        "for ms in /sys/module/cpu_boost/parameters/input_boost_ms " +
                        "/sys/devices/system/cpu/cpu_boost/input_boost_ms; do " +
                        "[ -w \"\$ms\" ] && echo ${level.inputBoostMs} > \"\$ms\" 2>/dev/null; done; true"
                )
            }

            val execRes = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
            val probed = probeScreenResponseStatus(appContext, prefs, config)
            val engineTag = if (execRes.usedRoot) "Root UID 0" else "Shizuku"
            val hzTag = if (config.maxRefreshSync) " • ${maxHz}Hz" else ""
            val ok = execRes.success || execRes.usedRoot || execRes.usedShizuku
            return@withContext probed to ActionFeedback(
                ok,
                "Responsif Layar Max (${level.label}) aktif via $engineTag$hzTag • ${level.longPressMs}ms • Slop ${level.touchSlopPx}px."
            )
        }

        val probed = probeScreenResponseStatus(appContext, prefs, config)
        if (wroteDirectSettings) {
            return@withContext probed to ActionFeedback(
                true,
                "Responsif Layar Max (${level.label} • ${maxHz}Hz) aktif via Write Settings. Hubungkan Root / Shizuku untuk boost penuh."
            )
        }

        probed to ActionFeedback(
            true,
            "Profil Responsif Layar Max (${level.label}) disimpan. Aktifkan Opsi 1 (Root) atau Opsi 2 (Shizuku) agar aktif penuh."
        )
    }

    suspend fun applyTouchResponse(
        context: Context,
        prefs: BoosterPreferences,
        config: TouchConfig,
        activeGamePkg: String?
    ): ActionFeedback = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val status = ShizukuBridge.refresh(appContext)
        val canPriv = prefs.canUsePrivileged(status)

        if (!config.enabled) {
            return@withContext resetTouchResponse(appContext, canPriv)
        }

        val gainX = config.gainX()
        val gainY = config.gainY()
        val params = computeTouchTuningParams(config)
        val scrollFriction = computeScrollFriction(config)

        // Layer 1 (Real-Time Live X/Y Companion Touch Amplifier — Root Evdev Slot-6 / Shizuku Input Boost)
        val liveAmpCfg = buildAmplifierConfig(appContext, config)
        val liveEngineLabel = if (canPriv) {
            ShizukuBridge.syncTouchAmplifierConfig(liveAmpCfg)
        } else {
            ShizukuBridge.syncTouchAmplifierConfig(liveAmpCfg.copy(enabled = false))
            "Perlu Root / Shizuku"
        }

        var wroteDirectSettings = false
        if (Settings.System.canWrite(appContext)) {
            wroteDirectSettings = runCatching {
                Settings.System.putInt(appContext.contentResolver, "pointer_speed", params.pointerSpeed)
                Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 1)
                Settings.System.putInt(appContext.contentResolver, "high_touch_sensitivity_enabled", 1)
                true
            }.getOrDefault(false)
        }

        if (canPriv) {
            val pollVal = params.pollingFlag
            val oplusRateVal = when (config.pollingPreset) {
                TouchPollingPreset.DEFAULT -> 0
                TouchPollingPreset.HIGH_240 -> 1
                TouchPollingPreset.ULTRA_480 -> 2
                TouchPollingPreset.MAX_HARDWARE -> 2
            }
            val oemSensLevel = ((params.xiaomiAimSens + params.xiaomiTapSens) / 2).coerceIn(1, 4)
            val inputBoostMs = (60 + config.responseBoost).coerceIn(60, 160)

            val cmds = mutableListOf(
                "settings put system pointer_speed ${params.pointerSpeed}",
                "settings put system touch_sensitivity 1",
                "settings put system high_touch_sensitivity_enabled 1",
                "settings put system auto_adjust_touch 1",
                "settings put system increase_touch_sensitivity 1",
                "settings put system touch_response_level ${params.xiaomiTapSens}",
                "settings put system touch_sensitivity_level $oemSensLevel",
                "settings put system touch_response_rate $oplusRateVal",
                "settings put system game_touch_sensitivity ${params.oplusSensitive}",
                "settings put system vivo_touch_sensitivity 1",
                "settings put system touch_boost_enable 1",
                "settings put system game_touch_boost 1",
                "settings put secure touch_sensitivity 1",
                "settings put secure gb_boosting 1",
                "settings put secure long_press_timeout ${params.longPressMs}",
                "settings put secure multi_press_timeout ${params.multiPressMs}",
                "settings put secure tap_duration_threshold 0.0",
                "settings put secure touch_blocking_period 0.0",
                "settings put secure accessibility_interactive_ui_timeout_ms 0",
                "settings put global block_untrusted_touches_mode 0",
                "setprop touch.pressure.scale 0.001 2>/dev/null; " +
                    "setprop debug.input.vsync_resample 0 2>/dev/null; " +
                    "setprop debug.sf.latch_unsignaled 1 2>/dev/null; " +
                    "setprop debug.sf.disable_backpressure 1 2>/dev/null; " +
                    "setprop view.scroll_friction $scrollFriction 2>/dev/null; " +
                    "setprop persist.sys.touch.sensitivity ${oemSensLevel + 1} 2>/dev/null; true"
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !activeGamePkg.isNullOrBlank()) {
                cmds.add("cmd game mode performance $activeGamePkg 2>/dev/null ; true")
            }

            cmds.add(
                "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                    "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                    "/sys/class/touch/tp_dev/bump_sample_rate " +
                    "/proc/touchpanel/game_switch_enable " +
                    "/proc/nvt_game_mode " +
                    "/proc/nvt_sensitivity_switch " +
                    "/proc/focaltech/game_mode " +
                    "/proc/ilitek/game_mode " +
                    "/sys/devices/platform/goodix_ts.0/game_mode " +
                    "/sys/class/touch/touch_dev/touch_active_status " +
                    "/sys/class/touch/touch_dev/touch_sensitivity; do " +
                    "[ -w \"\$p\" ] && echo $pollVal > \"\$p\" 2>/dev/null; done; true"
            )
            cmds.add(
                "[ -w /sys/class/touch/touch_dev/touch_aim_sensitivity ] && echo ${params.xiaomiAimSens} > /sys/class/touch/touch_dev/touch_aim_sensitivity 2>/dev/null; " +
                    "[ -w /sys/class/touch/touch_dev/touch_tap_sensitivity ] && echo ${params.xiaomiTapSens} > /sys/class/touch/touch_dev/touch_tap_sensitivity 2>/dev/null; " +
                    "[ -w /sys/class/touch/touch_dev/touch_tolerance ] && echo ${params.xiaomiTolerance} > /sys/class/touch/touch_dev/touch_tolerance 2>/dev/null; " +
                    "[ -w /proc/touchpanel/tp_report_rate ] && echo $oplusRateVal > /proc/touchpanel/tp_report_rate 2>/dev/null; " +
                    "[ -w /proc/touchpanel/sensitive_level ] && echo ${params.oplusSensitive} > /proc/touchpanel/sensitive_level 2>/dev/null; " +
                    "[ -w /proc/touchpanel/smooth_level ] && echo ${params.oplusSmooth} > /proc/touchpanel/smooth_level 2>/dev/null; " +
                    "[ -w /sys/module/tpd_setting/parameters/tpd_em_sample_cnt ] && echo 1 > /sys/module/tpd_setting/parameters/tpd_em_sample_cnt 2>/dev/null; " +
                    "if [ -w /sys/class/sec/tsp/cmd ]; then " +
                    "echo 'set_game_mode,$pollVal' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'glove_mode,1' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'set_scan_rate,1' > /sys/class/sec/tsp/cmd 2>/dev/null; fi; true"
            )
            cmds.add(
                "for p in /sys/module/cpu_boost/parameters/input_boost_enabled " +
                    "/sys/devices/system/cpu/cpu_boost/input_boost_enabled " +
                    "/sys/kernel/msm_performance/parameters/touchboost " +
                    "/sys/module/msm_performance/parameters/touchboost; do " +
                    "[ -w \"\$p\" ] && echo 1 > \"\$p\" 2>/dev/null; done; " +
                    "for ms in /sys/module/cpu_boost/parameters/input_boost_ms " +
                    "/sys/devices/system/cpu/cpu_boost/input_boost_ms; do " +
                    "[ -w \"\$ms\" ] && echo $inputBoostMs > \"\$ms\" 2>/dev/null; done; true"
            )
            if (config.edgeRejectionOff) {
                cmds.add(
                    "for p in /proc/touchpanel/oplus_tp_limit_enable " +
                        "/sys/class/touch/touch_dev/touch_edge_filter " +
                        "/sys/class/touch/touch_dev/edge_filter " +
                        "/sys/class/touch/touch_dev/grip_zone; do " +
                        "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; true"
                )
            }

            val sysRes = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
            if (sysRes.success || sysRes.usedShizuku || sysRes.usedRoot) {
                val boostTag = if (liveAmpCfg.hasEffectiveBoost()) {
                    "X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} • $liveEngineLabel"
                } else {
                    "${config.pollingPreset.shortLabel} • Slop ${params.touchSlopPx}px"
                }
                return@withContext ActionFeedback(
                    true,
                    "Touch Licin aktif ($boostTag • ${params.longPressMs}ms) tanpa ubah DPI."
                )
            }
        }

        if (wroteDirectSettings) {
            return@withContext ActionFeedback(
                true,
                "Touch X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} aktif terbatas (hubungkan Root / Shizuku agar X/Y Live Amplifier jalan penuh)."
            )
        }

        ActionFeedback(
            true,
            "Profil Touch X:${"%.2fx".format(gainX)} Y:${"%.2fx".format(gainY)} tersimpan. Hubungkan Root / Shizuku agar layar benar-benar super licin."
        )
    }

    private suspend fun resetTouchResponse(appContext: Context, canPriv: Boolean): ActionFeedback {
        ShizukuBridge.syncTouchAmplifierConfig(TouchAmplifierConfig(enabled = false))
        if (canPriv) {
            val cmds = listOf(
                "settings put system pointer_speed 0",
                "settings put system touch_sensitivity 0",
                "settings put system high_touch_sensitivity_enabled 0",
                "settings put system auto_adjust_touch 0",
                "settings put system increase_touch_sensitivity 0",
                "settings put system touch_response_level 0",
                "settings put system touch_sensitivity_level 0",
                "settings put system touch_response_rate 0",
                "settings put system game_touch_sensitivity 0",
                "settings put system vivo_touch_sensitivity 0",
                "settings put system touch_boost_enable 0",
                "settings put system game_touch_boost 0",
                "settings put secure touch_sensitivity 0",
                "settings put secure gb_boosting 0",
                "settings put secure long_press_timeout 400",
                "settings put secure multi_press_timeout 300",
                "settings delete secure tap_duration_threshold",
                "settings delete secure touch_blocking_period",
                "settings delete secure accessibility_interactive_ui_timeout_ms",
                "settings delete global block_untrusted_touches_mode",
                "setprop debug.input.vsync_resample 1 2>/dev/null; " +
                    "setprop view.scroll_friction 0.015 2>/dev/null; true",
                "for p in /sys/class/touch/touch_dev/bump_sample_rate " +
                    "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
                    "/sys/class/touch/tp_dev/bump_sample_rate " +
                    "/proc/touchpanel/game_switch_enable " +
                    "/proc/touchpanel/tp_report_rate " +
                    "/proc/nvt_game_mode " +
                    "/proc/nvt_sensitivity_switch " +
                    "/proc/focaltech/game_mode " +
                    "/proc/ilitek/game_mode " +
                    "/sys/devices/platform/goodix_ts.0/game_mode; do " +
                    "[ -w \"\$p\" ] && echo 0 > \"\$p\" 2>/dev/null; done; " +
                    "if [ -w /sys/class/sec/tsp/cmd ]; then " +
                    "echo 'set_game_mode,0' > /sys/class/sec/tsp/cmd 2>/dev/null; " +
                    "echo 'glove_mode,0' > /sys/class/sec/tsp/cmd 2>/dev/null; fi; true"
            )
            ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        } else if (Settings.System.canWrite(appContext)) {
            runCatching {
                Settings.System.putInt(appContext.contentResolver, "pointer_speed", 0)
                Settings.System.putInt(appContext.contentResolver, "touch_sensitivity", 0)
                Settings.System.putInt(appContext.contentResolver, "high_touch_sensitivity_enabled", 0)
            }
        }
        return ActionFeedback(true, "Touch response & X/Y Amplifier dimatikan (DPI tetap standar).")
    }
}
