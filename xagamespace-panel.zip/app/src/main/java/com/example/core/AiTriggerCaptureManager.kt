package com.example.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Cross-device screen frame manager for AI Trigger:
 * - Primary: MediaProjection + VirtualDisplay + ImageReader RGBA_8888 (15-30 FPS, handles arbitrary rowStride padding
 *   and orientation changes cleanly on Android 7..16).
 * - Secondary fallback for one-shot Crop / non-MediaProjection mode: Shizuku / Root `screencap -p`.
 */
object AiTriggerCaptureManager {

    data class FrameSnapshot(
        val width: Int,
        val height: Int,
        val argbPixels: IntArray,
        val timestampMs: Long
    )

    private val lock = Any()
    private val shizukuCaptureMutex = Mutex()
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var projectionCallback: MediaProjection.Callback? = null

    private var captureW = 0
    private var captureH = 0
    private var captureDpi = 320
    private var rawByteBuffer: ByteArray = ByteArray(0)
    private val pixelRing = Array(3) { IntArray(0) }
    private var ringIndex = 0
    private var lastUnpackAtMs = 0L

    @Volatile
    private var forceNextCapture = false

    @Volatile
    private var latestFrame: FrameSnapshot? = null

    private val frameArrivedChannel = Channel<Unit>(Channel.CONFLATED)

    fun requestImmediateFrame() {
        forceNextCapture = true
    }

    @Volatile
    var awaitingConsentPrompt: Boolean = false

    @Volatile
    var lastCaptureError: String? = null
        private set

    private val _hasProjection = MutableStateFlow(false)
    val hasProjection: StateFlow<Boolean> = _hasProjection.asStateFlow()

    private val _projectionDimensions = MutableStateFlow(0 to 0)
    val projectionDimensions: StateFlow<Pair<Int, Int>> = _projectionDimensions.asStateFlow()

    fun isProjectionActive(): Boolean = synchronized(lock) {
        mediaProjection != null && virtualDisplay != null && imageReader != null
    }

    fun getLatestFrame(): FrameSnapshot? = latestFrame

    suspend fun awaitNextFrame(timeoutMs: Long) {
        withTimeoutOrNull(timeoutMs.coerceAtLeast(1L)) {
            frameArrivedChannel.receive()
        }
    }

    fun attachProjection(context: Context, projection: MediaProjection): Boolean {
        stopProjection()
        lastCaptureError = null
        val (screenW, screenH, dpi) = queryDisplayMetrics(context)
        val (targetW, targetH) = computeScaledCaptureSize(screenW, screenH)

        return synchronized(lock) {
            try {
                mediaProjection = projection
                captureW = targetW
                captureH = targetH
                captureDpi = dpi.coerceIn(120, 640)

                val thread = HandlerThread("xa-ai-capture").apply { start() }
                captureThread = thread
                val handler = Handler(thread.looper)
                captureHandler = handler

                val cb = object : MediaProjection.Callback() {
                    override fun onStop() {
                        runCatching { stopProjection() }
                    }

                    override fun onCapturedContentResize(width: Int, height: Int) {
                        runCatching {
                            if (width > 16 && height > 16) {
                                val (scaledW, scaledH) = computeScaledCaptureSize(width, height)
                                val safeDpi = captureDpi.coerceIn(120, 640)
                                resizeCaptureSurface(scaledW, scaledH, safeDpi)
                            }
                        }
                    }
                }
                projectionCallback = cb
                // Mandatory on Android 14+ BEFORE createVirtualDisplay()
                projection.registerCallback(cb, handler)

                allocateReaderAndVirtualDisplayLocked(projection, targetW, targetH, captureDpi, handler)
                _hasProjection.value = true
                _projectionDimensions.value = targetW to targetH
                true
            } catch (t: Throwable) {
                lastCaptureError = "Gagal memulai VirtualDisplay: ${t.message ?: t.javaClass.simpleName}"
                stopProjectionLocked()
                false
            }
        }
    }

    fun syncOrientationIfNeeded(context: Context) {
        val proj = synchronized(lock) { mediaProjection } ?: return
        val (screenW, screenH, dpi) = queryDisplayMetrics(context)
        val (desiredW, desiredH) = computeScaledCaptureSize(screenW, screenH)
        if (desiredW != captureW || desiredH != captureH) {
            resizeCaptureSurface(desiredW, desiredH, dpi.coerceIn(120, 640))
            synchronized(lock) {
                if (virtualDisplay == null && proj == mediaProjection) {
                    captureHandler?.let { h ->
                        runCatching {
                            allocateReaderAndVirtualDisplayLocked(proj, desiredW, desiredH, dpi.coerceIn(120, 640), h)
                        }.onFailure {
                            lastCaptureError = "Gagal menyesuaikan orientasi layar: ${it.message ?: it.javaClass.simpleName}"
                        }
                    }
                }
            }
        }
    }

    private fun resizeCaptureSurface(newW: Int, newH: Int, dpi: Int) {
        synchronized(lock) {
            val proj = mediaProjection ?: return
            val handler = captureHandler ?: return
            val safeW = (newW and 1.inv()).coerceAtLeast(16)
            val safeH = (newH and 1.inv()).coerceAtLeast(16)
            val safeDpi = dpi.coerceIn(120, 640)
            if (safeW == captureW && safeH == captureH && imageReader != null && virtualDisplay != null) return

            captureW = safeW
            captureH = safeH
            captureDpi = safeDpi
            runCatching { imageReader?.setOnImageAvailableListener(null, null) }
            runCatching { imageReader?.close() }
            imageReader = null

            val reader = runCatching {
                ImageReader.newInstance(safeW, safeH, PixelFormat.RGBA_8888, 2)
            }.getOrElse {
                lastCaptureError = "ImageReader gagal dibuat: ${it.message ?: it.javaClass.simpleName}"
                return
            }
            reader.setOnImageAvailableListener({ r -> processAvailableImage(r) }, handler)
            imageReader = reader
            if (virtualDisplay != null) {
                runCatching {
                    virtualDisplay?.resize(safeW, safeH, safeDpi)
                    virtualDisplay?.surface = reader.surface
                }.onFailure {
                    runCatching { virtualDisplay?.release() }
                    virtualDisplay = null
                    runCatching {
                        allocateReaderAndVirtualDisplayLocked(proj, safeW, safeH, safeDpi, handler)
                    }.onFailure { err ->
                        lastCaptureError = "VirtualDisplay resize gagal: ${err.message ?: err.javaClass.simpleName}"
                    }
                }
            } else {
                runCatching {
                    allocateReaderAndVirtualDisplayLocked(proj, safeW, safeH, safeDpi, handler)
                }
            }
            _projectionDimensions.value = safeW to safeH
        }
    }

    private fun allocateReaderAndVirtualDisplayLocked(
        projection: MediaProjection,
        w: Int,
        h: Int,
        dpi: Int,
        handler: Handler
    ) {
        val safeW = (w and 1.inv()).coerceAtLeast(16)
        val safeH = (h and 1.inv()).coerceAtLeast(16)
        val safeDpi = dpi.coerceIn(120, 640)
        val reader = imageReader ?: ImageReader.newInstance(safeW, safeH, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ imgReader -> processAvailableImage(imgReader) }, handler)
            imageReader = r
        }
        virtualDisplay = projection.createVirtualDisplay(
            "XAAiTriggerDisplay",
            safeW,
            safeH,
            safeDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )
    }

    private fun processAvailableImage(reader: ImageReader) {
        val image = synchronized(lock) {
            if (reader !== imageReader) return
            runCatching { reader.acquireLatestImage() }.getOrNull()
        } ?: return

        try {
            val nowMs = SystemClock.uptimeMillis()
            if (!forceNextCapture && (nowMs - lastUnpackAtMs) < 36L) {
                return
            }
            forceNextCapture = false
            lastUnpackAtMs = nowMs

            val plane = image.planes.firstOrNull() ?: return
            val w = image.width
            val h = image.height
            if (w <= 0 || h <= 0) return
            val buf = plane.buffer
            val remaining = buf.remaining()
            if (remaining <= 0) return
            if (rawByteBuffer.size < remaining) {
                rawByteBuffer = ByteArray(remaining)
            }
            buf.get(rawByteBuffer, 0, remaining)

            val needed = w * h
            val slot = ringIndex
            ringIndex = (ringIndex + 1) % pixelRing.size
            if (pixelRing[slot].size != needed) {
                pixelRing[slot] = IntArray(needed)
            }
            val targetArray = pixelRing[slot]

            AiTriggerMatcher.rgbaBytesToArgbPixels(
                bytes = rawByteBuffer,
                width = w,
                height = h,
                pixelStride = plane.pixelStride,
                rowStride = plane.rowStride,
                outPixels = targetArray
            )
            latestFrame = FrameSnapshot(
                width = w,
                height = h,
                argbPixels = targetArray,
                timestampMs = SystemClock.uptimeMillis()
            )
            frameArrivedChannel.trySend(Unit)
        } catch (_: Throwable) {
            // Safe drop if surface or buffer resized mid-read
        } finally {
            runCatching { image.close() }
        }
    }

    private fun frameToBitmapSafe(frame: FrameSnapshot): Bitmap? {
        val w = frame.width
        val h = frame.height
        if (w <= 0 || h <= 0) return null
        val needed = w * h
        if (frame.argbPixels.size < needed) return null
        return runCatching {
            val copy = frame.argbPixels.copyOf(needed)
            Bitmap.createBitmap(copy, w, h, Bitmap.Config.ARGB_8888)
        }.getOrNull()
    }

    /**
     * Captures a clean Bitmap of the current screen either from active MediaProjection (waiting briefly
     * for a frame newer than `minTimestampMs` so dismissed crop overlays are never baked in)
     * or falls back to privileged Shizuku/Root `screencap -p`.
     */
    suspend fun captureBitmapForCrop(context: Context, minTimestampMs: Long = 0L): Bitmap? {
        if (isProjectionActive()) {
            requestImmediateFrame()
            var waited = 0L
            while (waited < 380L) {
                val cur = latestFrame
                if (cur != null && cur.timestampMs >= minTimestampMs) {
                    break
                }
                kotlinx.coroutines.delay(35L)
                waited += 35L
            }
        }
        val frame = latestFrame
        if (isProjectionActive() && frame != null &&
            frame.timestampMs >= minTimestampMs &&
            (SystemClock.uptimeMillis() - frame.timestampMs) < 3500L
        ) {
            frameToBitmapSafe(frame)?.let { return it }
        }
        // Fallback: Shizuku/Root screencap -p captures compositor frame cleanly
        val tempFile = File(context.cacheDir, "ai_crop_capture.png")
        val ok = shizukuCaptureMutex.withLock {
            ShizukuBridge.captureScreenPngToFile(tempFile)
        }
        if (ok) {
            val bmp = decodeDownsampledBitmap(tempFile, maxLongEdge = 1600)
            runCatching { tempFile.delete() }
            if (bmp != null) return bmp
        }
        // Fallback to whatever frame MediaProjection has (for static screens where VirtualDisplay stopped emitting)
        val stale = latestFrame
        if (stale != null) {
            frameToBitmapSafe(stale)?.let { return it }
        }
        return null
    }

    /**
     * Captures a downscaled ARGB frame via Shizuku/Root `screencap` if MediaProjection wasn't granted yet.
     */
    suspend fun captureFrameViaShizukuFallback(context: Context): FrameSnapshot? {
        return shizukuCaptureMutex.withLock {
            val tempFile = File(context.cacheDir, "ai_scan_fallback.png")
            try {
                if (!ShizukuBridge.captureScreenPngToFile(tempFile)) return@withLock null
                val sampled = decodeDownsampledBitmap(tempFile, maxLongEdge = 960) ?: return@withLock null
                val (tw, th) = computeScaledCaptureSize(sampled.width, sampled.height)
                val scaled = if (sampled.width == tw && sampled.height == th) {
                    sampled
                } else {
                    Bitmap.createScaledBitmap(sampled, tw, th, true)
                }
                val pixels = IntArray(tw * th)
                scaled.getPixels(pixels, 0, tw, 0, 0, tw, th)
                if (scaled !== sampled) scaled.recycle()
                sampled.recycle()
                FrameSnapshot(tw, th, pixels, SystemClock.uptimeMillis()).also {
                    latestFrame = it
                }
            } catch (_: Throwable) {
                null
            } finally {
                runCatching { tempFile.delete() }
            }
        }
    }

    private fun decodeDownsampledBitmap(file: File, maxLongEdge: Int): Bitmap? {
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0) return@runCatching null
            var sampleSize = 1
            val longest = max(w, h)
            while (longest / (sampleSize * 2) >= maxLongEdge) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
        }.getOrNull()
    }

    fun cropNormalizedRegion(
        source: Bitmap,
        leftNorm: Float,
        topNorm: Float,
        rightNorm: Float,
        bottomNorm: Float
    ): Bitmap? {
        if (source.isRecycled) return null
        val w = source.width
        val h = source.height
        if (w <= 4 || h <= 4) return null
        val x1 = (leftNorm.coerceIn(0f, 0.96f) * w).roundToInt().coerceIn(0, w - 4)
        val y1 = (topNorm.coerceIn(0f, 0.96f) * h).roundToInt().coerceIn(0, h - 4)
        val x2 = (rightNorm.coerceIn(0.04f, 1f) * w).roundToInt().coerceIn(x1 + 4, w)
        val y2 = (bottomNorm.coerceIn(0.04f, 1f) * h).roundToInt().coerceIn(y1 + 4, h)
        return runCatching {
            Bitmap.createBitmap(source, x1, y1, (x2 - x1).coerceAtLeast(4), (y2 - y1).coerceAtLeast(4))
        }.getOrNull()
    }

    fun stopProjection() {
        synchronized(lock) {
            stopProjectionLocked()
        }
    }

    private fun stopProjectionLocked() {
        runCatching {
            projectionCallback?.let { cb -> mediaProjection?.unregisterCallback(cb) }
        }
        projectionCallback = null
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        runCatching { captureThread?.quitSafely() }
        captureThread = null
        captureHandler = null
        captureW = 0
        captureH = 0
        latestFrame = null
        _hasProjection.value = false
        _projectionDimensions.value = 0 to 0
    }

    /**
     * Visual-context-safe screen metric query working cleanly from Application, Service, and Activity contexts
     * across Android 7..16 without triggering non-visual WindowManager assertions.
     */
    fun queryDisplayMetrics(context: Context): Triple<Int, Int, Int> {
        runCatching {
            val dmService = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val display = dmService?.getDisplay(Display.DEFAULT_DISPLAY)
            if (display != null) {
                val out = DisplayMetrics()
                @Suppress("DEPRECATION")
                display.getRealMetrics(out)
                if (out.widthPixels > 0 && out.heightPixels > 0) {
                    return Triple(out.widthPixels, out.heightPixels, out.densityDpi.coerceIn(120, 640))
                }
            }
        }

        runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (wm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val b = wm.currentWindowMetrics.bounds
                    if (b.width() > 0 && b.height() > 0) {
                        val dpi = context.resources.displayMetrics.densityDpi.coerceIn(120, 640)
                        return Triple(b.width(), b.height(), dpi)
                    }
                } else {
                    val out = DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay?.getRealMetrics(out)
                    if (out.widthPixels > 0 && out.heightPixels > 0) {
                        return Triple(out.widthPixels, out.heightPixels, out.densityDpi.coerceIn(120, 640))
                    }
                }
            }
        }

        val resDm = context.resources.displayMetrics
        return Triple(
            resDm.widthPixels.coerceAtLeast(720),
            resDm.heightPixels.coerceAtLeast(1280),
            resDm.densityDpi.coerceIn(120, 640)
        )
    }

    fun computeScaledCaptureSize(screenW: Int, screenH: Int, maxLongEdge: Int = 960): Pair<Int, Int> {
        val sw = screenW.coerceAtLeast(120)
        val sh = screenH.coerceAtLeast(120)
        val longest = max(sw, sh)
        if (longest <= maxLongEdge) {
            val evenW = (sw and 1.inv()).coerceAtLeast(16)
            val evenH = (sh and 1.inv()).coerceAtLeast(16)
            return evenW to evenH
        }
        val ratio = maxLongEdge.toFloat() / longest.toFloat()
        val scaledW = ((sw * ratio).roundToInt() and 1.inv()).coerceAtLeast(16)
        val scaledH = ((sh * ratio).roundToInt() and 1.inv()).coerceAtLeast(16)
        return scaledW to scaledH
    }
}
