package com.example.core

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.MotionEvent
import android.view.Surface
import android.view.WindowManager
import com.example.data.BoosterPreferences
import com.example.model.AiTriggerRule
import com.example.model.AiTriggerRuntimeState
import com.example.model.MacroInjectionMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.min

/**
 * RedMagic-style Continuous Head-Lock AI Trigger Engine:
 * - Captures game frames continuously via MediaProjection (or Shizuku fallback).
 * - Tracks the cropped enemy silhouette around the center crosshair.
 * - Keeps the game's center crosshair locked onto the user-aligned enemy head coordinate
 *   `(headOffsetXPercent, headOffsetPercent)` even while the player actively swipes the screen,
 *   automatically switching between SMART_POINTER and STYLUS_HYBRID on concurrent touch collisions.
 */
object AiTriggerEngine {

    private data class CacheKey(
        val ruleId: String,
        val path: String,
        val widthPx: Int,
        val heightPx: Int,
        val frameW: Int,
        val frameH: Int
    )

    private class CameraTrackSession {
        var isDown: Boolean = false
        var downTimeMs: Long = 0L
        var anchorX: Float = 0f
        var anchorY: Float = 0f
        var curX: Float = 0f
        var curY: Float = 0f
        var emaDx: Float = 0f
        var emaDy: Float = 0f
        var lastSeenMs: Long = 0L
        var alignedSinceMs: Long = 0L
        var stickyUntilMs: Long = 0L
        var stylusFallbackUntilMs: Long = 0L
        var mode: MacroInjectionMode = MacroInjectionMode.STYLUS_HYBRID
        var slotOffset: Int = 1
        var screenW: Int = 1080
        var screenH: Int = 2400
        var rotation: Int = 0
    }

    @Volatile
    private var lastCaptureErrorMsg: String? = null

    private val engineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
        lastCaptureErrorMsg = "AI Capture error: ${throwable.message ?: throwable.javaClass.simpleName}"
        _runtimeState.value = _runtimeState.value.copy(
            isCapturing = false,
            isMatched = false,
            crosshairTouchingBody = false,
            isAimingToHead = false,
            lastError = lastCaptureErrorMsg
        )
    }

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + engineExceptionHandler)
    private val templateCache = ConcurrentHashMap<CacheKey, AiTriggerMatcher.PreparedTemplate>()
    private val lastFireMsMap = ConcurrentHashMap<String, Long>()
    private val camSession = CameraTrackSession()

    private val _runtimeState = MutableStateFlow(AiTriggerRuntimeState())
    val runtimeState: StateFlow<AiTriggerRuntimeState> = _runtimeState.asStateFlow()

    private var loopJob: Job? = null

    fun reportCaptureError(message: String) {
        lastCaptureErrorMsg = message
        _runtimeState.value = _runtimeState.value.copy(
            isCapturing = AiTriggerCaptureManager.isProjectionActive(),
            lastError = message
        )
    }

    fun clearCaptureError() {
        lastCaptureErrorMsg = null
        if (_runtimeState.value.lastError != null) {
            _runtimeState.value = _runtimeState.value.copy(lastError = null)
        }
    }

    fun invalidateTemplateCache(ruleId: String? = null) {
        if (ruleId == null) {
            templateCache.clear()
        } else {
            val keys = templateCache.keys.filter { it.ruleId == ruleId }
            keys.forEach { templateCache.remove(it) }
        }
    }

    /**
     * Computes one proportional camera-drag step in screen pixels from the in-game crosshair
     * toward the enemy's aligned HEAD coordinate, with anti-jitter deadband and clamping.
     */
    fun computeHeadTriggerStepPx(
        headTargetNormX: Float,
        headTargetNormY: Float,
        crosshairNormX: Float,
        crosshairNormY: Float,
        screenW: Int,
        screenH: Int,
        headLiftPower: Int,
        deadbandPx: Float = 4f
    ): Pair<Float, Float> {
        val safeW = screenW.coerceAtLeast(100).toFloat()
        val safeH = screenH.coerceAtLeast(100).toFloat()
        val errX = (headTargetNormX - crosshairNormX) * safeW
        val errY = (headTargetNormY - crosshairNormY) * safeH
        val dist = hypot(errX.toDouble(), errY.toDouble()).toFloat()
        if (dist <= deadbandPx) return 0f to 0f

        val gain = (headLiftPower / 100f).coerceIn(0.50f, 2.20f)
        val dampedRatio = ((dist - deadbandPx * 0.45f) / dist).coerceIn(0.25f, 1f)
        val stepFactor = 0.68f * gain * dampedRatio
        val maxStep = min(safeW, safeH) * 0.22f
        val dx = (errX * stepFactor).coerceIn(-maxStep, maxStep)
        val dy = (errY * stepFactor).coerceIn(-maxStep, maxStep)
        return dx to dy
    }

    /**
     * Resolves a safe right-side camera drag anchor so dragging aim to the enemy's head never
     * touches the left-side movement joystick.
     */
    fun resolveCameraDragAnchor(
        rule: AiTriggerRule,
        screenW: Int,
        screenH: Int
    ): Pair<Float, Float> {
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val useTargetAim = rule.targetAimNormX >= 0.52f
        val normX = if (useTargetAim) rule.targetAimNormX else 0.76f
        val normY = if (useTargetAim) rule.targetAimNormY else 0.54f
        return (normX * safeW).coerceIn(24f, (safeW - 24).toFloat()) to
            (normY * safeH).coerceIn(24f, (safeH - 24).toFloat())
    }

    private fun resolveTouchEngineLabel(): String {
        val st = ShizukuBridge.status.value
        return when {
            st.isKernelMultiTouch -> "Kernel Multi-Jari"
            st.canRunPrivileged && ShizukuBridge.binderMotionBlocked -> "Perlu Debugging Keamanan"
            st.canRunPrivileged -> "Nubia Stylus Async"
            else -> "Butuh Shizuku"
        }
    }

    fun refreshStatusSnapshot(prefs: BoosterPreferences) {
        val master = prefs.aiTriggerMasterEnabled.value
        val rules = prefs.aiTriggerRules.value
        val activeList = rules.filter { it.enabled && it.hasValidTemplate() }
        val displayRule = activeList.firstOrNull() ?: prefs.aiDraftRule.value ?: rules.firstOrNull()
        val hasProj = AiTriggerCaptureManager.isProjectionActive()
        val st = ShizukuBridge.status.value
        val hasPriv = st.canRunPrivileged
        val (cw, ch) = AiTriggerCaptureManager.projectionDimensions.value
        val label = when {
            hasProj -> "MediaProjection Live (${cw}x${ch})"
            hasPriv && master -> "Shizuku Backup Capture"
            hasPriv -> "Siap (Shizuku / Izin Layar)"
            else -> "Butuh Izin Rekam Layar"
        }
        val injError = ShizukuBridge.lastInjectionError
        val capError = lastCaptureErrorMsg
        val missingError = when {
            !capError.isNullOrBlank() -> capError
            master && !hasProj && !hasPriv -> "Butuh Izin Rekam Layar & Shizuku"
            master && !hasPriv -> "Butuh Shizuku agar aim tempel kepala jalan"
            !injError.isNullOrBlank() -> injError
            else -> null
        }
        _runtimeState.value = _runtimeState.value.copy(
            masterEnabled = master,
            isCapturing = hasProj || (loopJob?.isActive == true && hasPriv),
            hasProjectionPermission = hasProj,
            captureEngineLabel = label,
            lastTouchEngineStatus = resolveTouchEngineLabel(),
            activeRulesCount = activeList.size,
            activeCrosshairNormX = displayRule?.gameCrosshairNormX ?: 0.50f,
            activeCrosshairNormY = displayRule?.gameCrosshairNormY ?: 0.50f,
            activeContactRadiusPercent = displayRule?.contactRadiusPercent ?: 28,
            showLiveHud = activeList.any { it.showLiveHud },
            lastError = missingError
        )
    }

    fun syncLoop(context: Context, prefs: BoosterPreferences) {
        val master = prefs.aiTriggerMasterEnabled.value
        val activeRules = prefs.aiTriggerRules.value.filter { it.enabled && it.hasValidTemplate() }
        refreshStatusSnapshot(prefs)
        if (master && activeRules.isNotEmpty()) {
            if (loopJob?.isActive != true) {
                startLoop(context.applicationContext, prefs)
            }
        } else {
            stopLoop(prefs)
        }
    }

    fun stopLoop(prefs: BoosterPreferences? = null) {
        loopJob?.cancel()
        loopJob = null
        engineScope.launch {
            releaseCameraFinger()
        }
        if (prefs != null) {
            refreshStatusSnapshot(prefs)
        } else {
            val hasProj = AiTriggerCaptureManager.isProjectionActive()
            _runtimeState.value = _runtimeState.value.copy(
                masterEnabled = false,
                isCapturing = hasProj,
                hasProjectionPermission = hasProj,
                isMatched = false,
                crosshairTouchingBody = false,
                isAimingToHead = false,
                showLiveHud = false,
                captureEngineLabel = if (hasProj) "MediaProjection Standby" else "Nonaktif"
            )
        }
    }

    /**
     * Tests real head-lock camera tracking swipe in the right-side camera zone so the user can
     * verify smooth head alignment injection immediately in-game.
     */
    suspend fun testHeadTriggerSwipe(
        context: Context,
        @Suppress("UNUSED_PARAMETER") prefs: BoosterPreferences,
        rule: AiTriggerRule
    ): Pair<Boolean, String> {
        val st = ShizukuBridge.refresh(context, autoTriggerIfReady = true)
        if (!st.canRunPrivileged) {
            return false to "Shizuku/Root belum aktif. Aktifkan Shizuku dulu agar Aim Kepala bisa menggeser kamera."
        }
        val (screenW, screenH, rotation, _) = queryScreenAndRotation(context)
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val (startX, startY) = resolveCameraDragAnchor(rule, safeW, safeH)
        val liftPx = (min(safeW, safeH) * 0.11f * (rule.headLiftPower / 100f))
            .coerceIn(42f, min(safeW, safeH) * 0.24f)
        val endY = (startY - liftPx).coerceIn(16f, (safeH - 16).toFloat())

        val ok = ShizukuBridge.injectSwipe(
            x1 = startX,
            y1 = startY,
            x2 = startX,
            y2 = endY,
            durationMs = 85L,
            mode = selectCameraSlot().first,
            screenW = safeW,
            screenH = safeH,
            rotation = rotation,
            slotOffset = 1
        )
        return if (ok) {
            true to "Tes tarik aim ke kepala terkirim via ${resolveTouchEngineLabel()}!"
        } else {
            false to (ShizukuBridge.lastInjectionError
                ?: "Input ditolak sistem. Cek 'Debugging USB (Setelan Keamanan)' di Opsi Developer.")
        }
    }

    private fun selectCameraSlot(): Pair<MacroInjectionMode, Int> {
        val mode = if (ShizukuBridge.isKernelMultiTouchActive()) {
            MacroInjectionMode.SMART_POINTER
        } else {
            // Non-root devices keep AI camera tracking on STYLUS_HYBRID so physical fingers never collide
            MacroInjectionMode.STYLUS_HYBRID
        }
        return mode to 1
    }

    private suspend fun releaseCameraFinger() {
        camSession.stickyUntilMs = 0L
        camSession.alignedSinceMs = 0L
        camSession.emaDx = 0f
        camSession.emaDy = 0f
        if (!camSession.isDown) return
        val x = camSession.curX
        val y = camSession.curY
        val dt = camSession.downTimeMs
        val mode = camSession.mode
        val sw = camSession.screenW
        val sh = camSession.screenH
        val rot = camSession.rotation
        val slot = camSession.slotOffset
        camSession.isDown = false
        ShizukuBridge.injectMotion(
            action = MotionEvent.ACTION_UP,
            x = x,
            y = y,
            downTime = dt,
            mode = mode,
            screenW = sw,
            screenH = sh,
            rotation = rot,
            slotOffset = slot
        )
    }

    private suspend fun trackCameraStep(
        rule: AiTriggerRule,
        dxPx: Float,
        dyPx: Float,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ) {
        val (selectedMode, slot) = selectCameraSlot()
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val (anchorX, anchorY) = resolveCameraDragAnchor(rule, safeW, safeH)
        val now = SystemClock.uptimeMillis()

        camSession.lastSeenMs = now
        camSession.screenW = safeW
        camSession.screenH = safeH
        camSession.rotation = rotation

        val stepDist = hypot(dxPx.toDouble(), dyPx.toDouble()).toFloat()
        if (stepDist < 1.2f) {
            // Once crosshair settles on head for >=70ms, release virtual finger promptly so screen stays 100% free
            if (camSession.alignedSinceMs == 0L) {
                camSession.alignedSinceMs = now
            } else if (camSession.isDown && (now - camSession.alignedSinceMs) >= 70L) {
                releaseCameraFinger()
            }
            return
        }
        camSession.alignedSinceMs = 0L

        // Never run slow shell `input touchscreen swipe` inside live tracking; it locks physical touch for ~120ms+
        if (ShizukuBridge.binderMotionBlocked && !ShizukuBridge.isKernelMultiTouchActive()) {
            releaseCameraFinger()
            return
        }

        // Nubia/RedMagic subtle EMA stabilizer reduces micro-jitter when locked on target
        val smoothAlpha = 0.72f
        val filtDx = if (!camSession.isDown) dxPx else (camSession.emaDx * (1f - smoothAlpha) + dxPx * smoothAlpha)
        val filtDy = if (!camSession.isDown) dyPx else (camSession.emaDy * (1f - smoothAlpha) + dyPx * smoothAlpha)
        camSession.emaDx = filtDx
        camSession.emaDy = filtDy

        val maxRadius = min(safeW, safeH) * 0.28f
        val needRecenter = camSession.isDown && (
            camSession.slotOffset != slot ||
                hypot((camSession.curX - camSession.anchorX).toDouble(), (camSession.curY - camSession.anchorY).toDouble()) > maxRadius ||
                camSession.curX !in 24f..(safeW - 24f) ||
                camSession.curY !in 24f..(safeH - 24f)
            )

        if (needRecenter) {
            releaseCameraFinger()
            delay(4L)
        }

        var justPressed = false
        if (!camSession.isDown) {
            val startDownTime = SystemClock.uptimeMillis()
            val okDown = ShizukuBridge.injectMotion(
                action = MotionEvent.ACTION_DOWN,
                x = anchorX,
                y = anchorY,
                downTime = startDownTime,
                mode = selectedMode,
                screenW = safeW,
                screenH = safeH,
                rotation = rotation,
                slotOffset = slot
            )
            if (okDown) {
                camSession.isDown = true
                camSession.downTimeMs = startDownTime
                camSession.anchorX = anchorX
                camSession.anchorY = anchorY
                camSession.curX = anchorX
                camSession.curY = anchorY
                camSession.mode = selectedMode
                camSession.slotOffset = slot
                justPressed = true
                delay(4L)
            } else {
                return
            }
        }

        val startX = camSession.curX
        val startY = camSession.curY
        // Compensate game camera touch-slop (~12px) on initial ACTION_DOWN -> ACTION_MOVE
        val filtDist = hypot(filtDx.toDouble(), filtDy.toDouble()).toFloat().coerceAtLeast(0.5f)
        val moveScale = if (justPressed && filtDist < 20f) (20f / filtDist).coerceAtMost(2.0f) else 1f
        val targetX = (startX + filtDx * moveScale).coerceIn(20f, (safeW - 20).toFloat())
        val targetY = (startY + filtDy * moveScale).coerceIn(20f, (safeH - 20).toFloat())

        val totalDx = targetX - startX
        val totalDy = targetY - startY
        val moveDist = hypot(totalDx.toDouble(), totalDy.toDouble()).toFloat()
        val subSteps = if (justPressed) {
            ceil(moveDist / 24f).toInt().coerceIn(1, 2)
        } else {
            1
        }

        for (i in 1..subSteps) {
            val t = i.toFloat() / subSteps.toFloat()
            val sx = startX + totalDx * t
            val sy = startY + totalDy * t
            val okMove = ShizukuBridge.injectMotion(
                action = MotionEvent.ACTION_MOVE,
                x = sx,
                y = sy,
                downTime = camSession.downTimeMs,
                mode = camSession.mode,
                screenW = safeW,
                screenH = safeH,
                rotation = rotation,
                slotOffset = camSession.slotOffset
            )
            if (okMove) {
                camSession.curX = sx
                camSession.curY = sy
            } else {
                camSession.isDown = false
                break
            }
            if (i < subSteps) delay(3L)
        }
    }

    private fun startLoop(appContext: Context, prefs: BoosterPreferences) {
        loopJob?.cancel()
        loopJob = engineScope.launch {
            var lastTickStatusSyncMs = 0L
            var lastScannedFrameTs = -1L
            var cachedMetrics: ScreenMetricsData? = null
            var lastMetricsFetchMs = 0L
            try {
                while (isActive) {
                    val master = prefs.aiTriggerMasterEnabled.value
                    val rules = prefs.aiTriggerRules.value.filter { it.enabled && it.hasValidTemplate() }
                    if (!master || rules.isEmpty()) {
                        releaseCameraFinger()
                        break
                    }

                    if (prefs.overlayPanelExpanded.value ||
                        prefs.aiCropOverlayMode.value ||
                        prefs.aiTargetPickerMode.value ||
                        prefs.macroPlacementMode.value ||
                        AiTriggerCaptureManager.awaitingConsentPrompt
                    ) {
                        releaseCameraFinger()
                        delay(140L)
                        continue
                    }

                    val hasProj = AiTriggerCaptureManager.isProjectionActive()
                    val nowBefore = SystemClock.uptimeMillis()
                    if (cachedMetrics == null || (nowBefore - lastMetricsFetchMs) > 1500L) {
                        cachedMetrics = queryScreenAndRotation(appContext)
                        lastMetricsFetchMs = nowBefore
                        if (hasProj) {
                            runCatching { AiTriggerCaptureManager.syncOrientationIfNeeded(appContext) }
                        }
                    }

                    if (hasProj && lastScannedFrameTs > 0L &&
                        AiTriggerCaptureManager.getLatestFrame()?.timestampMs == lastScannedFrameTs
                    ) {
                        AiTriggerCaptureManager.awaitNextFrame(36L)
                    }

                    var frame = AiTriggerCaptureManager.getLatestFrame()
                    val now = SystemClock.uptimeMillis()
                    val frameFresh = frame != null && (now - frame.timestampMs) <= 1200L

                    // Never hammer `screencap -p` under 850ms: PNG encode/decode causes severe SurfaceFlinger stutter
                    if (!hasProj && (!frameFresh || (now - lastTickStatusSyncMs) > 850L)) {
                        frame = AiTriggerCaptureManager.captureFrameViaShizukuFallback(appContext)
                        lastTickStatusSyncMs = SystemClock.uptimeMillis()
                    }

                    if (frame == null) {
                        if (now > camSession.stickyUntilMs && (now - camSession.lastSeenMs) > 120L) {
                            releaseCameraFinger()
                        }
                        refreshStatusSnapshot(prefs)
                        delay(150L)
                        continue
                    }
                    if (hasProj && frame.timestampMs == lastScannedFrameTs) {
                        // Release held finger quickly if screen frame didn't update (static pause menu, etc.)
                        if (camSession.isDown && (now - camSession.lastSeenMs) > 110L) {
                            releaseCameraFinger()
                        }
                        delay(30L)
                        continue
                    }
                    lastScannedFrameTs = frame.timestampMs

                    val metrics = cachedMetrics ?: queryScreenAndRotation(appContext).also {
                        cachedMetrics = it
                        lastMetricsFetchMs = now
                    }
                    val (screenW, screenH, rotation, _) = metrics

                    val scanStartMs = SystemClock.uptimeMillis()
                    var bestScore = 0
                    var bestRule: AiTriggerRule? = null
                    var bestMatch: AiTriggerMatcher.MatchResult? = null
                    var anyMatched = false
                    var anyTouchingBody = false
                    var firedRule: AiTriggerRule? = null
                    var aimingToHead = false

                    for (rule in rules) {
                        val prepared = getOrPrepareTemplate(prefs, rule, frame.width, frame.height) ?: continue
                        val match = AiTriggerMatcher.match(
                            framePixels = frame.argbPixels,
                            frameW = frame.width,
                            frameH = frame.height,
                            template = prepared,
                            rule = rule
                        )
                        if (match.scorePercent > bestScore) {
                            bestScore = match.scorePercent
                            bestRule = rule
                            bestMatch = match
                        }
                        if (match.matched) {
                            anyMatched = true
                        }
                        val triggered = match.matched &&
                            (match.touchingCrosshair || rule.autoTriggerAllZones)
                        if (triggered) {
                            anyTouchingBody = true
                            bestRule = rule
                            bestMatch = match
                            val curNow = SystemClock.uptimeMillis()
                            aimingToHead = true
                            camSession.stickyUntilMs = curNow + 110L

                            val (stepDx, stepDy) = computeHeadTriggerStepPx(
                                headTargetNormX = match.headNormX,
                                headTargetNormY = match.headNormY,
                                crosshairNormX = rule.gameCrosshairNormX,
                                crosshairNormY = rule.gameCrosshairNormY,
                                screenW = screenW,
                                screenH = screenH,
                                headLiftPower = rule.headLiftPower,
                                deadbandPx = 4f
                            )
                            trackCameraStep(
                                rule = rule,
                                dxPx = stepDx,
                                dyPx = stepDy,
                                screenW = screenW,
                                screenH = screenH,
                                rotation = rotation
                            )
                            val lastFire = lastFireMsMap[rule.id] ?: 0L
                            if (curNow - lastFire >= rule.minIntervalMs) {
                                lastFireMsMap[rule.id] = curNow
                                firedRule = rule
                            }
                            break
                        }
                    }

                    val postScanMs = SystemClock.uptimeMillis()
                    val scanLatency = (postScanMs - scanStartMs).toInt().coerceAtLeast(1)

                    if (!aimingToHead && camSession.isDown && postScanMs > camSession.stickyUntilMs) {
                        releaseCameraFinger()
                    }

                    val st = ShizukuBridge.status.value
                    val canInject = st.canRunPrivileged
                    val activeRule = bestRule ?: rules.first()
                    val curState = _runtimeState.value
                    _runtimeState.value = curState.copy(
                        masterEnabled = true,
                        isCapturing = hasProj || canInject,
                        hasProjectionPermission = hasProj,
                        captureEngineLabel = if (hasProj) {
                            "MediaProjection Live (${frame.width}x${frame.height})"
                        } else {
                            "Shizuku Capture (${frame.width}x${frame.height})"
                        },
                        lastTouchEngineStatus = resolveTouchEngineLabel(),
                        activeRulesCount = rules.size,
                        lastMatchScore = bestScore,
                        isMatched = anyMatched,
                        crosshairTouchingBody = anyTouchingBody,
                        isAimingToHead = anyTouchingBody && aimingToHead,
                        scanLatencyMs = scanLatency,
                        matchedLeftNorm = bestMatch?.bestLeftNorm ?: curState.matchedLeftNorm,
                        matchedTopNorm = bestMatch?.bestTopNorm ?: curState.matchedTopNorm,
                        matchedRightNorm = bestMatch?.bestRightNorm ?: curState.matchedRightNorm,
                        matchedBottomNorm = bestMatch?.bestBottomNorm ?: curState.matchedBottomNorm,
                        matchedBodyNormX = bestMatch?.bestBodyNormX ?: activeRule.gameCrosshairNormX,
                        matchedBodyNormY = bestMatch?.bestBodyNormY ?: activeRule.gameCrosshairNormY,
                        headTargetNormX = bestMatch?.headNormX ?: activeRule.gameCrosshairNormX,
                        headTargetNormY = bestMatch?.headNormY ?: (activeRule.gameCrosshairNormY - 0.06f).coerceAtLeast(0.02f),
                        activeCrosshairNormX = activeRule.gameCrosshairNormX,
                        activeCrosshairNormY = activeRule.gameCrosshairNormY,
                        activeContactRadiusPercent = activeRule.contactRadiusPercent,
                        showLiveHud = rules.any { it.showLiveHud },
                        lastBestRuleName = bestRule?.name ?: curState.lastBestRuleName,
                        lastTriggeredRuleName = firedRule?.name ?: curState.lastTriggeredRuleName,
                        triggerCount = if (firedRule != null) curState.triggerCount + 1L else curState.triggerCount,
                        captureWidth = frame.width,
                        captureHeight = frame.height,
                        lastError = when {
                            !canInject -> "Shizuku belum aktif untuk aim kepala"
                            !ShizukuBridge.lastInjectionError.isNullOrBlank() -> ShizukuBridge.lastInjectionError
                            else -> lastCaptureErrorMsg
                        }
                    )

                    // Smooth zero-stutter pacing (~23 Hz max scan rate so game thread always keeps GPU/CPU headroom)
                    if (!hasProj) {
                        delay(260L)
                    } else {
                        val remainingMs = (42L - scanLatency).coerceAtLeast(12L)
                        delay(remainingMs)
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                lastCaptureErrorMsg = "Scan layar terhenti sementara: ${t.message ?: t.javaClass.simpleName}"
                _runtimeState.value = _runtimeState.value.copy(
                    isAimingToHead = false,
                    crosshairTouchingBody = false,
                    lastError = lastCaptureErrorMsg
                )
            } finally {
                withContext(NonCancellable) {
                    runCatching { releaseCameraFinger() }
                }
                runCatching { refreshStatusSnapshot(prefs) }
            }
        }
    }

    private fun getOrPrepareTemplate(
        prefs: BoosterPreferences,
        rule: AiTriggerRule,
        frameW: Int,
        frameH: Int
    ): AiTriggerMatcher.PreparedTemplate? {
        val key = CacheKey(
            ruleId = rule.id,
            path = rule.templatePath,
            widthPx = rule.templateWidth,
            heightPx = rule.templateHeight,
            frameW = frameW,
            frameH = frameH
        )
        templateCache[key]?.let { return it }

        val bmp = prefs.loadAiTemplateBitmap(rule.templatePath) ?: return null
        return try {
            if (bmp.isRecycled || bmp.width <= 0 || bmp.height <= 0) return null
            val cropW = (rule.cropRightNorm - rule.cropLeftNorm).coerceIn(0.015f, 0.9f)
            val cropH = (rule.cropBottomNorm - rule.cropTopNorm).coerceIn(0.015f, 0.9f)
            val prepared = AiTriggerMatcher.prepareFromBitmap(bmp, cropW, cropH, frameW, frameH)
            if (prepared != null) {
                templateCache[key] = prepared
            }
            prepared
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { if (!bmp.isRecycled) bmp.recycle() }
        }
    }

    private data class ScreenMetricsData(
        val width: Int,
        val height: Int,
        val rotation: Int,
        val density: Float
    )

    private fun queryScreenAndRotation(context: Context): ScreenMetricsData {
        val density = context.resources.displayMetrics.density
        runCatching {
            val dmService = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val display = dmService?.getDisplay(Display.DEFAULT_DISPLAY)
            if (display != null) {
                val dm = DisplayMetrics()
                @Suppress("DEPRECATION")
                display.getRealMetrics(dm)
                val rot = runCatching { display.rotation }.getOrDefault(Surface.ROTATION_0)
                if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                    return ScreenMetricsData(dm.widthPixels, dm.heightPixels, rot, dm.density)
                }
            }
        }
        runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (wm != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val b = wm.currentWindowMetrics.bounds
                    val rot = runCatching { context.display?.rotation ?: Surface.ROTATION_0 }.getOrDefault(Surface.ROTATION_0)
                    if (b.width() > 0 && b.height() > 0) {
                        return ScreenMetricsData(b.width(), b.height(), rot, density)
                    }
                } else {
                    val dm = DisplayMetrics()
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay?.getRealMetrics(dm)
                    @Suppress("DEPRECATION")
                    val rot = runCatching { wm.defaultDisplay?.rotation ?: Surface.ROTATION_0 }.getOrDefault(Surface.ROTATION_0)
                    if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                        return ScreenMetricsData(dm.widthPixels, dm.heightPixels, rot, dm.density)
                    }
                }
            }
        }
        val resDm = context.resources.displayMetrics
        return ScreenMetricsData(
            resDm.widthPixels.coerceAtLeast(720),
            resDm.heightPixels.coerceAtLeast(1280),
            Surface.ROTATION_0,
            density
        )
    }
}
