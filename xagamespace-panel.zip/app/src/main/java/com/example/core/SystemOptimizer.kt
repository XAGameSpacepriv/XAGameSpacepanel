package com.example.core

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.LruCache
import android.view.WindowManager
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.BoosterPreferences
import com.example.data.UadDatabase
import com.example.model.AngleRuntimeReport
import com.example.model.AntiMistouchConfig
import com.example.model.BurikConfig
import com.example.model.BurikPreset
import com.example.model.BypassChargingStatus
import com.example.model.CompatibilityReport
import com.example.model.DebloatAppEntry
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.GameEntry
import com.example.model.MaxScreenResponseConfig
import com.example.model.PerformanceProfile
import com.example.model.ScreenResponseStatus
import com.example.model.ThermalConfig
import com.example.model.ThermalStatus
import com.example.model.TouchConfig
import com.example.model.TouchDriverStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

data class BoostResult(
    val scoreAfter: Int,
    val freedMb: Long,
    val killedProcesses: Int,
    val privilegedApplied: Boolean,
    val summary: String
)

data class ActionFeedback(
    val success: Boolean,
    val message: String
)

/**
 * Core Android system optimizer connecting standard Android APIs (ActivityManager, PackageManager,
 * NotificationManager, Settings) with privileged Root (UID 0) or Shizuku (Non-Root) commands.
 */
class SystemOptimizer(
    private val context: Context,
    private val prefs: BoosterPreferences
) {
    private val appContext = context.applicationContext
    private val pm: PackageManager = appContext.packageManager
    private val am: ActivityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    private val iconCache = object : LruCache<String, ImageBitmap>(120) {}

    @Volatile
    private var cachedPhysicalDensityDpi: Int = 0

    private data class BypassNodeSpec(
        val path: String,
        val enableVal: String,
        val disableVal: String,
        val label: String
    )

    private val bypassChargingNodes = listOf(
        BypassNodeSpec("/sys/class/power_supply/battery/input_suspend", "1", "0", "Qualcomm input_suspend"),
        BypassNodeSpec("/sys/class/power_supply/battery/charging_enabled", "0", "1", "Battery charging_enabled"),
        BypassNodeSpec("/sys/class/power_supply/battery/battery_charging_enabled", "0", "1", "Battery charge_switch"),
        BypassNodeSpec("/sys/class/power_supply/battery/store_mode", "1", "0", "Samsung store_mode"),
        BypassNodeSpec("/sys/class/power_supply/battery/mmi_charging_enable", "0", "1", "Motorola mmi_charging"),
        BypassNodeSpec("/sys/class/power_supply/battery/charge_disable", "1", "0", "Generic charge_disable"),
        BypassNodeSpec("/sys/class/qcom-battery/input_suspend", "1", "0", "QCOM Battery suspend"),
        BypassNodeSpec("/proc/mtk_battery_cmd/current_cmd", "0 1", "0 0", "MediaTek current_cmd")
    )

    fun getAppIcon(packageName: String): ImageBitmap? {
        iconCache.get(packageName)?.let { return it }
        return runCatching {
            val drawable = pm.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable, 96)
            val img = bitmap.asImageBitmap()
            iconCache.put(packageName, img)
            img
        }.getOrNull()
    }

    private fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return Bitmap.createScaledBitmap(drawable.bitmap, sizePx, sizePx, true)
        }
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    suspend fun scanLaunchableApps(addedPackages: Set<String>): List<GameEntry> =
        withContext(Dispatchers.IO) {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
            }

            val seen = HashSet<String>()
            val results = mutableListOf<GameEntry>()

            for (ri in resolveInfos) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == appContext.packageName || !seen.add(pkg)) continue
                val appInfo = ri.activityInfo.applicationInfo
                val label = ri.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg

                val isGame = isLikelyGame(appInfo, pkg)
                results.add(
                    GameEntry(
                        packageName = pkg,
                        name = label,
                        isGameCategory = isGame,
                        isAdded = addedPackages.contains(pkg),
                        compileStatus = prefs.compileStatusFor(pkg),
                        burikOverride = prefs.perGameBurik.value[pkg]
                    )
                )
            }

            results.sortedWith(
                compareByDescending<GameEntry> { it.isAdded }
                    .thenByDescending { it.isGameCategory }
                    .thenBy { it.name.lowercase() }
            )
        }

    private fun isLikelyGame(appInfo: ApplicationInfo, pkg: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && appInfo.category == ApplicationInfo.CATEGORY_GAME) {
            return true
        }
        @Suppress("DEPRECATION")
        if ((appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return true
        val lower = pkg.lowercase()
        val keywords = listOf(
            "game", "freefire", "dts.freefire", "garena", "pubg", "krafton", "tencent",
            "mobilelegends", "mobile.legends", "genshin", "hoyoverse", "mihoyo", "kurogame",
            "roblox", "minecraft", "mojang", "codm", "activision", "mostwanted", "valorant",
            "riotgames", "wildrift", "efootball", "konami", "supercell", "brawlstars",
            "clashroyale", "clashofclans", "levelinfinite", "proxima", "netease", "bloodstrike",
            "deltaforce", "arenaofvalor", "honorofkings", "pearlabyss", "lilithgame", "carx",
            "stumbleguys", "gameloft", "rockstargames", "epicgames", "innersloth", "ea.gp"
        )
        return keywords.any { lower.contains(it) }
    }

    suspend fun scanDebloatPackages(): List<DebloatAppEntry> = withContext(Dispatchers.IO) {
        val flags = PackageManager.MATCH_UNINSTALLED_PACKAGES
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }

        packages.mapNotNull { pi ->
            val appInfo = pi.applicationInfo ?: return@mapNotNull null
            if (pi.packageName == appContext.packageName) return@mapNotNull null
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val isInstalledForUser = (appInfo.flags and ApplicationInfo.FLAG_INSTALLED) != 0 && appInfo.enabled
            val (category, desc) = UadDatabase.classify(pi.packageName, appInfo)
            val label = runCatching { pm.getApplicationLabel(appInfo).toString() }
                .getOrDefault(pi.packageName)

            DebloatAppEntry(
                packageName = pi.packageName,
                appName = label,
                category = category,
                description = desc,
                isInstalled = isInstalledForUser,
                isSystemApp = isSystem
            )
        }.sortedWith(
            compareByDescending<DebloatAppEntry> { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
    }

    suspend fun performBoost(): BoostResult = withContext(Dispatchers.IO) {
        val beforeMem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(beforeMem)

        var killed = 0
        val addedGames = prefs.addedGames.value
        val installed = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        }.getOrDefault(emptyList())

        for (app in installed) {
            val pkg = app.packageName
            if (pkg == appContext.packageName || addedGames.contains(pkg)) continue
            if ((app.flags and ApplicationInfo.FLAG_PERSISTENT) == 0) {
                runCatching {
                    am.killBackgroundProcesses(pkg)
                    killed++
                }
            }
        }

        var privileged = false
        var engineLabel = "Standard RAM"
        val st = ShizukuBridge.refresh(appContext)
        if (prefs.canUsePrivileged(st)) {
            val cmds = buildList {
                add("pm trim-caches 128000000 2>/dev/null ; true")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    add("cmd power set-fixed-performance-mode-enabled true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    addedGames.take(16).forEach { gamePkg ->
                        add("cmd game mode performance $gamePkg")
                    }
                }
                if (prefs.touchConfig.value.nubiaGameTweakEnabled) {
                    add("settings put system speed_up_touch 1")
                    add("settings put secure touch_blocking_period 0.0")
                    if (isNubiaOrRedMagicDevice()) {
                        add("settings put global nubia_game_mode 1")
                    }
                    if (prefs.useRoot.value && st.isRootGranted) {
                        add(nubiaRootTouchSysfsScript(enable = true))
                    }
                }
                if (prefs.fastAnimationEnabled.value) {
                    add("settings put global window_animation_scale 0.3")
                    add("settings put global transition_animation_scale 0.3")
                    add("settings put global animator_duration_scale 0.3")
                }
            }.joinToString(" ; ")
            val res = ShizukuBridge.execPrivileged(cmds)
            privileged = res.usedShizuku || res.usedRoot
            engineLabel = if (res.usedRoot) "Root + RAM" else if (res.usedShizuku) "Shizuku + RAM" else "Standard RAM"
        }

        if (prefs.dndOnSession.value) {
            val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                runCatching { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY) }
            }
        }

        val afterMem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(afterMem)
        val deltaBytes = (afterMem.availMem - beforeMem.availMem).coerceAtLeast(0L)
        val freedMb = (deltaBytes / (1024L * 1024L)).coerceAtLeast(if (killed > 0) 24L else 8L)

        val freeRatio = afterMem.availMem.toFloat() / afterMem.totalMem.coerceAtLeast(1L).toFloat()
        var score = (55 + (freeRatio * 35f).toInt()).coerceIn(60, 90)
        if (privileged) score = (score + 7).coerceAtMost(99)
        if (prefs.fastAnimationEnabled.value) score = (score + 3).coerceAtMost(99)
        if (prefs.maxScreenResponseConfig.value.enabled) score = (score + 2).coerceAtMost(99)
        prefs.setBoostScore(score)

        BoostResult(
            scoreAfter = score,
            freedMb = freedMb,
            killedProcesses = killed,
            privilegedApplied = privileged,
            summary = "Boost ($engineLabel): $freedMb MB dibebaskan, $killed proses latar dihentikan."
        )
    }

    suspend fun applyPerformanceProfile(
        profile: PerformanceProfile,
        targetPackages: List<String> = emptyList()
    ): ActionFeedback = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext ActionFeedback(
                false,
                "Profil ${profile.label} disimpan. Aktifkan Opsi 1 (Root) atau Opsi 2 (Shizuku) untuk menerapkan ke sistem."
            )
        }
        val pkgs = (targetPackages + prefs.addedGames.value).distinct().take(24)
        val cmds = mutableListOf<String>()
        when (profile) {
            PerformanceProfile.BATTERY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled false 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { cmds.add("cmd game mode battery $it 2>/dev/null ; true") }
                }
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add(
                        "for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do " +
                            "[ -w \"\$g\" ] && echo powersave > \"\$g\" 2>/dev/null; done; true"
                    )
                }
            }
            PerformanceProfile.BALANCED -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled false 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { cmds.add("cmd game mode standard $it 2>/dev/null ; true") }
                }
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add(
                        "for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do " +
                            "[ -w \"\$g\" ] && echo schedutil > \"\$g\" 2>/dev/null; done; true"
                    )
                }
            }
            PerformanceProfile.PRO_GAMER -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { cmds.add("cmd game mode performance $it 2>/dev/null ; true") }
                }
                cmds.add("settings put system speed_up_touch 1 2>/dev/null ; true")
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add(
                        "for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do " +
                            "[ -w \"\$g\" ] && echo schedutil > \"\$g\" 2>/dev/null; done; true"
                    )
                }
            }
            PerformanceProfile.ESPORT_TURBO -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cmds.add("cmd power set-fixed-performance-mode-enabled true 2>/dev/null ; true")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pkgs.forEach { cmds.add("cmd game mode performance $it 2>/dev/null ; true") }
                }
                cmds.add("settings put system speed_up_touch 1 2>/dev/null ; true")
                cmds.add("settings put secure touch_blocking_period 0.0 2>/dev/null ; true")
                if (prefs.useRoot.value && status.isRootGranted) {
                    cmds.add(
                        "for g in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do " +
                            "[ -w \"\$g\" ] && echo performance > \"\$g\" 2>/dev/null; done; true"
                    )
                }
            }
        }
        val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        val engine = if (res.usedRoot) "Root UID 0" else "Shizuku"
        ActionFeedback(
            res.success || res.usedRoot || res.usedShizuku,
            "Profil Performa ${profile.label} diterapkan via $engine (${pkgs.size} game)."
        )
    }

    suspend fun probeBypassChargingSupport(): BypassChargingStatus = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext BypassChargingStatus(
                supported = false,
                enabled = false,
                detail = "Hubungkan Root / Shizuku untuk memeriksa node Bypass Charging kernel."
            )
        }
        val probeCmd = bypassChargingNodes.joinToString(" ; ") { node ->
            "if [ -w '${node.path}' ]; then echo BNODE=${node.path}=$(cat '${node.path}' 2>/dev/null | head -n 1); fi"
        }
        val res = ShizukuBridge.execPrivileged(probeCmd)
        val match = Regex("BNODE=([^=\\n]+)=([^\\n]*)").find(res.output)
        if (match != null) {
            val foundPath = match.groupValues[1].trim()
            val curVal = match.groupValues[2].trim()
            val spec = bypassChargingNodes.firstOrNull { it.path == foundPath }
            val isOn = spec != null && curVal == spec.enableVal
            BypassChargingStatus(
                supported = true,
                enabled = isOn,
                activeNodePath = foundPath,
                detail = if (isOn) {
                    "Bypass Charging AKTIF (${spec?.label ?: foundPath})"
                } else {
                    "Siap (${spec?.label ?: foundPath})"
                }
            )
        } else {
            BypassChargingStatus(
                supported = false,
                enabled = false,
                detail = "Node Bypass Charging kernel tidak writable di perangkat ini (umumnya perlu Root)."
            )
        }
    }

    suspend fun setBypassCharging(enable: Boolean): Pair<BypassChargingStatus, ActionFeedback> =
        withContext(Dispatchers.IO) {
            val probed = probeBypassChargingSupport()
            if (!probed.supported || probed.activeNodePath.isBlank()) {
                return@withContext probed to ActionFeedback(false, probed.detail)
            }
            val spec = bypassChargingNodes.firstOrNull { it.path == probed.activeNodePath }
                ?: return@withContext probed to ActionFeedback(false, "Node Bypass Charging tidak cocok.")
            val targetVal = if (enable) spec.enableVal else spec.disableVal
            val res = ShizukuBridge.execPrivileged("echo '$targetVal' > '${spec.path}'")
            val verified = probeBypassChargingSupport()
            val ok = res.success || verified.enabled == enable
            verified to ActionFeedback(
                ok,
                if (enable) "Bypass Charging diaktifkan (${spec.label})." else "Bypass Charging dimatikan (pengisian normal)."
            )
        }

    suspend fun applyThermalConfig(
        config: ThermalConfig,
        targetPackages: List<String> = emptyList()
    ): Pair<ThermalStatus, ActionFeedback> =
        ThermalEngine.applyThermalProfile(appContext, prefs, config, targetPackages)

    suspend fun applyThermalMaxCap(
        config: ThermalConfig,
        engageClamp: Boolean,
        targetPackages: List<String> = emptyList()
    ): Pair<ThermalStatus, ActionFeedback> =
        ThermalEngine.applyThermalMaxCap(appContext, prefs, config, engageClamp, targetPackages)

    suspend fun probeThermalStatus(guardTriggered: Boolean = false): ThermalStatus =
        ThermalEngine.probeThermalStatus(appContext, prefs, guardTriggered)

    suspend fun probeTouchDriverNodes(): TouchDriverStatus =
        TouchResponseEngine.probeTouchDriverNodes(appContext, prefs)

    suspend fun applyMaxScreenResponse(
        config: MaxScreenResponseConfig,
        activeGamePkg: String? = prefs.activeSessionGamePkg.value
    ): Pair<ScreenResponseStatus, ActionFeedback> =
        TouchResponseEngine.applyMaxScreenResponse(appContext, prefs, config, activeGamePkg)

    suspend fun probeScreenResponseStatus(
        config: MaxScreenResponseConfig = prefs.maxScreenResponseConfig.value
    ): ScreenResponseStatus =
        TouchResponseEngine.probeScreenResponseStatus(appContext, prefs, config)

    suspend fun applyAntiMistouch(config: AntiMistouchConfig): ActionFeedback = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext ActionFeedback(
                false,
                "Anti-Mistouch disimpan. Hubungkan Root / Shizuku untuk mengunci gestur tepi & notifikasi."
            )
        }
        val cmds = mutableListOf<String>()
        if (config.enabled) {
            if (config.immersiveFull || config.blockBackGesture || config.disableEdgeGestures) {
                cmds.add("settings put secure back_gesture_inset_scale_left 0.0")
                cmds.add("settings put secure back_gesture_inset_scale_right 0.0")
                if (config.immersiveFull || config.blockStatusBarPull) {
                    cmds.add("settings put global policy_control immersive.full=*")
                }
            }
            if (config.blockHeadsUp) {
                cmds.add("settings put global heads_up_notifications_enabled 0")
            }
            if (config.lockAutoBrightness) {
                cmds.add("settings put system screen_brightness_mode 0")
            }
            if (config.enableDnd) {
                cmds.add("cmd notification set_dnd priority 2>/dev/null ; true")
            }
        } else {
            cmds.add("settings delete secure back_gesture_inset_scale_left")
            cmds.add("settings delete secure back_gesture_inset_scale_right")
            cmds.add("settings delete global policy_control")
            cmds.add("settings put global heads_up_notifications_enabled 1")
            cmds.add("settings put system screen_brightness_mode 1")
            cmds.add("cmd notification set_dnd off 2>/dev/null ; true")
        }
        val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        ActionFeedback(
            res.success || res.usedRoot || res.usedShizuku,
            if (config.enabled) "Anti-Mistouch aktif (gestur tepi & pop-up notifikasi diblokir saat main)."
            else "Anti-Mistouch dimatikan (gestur & notifikasi kembali normal)."
        )
    }

    suspend fun applyFastAnimation(enabled: Boolean): ActionFeedback = withContext(Dispatchers.IO) {
        val scale = if (enabled) "0.3" else "1.0"
        val status = ShizukuBridge.refresh(appContext)
        if (prefs.canUsePrivileged(status)) {
            val res = ShizukuBridge.execPrivileged(
                "settings put global window_animation_scale $scale && " +
                    "settings put global transition_animation_scale $scale && " +
                    "settings put global animator_duration_scale $scale"
            )
            if (res.success || res.usedRoot || res.usedShizuku) {
                val engine = if (res.usedRoot) "Root" else "Shizuku"
                return@withContext ActionFeedback(
                    true,
                    if (enabled) "Animasi sistem disetel ke 0.3x via $engine." else "Animasi sistem dikembalikan ke 1.0x."
                )
            }
        }
        ActionFeedback(
            false,
            if (enabled) "Mode Animasi 0.3x aktif di profil (hubungkan Root / Shizuku untuk ubah skala global)."
            else "Animasi cepat dimatikan."
        )
    }

    suspend fun compilePackage(packageName: String, fullSpeed: Boolean = true): ActionFeedback =
        withContext(Dispatchers.IO) {
            val status = ShizukuBridge.refresh(appContext)
            if (!prefs.canUsePrivileged(status)) {
                return@withContext ActionFeedback(
                    false,
                    "Hubungkan Opsi 1 (Root) atau Opsi 2 (Shizuku) untuk menjalankan `cmd package compile`."
                )
            }
            val mode = if (fullSpeed) "speed" else "speed-profile"
            val res = ShizukuBridge.execPrivileged("cmd package compile -m $mode -f $packageName")
            if (res.success || res.output.contains("Success", ignoreCase = true)) {
                prefs.markCompiled(packageName, true)
                ActionFeedback(true, "$packageName berhasil di-compile ($mode).")
            } else {
                ActionFeedback(false, res.error.ifEmpty { "Gagal compile $packageName" })
            }
        }

    private fun getAllGamePackagesForAngle(explicitTargets: List<String>): List<String> {
        val pkgs = LinkedHashSet<String>()
        pkgs.addAll(explicitTargets)
        pkgs.addAll(prefs.addedGames.value)
        val installed = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
        }.getOrDefault(emptyList())
        for (app in installed) {
            if (app.packageName != appContext.packageName && isLikelyGame(app, app.packageName)) {
                pkgs.add(app.packageName)
            }
        }
        return pkgs.toList()
    }

    private fun isPackageInstalled(packageName: String): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, 0)
        }
        true
    }.getOrDefault(false)

    private fun detectInstalledAnglePackage(): String? {
        val candidates = listOf("com.android.angle", "com.google.android.angle", "org.chromium.angle")
        return candidates.firstOrNull { isPackageInstalled(it) }
    }

    private fun isSystemUiOrLauncher(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return pkg == appContext.packageName ||
            lower == "com.android.systemui" ||
            lower == "com.android.settings" ||
            lower.contains("launcher") ||
            lower == "android"
    }

    suspend fun forceStopPackage(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (packageName.isBlank() || isSystemUiOrLauncher(packageName)) return@withContext false
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) return@withContext false
        val res = ShizukuBridge.execPrivileged("am force-stop '$packageName'")
        res.success || res.usedShizuku || res.usedRoot
    }

    suspend fun resolvePrimaryGamePackage(explicitTargets: List<String> = emptyList()): String? =
        withContext(Dispatchers.IO) {
            prefs.activeSessionGamePkg.value?.takeIf { it.isNotBlank() && !isSystemUiOrLauncher(it) }
                ?.let { return@withContext it }
            explicitTargets.firstOrNull { it.isNotBlank() && !isSystemUiOrLauncher(it) }
                ?.let { return@withContext it }
            val fg = ShizukuBridge.getForegroundPackageViaShizuku()
            if (!fg.isNullOrBlank() && !isSystemUiOrLauncher(fg)) {
                return@withContext fg
            }
            prefs.addedGames.value.firstOrNull { !isSystemUiOrLauncher(it) }
        }

    suspend fun restartTargetGameForAngle(explicitPackage: String? = null): ActionFeedback =
        withContext(Dispatchers.IO) {
            val status = ShizukuBridge.refresh(appContext)
            if (!prefs.canUsePrivileged(status)) {
                return@withContext ActionFeedback(
                    false,
                    "Hubungkan Root / Shizuku agar game dapat di-restart otomatis dengan driver ANGLE."
                )
            }
            val targetPkg = explicitPackage?.takeIf { it.isNotBlank() }
                ?: resolvePrimaryGamePackage()
                ?: return@withContext ActionFeedback(
                    false,
                    "ANGLE diterapkan, tapi belum ada game target yang dipilih/berjalan. Buka game secara manual."
                )

            ShizukuBridge.execPrivileged("am force-stop '$targetPkg'")
            delay(380L)
            val launched = withContext(Dispatchers.Main) { launchGame(targetPkg) }
            if (launched) {
                prefs.setGameSessionActive(true, targetPkg)
                ActionFeedback(true, "Game $targetPkg di-restart ulang dengan driver ANGLE aktif.")
            } else {
                ActionFeedback(false, "Game $targetPkg dihentikan, silakan buka kembali dari Beranda.")
            }
        }

    suspend fun restoreAngleTextureOnly(): ActionFeedback = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext ActionFeedback(true, "Sesi berakhir — profil ANGLE disetel OFF.")
        }
        val cmds = mutableListOf(
            "settings put global angle_gl_driver_all_angle 0",
            "settings delete global angle_gl_driver_all_angle",
            "settings delete global angle_gl_driver_selection_pkgs",
            "settings delete global angle_gl_driver_selection_values",
            "settings delete global angle_egl_features",
            "settings delete global angle_debug_package"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && prefs.useRoot.value && status.isRootGranted) {
            cmds.add("setprop persist.graphics.egl \"\" 2>/dev/null ; true")
        }
        ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        ActionFeedback(true, "Driver ANGLE Texture dipulihkan ke OpenGL ES default.")
    }

    suspend fun applyBurik(
        targetPackages: List<String>,
        config: BurikConfig
    ): ActionFeedback = withContext(Dispatchers.IO) {
        val qualityPct = config.effectiveTextureQuality()
        val mipLevel = config.effectiveMipmapLevel()
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext ActionFeedback(
                false,
                "Profil ANGLE ${config.preset.title} ($qualityPct% • Mip$mipLevel) disimpan. Hubungkan Root / Shizuku untuk terapkan ke game."
            )
        }

        val liveForeground = ShizukuBridge.getForegroundPackageViaShizuku()
            ?.takeIf { it.isNotBlank() && !isSystemUiOrLauncher(it) }

        val basePkgs = LinkedHashSet<String>()
        prefs.activeSessionGamePkg.value?.takeIf { it.isNotBlank() && !isSystemUiOrLauncher(it) }?.let { basePkgs.add(it) }
        liveForeground?.let { basePkgs.add(it) }
        basePkgs.addAll(targetPackages.filter { it.isNotBlank() && !isSystemUiOrLauncher(it) })
        basePkgs.addAll(prefs.addedGames.value.filter { it.isNotBlank() && !isSystemUiOrLauncher(it) })
        if (config.applyAllGames) {
            basePkgs.addAll(getAllGamePackagesForAngle(targetPackages))
        }
        val resolvedPkgs = basePkgs.take(60)

        val cmds = mutableListOf<String>()
        if (config.preset == BurikPreset.OFF) {
            cmds.add("settings put global angle_gl_driver_all_angle 0")
            cmds.add("settings delete global angle_gl_driver_all_angle")
            cmds.add("settings delete global angle_gl_driver_selection_pkgs")
            cmds.add("settings delete global angle_gl_driver_selection_values")
            cmds.add("settings delete global angle_egl_features")
            cmds.add("settings delete global angle_debug_package")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && prefs.useRoot.value && status.isRootGranted) {
                cmds.add("setprop persist.graphics.egl \"\" 2>/dev/null ; true")
            }

            val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
            return@withContext ActionFeedback(
                res.success || res.usedShizuku || res.usedRoot,
                "ANGLE Texture dimatikan (kembali ke driver OpenGL ES bawaan). Restart game bila sedang berjalan."
            )
        }

        val features = config.angleFeatureFlags()
        val perPkgFeatures = features.joinToString(":")
        val installedAnglePkg = detectInstalledAnglePackage()

        cmds.add("setprop debug.graphics.angle.developeroption.enable true 2>/dev/null ; true")

        if (installedAnglePkg == "org.chromium.angle") {
            cmds.add("settings put global angle_debug_package org.chromium.angle")
        } else {
            cmds.add("settings delete global angle_debug_package")
        }

        if (config.applyAllGames) {
            cmds.add("settings put global angle_gl_driver_all_angle 1")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && prefs.useRoot.value && status.isRootGranted) {
                cmds.add("setprop persist.graphics.egl angle 2>/dev/null ; true")
            }
        } else {
            cmds.add("settings put global angle_gl_driver_all_angle 0")
            cmds.add("settings delete global angle_gl_driver_all_angle")
        }

        if (resolvedPkgs.isNotEmpty()) {
            val pkgCsv = resolvedPkgs.joinToString(",")
            val valCsv = List(resolvedPkgs.size) { "angle" }.joinToString(",")
            val featCsv = List(resolvedPkgs.size) { perPkgFeatures }.joinToString(",")
            cmds.add("settings put global angle_gl_driver_selection_pkgs '$pkgCsv'")
            cmds.add("settings put global angle_gl_driver_selection_values '$valCsv'")
            cmds.add("settings put global angle_egl_features '$featCsv'")
        } else {
            cmds.add("settings delete global angle_gl_driver_selection_pkgs")
            cmds.add("settings delete global angle_gl_driver_selection_values")
            cmds.add("settings put global angle_egl_features '$perPkgFeatures'")
        }

        val execRes = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
        val verifyRes = ShizukuBridge.execPrivileged(
            "echo ALL=$(settings get global angle_gl_driver_all_angle) ; " +
                "echo PKGS=$(settings get global angle_gl_driver_selection_pkgs) ; " +
                "echo VALS=$(settings get global angle_gl_driver_selection_values)"
        )
        val savedPkgs = Regex("PKGS=([^\\s]+)").find(verifyRes.output)?.groupValues?.getOrNull(1) ?: "null"
        val savedAll = Regex("ALL=([^\\s]+)").find(verifyRes.output)?.groupValues?.getOrNull(1) ?: "null"
        val persistedCount = if (savedPkgs == "null" || savedPkgs.isBlank()) 0 else savedPkgs.split(',').count { it.isNotBlank() }

        val scopeLabel = if (config.applyAllGames) {
            "All Games ($persistedCount paket)"
        } else {
            "$persistedCount game"
        }
        val restartNote = if (liveForeground != null || prefs.activeSessionGamePkg.value != null) {
            " • Tekan 'Restart Game' agar proses game memuat ulang ANGLE."
        } else {
            " • Aktif saat game dibuka."
        }
        val written = execRes.usedShizuku || execRes.usedRoot || savedAll == "1" || persistedCount > 0
        ActionFeedback(
            written,
            "ANGLE ${config.preset.title} [${features.joinToString(", ")}] diterapkan ($scopeLabel)$restartNote"
        )
    }

    suspend fun buildAngleRuntimeReport(config: BurikConfig): AngleRuntimeReport =
        withContext(Dispatchers.IO) {
            val installedPkg = detectInstalledAnglePackage()
            val status = ShizukuBridge.refresh(appContext)
            if (!prefs.canUsePrivileged(status)) {
                return@withContext AngleRuntimeReport(
                    shizukuReady = false,
                    angleDriverDetected = installedPkg != null,
                    angleProviderLabel = installedPkg ?: "Belum dicek (Root/Shizuku OFF)",
                    allAngleEnabled = false,
                    targetedPackagesCount = prefs.addedGames.value.size,
                    activeEglFeatures = config.angleFeatureFlags().joinToString(":"),
                    logcatConfirmed = false,
                    lastCheckSummary = "Hubungkan Opsi 1 (Root) atau Opsi 2 (Shizuku) untuk memeriksa driver ANGLE."
                )
            }

            val probe = ShizukuBridge.execPrivileged(
                "echo SUP=$(getprop ro.gfx.angle.supported) ; " +
                    "echo EGL=$(getprop persist.graphics.egl) ; " +
                    "echo DEVOPT=$(getprop debug.graphics.angle.developeroption.enable) ; " +
                    "echo ALL=$(settings get global angle_gl_driver_all_angle) ; " +
                    "echo PKGS=$(settings get global angle_gl_driver_selection_pkgs) ; " +
                    "echo FEAT=$(settings get global angle_egl_features) ; " +
                    "echo SOLIB=$(ls /system/lib64/egl/*angle* /vendor/lib64/egl/*angle* /system/lib/egl/*angle* 2>/dev/null | head -n 1) ; " +
                    "echo LOGANGLE=$(logcat -d -t 120 2>/dev/null | grep -iE 'ANGLE: Version|should use ANGLE.*true|ANGLE package enabled' | tail -n 1)"
            )
            val sup = Regex("SUP=([^\\n]*)").find(probe.output)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            val egl = Regex("EGL=([^\\n]*)").find(probe.output)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            val allFlag = Regex("ALL=([^\\s\\n]+)").find(probe.output)?.groupValues?.getOrNull(1) ?: "null"
            val pkgsVal = Regex("PKGS=([^\\s\\n]+)").find(probe.output)?.groupValues?.getOrNull(1) ?: "null"
            val featVal = Regex("FEAT=([^\\s\\n]+)").find(probe.output)?.groupValues?.getOrNull(1) ?: "null"
            val solib = Regex("SOLIB=([^\\n]*)").find(probe.output)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            val logAngle = Regex("LOGANGLE=([^\\n]*)").find(probe.output)?.groupValues?.getOrNull(1)?.trim().orEmpty()

            val pkgCount = if (pkgsVal == "null" || pkgsVal.isBlank()) 0 else pkgsVal.split(',').count { it.isNotBlank() }
            val hasSystemAngle = sup.equals("true", ignoreCase = true) ||
                sup == "1" ||
                egl.equals("angle", ignoreCase = true) ||
                solib.isNotBlank()
            val driverReady = installedPkg != null || hasSystemAngle || logAngle.isNotBlank()
            val providerLabel = when {
                installedPkg != null -> "APK: $installedPkg"
                hasSystemAngle -> "System ANGLE (${egl.ifBlank { "Vulkan" }})"
                else -> "ANGLE sistem tidak terdeteksi"
            }
            val summary = if (logAngle.isNotBlank()) {
                "ANGLE aktif di log: $logAngle"
            } else if (!driverReady) {
                "Perangkat ini tidak memiliki APK/library ANGLE bawaan (com.android.angle)."
            } else {
                "all_angle=$allFlag • Paket=$pkgCount • Provider=$providerLabel"
            }

            AngleRuntimeReport(
                shizukuReady = true,
                angleDriverDetected = driverReady,
                angleProviderLabel = providerLabel,
                allAngleEnabled = allFlag == "1",
                targetedPackagesCount = pkgCount,
                activeEglFeatures = if (featVal == "null") "" else featVal.substringBefore(','),
                logcatConfirmed = logAngle.isNotBlank(),
                lastCheckSummary = summary
            )
        }

    suspend fun inspectAngleStatus(config: BurikConfig): ActionFeedback = withContext(Dispatchers.IO) {
        val report = buildAngleRuntimeReport(config)
        val qualityPct = config.effectiveTextureQuality()
        val mipLevel = config.effectiveMipmapLevel()
        if (!report.shizukuReady) {
            return@withContext ActionFeedback(
                false,
                "Profil ANGLE (${config.preset.title} • $qualityPct% • Mip$mipLevel) siap. Hubungkan Root / Shizuku untuk memeriksa status ANGLE."
            )
        }
        val featInfo = report.activeEglFeatures.ifBlank { "none" }
        val logBadge = if (report.logcatConfirmed) " • Logcat: ANGLE Running" else ""
        ActionFeedback(
            report.angleDriverDetected,
            "${report.angleProviderLabel} • all_angle=${if (report.allAngleEnabled) "1" else "0"} • Paket=${report.targetedPackagesCount} • Flags=$featInfo$logBadge"
        )
    }

    suspend fun debloatPackage(packageName: String): ActionFeedback = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (prefs.canUsePrivileged(status)) {
            val res = ShizukuBridge.execPrivileged("pm uninstall -k --user 0 $packageName")
            if (res.success || res.output.contains("Success", ignoreCase = true)) {
                return@withContext ActionFeedback(true, "$packageName berhasil dihapus untuk user 0.")
            }
            val disableRes = ShizukuBridge.execPrivileged("pm disable-user --user 0 $packageName")
            if (disableRes.success || disableRes.output.contains("disabled", ignoreCase = true)) {
                return@withContext ActionFeedback(true, "$packageName dinonaktifkan untuk user 0.")
            }
            return@withContext ActionFeedback(false, res.error.ifEmpty { disableRes.error })
        }

        withContext(Dispatchers.Main) {
            runCatching {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
            }
        }
        ActionFeedback(false, "Membuka info aplikasi $packageName (aktifkan Root / Shizuku untuk hapus 1-klik).")
    }

    suspend fun restoreDebloatPackage(packageName: String): ActionFeedback = withContext(Dispatchers.IO) {
        val status = ShizukuBridge.refresh(appContext)
        if (!prefs.canUsePrivileged(status)) {
            return@withContext ActionFeedback(false, "Perlu Root / Shizuku untuk memulihkan paket sistem.")
        }
        val res = ShizukuBridge.execPrivileged(
            "cmd package install-existing $packageName ; pm enable $packageName"
        )
        if (res.success || res.output.contains("installed", ignoreCase = true) ||
            res.output.contains("enabled", ignoreCase = true)
        ) {
            ActionFeedback(true, "$packageName dipulihkan.")
        } else {
            ActionFeedback(false, res.error.ifEmpty { "Gagal memulihkan $packageName" })
        }
    }

    suspend fun readPhysicalDensityDpi(): Int = withContext(Dispatchers.IO) {
        if (cachedPhysicalDensityDpi > 0) return@withContext cachedPhysicalDensityDpi
        val status = ShizukuBridge.refresh(appContext)
        if (prefs.canUsePrivileged(status)) {
            val res = ShizukuBridge.execPrivileged("wm density")
            val match = Regex("Physical density:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(res.output)
            val parsed = match?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (parsed != null && parsed in 120..960) {
                cachedPhysicalDensityDpi = parsed
                return@withContext parsed
            }
        }
        appContext.resources.displayMetrics.densityDpi.coerceAtLeast(160)
    }

    private fun nubiaRootTouchSysfsScript(enable: Boolean): String {
        val v = if (enable) "1" else "0"
        return "for p in " +
            "/sys/devices/platform/nubia_goodix_tp/gamemode " +
            "/sys/devices/platform/nubia_synaptics_tp/gamemode " +
            "/sys/class/touch/touch_dev/bump_sample_rate " +
            "/sys/devices/virtual/touch/touch_dev/bump_sample_rate " +
            "/proc/touchpanel/game_switch_enable " +
            "/proc/touchpanel/report_rate; do " +
            "[ -w \"\$p\" ] && echo $v > \"\$p\" 2>/dev/null; done; true"
    }

    suspend fun applyTouchSensitivity(
        config: TouchConfig,
        applyDpiChange: Boolean = false
    ): ActionFeedback {
        val feedback = TouchResponseEngine.applyTouchResponse(
            context = appContext,
            prefs = prefs,
            config = config,
            activeGamePkg = prefs.activeSessionGamePkg.value
        )
        if (applyDpiChange && !config.enabled) {
            val status = ShizukuBridge.refresh(appContext)
            if (prefs.canUsePrivileged(status)) {
                ShizukuBridge.execPrivileged("wm density reset")
            }
        }
        return feedback
    }

    suspend fun applyFpsLock(targetPackages: List<String>, config: FpsLockConfig): ActionFeedback =
        withContext(Dispatchers.IO) {
            val resolvedPkgs = if (config.applyToAllGames) {
                getAllGamePackagesForAngle(targetPackages)
            } else {
                targetPackages.ifEmpty { prefs.addedGames.value.toList() }
            }

            val fps = config.target.fps
            val status = ShizukuBridge.refresh(appContext)
            if (prefs.canUsePrivileged(status)) {
                val cmds = mutableListOf<String>()
                if (config.target == FpsLockTarget.DEFAULT) {
                    cmds.add("settings delete system min_refresh_rate")
                    cmds.add("settings delete system peak_refresh_rate")
                    cmds.add("settings delete system user_refresh_rate")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        cmds.add("device_config set_sync_disabled_for_tests none")
                        resolvedPkgs.forEach { pkg ->
                            cmds.add("device_config delete game_overlay $pkg")
                            cmds.add("cmd game mode standard $pkg")
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                cmds.add("cmd game set --fps disable $pkg 2>/dev/null ; true")
                            }
                        }
                    }
                } else {
                    if (config.forceSystemRefreshRate) {
                        cmds.add("settings put system min_refresh_rate $fps")
                        cmds.add("settings put system peak_refresh_rate $fps")
                        cmds.add("settings put system user_refresh_rate $fps")
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        cmds.add("device_config set_sync_disabled_for_tests persistent")
                        val overlaySpec = "mode=2,fps=$fps:mode=3,fps=$fps"
                        resolvedPkgs.forEach { pkg ->
                            cmds.add("device_config put game_overlay $pkg $overlaySpec")
                            cmds.add("cmd game mode performance $pkg")
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                cmds.add("cmd game set --mode 2 --fps $fps $pkg 2>/dev/null ; true")
                            }
                        }
                    }
                }
                val res = ShizukuBridge.execPrivileged(cmds.joinToString(" ; "))
                return@withContext ActionFeedback(
                    res.success || res.usedShizuku || res.usedRoot,
                    if (config.target == FpsLockTarget.DEFAULT) {
                        "FPS Lock dimatikan (kembali ke refresh rate bawaan)."
                    } else {
                        "FPS Lock ${config.target.label} aktif (${resolvedPkgs.size} game + sistem ${fps}Hz)."
                    }
                )
            }

            if (Settings.System.canWrite(appContext)) {
                val ok = runCatching {
                    if (config.target == FpsLockTarget.DEFAULT) {
                        Settings.System.putFloat(appContext.contentResolver, "min_refresh_rate", 0f)
                        Settings.System.putFloat(appContext.contentResolver, "peak_refresh_rate", 0f)
                    } else {
                        Settings.System.putFloat(appContext.contentResolver, "min_refresh_rate", fps.toFloat())
                        Settings.System.putFloat(appContext.contentResolver, "peak_refresh_rate", fps.toFloat())
                    }
                }.getOrDefault(false)
                if (ok) {
                    return@withContext ActionFeedback(
                        true,
                        if (config.target == FpsLockTarget.DEFAULT) {
                            "Refresh rate sistem dikembalikan ke default."
                        } else {
                            "Refresh rate layar dikunci ke ${fps}Hz (Write Settings)."
                        }
                    )
                }
            }

            ActionFeedback(
                false,
                if (config.target == FpsLockTarget.DEFAULT) {
                    "FPS Lock disetel ke Default."
                } else {
                    "Profil FPS Lock ${config.target.label} disimpan. Aktifkan Root / Shizuku atau Write Settings untuk mengunci ${fps}Hz."
                }
            )
        }

    suspend fun restoreAllSessionTweaks(): ActionFeedback = withContext(Dispatchers.IO) {
        prefs.setGameSessionActive(false, null)
        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            runCatching { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL) }
        }
        val status = ShizukuBridge.refresh(appContext)
        if (prefs.canUsePrivileged(status)) {
            val games = getAllGamePackagesForAngle(emptyList())
            val restoreCmd = buildString {
                append("settings put global angle_gl_driver_all_angle 0 ; ")
                append("settings delete global angle_gl_driver_all_angle ; ")
                append("settings delete global angle_gl_driver_selection_pkgs ; ")
                append("settings delete global angle_gl_driver_selection_values ; ")
                append("settings delete global angle_egl_features ; ")
                append("settings delete global angle_debug_package ; ")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && prefs.useRoot.value && status.isRootGranted) {
                    append("setprop persist.graphics.egl \"\" 2>/dev/null ; true ; ")
                }
                append("settings delete system min_refresh_rate ; ")
                append("settings delete system peak_refresh_rate ; ")
                append("settings delete system user_refresh_rate ; ")
                append("settings put global window_animation_scale 1.0 ; ")
                append("settings put global transition_animation_scale 1.0 ; ")
                append("settings put global animator_duration_scale 1.0 ; ")
                append("settings put system pointer_speed 0 ; ")
                append("settings put system touch_sensitivity 0 ; ")
                append("settings put system high_touch_sensitivity_enabled 0 ; ")
                append("settings delete system speed_up_touch ; ")
                append("settings delete secure touch_blocking_period ; ")
                if (isNubiaOrRedMagicDevice()) {
                    append("settings put global nubia_game_mode 0 ; ")
                }
                if (prefs.useRoot.value && status.isRootGranted) {
                    append(nubiaRootTouchSysfsScript(enable = false)).append(" ; ")
                }
                append("settings delete secure tap_duration_threshold ; ")
                append("settings put secure long_press_timeout 400 ; ")
                append("settings put secure multi_press_timeout 300 ; ")
                append("setprop debug.input.vsync_resample 1 2>/dev/null ; true ; ")
                append("setprop view.scroll_friction 0.015 2>/dev/null ; true")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    append(" ; cmd power set-fixed-performance-mode-enabled false")
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    append(" ; device_config set_sync_disabled_for_tests none")
                    games.forEach { pkg ->
                        append(" ; device_config delete game_overlay ").append(pkg)
                        append(" ; cmd game mode standard ").append(pkg)
                    }
                }
            }
            ShizukuBridge.execPrivileged(restoreCmd)
        }
        ActionFeedback(true, "ANGLE Texture, FPS Lock, animasi, dan respons sentuhan dipulihkan ke default.")
    }

    fun launchGame(packageName: String): Boolean {
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appContext.startActivity(intent)
        return true
    }

    fun buildCompatibilityReport(): CompatibilityReport {
        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val refreshRate = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                appContext.display?.refreshRate?.toInt() ?: wm.defaultDisplay.refreshRate.toInt()
            } else {
                wm.defaultDisplay.refreshRate.toInt()
            }
        }.getOrDefault(60)

        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val isUsageAccessOn = isUsageStatsGranted()

        return CompatibilityReport(
            overlayGranted = Settings.canDrawOverlays(appContext),
            usageStatsGranted = isUsageAccessOn,
            writeSettingsGranted = Settings.System.canWrite(appContext),
            dndGranted = nm.isNotificationPolicyAccessGranted,
            shizukuStatus = ShizukuBridge.refresh(appContext),
            refreshRateHz = refreshRate,
            gameManagerSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
            androidVersionLabel = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
        )
    }

    fun isUsageStatsGranted(): Boolean {
        val appOps = appContext.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                appContext.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                appContext.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getCurrentForegroundPackage(lookbackMs: Long = 20_000L): String? {
        if (!isUsageStatsGranted()) return null
        val usm = appContext.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val endTime = System.currentTimeMillis()
        val startTime = (endTime - lookbackMs).coerceAtLeast(0L)
        val events = runCatching { usm.queryEvents(startTime, endTime) }.getOrNull() ?: return null
        val event = UsageEvents.Event()
        var latestPkg: String? = null
        var latestTime = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val isResumed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            if (isResumed && event.timeStamp >= latestTime && !event.packageName.isNullOrBlank()) {
                latestTime = event.timeStamp
                latestPkg = event.packageName
            }
        }
        return latestPkg
    }

    fun getLauncherPackages(): Set<String> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val infos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        return infos.mapNotNull { it.activityInfo?.packageName }.toSet()
    }

    fun checkCpuSysfsReadable(): Boolean =
        File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").canRead()

    companion object {
        fun isNubiaOrRedMagicDevice(
            manufacturer: String = Build.MANUFACTURER ?: "",
            brand: String = Build.BRAND ?: "",
            model: String = Build.MODEL ?: ""
        ): Boolean {
            val combined = "$manufacturer $brand $model".lowercase()
            return combined.contains("nubia") ||
                combined.contains("redmagic") ||
                combined.contains("zte") ||
                combined.contains("nx6") ||
                combined.contains("nx7")
        }
    }
}
