package com.example.core

import android.content.Context
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import androidx.annotation.Keep
import com.example.model.MacroInjectionMode
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap
import kotlin.system.exitProcess

/**
 * Persistent Shizuku UserService running in the privileged `shell` (UID 2000) process.
 *
 * Key capabilities:
 * - Supports both Shizuku v13+ (Context) constructor and standard 16777115 destroy transaction
 * - Auto-probes /dev/input/eventX kernel Slot-9 hardware multi-touch when shell-writable
 * - Non-Root Multi-Pointer Merge: passively tracks physical fingers via KernelTouchEngine so
 *   macro taps merge as ACTION_POINTER_DOWN/UP on the real touchscreen device without cancelling
 *   or stuttering active camera swipes!
 * - Real-Time Live Touch X/Y Amplifier via TX_SYNC_BOOST_CFG + external stylus companion injector
 * - TX_SET_MACRO_ACTIVE pauses non-kernel companion boost while macro fires so both never collide
 */
@Keep
class ShizukuInputUserService @Keep constructor() : Binder() {

    @Keep
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    private data class StreamProfile(
        val pointerId: Int,
        val toolType: Int,
        val source: Int,
        val deviceId: Int
    )

    private var injectorTarget: Any? = null
    private var injectMethod: Method? = null
    private var realTouchDeviceId: Int = 0
    private val kernelEngine = KernelTouchEngine()
    private val activeStreams = ConcurrentHashMap<Int, StreamProfile>()
    private val preferredProfiles = ConcurrentHashMap<Int, StreamProfile>()
    private val activeMergedStreams = ConcurrentHashMap<Int, Int>() // slotKey -> merged pointerId

    init {
        resolveInputInjector()
        realTouchDeviceId = detectPhysicalTouchscreenId()
        kernelEngine.setExternalBoostInjector { action, x, y, downTimeMs, _, _, _ ->
            injectBoostStylusAsync(action, x, y, downTimeMs)
        }
        runCatching { kernelEngine.initIfPermitted() }
    }

    private fun detectPhysicalTouchscreenId(): Int {
        return runCatching {
            val ids = InputDevice.getDeviceIds()
            for (id in ids) {
                val dev = InputDevice.getDevice(id) ?: continue
                val isTouch = (dev.sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
                if (isTouch && !dev.isVirtual) {
                    return@runCatching id
                }
            }
            0
        }.getOrDefault(0)
    }

    private fun resolveInputInjector() {
        // 1. Android 14+ (API 34+): android.hardware.input.InputManagerGlobal.getInstance()
        runCatching {
            val globalClass = Class.forName("android.hardware.input.InputManagerGlobal")
            val getInstance = globalClass.getMethod("getInstance")
            val instance = getInstance.invoke(null)
            val method = globalClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            if (instance != null) {
                injectorTarget = instance
                injectMethod = method
                return
            }
        }

        // 2. Android 7 - 13 (API 24-33): android.hardware.input.InputManager.getInstance()
        runCatching {
            val imClass = Class.forName("android.hardware.input.InputManager")
            val getInstance = imClass.getMethod("getInstance")
            val instance = getInstance.invoke(null)
            val method = imClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            if (instance != null) {
                injectorTarget = instance
                injectMethod = method
                return
            }
        }

        // 3. Direct Binder fallback via ServiceManager("input") -> IInputManager.Stub.asInterface
        runCatching {
            val smClass = Class.forName("android.os.ServiceManager")
            val getService = smClass.getMethod("getService", String::class.java)
            val binder = getService.invoke(null, "input") as? IBinder ?: return@runCatching
            val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
            val asInterface = stubClass.getMethod("asInterface", IBinder::class.java)
            val iInputManager = asInterface.invoke(null, binder) ?: return@runCatching
            val method = iInputManager.javaClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            injectorTarget = iInputManager
            injectMethod = method
        }
    }

    private fun injectBoostStylusAsync(
        action: Int,
        x: Float,
        y: Float,
        downTimeMs: Long
    ): Boolean {
        if (injectorTarget == null || injectMethod == null) {
            resolveInputInjector()
        }
        val target = injectorTarget ?: return false
        val method = injectMethod ?: return false
        return sendMotionEvent(
            target = target,
            method = method,
            action = action,
            x = x,
            y = y,
            downTime = downTimeMs,
            pointerId = BOOST_STYLUS_POINTER_ID,
            toolType = MotionEvent.TOOL_TYPE_STYLUS,
            source = InputDevice.SOURCE_STYLUS,
            deviceId = 0
        )
    }

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        when (code) {
            TX_PING -> {
                data.enforceInterface(DESCRIPTOR)
                if (injectorTarget == null || injectMethod == null) {
                    resolveInputInjector()
                }
                if (realTouchDeviceId == 0) {
                    realTouchDeviceId = detectPhysicalTouchscreenId()
                }
                var capMask = 0
                if (injectorTarget != null && injectMethod != null) capMask = capMask or 1
                if (kernelEngine.isWritable) capMask = capMask or 2
                if (kernelEngine.isLiveBoostReaderActive) capMask = capMask or 4
                reply?.writeNoException()
                reply?.writeInt(capMask)
                return true
            }

            TX_INJECT_MOTION -> {
                data.enforceInterface(DESCRIPTOR)
                val action = data.readInt()
                val x = data.readFloat()
                val y = data.readFloat()
                val downTime = data.readLong()
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val slotOffset = data.readInt()
                val physHint = if (data.dataAvail() >= 4) data.readInt() == 1 else false
                val ok = injectMotionInternal(
                    action = action,
                    x = x,
                    y = y,
                    downTime = downTime,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation,
                    slotOffset = slotOffset,
                    physicalFingerHint = physHint
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_INJECT_PULSE -> {
                data.enforceInterface(DESCRIPTOR)
                val x = data.readFloat()
                val y = data.readFloat()
                val pressMs = data.readLong().coerceIn(4L, 1200L)
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val slotOffset = data.readInt()
                val physHint = if (data.dataAvail() >= 4) data.readInt() == 1 else false
                val ok = injectPulseInternal(
                    x = x,
                    y = y,
                    pressMs = pressMs,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation,
                    slotOffset = slotOffset,
                    physicalFingerHint = physHint
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_INJECT_SWIPE -> {
                data.enforceInterface(DESCRIPTOR)
                val x1 = data.readFloat()
                val y1 = data.readFloat()
                val x2 = data.readFloat()
                val y2 = data.readFloat()
                val durationMs = data.readLong().coerceIn(30L, 1500L)
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val ok = injectSwipeInternal(
                    x1 = x1,
                    y1 = y1,
                    x2 = x2,
                    y2 = y2,
                    durationMs = durationMs,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_SYNC_BOOST_CFG -> {
                data.enforceInterface(DESCRIPTOR)
                val cfg = TouchAmplifierConfig(
                    enabled = data.readInt() == 1,
                    gainX = data.readFloat().coerceIn(0.45f, 3.50f),
                    gainY = data.readFloat().coerceIn(0.45f, 3.50f),
                    responseBoost = data.readInt().coerceIn(0, 100),
                    touchSlopReduction = data.readInt().coerceIn(0, 100),
                    smoothing = data.readInt().coerceIn(0, 100),
                    deadzone = data.readInt().coerceIn(0, 50),
                    areaCode = data.readInt().coerceIn(0, 2),
                    screenW = data.readInt().coerceAtLeast(100),
                    screenH = data.readInt().coerceAtLeast(100),
                    rotation = data.readInt().coerceIn(0, 3)
                )
                kernelEngine.updateBoostConfig(cfg)
                reply?.writeNoException()
                reply?.writeInt(if (kernelEngine.isLiveBoostReaderActive) 1 else 0)
                return true
            }

            TX_SET_MACRO_ACTIVE -> {
                data.enforceInterface(DESCRIPTOR)
                val active = data.readInt() == 1
                kernelEngine.setMacroActive(active)
                reply?.writeNoException()
                reply?.writeInt(1)
                return true
            }

            TX_DESTROY, SHIZUKU_DESTROY_TRANSACTION -> {
                runCatching { data.enforceInterface(DESCRIPTOR) }
                kernelEngine.close()
                reply?.writeNoException()
                Thread {
                    SystemClock.sleep(25L)
                    exitProcess(0)
                }.start()
                return true
            }
        }
        return super.onTransact(code, data, reply, flags)
    }

    private fun tryInjectMergedMultiPointer(
        target: Any,
        method: Method,
        action: Int,
        x: Float,
        y: Float,
        safeW: Int,
        safeH: Int,
        rotation: Int,
        slotKey: Int
    ): Boolean {
        if (realTouchDeviceId == 0) return false
        val snapshot = kernelEngine.snapshotActivePhysicalPointers(safeW, safeH, rotation)
        if (snapshot.pointers.isEmpty()) return false

        val synthPointerId = activeMergedStreams[slotKey] ?: run {
            val used = snapshot.pointers.mapTo(HashSet()) { it.pointerId }
            var candidate = (9 - slotKey).coerceIn(1, 15)
            while (used.contains(candidate) && candidate < 15) candidate++
            candidate
        }

        val count = snapshot.pointers.size + 1
        val props = Array(count) { MotionEvent.PointerProperties() }
        val coords = Array(count) { MotionEvent.PointerCoords() }

        snapshot.pointers.forEachIndexed { idx, p ->
            props[idx].id = p.pointerId
            props[idx].toolType = MotionEvent.TOOL_TYPE_FINGER
            coords[idx].x = p.screenX.coerceIn(1f, (safeW - 1).toFloat())
            coords[idx].y = p.screenY.coerceIn(1f, (safeH - 1).toFloat())
            coords[idx].pressure = 1f
            coords[idx].size = 0.12f
            coords[idx].touchMajor = 14f
            coords[idx].touchMinor = 14f
        }

        val synthIdx = count - 1
        val isUpOrCancel = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL
        props[synthIdx].id = synthPointerId
        props[synthIdx].toolType = MotionEvent.TOOL_TYPE_FINGER
        coords[synthIdx].x = x
        coords[synthIdx].y = y
        coords[synthIdx].pressure = if (isUpOrCancel) 0f else 1f
        coords[synthIdx].size = if (isUpOrCancel) 0f else 0.1f
        coords[synthIdx].touchMajor = if (isUpOrCancel) 0f else 12f
        coords[synthIdx].touchMinor = if (isUpOrCancel) 0f else 12f

        val mergedAction = when (action) {
            MotionEvent.ACTION_DOWN ->
                MotionEvent.ACTION_POINTER_DOWN or (synthIdx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                MotionEvent.ACTION_POINTER_UP or (synthIdx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
            else -> MotionEvent.ACTION_MOVE
        }

        val eventTime = SystemClock.uptimeMillis()
        val downTime = if (snapshot.downTimeMs > 0L) snapshot.downTimeMs else eventTime
        val event = MotionEvent.obtain(
            downTime,
            eventTime,
            mergedAction,
            count,
            props,
            coords,
            0,
            0,
            1f,
            1f,
            realTouchDeviceId,
            0,
            InputDevice.SOURCE_TOUCHSCREEN,
            0
        )

        return try {
            val res = method.invoke(target, event, INJECT_MODE_ASYNC)
            val ok = (res as? Boolean) ?: true
            if (ok) {
                when (action) {
                    MotionEvent.ACTION_DOWN -> activeMergedStreams[slotKey] = synthPointerId
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> activeMergedStreams.remove(slotKey)
                }
            }
            ok
        } catch (_: Throwable) {
            activeMergedStreams.remove(slotKey)
            false
        } finally {
            event.recycle()
        }
    }

    private fun injectMotionInternal(
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int,
        physicalFingerHint: Boolean = false
    ): Boolean {
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val clampedX = x.coerceIn(2f, (safeW - 2).toFloat())
        val clampedY = y.coerceIn(2f, (safeH - 2).toFloat())

        // 1. Hardware kernel Slot-9 / Slot-8 path if UID 2000 has writable /dev/input/eventX
        if (kernelEngine.isWritable) {
            val kernelOk = when (action) {
                MotionEvent.ACTION_DOWN -> kernelEngine.down(
                    slotOffset, clampedX, clampedY, safeW, safeH, rotation, physicalFingerHint
                )
                MotionEvent.ACTION_MOVE -> kernelEngine.move(slotOffset, clampedX, clampedY, safeW, safeH, rotation)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> kernelEngine.up(slotOffset, physicalFingerHint)
                else -> false
            }
            if (kernelOk) return true
        }

        if (injectorTarget == null || injectMethod == null) {
            resolveInputInjector()
        }
        val target = injectorTarget ?: return false
        val method = injectMethod ?: return false

        val mode = MacroInjectionMode.entries.getOrElse(modeOrdinal) { MacroInjectionMode.SMART_POINTER }
        val isTouchDirect = mode == MacroInjectionMode.TOUCHSCREEN_DIRECT
        val slotKey = slotOffset.coerceIn(0, 3)

        // 2. Non-root Multi-Pointer Merge when physical fingers are tracked passively (zero swipe stutter)
        if (!isTouchDirect && kernelEngine.isLiveBoostReaderActive) {
            val wasMerged = activeMergedStreams.containsKey(slotKey)
            if (action == MotionEvent.ACTION_DOWN || wasMerged) {
                if (tryInjectMergedMultiPointer(
                        target, method, action, clampedX, clampedY, safeW, safeH, rotation, slotKey
                    )
                ) {
                    return true
                }
                if (wasMerged && (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL)) {
                    activeMergedStreams.remove(slotKey)
                }
            }
        }

        val (source, toolType) = when (mode) {
            // Non-root SMART_POINTER uses SOURCE_STYLUS by default so physical touchscreen fingers never cancel/freeze
            MacroInjectionMode.SMART_POINTER -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.STYLUS_HYBRID -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> InputDevice.SOURCE_TOUCHSCREEN to MotionEvent.TOOL_TYPE_FINGER
        }

        val pointerId = when (mode) {
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> if (slotOffset == 0) 0 else 8
            else -> (9 - slotOffset.coerceIn(0, 3)).coerceIn(1, 9)
        }

        if (action != MotionEvent.ACTION_DOWN) {
            val active = activeStreams[slotKey]
            if (active != null) {
                val ok = sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    active.pointerId, active.toolType, active.source, active.deviceId
                )
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    activeStreams.remove(slotKey)
                }
                if (ok) return true
            }
        }

        val prefKey = (mode.ordinal shl 4) or slotKey
        val cachedProfile = preferredProfiles[prefKey]
        if (cachedProfile != null) {
            if (sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    cachedProfile.pointerId, cachedProfile.toolType, cachedProfile.source, cachedProfile.deviceId
                )
            ) {
                if (action == MotionEvent.ACTION_DOWN) {
                    activeStreams[slotKey] = cachedProfile
                }
                return true
            }
            preferredProfiles.remove(prefKey)
        }

        val candidates = buildList {
            add(StreamProfile(pointerId, toolType, source, 0))
            if (!isTouchDirect && pointerId != 8) {
                add(StreamProfile(8, MotionEvent.TOOL_TYPE_STYLUS, InputDevice.SOURCE_STYLUS, 0))
            }
            if (isTouchDirect && realTouchDeviceId != 0) {
                add(StreamProfile(pointerId, toolType, source, realTouchDeviceId))
            }
            if (source != InputDevice.SOURCE_TOUCHSCREEN) {
                add(StreamProfile(pointerId, MotionEvent.TOOL_TYPE_FINGER, InputDevice.SOURCE_TOUCHSCREEN, 0))
            }
            if (pointerId != 0 && isTouchDirect) {
                add(StreamProfile(0, toolType, source, 0))
            }
        }

        for (candidate in candidates) {
            if (sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    candidate.pointerId, candidate.toolType, candidate.source, candidate.deviceId
                )
            ) {
                preferredProfiles[prefKey] = candidate
                if (action == MotionEvent.ACTION_DOWN) {
                    activeStreams[slotKey] = candidate
                }
                return true
            }
        }
        return false
    }

    private fun sendMotionEvent(
        target: Any,
        method: Method,
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        pointerId: Int,
        toolType: Int,
        source: Int,
        deviceId: Int
    ): Boolean {
        val isUpOrCancel = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL
        val props = arrayOf(
            MotionEvent.PointerProperties().apply {
                id = pointerId
                this.toolType = toolType
            }
        )
        val coords = arrayOf(
            MotionEvent.PointerCoords().apply {
                this.x = x
                this.y = y
                pressure = if (isUpOrCancel) 0f else 1f
                size = if (isUpOrCancel) 0f else 0.1f
                touchMajor = if (isUpOrCancel) 0f else 12f
                touchMinor = if (isUpOrCancel) 0f else 12f
            }
        )

        val eventTime = SystemClock.uptimeMillis()
        val safeDownTime = if (downTime > 0L) downTime else eventTime
        val event = MotionEvent.obtain(
            safeDownTime,
            eventTime,
            action,
            1,
            props,
            coords,
            0,
            0,
            1f,
            1f,
            deviceId,
            0,
            source,
            0
        )

        return try {
            val res = method.invoke(target, event, INJECT_MODE_ASYNC)
            (res as? Boolean) ?: true
        } catch (_: Throwable) {
            false
        } finally {
            event.recycle()
        }
    }

    private fun injectPulseInternal(
        x: Float,
        y: Float,
        pressMs: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int,
        physicalFingerHint: Boolean = false
    ): Boolean {
        if (kernelEngine.isWritable) {
            if (kernelEngine.pulse(slotOffset, x, y, screenW, screenH, rotation, pressMs, physicalFingerHint)) {
                return true
            }
        }
        val downTime = SystemClock.uptimeMillis()
        if (!injectMotionInternal(
                MotionEvent.ACTION_DOWN, x, y, downTime, modeOrdinal, screenW, screenH, rotation, slotOffset, physicalFingerHint
            )
        ) {
            return false
        }
        SystemClock.sleep(pressMs)
        return injectMotionInternal(
            MotionEvent.ACTION_UP, x, y, downTime, modeOrdinal, screenW, screenH, rotation, slotOffset, physicalFingerHint
        )
    }

    private fun injectSwipeInternal(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Boolean {
        if (kernelEngine.isWritable) {
            if (kernelEngine.down(0, x1, y1, screenW, screenH, rotation)) {
                SystemClock.sleep(10L)
                val steps = (durationMs / 12L).toInt().coerceIn(5, 30)
                val stepDelay = (durationMs / steps).coerceAtLeast(5L)
                for (i in 1..steps) {
                    val t = i.toFloat() / steps.toFloat()
                    kernelEngine.move(0, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, screenW, screenH, rotation)
                    SystemClock.sleep(stepDelay)
                }
                if (kernelEngine.up(0)) return true
            }
        }

        val downTime = SystemClock.uptimeMillis()
        if (!injectMotionInternal(MotionEvent.ACTION_DOWN, x1, y1, downTime, modeOrdinal, screenW, screenH, rotation, 0)) {
            return false
        }
        SystemClock.sleep(10L)
        val steps = (durationMs / 12L).toInt().coerceIn(5, 30)
        val stepDelay = (durationMs / steps).coerceAtLeast(5L)
        for (i in 1..steps) {
            val t = i.toFloat() / steps.toFloat()
            val curX = x1 + (x2 - x1) * t
            val curY = y1 + (y2 - y1) * t
            injectMotionInternal(MotionEvent.ACTION_MOVE, curX, curY, downTime, modeOrdinal, screenW, screenH, rotation, 0)
            SystemClock.sleep(stepDelay)
        }
        return injectMotionInternal(MotionEvent.ACTION_UP, x2, y2, downTime, modeOrdinal, screenW, screenH, rotation, 0)
    }

    companion object {
        const val DESCRIPTOR = "com.example.core.IShizukuInputUserService"
        const val TX_PING = FIRST_CALL_TRANSACTION + 0
        const val TX_INJECT_MOTION = FIRST_CALL_TRANSACTION + 1
        const val TX_INJECT_SWIPE = FIRST_CALL_TRANSACTION + 2
        const val TX_INJECT_PULSE = FIRST_CALL_TRANSACTION + 3
        const val TX_SYNC_BOOST_CFG = FIRST_CALL_TRANSACTION + 4
        const val TX_SET_MACRO_ACTIVE = FIRST_CALL_TRANSACTION + 5
        const val TX_DESTROY = FIRST_CALL_TRANSACTION + 99
        private const val SHIZUKU_DESTROY_TRANSACTION = 16777115
        private const val INJECT_MODE_ASYNC = 0
        private const val BOOST_STYLUS_POINTER_ID = 7
    }
}
