package com.example.core

import android.content.Context
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import androidx.annotation.Keep
import com.example.model.MacroInjectionMode
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap
import kotlin.system.exitProcess

/**
 * Persistent Shizuku UserService running in the privileged `shell` (UID 2000) process.
 *
 * Key capabilities:
 * - Supports both Shizuku v13+ (Context) constructor and standard 16777115 destroy transaction
 * - Auto-probes /dev/input/eventX kernel Slot-9 hardware multi-touch when shell-writable
 * - Provides single-IPC TX_INJECT_PULSE (DOWN -> micro-sleep -> UP in one Binder call)
 * - Uses SOURCE_TOUCHSCREEN (never SOURCE_MOUSE) for SMART_POINTER so games never lock camera/aim
 */
@Keep
class ShizukuInputUserService @Keep constructor() : Binder() {

    @Keep
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    private data class StreamProfile(
        val pointerId: Int,
        val toolType: Int,
        val source: Int,
        val deviceId: Int
    )

    private var injectorTarget: Any? = null
    private var injectMethod: Method? = null
    private var realTouchDeviceId: Int = 0
    private val kernelEngine = KernelTouchEngine()
    private val activeStreams = ConcurrentHashMap<Int, StreamProfile>()
    private val preferredProfiles = ConcurrentHashMap<Int, StreamProfile>()

    init {
        resolveInputInjector()
        realTouchDeviceId = detectPhysicalTouchscreenId()
        runCatching { kernelEngine.initIfPermitted() }
    }

    private fun detectPhysicalTouchscreenId(): Int {
        return runCatching {
            val ids = InputDevice.getDeviceIds()
            for (id in ids) {
                val dev = InputDevice.getDevice(id) ?: continue
                val isTouch = (dev.sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
                if (isTouch && !dev.isVirtual) {
                    return@runCatching id
                }
            }
            0
        }.getOrDefault(0)
    }

    private fun resolveInputInjector() {
        // 1. Android 14+ (API 34+): android.hardware.input.InputManagerGlobal.getInstance()
        runCatching {
            val globalClass = Class.forName("android.hardware.input.InputManagerGlobal")
            val getInstance = globalClass.getMethod("getInstance")
            val instance = getInstance.invoke(null)
            val method = globalClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            if (instance != null) {
                injectorTarget = instance
                injectMethod = method
                return
            }
        }

        // 2. Android 7 - 13 (API 24-33): android.hardware.input.InputManager.getInstance()
        runCatching {
            val imClass = Class.forName("android.hardware.input.InputManager")
            val getInstance = imClass.getMethod("getInstance")
            val instance = getInstance.invoke(null)
            val method = imClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            if (instance != null) {
                injectorTarget = instance
                injectMethod = method
                return
            }
        }

        // 3. Direct Binder fallback via ServiceManager("input") -> IInputManager.Stub.asInterface
        runCatching {
            val smClass = Class.forName("android.os.ServiceManager")
            val getService = smClass.getMethod("getService", String::class.java)
            val binder = getService.invoke(null, "input") as? IBinder ?: return@runCatching
            val stubClass = Class.forName("android.hardware.input.IInputManager\$Stub")
            val asInterface = stubClass.getMethod("asInterface", IBinder::class.java)
            val iInputManager = asInterface.invoke(null, binder) ?: return@runCatching
            val method = iInputManager.javaClass.getMethod(
                "injectInputEvent",
                InputEvent::class.java,
                Int::class.javaPrimitiveType
            )
            injectorTarget = iInputManager
            injectMethod = method
        }
    }

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        when (code) {
            TX_PING -> {
                data.enforceInterface(DESCRIPTOR)
                if (injectorTarget == null || injectMethod == null) {
                    resolveInputInjector()
                }
                if (realTouchDeviceId == 0) {
                    realTouchDeviceId = detectPhysicalTouchscreenId()
                }
                var capMask = 0
                if (injectorTarget != null && injectMethod != null) capMask = capMask or 1
                if (kernelEngine.isWritable) capMask = capMask or 2
                reply?.writeNoException()
                reply?.writeInt(capMask)
                return true
            }

            TX_INJECT_MOTION -> {
                data.enforceInterface(DESCRIPTOR)
                val action = data.readInt()
                val x = data.readFloat()
                val y = data.readFloat()
                val downTime = data.readLong()
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val slotOffset = data.readInt()
                val ok = injectMotionInternal(
                    action = action,
                    x = x,
                    y = y,
                    downTime = downTime,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation,
                    slotOffset = slotOffset
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_INJECT_PULSE -> {
                data.enforceInterface(DESCRIPTOR)
                val x = data.readFloat()
                val y = data.readFloat()
                val pressMs = data.readLong().coerceIn(4L, 1200L)
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val slotOffset = data.readInt()
                val ok = injectPulseInternal(
                    x = x,
                    y = y,
                    pressMs = pressMs,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation,
                    slotOffset = slotOffset
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_INJECT_SWIPE -> {
                data.enforceInterface(DESCRIPTOR)
                val x1 = data.readFloat()
                val y1 = data.readFloat()
                val x2 = data.readFloat()
                val y2 = data.readFloat()
                val durationMs = data.readLong().coerceIn(30L, 1500L)
                val modeOrdinal = data.readInt()
                val screenW = data.readInt()
                val screenH = data.readInt()
                val rotation = data.readInt()
                val ok = injectSwipeInternal(
                    x1 = x1,
                    y1 = y1,
                    x2 = x2,
                    y2 = y2,
                    durationMs = durationMs,
                    modeOrdinal = modeOrdinal,
                    screenW = screenW,
                    screenH = screenH,
                    rotation = rotation
                )
                reply?.writeNoException()
                reply?.writeInt(if (ok) 1 else 0)
                return true
            }

            TX_DESTROY, SHIZUKU_DESTROY_TRANSACTION -> {
                runCatching { data.enforceInterface(DESCRIPTOR) }
                kernelEngine.close()
                reply?.writeNoException()
                Thread {
                    SystemClock.sleep(25L)
                    exitProcess(0)
                }.start()
                return true
            }
        }
        return super.onTransact(code, data, reply, flags)
    }

    private fun injectMotionInternal(
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int
    ): Boolean {
        val safeW = screenW.coerceAtLeast(100)
        val safeH = screenH.coerceAtLeast(100)
        val clampedX = x.coerceIn(2f, (safeW - 2).toFloat())
        val clampedY = y.coerceIn(2f, (safeH - 2).toFloat())

        // 1. Hardware kernel Slot-9 / Slot-8 path if UID 2000 has writable /dev/input/eventX
        if (kernelEngine.isWritable) {
            val kernelOk = when (action) {
                MotionEvent.ACTION_DOWN -> kernelEngine.down(slotOffset, clampedX, clampedY, safeW, safeH, rotation)
                MotionEvent.ACTION_MOVE -> kernelEngine.move(slotOffset, clampedX, clampedY, safeW, safeH, rotation)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> kernelEngine.up(slotOffset)
                else -> false
            }
            if (kernelOk) return true
        }

        if (injectorTarget == null || injectMethod == null) {
            resolveInputInjector()
        }
        val target = injectorTarget ?: return false
        val method = injectMethod ?: return false

        val mode = MacroInjectionMode.entries.getOrElse(modeOrdinal) { MacroInjectionMode.SMART_POINTER }
        val isTouchDirect = mode == MacroInjectionMode.TOUCHSCREEN_DIRECT
        val (source, toolType) = when (mode) {
            // Non-root SMART_POINTER uses SOURCE_STYLUS by default so physical touchscreen fingers never cancel/freeze
            MacroInjectionMode.SMART_POINTER -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.STYLUS_HYBRID -> InputDevice.SOURCE_STYLUS to MotionEvent.TOOL_TYPE_STYLUS
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> InputDevice.SOURCE_TOUCHSCREEN to MotionEvent.TOOL_TYPE_FINGER
        }

        val pointerId = when (mode) {
            MacroInjectionMode.TOUCHSCREEN_DIRECT -> if (slotOffset == 0) 0 else 8
            else -> (9 - slotOffset.coerceIn(0, 3)).coerceIn(1, 9)
        }

        val slotKey = slotOffset.coerceIn(0, 3)
        if (action != MotionEvent.ACTION_DOWN) {
            val active = activeStreams[slotKey]
            if (active != null) {
                val ok = sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    active.pointerId, active.toolType, active.source, active.deviceId
                )
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    activeStreams.remove(slotKey)
                }
                if (ok) return true
            }
        }

        val prefKey = (mode.ordinal shl 4) or slotKey
        val cachedProfile = preferredProfiles[prefKey]
        if (cachedProfile != null) {
            if (sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    cachedProfile.pointerId, cachedProfile.toolType, cachedProfile.source, cachedProfile.deviceId
                )
            ) {
                if (action == MotionEvent.ACTION_DOWN) {
                    activeStreams[slotKey] = cachedProfile
                }
                return true
            }
            preferredProfiles.remove(prefKey)
        }

        // Probe least-intrusive concurrent stream first (STYLUS virtual deviceId=0), only touching hardware deviceId when explicit
        val candidates = buildList {
            add(StreamProfile(pointerId, toolType, source, 0))
            if (!isTouchDirect && pointerId != 8) {
                add(StreamProfile(8, MotionEvent.TOOL_TYPE_STYLUS, InputDevice.SOURCE_STYLUS, 0))
            }
            if (isTouchDirect && realTouchDeviceId != 0) {
                add(StreamProfile(pointerId, toolType, source, realTouchDeviceId))
            }
            if (source != InputDevice.SOURCE_TOUCHSCREEN) {
                add(StreamProfile(pointerId, MotionEvent.TOOL_TYPE_FINGER, InputDevice.SOURCE_TOUCHSCREEN, 0))
            }
            if (pointerId != 0 && isTouchDirect) {
                add(StreamProfile(0, toolType, source, 0))
            }
        }

        for (candidate in candidates) {
            if (sendMotionEvent(
                    target, method, action, clampedX, clampedY, downTime,
                    candidate.pointerId, candidate.toolType, candidate.source, candidate.deviceId
                )
            ) {
                preferredProfiles[prefKey] = candidate
                if (action == MotionEvent.ACTION_DOWN) {
                    activeStreams[slotKey] = candidate
                }
                return true
            }
        }
        return false
    }

    private fun sendMotionEvent(
        target: Any,
        method: Method,
        action: Int,
        x: Float,
        y: Float,
        downTime: Long,
        pointerId: Int,
        toolType: Int,
        source: Int,
        deviceId: Int
    ): Boolean {
        val isUpOrCancel = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL
        val props = arrayOf(
            MotionEvent.PointerProperties().apply {
                id = pointerId
                this.toolType = toolType
            }
        )
        val coords = arrayOf(
            MotionEvent.PointerCoords().apply {
                this.x = x
                this.y = y
                pressure = if (isUpOrCancel) 0f else 1f
                size = if (isUpOrCancel) 0f else 0.1f
                touchMajor = if (isUpOrCancel) 0f else 12f
                touchMinor = if (isUpOrCancel) 0f else 12f
            }
        )

        val eventTime = SystemClock.uptimeMillis()
        val safeDownTime = if (downTime > 0L) downTime else eventTime
        val event = MotionEvent.obtain(
            safeDownTime,
            eventTime,
            action,
            1,
            props,
            coords,
            0,
            0,
            1f,
            1f,
            deviceId,
            0,
            source,
            0
        )

        // Always use INJECT_MODE_ASYNC so InputDispatcher never stalls active touches or causes UI freeze
        val injectMode = INJECT_MODE_ASYNC

        return try {
            val res = method.invoke(target, event, injectMode)
            (res as? Boolean) ?: true
        } catch (_: Throwable) {
            false
        } finally {
            event.recycle()
        }
    }

    private fun injectPulseInternal(
        x: Float,
        y: Float,
        pressMs: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int
    ): Boolean {
        if (kernelEngine.isWritable) {
            if (kernelEngine.pulse(slotOffset, x, y, screenW, screenH, rotation, pressMs)) {
                return true
            }
        }
        val downTime = SystemClock.uptimeMillis()
        if (!injectMotionInternal(
                MotionEvent.ACTION_DOWN, x, y, downTime, modeOrdinal, screenW, screenH, rotation, slotOffset
            )
        ) {
            return false
        }
        SystemClock.sleep(pressMs)
        return injectMotionInternal(
            MotionEvent.ACTION_UP, x, y, downTime, modeOrdinal, screenW, screenH, rotation, slotOffset
        )
    }

    private fun injectSwipeInternal(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long,
        modeOrdinal: Int,
        screenW: Int,
        screenH: Int,
        rotation: Int
    ): Boolean {
        if (kernelEngine.isWritable) {
            if (kernelEngine.down(0, x1, y1, screenW, screenH, rotation)) {
                SystemClock.sleep(10L)
                val steps = (durationMs / 12L).toInt().coerceIn(5, 30)
                val stepDelay = (durationMs / steps).coerceAtLeast(5L)
                for (i in 1..steps) {
                    val t = i.toFloat() / steps.toFloat()
                    kernelEngine.move(0, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, screenW, screenH, rotation)
                    SystemClock.sleep(stepDelay)
                }
                if (kernelEngine.up(0)) return true
            }
        }

        val downTime = SystemClock.uptimeMillis()
        if (!injectMotionInternal(MotionEvent.ACTION_DOWN, x1, y1, downTime, modeOrdinal, screenW, screenH, rotation, 0)) {
            return false
        }
        SystemClock.sleep(10L)
        val steps = (durationMs / 12L).toInt().coerceIn(5, 30)
        val stepDelay = (durationMs / steps).coerceAtLeast(5L)
        for (i in 1..steps) {
            val t = i.toFloat() / steps.toFloat()
            val curX = x1 + (x2 - x1) * t
            val curY = y1 + (y2 - y1) * t
            injectMotionInternal(MotionEvent.ACTION_MOVE, curX, curY, downTime, modeOrdinal, screenW, screenH, rotation, 0)
            SystemClock.sleep(stepDelay)
        }
        return injectMotionInternal(MotionEvent.ACTION_UP, x2, y2, downTime, modeOrdinal, screenW, screenH, rotation, 0)
    }

    companion object {
        const val DESCRIPTOR = "com.example.core.IShizukuInputUserService"
        const val TX_PING = FIRST_CALL_TRANSACTION + 0
        const val TX_INJECT_MOTION = FIRST_CALL_TRANSACTION + 1
        const val TX_INJECT_SWIPE = FIRST_CALL_TRANSACTION + 2
        const val TX_INJECT_PULSE = FIRST_CALL_TRANSACTION + 3
        const val TX_DESTROY = FIRST_CALL_TRANSACTION + 99
        private const val SHIZUKU_DESTROY_TRANSACTION = 16777115
        private const val INJECT_MODE_ASYNC = 0
        private const val INJECT_MODE_WAIT_FOR_RESULT = 1
    }
}
