package com.example.data

import android.content.pm.ApplicationInfo
import com.example.model.DebloatCategory

data class UadRule(
    val packageName: String,
    val category: DebloatCategory,
    val description: String
)

/**
 * Built-in UAD-ng (Universal Android Debloater) rule registry covering common OEM,
 * Google, telemetry, carrier, and social bloatware packages, plus heuristic classification.
 */
object UadDatabase {

    private val exactRules: Map<String, UadRule> = listOf(
        // SAFE - Telemetry, bloatware, preinstalled social/ad services
        UadRule("com.facebook.katana", DebloatCategory.SAFE, "Aplikasi Facebook bawaan (aman dihapus)."),
        UadRule("com.facebook.system", DebloatCategory.SAFE, "Facebook App Installer latar belakang."),
        UadRule("com.facebook.appmanager", DebloatCategory.SAFE, "Facebook App Manager pembaru otomatis."),
        UadRule("com.facebook.services", DebloatCategory.SAFE, "Layanan latar belakang Meta/Facebook."),
        UadRule("com.instagram.android", DebloatCategory.SAFE, "Aplikasi Instagram bawaan."),
        UadRule("com.zhiliaoapp.musically", DebloatCategory.SAFE, "TikTok bawaan OEM."),
        UadRule("com.ss.android.ugc.trill", DebloatCategory.SAFE, "TikTok Asia preinstalled."),
        UadRule("com.spotify.music", DebloatCategory.SAFE, "Spotify bawaan OEM."),
        UadRule("com.netflix.mediaclient", DebloatCategory.SAFE, "Netflix preinstalled."),
        UadRule("com.netflix.partner.activation", DebloatCategory.SAFE, "Aktivasi partner Netflix."),
        UadRule("com.google.android.apps.tachyon", DebloatCategory.SAFE, "Google Meet / Duo bawaan."),
        UadRule("com.google.android.videos", DebloatCategory.SAFE, "Google TV / Play Movies."),
        UadRule("com.google.android.apps.youtube.music", DebloatCategory.SAFE, "YouTube Music bawaan."),
        UadRule("com.google.android.apps.magazines", DebloatCategory.SAFE, "Google News."),
        UadRule("com.google.android.apps.books", DebloatCategory.SAFE, "Google Play Books."),
        UadRule("com.google.android.apps.subscriptions.red", DebloatCategory.SAFE, "Google One."),
        UadRule("com.google.android.apps.wellbeing", DebloatCategory.SAFE, "Digital Wellbeing (mengurangi polling latar belakang)."),
        UadRule("com.google.android.feedback", DebloatCategory.SAFE, "Agen umpan balik crash Google."),
        UadRule("com.google.android.marvin.talkback", DebloatCategory.SAFE, "Android Accessibility Suite (jika tidak dipakai)."),
        UadRule("com.google.ar.core", DebloatCategory.SAFE, "Google Play Services for AR."),
        UadRule("com.android.bips", DebloatCategory.SAFE, "Default Print Service."),
        UadRule("com.android.printspooler", DebloatCategory.SAFE, "Print Spooler latar belakang."),
        UadRule("com.android.bookmarkprovider", DebloatCategory.SAFE, "Bookmark Provider lama."),
        UadRule("com.android.wallpaper.livepicker", DebloatCategory.SAFE, "Live Wallpaper Picker."),
        UadRule("com.android.dreams.basic", DebloatCategory.SAFE, "Basic Daydreams screensaver."),
        UadRule("com.android.dreams.phototable", DebloatCategory.SAFE, "Photo Screensavers."),
        UadRule("com.miui.analytics", DebloatCategory.SAFE, "Telemetri & analitik MIUI/HyperOS."),
        UadRule("com.miui.msa.global", DebloatCategory.SAFE, "MIUI System Ads (iklan sistem Xiaomi)."),
        UadRule("com.miui.daemon", DebloatCategory.SAFE, "Daemon pelacak latar belakang MIUI."),
        UadRule("com.miui.bugreport", DebloatCategory.SAFE, "Pelapor bug MIUI."),
        UadRule("com.xiaomi.mipicks", DebloatCategory.SAFE, "GetApps Xiaomi."),
        UadRule("com.xiaomi.glgm", DebloatCategory.SAFE, "Xiaomi Games bloatware."),
        UadRule("com.xiaomi.joyose", DebloatCategory.ADVANCED, "Joyose (mengatur limitasi thermal/game Xiaomi - hati-hati)."),
        UadRule("com.coloros.gamespace", DebloatCategory.SAFE, "Game Space bawaan ColorOS/Realme."),
        UadRule("com.heytap.browser", DebloatCategory.SAFE, "Browser bawaan Oppo/Realme."),
        UadRule("com.heytap.market", DebloatCategory.SAFE, "App Market Oppo/Realme."),
        UadRule("com.heytap.pictorial", DebloatCategory.SAFE, "Lockscreen Magazine ColorOS."),
        UadRule("com.oppo.quicksearchbox", DebloatCategory.SAFE, "Global Search ColorOS."),
        UadRule("com.nearme.atlas", DebloatCategory.SAFE, "Atlas layanan analitik ColorOS."),
        UadRule("com.finshell.fin", DebloatCategory.SAFE, "FinShell Pay bloatware."),
        UadRule("com.vivo.browser", DebloatCategory.SAFE, "Vivo Browser bawaan."),
        UadRule("com.vivo.appstore", DebloatCategory.SAFE, "V-Appstore Vivo."),
        UadRule("com.samsung.android.bixby.agent", DebloatCategory.SAFE, "Asisten Bixby Samsung."),
        UadRule("com.samsung.android.app.spage", DebloatCategory.SAFE, "Samsung Free / Daily."),
        UadRule("com.samsung.android.game.gos", DebloatCategory.ADVANCED, "Game Optimizing Service Samsung (bisa menurunkan throttling)."),
        UadRule("com.samsung.android.game.gamehome", DebloatCategory.SAFE, "Samsung Gaming Hub."),
        UadRule("com.microsoft.skydrive", DebloatCategory.SAFE, "OneDrive bawaan."),
        UadRule("com.linkedin.android", DebloatCategory.SAFE, "LinkedIn preinstalled."),
        UadRule("com.opera.browser", DebloatCategory.SAFE, "Opera Browser bawaan."),
        UadRule("com.aura.oobe.motorola", DebloatCategory.SAFE, "Aura App Recommendations."),
        UadRule("com.ironsource.appcloud.oobe", DebloatCategory.SAFE, "AppCloud penginstal iklan OEM."),

        // ADVANCED - Useful if unused, slight side effects possible
        UadRule("com.google.android.gms.location.history", DebloatCategory.ADVANCED, "Google Location History."),
        UadRule("com.google.android.as", DebloatCategory.ADVANCED, "Android System Intelligence (Live Caption, Smart Reply)."),
        UadRule("com.google.android.projection.gearhead", DebloatCategory.ADVANCED, "Android Auto."),
        UadRule("com.google.android.tts", DebloatCategory.ADVANCED, "Speech Recognition & Synthesis."),
        UadRule("com.google.android.apps.googleassistant", DebloatCategory.ADVANCED, "Google Assistant app."),
        UadRule("com.android.stk", DebloatCategory.ADVANCED, "SIM Toolkit."),
        UadRule("com.android.cellbroadcastreceiver", DebloatCategory.ADVANCED, "Peringatan darurat seluler."),
        UadRule("com.android.egg", DebloatCategory.SAFE, "Android Easter Egg."),
        UadRule("com.qualcomm.qti.optinoverlay", DebloatCategory.SAFE, "Qualcomm Telemetry Opt-In."),
        UadRule("com.qualcomm.qti.uceShimService", DebloatCategory.ADVANCED, "Qualcomm RCS / UCE Shim."),

        // EXPERT - System features, account sync, cloud services
        UadRule("com.google.android.gms", DebloatCategory.UNSAFE, "Google Play Services (PENTING: menghapus ini merusak banyak game)."),
        UadRule("com.android.vending", DebloatCategory.UNSAFE, "Google Play Store (PENTING untuk lisensi game)."),
        UadRule("com.google.android.gsf", DebloatCategory.UNSAFE, "Google Services Framework (JANGAN HAPUS)."),
        UadRule("com.miui.securitycenter", DebloatCategory.UNSAFE, "MIUI Security Center (menghapus bisa menyebabkan bootloop di Xiaomi)."),
        UadRule("com.android.systemui", DebloatCategory.UNSAFE, "System UI (KRITIS - JANGAN HAPUS)."),
        UadRule("com.android.settings", DebloatCategory.UNSAFE, "Pengaturan Android (KRITIS)."),
        UadRule("com.android.phone", DebloatCategory.UNSAFE, "Layanan Telepon (KRITIS)."),
        UadRule("com.android.providers.telephony", DebloatCategory.UNSAFE, "Penyedia Telepon & SMS."),
        UadRule("com.android.webview", DebloatCategory.UNSAFE, "Android System WebView (dibutuhkan banyak app)."),
        UadRule("com.google.android.webview", DebloatCategory.UNSAFE, "Android System WebView."),
        UadRule("com.android.permissioncontroller", DebloatCategory.UNSAFE, "Pengontrol Izin Android (KRITIS)."),
        UadRule("com.android.packageinstaller", DebloatCategory.UNSAFE, "Package Installer (KRITIS)."),
        UadRule("com.android.inputmethod.latin", DebloatCategory.EXPERT, "Keyboard AOSP (pastikan ada keyboard lain)."),
        UadRule("com.google.android.inputmethod.latin", DebloatCategory.EXPERT, "Gboard (pastikan ada keyboard lain sebelum hapus)."),
        UadRule("com.android.bluetooth", DebloatCategory.EXPERT, "Layanan Bluetooth sistem."),
        UadRule("com.android.nfc", DebloatCategory.EXPERT, "Layanan NFC sistem."),
        UadRule("com.android.camera", DebloatCategory.EXPERT, "Aplikasi Kamera bawaan."),
        UadRule("com.android.gallery3d", DebloatCategory.EXPERT, "Galeri bawaan AOSP.")
    ).associateBy { it.packageName }

    fun classify(packageName: String, appInfo: ApplicationInfo): Pair<DebloatCategory, String> {
        exactRules[packageName]?.let { return it.category to it.description }

        val pkg = packageName.lowercase()
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
            (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

        return when {
            pkg.contains("systemui") || pkg.contains("framework") || pkg == "android" ||
                pkg.contains("keychain") || pkg.contains("permissioncontroller") ||
                pkg.contains("packageinstaller") || pkg.contains("telephony") ||
                pkg.contains("settings") || pkg.contains("providers.media") ||
                pkg.contains("providers.contacts") || pkg.contains("webview") ->
                DebloatCategory.UNSAFE to "Komponen inti Android OS. Disarankan tidak dihapus."

            pkg.contains("analytics") || pkg.contains("telemetry") || pkg.contains("msa") ||
                pkg.contains("adservice") || pkg.contains("facebook") || pkg.contains("bugreport") ||
                pkg.contains("feedback") || pkg.contains("partner") || pkg.contains("oobe") ||
                pkg.contains("demo") || pkg.contains("gamespace") || pkg.contains("pictorial") ||
                pkg.contains("wellbeing") || pkg.contains("print") || pkg.contains("wallpaper") ->
                DebloatCategory.SAFE to "Layanan telemetri, iklan, atau aplikasi pendamping bawaan (Aman)."

            pkg.contains("launcher") || pkg.contains("keyboard") || pkg.contains("inputmethod") ||
                pkg.contains("bluetooth") || pkg.contains("nfc") || pkg.contains("wifi") ||
                pkg.contains("ims") || pkg.contains("qti") || pkg.contains("mediatek") ->
                DebloatCategory.EXPERT to "Komponen perangkat keras / antarmuka sistem (Khusus pengguna mahir)."

            isSystem ->
                DebloatCategory.ADVANCED to "Aplikasi sistem OEM. Periksa fungsi sebelum menonaktifkan."

            else ->
                DebloatCategory.SAFE to "Aplikasi pihak ketiga / pra-instalasi pengguna."
        }
    }
}
