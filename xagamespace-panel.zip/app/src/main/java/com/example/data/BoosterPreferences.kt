package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.Settings
import com.example.model.AccentPreset
import com.example.model.AiTriggerActionType
import com.example.model.AiTriggerRule
import com.example.model.AppLanguage
import com.example.model.BurikConfig
import com.example.model.BurikPreset
import com.example.model.CompileStatus
import com.example.model.CrosshairConfig
import com.example.model.CrosshairShape
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.HudConfig
import com.example.model.HudPosition
import com.example.model.MacroConfig
import com.example.model.MacroInjectionMode
import com.example.model.MacroPattern
import com.example.model.PanelTab
import com.example.model.RadialConfig
import com.example.model.ThemeMode
import com.example.model.TouchArea
import com.example.model.TouchConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Lightweight, singleton reactive preferences repository backed by SharedPreferences.
 * Shared seamlessly between MainActivity UI and GameOverlayService.
 */
class BoosterPreferences private constructor(context: Context) {

    private val appContext: Context = context.applicationContext

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("xa_gamespace_prefs", Context.MODE_PRIVATE)

    val deviceSessionId: String by lazy {
        val raw = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: "xa-panel-default"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        digest.take(4).joinToString("") { "%02x".format(it) }
    }

    private val _addedGames = MutableStateFlow(loadAddedGames())
    val addedGames: StateFlow<Set<String>> = _addedGames.asStateFlow()

    private val _compiledGames = MutableStateFlow(loadCompiledGames())
    val compiledGames: StateFlow<Set<String>> = _compiledGames.asStateFlow()

    private val _perGameBurik = MutableStateFlow(loadPerGameBurik())
    val perGameBurik: StateFlow<Map<String, BurikPreset>> = _perGameBurik.asStateFlow()

    private val _gameSessionActive = MutableStateFlow(prefs.getBoolean("game_session_active", false))
    val gameSessionActive: StateFlow<Boolean> = _gameSessionActive.asStateFlow()

    private val _fastAnimationEnabled = MutableStateFlow(prefs.getBoolean("fast_anim", false))
    val fastAnimationEnabled: StateFlow<Boolean> = _fastAnimationEnabled.asStateFlow()

    private val _useShizuku = MutableStateFlow(prefs.getBoolean("use_shizuku", true))
    val useShizuku: StateFlow<Boolean> = _useShizuku.asStateFlow()

    private val _restoreAfterSession = MutableStateFlow(prefs.getBoolean("restore_after_session", true))
    val restoreAfterSession: StateFlow<Boolean> = _restoreAfterSession.asStateFlow()

    private val _dndOnSession = MutableStateFlow(prefs.getBoolean("dnd_on_session", false))
    val dndOnSession: StateFlow<Boolean> = _dndOnSession.asStateFlow()

    private val _boostScore = MutableStateFlow(prefs.getInt("boost_score", 25))
    val boostScore: StateFlow<Int> = _boostScore.asStateFlow()

    private val _hudConfig = MutableStateFlow(loadHudConfig())
    val hudConfig: StateFlow<HudConfig> = _hudConfig.asStateFlow()

    private val _touchConfig = MutableStateFlow(loadTouchConfig())
    val touchConfig: StateFlow<TouchConfig> = _touchConfig.asStateFlow()

    private val _crosshairConfig = MutableStateFlow(loadCrosshairConfig())
    val crosshairConfig: StateFlow<CrosshairConfig> = _crosshairConfig.asStateFlow()

    private val _macroConfig = MutableStateFlow(loadMacroConfig())
    val macroConfig: StateFlow<MacroConfig> = _macroConfig.asStateFlow()

    private val _burikConfig = MutableStateFlow(loadBurikConfig())
    val burikConfig: StateFlow<BurikConfig> = _burikConfig.asStateFlow()

    private val _fpsLockConfig = MutableStateFlow(loadFpsLockConfig())
    val fpsLockConfig: StateFlow<FpsLockConfig> = _fpsLockConfig.asStateFlow()

    private val _radialConfig = MutableStateFlow(loadRadialConfig())
    val radialConfig: StateFlow<RadialConfig> = _radialConfig.asStateFlow()

    private val _edgeHandleRight = MutableStateFlow(prefs.getBoolean("edge_handle_right", false))
    val edgeHandleRight: StateFlow<Boolean> = _edgeHandleRight.asStateFlow()

    private val _edgeHandleNormY = MutableStateFlow(prefs.getFloat("edge_handle_norm_y", 0.48f))
    val edgeHandleNormY: StateFlow<Float> = _edgeHandleNormY.asStateFlow()

    private val _themeMode = MutableStateFlow(
        runCatching { ThemeMode.valueOf(prefs.getString("theme_mode", ThemeMode.DARK.name)!!) }
            .getOrDefault(ThemeMode.DARK)
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _accentPreset = MutableStateFlow(
        runCatching { AccentPreset.valueOf(prefs.getString("accent_preset", AccentPreset.MONO.name)!!) }
            .getOrDefault(AccentPreset.MONO)
    )
    val accentPreset: StateFlow<AccentPreset> = _accentPreset.asStateFlow()

    private val _language = MutableStateFlow(
        runCatching { AppLanguage.valueOf(prefs.getString("app_lang", AppLanguage.INDONESIAN.name)!!) }
            .getOrDefault(AppLanguage.INDONESIAN)
    )
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _macroPlacementMode = MutableStateFlow(false)
    val macroPlacementMode: StateFlow<Boolean> = _macroPlacementMode.asStateFlow()

    private val _overlayPanelExpanded = MutableStateFlow(false)
    val overlayPanelExpanded: StateFlow<Boolean> = _overlayPanelExpanded.asStateFlow()

    private val _requestedPanelTab = MutableStateFlow<PanelTab?>(null)
    val requestedPanelTab: StateFlow<PanelTab?> = _requestedPanelTab.asStateFlow()

    private val _aiTriggerMasterEnabled = MutableStateFlow(prefs.getBoolean("ai_trigger_master", false))
    val aiTriggerMasterEnabled: StateFlow<Boolean> = _aiTriggerMasterEnabled.asStateFlow()

    private val _aiTriggerRules = MutableStateFlow(loadAiTriggerRules())
    val aiTriggerRules: StateFlow<List<AiTriggerRule>> = _aiTriggerRules.asStateFlow()

    private val _aiCropOverlayMode = MutableStateFlow(false)
    val aiCropOverlayMode: StateFlow<Boolean> = _aiCropOverlayMode.asStateFlow()

    private val _aiTargetPickerMode = MutableStateFlow(false)
    val aiTargetPickerMode: StateFlow<Boolean> = _aiTargetPickerMode.asStateFlow()

    private val _aiDraftRule = MutableStateFlow<AiTriggerRule?>(null)
    val aiDraftRule: StateFlow<AiTriggerRule?> = _aiDraftRule.asStateFlow()

    private val _activeSessionGamePkg = MutableStateFlow<String?>(null)
    val activeSessionGamePkg: StateFlow<String?> = _activeSessionGamePkg.asStateFlow()

    fun setAddedGames(packages: Set<String>) {
        _addedGames.value = packages
        prefs.edit().putStringSet("added_games", packages).apply()
    }

    fun toggleAddedGame(packageName: String) {
        val current = _addedGames.value.toMutableSet()
        if (current.contains(packageName)) current.remove(packageName) else current.add(packageName)
        setAddedGames(current)
    }

    fun markCompiled(packageName: String, compiled: Boolean = true) {
        val next = _compiledGames.value.toMutableSet()
        if (compiled) next.add(packageName) else next.remove(packageName)
        _compiledGames.value = next
        prefs.edit().putStringSet("compiled_games", next).apply()
    }

    fun compileStatusFor(packageName: String): CompileStatus =
        if (_compiledGames.value.contains(packageName)) CompileStatus.COMPILED else CompileStatus.NOT_COMPILED

    fun setGameBurikOverride(packageName: String, preset: BurikPreset?) {
        val next = _perGameBurik.value.toMutableMap()
        if (preset == null) next.remove(packageName) else next[packageName] = preset
        _perGameBurik.value = next
        val obj = JSONObject()
        next.forEach { (k, v) -> obj.put(k, v.name) }
        prefs.edit().putString("per_game_burik", obj.toString()).apply()
    }

    fun setGameSessionActive(active: Boolean, gamePkg: String? = _activeSessionGamePkg.value) {
        _gameSessionActive.value = active
        _activeSessionGamePkg.value = if (active) gamePkg else null
        prefs.edit().putBoolean("game_session_active", active).apply()
    }

    fun setFastAnimation(enabled: Boolean) {
        _fastAnimationEnabled.value = enabled
        prefs.edit().putBoolean("fast_anim", enabled).apply()
    }

    fun setUseShizuku(enabled: Boolean) {
        _useShizuku.value = enabled
        prefs.edit().putBoolean("use_shizuku", enabled).apply()
    }

    fun setRestoreAfterSession(enabled: Boolean) {
        _restoreAfterSession.value = enabled
        prefs.edit().putBoolean("restore_after_session", enabled).apply()
    }

    fun setDndOnSession(enabled: Boolean) {
        _dndOnSession.value = enabled
        prefs.edit().putBoolean("dnd_on_session", enabled).apply()
    }

    fun setBoostScore(score: Int) {
        val clamped = score.coerceIn(0, 100)
        _boostScore.value = clamped
        prefs.edit().putInt("boost_score", clamped).apply()
    }

    fun updateHudConfig(transform: (HudConfig) -> HudConfig) {
        val updated = transform(_hudConfig.value)
        _hudConfig.value = updated
        saveHudConfig(updated)
    }

    fun updateTouchConfig(transform: (TouchConfig) -> TouchConfig) {
        val updated = transform(_touchConfig.value)
        _touchConfig.value = updated
        saveTouchConfig(updated)
    }

    fun updateCrosshairConfig(transform: (CrosshairConfig) -> CrosshairConfig) {
        val updated = transform(_crosshairConfig.value)
        _crosshairConfig.value = updated
        saveCrosshairConfig(updated)
    }

    fun updateMacroConfig(transform: (MacroConfig) -> MacroConfig) {
        val updated = transform(_macroConfig.value)
        _macroConfig.value = updated
        saveMacroConfig(updated)
    }

    fun updateBurikConfig(transform: (BurikConfig) -> BurikConfig) {
        val updated = transform(_burikConfig.value)
        _burikConfig.value = updated
        saveBurikConfig(updated)
    }

    fun updateFpsLockConfig(transform: (FpsLockConfig) -> FpsLockConfig) {
        val updated = transform(_fpsLockConfig.value)
        _fpsLockConfig.value = updated
        saveFpsLockConfig(updated)
    }

    fun updateRadialConfig(transform: (RadialConfig) -> RadialConfig) {
        val updated = transform(_radialConfig.value)
        _radialConfig.value = updated
        saveRadialConfig(updated)
    }

    fun setEdgeHandlePosition(isRightEdge: Boolean, normY: Float) {
        val clampedY = normY.coerceIn(0.05f, 0.95f)
        _edgeHandleRight.value = isRightEdge
        _edgeHandleNormY.value = clampedY
        prefs.edit()
            .putBoolean("edge_handle_right", isRightEdge)
            .putFloat("edge_handle_norm_y", clampedY)
            .apply()
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun setAccentPreset(preset: AccentPreset) {
        _accentPreset.value = preset
        prefs.edit().putString("accent_preset", preset.name).apply()
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        prefs.edit().putString("app_lang", lang.name).apply()
    }

    fun setMacroPlacementMode(enabled: Boolean) {
        _macroPlacementMode.value = enabled
    }

    fun setOverlayPanelExpanded(expanded: Boolean) {
        _overlayPanelExpanded.value = expanded
    }

    fun requestPanelTab(tab: PanelTab?) {
        _requestedPanelTab.value = tab
    }

    fun setAiTriggerMasterEnabled(enabled: Boolean) {
        _aiTriggerMasterEnabled.value = enabled
        prefs.edit().putBoolean("ai_trigger_master", enabled).apply()
    }

    fun setAiCropOverlayMode(enabled: Boolean) {
        _aiCropOverlayMode.value = enabled
    }

    fun setAiTargetPickerMode(enabled: Boolean) {
        _aiTargetPickerMode.value = enabled
    }

    fun setAiDraftRule(rule: AiTriggerRule?) {
        _aiDraftRule.value = rule
    }

    fun upsertAiTriggerRule(rule: AiTriggerRule) {
        val current = _aiTriggerRules.value.toMutableList()
        val idx = current.indexOfFirst { it.id == rule.id }
        if (idx >= 0) {
            current[idx] = rule
        } else {
            if (current.size >= 5) return
            current.add(rule)
        }
        _aiTriggerRules.value = current
        saveAiTriggerRules(current)
    }

    fun toggleAiTriggerRule(id: String, enabled: Boolean) {
        val updated = _aiTriggerRules.value.map {
            if (it.id == id) it.copy(enabled = enabled) else it
        }
        _aiTriggerRules.value = updated
        saveAiTriggerRules(updated)
    }

    fun deleteAiTriggerRule(id: String) {
        val target = _aiTriggerRules.value.firstOrNull { it.id == id }
        val updated = _aiTriggerRules.value.filterNot { it.id == id }
        _aiTriggerRules.value = updated
        saveAiTriggerRules(updated)
        target?.templatePath?.let { path ->
            if (path.isNotBlank()) runCatching { File(path).delete() }
        }
    }

    fun saveAiTemplateBitmap(ruleId: String, bitmap: Bitmap): String? {
        return runCatching {
            val dir = File(appContext.filesDir, "ai_triggers").apply { mkdirs() }
            val safeId = ruleId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val file = File(dir, "$safeId.png")
            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            file.absolutePath
        }.getOrNull()
    }

    fun loadAiTemplateBitmap(path: String): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists()) return null
        return runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
    }

    private fun loadAddedGames(): Set<String> =
        prefs.getStringSet("added_games", emptySet())?.toSet() ?: emptySet()

    private fun loadCompiledGames(): Set<String> =
        prefs.getStringSet("compiled_games", emptySet())?.toSet() ?: emptySet()

    private fun loadPerGameBurik(): Map<String, BurikPreset> {
        val raw = prefs.getString("per_game_burik", null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            val map = mutableMapOf<String, BurikPreset>()
            obj.keys().forEach { key ->
                runCatching { map[key] = BurikPreset.valueOf(obj.getString(key)) }
            }
            map
        }.getOrDefault(emptyMap())
    }

    private fun loadHudConfig(): HudConfig {
        val raw = prefs.getString("hud_config", null) ?: return HudConfig()
        return runCatching {
            val o = JSONObject(raw)
            HudConfig(
                enabled = o.optBoolean("enabled", false),
                position = runCatching { HudPosition.valueOf(o.optString("position", "CENTER")) }
                    .getOrDefault(HudPosition.CENTER),
                scalePercent = o.optInt("scalePercent", 100),
                opacityPercent = o.optInt("opacityPercent", 92),
                hideOnTouch = o.optBoolean("hideOnTouch", false),
                updateIntervalMs = o.optInt("updateIntervalMs", 250),
                showFps = o.optBoolean("showFps", true),
                showCpu = o.optBoolean("showCpu", true),
                showRam = o.optBoolean("showRam", false),
                showTemp = o.optBoolean("showTemp", true),
                showBattery = o.optBoolean("showBattery", false),
                showPing = o.optBoolean("showPing", false),
                showLabels = o.optBoolean("showLabels", true),
                compactMode = o.optBoolean("compactMode", false),
                singleRow = o.optBoolean("singleRow", true),
                useFahrenheit = o.optBoolean("useFahrenheit", false)
            )
        }.getOrDefault(HudConfig())
    }

    private fun saveHudConfig(c: HudConfig) {
        val o = JSONObject().apply {
            put("enabled", c.enabled)
            put("position", c.position.name)
            put("scalePercent", c.scalePercent)
            put("opacityPercent", c.opacityPercent)
            put("hideOnTouch", c.hideOnTouch)
            put("updateIntervalMs", c.updateIntervalMs)
            put("showFps", c.showFps)
            put("showCpu", c.showCpu)
            put("showRam", c.showRam)
            put("showTemp", c.showTemp)
            put("showBattery", c.showBattery)
            put("showPing", c.showPing)
            put("showLabels", c.showLabels)
            put("compactMode", c.compactMode)
            put("singleRow", c.singleRow)
            put("useFahrenheit", c.useFahrenheit)
        }
        prefs.edit().putString("hud_config", o.toString()).apply()
    }

    private fun loadTouchConfig(): TouchConfig {
        val raw = prefs.getString("touch_config", null) ?: return TouchConfig()
        return runCatching {
            val o = JSONObject(raw)
            TouchConfig(
                enabled = o.optBoolean("enabled", false),
                speedX = o.optInt("speedX", 0),
                speedY = o.optInt("speedY", 0),
                responseBoost = o.optInt("responseBoost", 0),
                area = runCatching { TouchArea.valueOf(o.optString("area", "ALL")) }
                    .getOrDefault(TouchArea.ALL),
                smoothing = o.optInt("smoothing", 0),
                deadzone = o.optInt("deadzone", 0),
                dpiBoostEnabled = o.optBoolean("dpiBoostEnabled", true),
                nubiaGameTweakEnabled = o.optBoolean("nubiaGameTweakEnabled", true),
                liveAimPadEnabled = o.optBoolean("liveAimPadEnabled", false),
                aimPadNormX = o.optDouble("aimPadNormX", 0.76).toFloat().coerceIn(0.10f, 0.90f),
                aimPadNormY = o.optDouble("aimPadNormY", 0.44).toFloat().coerceIn(0.12f, 0.88f),
                aimPadLocked = o.optBoolean("aimPadLocked", false)
            )
        }.getOrDefault(TouchConfig())
    }

    private fun saveTouchConfig(c: TouchConfig) {
        val o = JSONObject().apply {
            put("enabled", c.enabled)
            put("speedX", c.speedX)
            put("speedY", c.speedY)
            put("responseBoost", c.responseBoost)
            put("area", c.area.name)
            put("smoothing", c.smoothing)
            put("deadzone", c.deadzone)
            put("dpiBoostEnabled", c.dpiBoostEnabled)
            put("nubiaGameTweakEnabled", c.nubiaGameTweakEnabled)
            put("liveAimPadEnabled", c.liveAimPadEnabled)
            put("aimPadNormX", c.aimPadNormX.toDouble())
            put("aimPadNormY", c.aimPadNormY.toDouble())
            put("aimPadLocked", c.aimPadLocked)
        }
        prefs.edit().putString("touch_config", o.toString()).apply()
    }

    private fun loadCrosshairConfig(): CrosshairConfig {
        val raw = prefs.getString("crosshair_config", null) ?: return CrosshairConfig()
        return runCatching {
            val o = JSONObject(raw)
            CrosshairConfig(
                enabled = o.optBoolean("enabled", false),
                shape = runCatching { CrosshairShape.valueOf(o.optString("shape", "TARGET")) }
                    .getOrDefault(CrosshairShape.TARGET),
                outline = o.optBoolean("outline", true),
                sizeDp = o.optInt("sizeDp", 14),
                thicknessDp = o.optInt("thicknessDp", 2),
                gapDp = o.optInt("gapDp", 3),
                colorIndex = o.optInt("colorIndex", 1),
                offsetX = o.optInt("offsetX", 0),
                offsetY = o.optInt("offsetY", 0)
            )
        }.getOrDefault(CrosshairConfig())
    }

    private fun saveCrosshairConfig(c: CrosshairConfig) {
        val o = JSONObject().apply {
            put("enabled", c.enabled)
            put("shape", c.shape.name)
            put("outline", c.outline)
            put("sizeDp", c.sizeDp)
            put("thicknessDp", c.thicknessDp)
            put("gapDp", c.gapDp)
            put("colorIndex", c.colorIndex)
            put("offsetX", c.offsetX)
            put("offsetY", c.offsetY)
        }
        prefs.edit().putString("crosshair_config", o.toString()).apply()
    }

    private fun loadMacroConfig(): MacroConfig {
        val raw = prefs.getString("macro_config", null) ?: return MacroConfig()
        return runCatching {
            val o = JSONObject(raw)
            MacroConfig(
                enabled = o.optBoolean("enabled", false),
                pattern = runCatching { MacroPattern.valueOf(o.optString("pattern", "REPEAT")) }
                    .getOrDefault(MacroPattern.REPEAT),
                injectionMode = runCatching {
                    MacroInjectionMode.valueOf(o.optString("injectionMode", MacroInjectionMode.SMART_POINTER.name))
                }.getOrDefault(MacroInjectionMode.SMART_POINTER),
                triggerScale = o.optDouble("triggerScale", 1.0).toFloat(),
                intervalMs = o.optInt("intervalMs", 150),
                holdDurationMs = o.optInt("holdDurationMs", 35),
                randomJitterPx = o.optInt("randomJitterPx", 0),
                burstCount = o.optInt("burstCount", 3),
                showTarget = o.optBoolean("showTarget", true),
                triggerNormX = o.optDouble("triggerNormX", 0.22).toFloat(),
                triggerNormY = o.optDouble("triggerNormY", 0.62).toFloat(),
                targetNormX = o.optDouble("targetNormX", 0.48).toFloat(),
                targetNormY = o.optDouble("targetNormY", 0.56).toFloat(),
                enableTarget2 = o.optBoolean("enableTarget2", false),
                target2NormX = o.optDouble("target2NormX", 0.68).toFloat(),
                target2NormY = o.optDouble("target2NormY", 0.36).toFloat(),
                switchDelayMs = o.optInt("switchDelayMs", 120).coerceIn(25, 1200),
                isLocked = o.optBoolean("isLocked", false),
                holdToTrigger = o.optBoolean("holdToTrigger", true),
                lockedOpacity = o.optDouble("lockedOpacity", 0.30).toFloat().coerceIn(0.15f, 0.70f),
                isRunning = false
            )
        }.getOrDefault(MacroConfig())
    }

    private fun saveMacroConfig(c: MacroConfig) {
        val o = JSONObject().apply {
            put("enabled", c.enabled)
            put("pattern", c.pattern.name)
            put("injectionMode", c.injectionMode.name)
            put("triggerScale", c.triggerScale.toDouble())
            put("intervalMs", c.intervalMs)
            put("holdDurationMs", c.holdDurationMs)
            put("randomJitterPx", c.randomJitterPx)
            put("burstCount", c.burstCount)
            put("showTarget", c.showTarget)
            put("triggerNormX", c.triggerNormX.toDouble())
            put("triggerNormY", c.triggerNormY.toDouble())
            put("targetNormX", c.targetNormX.toDouble())
            put("targetNormY", c.targetNormY.toDouble())
            put("enableTarget2", c.enableTarget2)
            put("target2NormX", c.target2NormX.toDouble())
            put("target2NormY", c.target2NormY.toDouble())
            put("switchDelayMs", c.switchDelayMs)
            put("isLocked", c.isLocked)
            put("holdToTrigger", c.holdToTrigger)
            put("lockedOpacity", c.lockedOpacity.toDouble())
        }
        prefs.edit().putString("macro_config", o.toString()).apply()
    }

    private fun loadFpsLockConfig(): FpsLockConfig {
        val raw = prefs.getString("fps_lock_config", null) ?: return FpsLockConfig()
        return runCatching {
            val o = JSONObject(raw)
            FpsLockConfig(
                target = runCatching { FpsLockTarget.valueOf(o.optString("target", "DEFAULT")) }
                    .getOrDefault(FpsLockTarget.DEFAULT),
                forceSystemRefreshRate = o.optBoolean("forceSystemRefreshRate", true),
                applyToAllGames = o.optBoolean("applyToAllGames", true)
            )
        }.getOrDefault(FpsLockConfig())
    }

    private fun saveFpsLockConfig(c: FpsLockConfig) {
        val o = JSONObject().apply {
            put("target", c.target.name)
            put("forceSystemRefreshRate", c.forceSystemRefreshRate)
            put("applyToAllGames", c.applyToAllGames)
        }
        prefs.edit().putString("fps_lock_config", o.toString()).apply()
    }

    private fun loadBurikConfig(): BurikConfig {
        val raw = prefs.getString("burik_config", null) ?: return BurikConfig()
        return runCatching {
            val o = JSONObject(raw)
            BurikConfig(
                preset = runCatching { BurikPreset.valueOf(o.optString("preset", "OFF")) }
                    .getOrDefault(BurikPreset.OFF),
                customTextureQualityPercent = o.optInt("customTextureQualityPercent", 50).coerceIn(15, 100),
                customMipmapLevel = o.optInt("customMipmapLevel", 2).coerceIn(0, 4),
                customNearestFiltering = o.optBoolean("customNearestFiltering", true),
                customDisableAnisotropic = o.optBoolean("customDisableAnisotropic", true),
                applyAllGames = o.optBoolean("applyAllGames", true)
            )
        }.getOrDefault(BurikConfig())
    }

    private fun saveBurikConfig(c: BurikConfig) {
        val o = JSONObject().apply {
            put("preset", c.preset.name)
            put("customTextureQualityPercent", c.customTextureQualityPercent)
            put("customMipmapLevel", c.customMipmapLevel)
            put("customNearestFiltering", c.customNearestFiltering)
            put("customDisableAnisotropic", c.customDisableAnisotropic)
            put("applyAllGames", c.applyAllGames)
        }
        prefs.edit().putString("burik_config", o.toString()).apply()
    }

    private fun loadRadialConfig(): RadialConfig {
        val raw = prefs.getString("radial_config", null) ?: return RadialConfig()
        return runCatching {
            val o = JSONObject(raw)
            RadialConfig(
                enabled = o.optBoolean("enabled", false),
                normX = o.optDouble("normX", 0.90).toFloat(),
                normY = o.optDouble("normY", 0.45).toFloat()
            )
        }.getOrDefault(RadialConfig())
    }

    private fun saveRadialConfig(c: RadialConfig) {
        val o = JSONObject().apply {
            put("enabled", c.enabled)
            put("normX", c.normX.toDouble())
            put("normY", c.normY.toDouble())
        }
        prefs.edit().putString("radial_config", o.toString()).apply()
    }

    private fun loadAiTriggerRules(): List<AiTriggerRule> {
        val raw = prefs.getString("ai_trigger_rules", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id", "").ifBlank { "ai_${i}_${System.currentTimeMillis()}" }
                    val legacyPrecision = o.optInt("matchThresholdPercent", 82)
                    val precision = o.optInt("matchPrecision", legacyPrecision).coerceIn(60, 100)
                    val targetX = if (o.has("targetAimNormX")) o.optDouble("targetAimNormX", 0.76)
                    else o.optDouble("tapNormX", 0.76)
                    val targetY = if (o.has("targetAimNormY")) o.optDouble("targetAimNormY", 0.50)
                    else o.optDouble("tapNormY", 0.50)
                    val crossX = if (o.has("gameCrosshairNormX")) o.optDouble("gameCrosshairNormX", 0.50)
                    else o.optDouble("aiCrosshairNormX", 0.50)
                    val crossY = if (o.has("gameCrosshairNormY")) o.optDouble("gameCrosshairNormY", 0.50)
                    else o.optDouble("aiCrosshairNormY", 0.50)
                    add(
                        AiTriggerRule(
                            id = id,
                            name = o.optString("name", "AI Trigger ${(i + 1).toString().padStart(2, '0')}"),
                            enabled = o.optBoolean("enabled", true),
                            templatePath = o.optString("templatePath", ""),
                            cropLeftNorm = o.optDouble("cropLeftNorm", 0.475).toFloat().coerceIn(0f, 0.98f),
                            cropTopNorm = o.optDouble("cropTopNorm", 0.39).toFloat().coerceIn(0f, 0.98f),
                            cropRightNorm = o.optDouble("cropRightNorm", 0.525).toFloat().coerceIn(0.02f, 1f),
                            cropBottomNorm = o.optDouble("cropBottomNorm", 0.61).toFloat().coerceIn(0.02f, 1f),
                            templateWidth = o.optInt("templateWidth", 0),
                            templateHeight = o.optInt("templateHeight", 0),
                            matchPrecision = precision,
                            minIntervalMs = o.optInt("minIntervalMs", 60).coerceIn(40, 2000),
                            actionType = AiTriggerActionType.HEAD_LOCK,
                            targetAimNormX = targetX.toFloat().coerceIn(0.04f, 0.96f),
                            targetAimNormY = targetY.toFloat().coerceIn(0.04f, 0.96f),
                            gameCrosshairNormX = crossX.toFloat().coerceIn(0.15f, 0.85f),
                            gameCrosshairNormY = crossY.toFloat().coerceIn(0.15f, 0.85f),
                            contactRadiusPercent = o.optInt("contactRadiusPercent", 28).coerceIn(5, 60),
                            headOffsetXPercent = o.optInt("headOffsetXPercent", 50).coerceIn(10, 90),
                            headOffsetPercent = o.optInt("headOffsetPercent", 18).coerceIn(5, 55),
                            headLiftPower = o.optInt("headLiftPower", 125).coerceIn(50, 220),
                            showLiveHud = o.optBoolean("showLiveHud", true),
                            autoTriggerAllZones = o.optBoolean("autoTriggerAllZones", true)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun saveAiTriggerRules(rules: List<AiTriggerRule>) {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("name", r.name)
                    put("enabled", r.enabled)
                    put("templatePath", r.templatePath)
                    put("cropLeftNorm", r.cropLeftNorm.toDouble())
                    put("cropTopNorm", r.cropTopNorm.toDouble())
                    put("cropRightNorm", r.cropRightNorm.toDouble())
                    put("cropBottomNorm", r.cropBottomNorm.toDouble())
                    put("templateWidth", r.templateWidth)
                    put("templateHeight", r.templateHeight)
                    put("matchPrecision", r.matchPrecision)
                    put("minIntervalMs", r.minIntervalMs)
                    put("actionType", AiTriggerActionType.HEAD_LOCK.name)
                    put("targetAimNormX", r.targetAimNormX.toDouble())
                    put("targetAimNormY", r.targetAimNormY.toDouble())
                    put("gameCrosshairNormX", r.gameCrosshairNormX.toDouble())
                    put("gameCrosshairNormY", r.gameCrosshairNormY.toDouble())
                    put("contactRadiusPercent", r.contactRadiusPercent)
                    put("headOffsetXPercent", r.headOffsetXPercent)
                    put("headOffsetPercent", r.headOffsetPercent)
                    put("headLiftPower", r.headLiftPower)
                    put("showLiveHud", r.showLiveHud)
                    put("autoTriggerAllZones", r.autoTriggerAllZones)
                }
            )
        }
        prefs.edit().putString("ai_trigger_rules", arr.toString()).apply()
    }

    companion object {
        @Volatile
        private var instance: BoosterPreferences? = null

        fun getInstance(context: Context): BoosterPreferences =
            instance ?: synchronized(this) {
                instance ?: BoosterPreferences(context).also { instance = it }
            }
    }
}
