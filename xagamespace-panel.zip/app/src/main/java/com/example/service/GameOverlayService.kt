package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas as AndroidCanvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.core.AiTriggerCaptureManager
import com.example.core.AiTriggerEngine
import com.example.core.ShizukuBridge
import com.example.core.SystemOptimizer
import com.example.core.TelemetryMonitor
import com.example.data.BoosterPreferences
import com.example.model.AiTriggerRule
import com.example.model.BurikPreset
import com.example.model.CrosshairConfig
import com.example.model.CrosshairShape
import com.example.model.FpsLockTarget
import com.example.model.HudPosition
import com.example.model.MacroConfig
import com.example.model.MacroInjectionMode
import com.example.model.MacroPattern
import com.example.model.PanelTab
import com.example.model.TouchConfig
import com.example.ui.icons.AppIcons
import com.example.ui.overlay.FloatingGamePanelContent
import com.example.ui.theme.CrosshairPalette
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianTextPrimary
import com.example.ui.theme.ObsidianTextSecondary
import com.example.ui.theme.StatusCyan
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.XAGameSpaceTheme
import com.example.ui.theme.accentColorFor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Foreground overlay service managing independent, dynamically added/removed WindowManager layers.
 * Crucially:
 * - Every window uses FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL so background touches/swipes ALWAYS pass through.
 * - Crosshair and Macro Connector use lightweight native View canvases (never full-screen ComposeView).
 * - Disabled overlay windows are completely removed from WindowManager rather than left invisible.
 */
class GameOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: BoosterPreferences
    private lateinit var telemetryMonitor: TelemetryMonitor
    private lateinit var optimizer: SystemOptimizer
    private val lifecycleOwner = ServiceLifecycleOwner()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var hudView: ComposeView? = null
    private var hudParams: WindowManager.LayoutParams? = null

    private var edgeHandleView: EdgeHandleTabView? = null
    private var edgeHandleParams: WindowManager.LayoutParams? = null

    private var crosshairView: CrosshairCanvasView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null

    private var macroLineView: MacroConnectorCanvasView? = null
    private var macroLineParams: WindowManager.LayoutParams? = null

    private var macroTriggerView: MacroTriggerOverlayView? = null
    private var macroTriggerParams: WindowManager.LayoutParams? = null

    private var macroTargetView: MacroTargetOverlayView? = null
    private var macroTargetParams: WindowManager.LayoutParams? = null

    private var macroTarget2View: MacroTargetOverlayView? = null
    private var macroTarget2Params: WindowManager.LayoutParams? = null

    private var macroLockChipView: ComposeView? = null
    private var dpadEditorView: ComposeView? = null
    private var radialView: ComposeView? = null
    private var radialParams: WindowManager.LayoutParams? = null

    private var panelView: ComposeView? = null
    private var panelParams: WindowManager.LayoutParams? = null

    private var touchAimPadView: TouchAimBoosterPadView? = null
    private var touchAimPadParams: WindowManager.LayoutParams? = null

    private var aiCropOverlayView: AiCropBoxOverlayView? = null
    private var aiCropBarView: ComposeView? = null
    private var aiCropHintView: ComposeView? = null
    private var aiTargetPickerView: AiTargetPickerOverlayView? = null
    private var aiTargetBarView: ComposeView? = null
    private var aiTargetHintView: ComposeView? = null
    private var aiCrosshairView: AiTriggerCrosshairView? = null
    private var aiStatusBadgeView: ComposeView? = null
    private var aiStatusBadgeParams: WindowManager.LayoutParams? = null
    private var aiPickerPreviewBitmap: android.graphics.Bitmap? = null

    private var aiCropWidthPx by mutableIntStateOf(0)
    private var aiCropHeightPx by mutableIntStateOf(0)
    private var aiHeadOffsetXPct by mutableIntStateOf(50)
    private var aiHeadOffsetYPct by mutableIntStateOf(18)

    private var statusBannerMessage by mutableStateOf<String?>(null)
    private var statusClearJob: Job? = null
    private var touchApplyJob: Job? = null
    private var burikApplyJob: Job? = null
    private var shizukuMacroJob: Job? = null
    private var foregroundWatcherJob: Job? = null
    private var cachedPhysDpi: Int = 0
    private var lastShizukuHintAtMs = 0L
    private var shownNonRootLatchHint = false
    private var activePlacementTarget by mutableStateOf(1) // 0 = Trigger, 1 = Target 1 (Tembak), 2 = Target 2 (Senjata)

    private var triggerHalfW = 54
    private var triggerHalfH = 54
    private var targetHalfW = 42
    private var targetHalfH = 42
    private var target2HalfW = 42
    private var target2HalfH = 42

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = BoosterPreferences.getInstance(this)
        telemetryMonitor = TelemetryMonitor.getInstance(this)
        optimizer = SystemOptimizer(this, prefs)
        ShizukuBridge.init(this)

        lifecycleOwner.onCreate()
        lifecycleOwner.onStart()

        startForegroundNotification()
        serviceScope.launch {
            cachedPhysDpi = optimizer.readPhysicalDensityDpi()
        }
        observeOverlayState()
        startForegroundGameExitWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.setOverlayPanelExpanded(false)
                prefs.setMacroPlacementMode(false)
                prefs.setAiCropOverlayMode(false)
                prefs.setAiTargetPickerMode(false)
                AiTriggerEngine.stopLoop(prefs)
                AiTriggerProjectionService.stop(this)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_OPEN_PANEL -> prefs.setOverlayPanelExpanded(true)
            ACTION_BOOST -> triggerBoost()
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "xa_game_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                channelId,
                getString(R.string.overlay_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.overlay_channel_desc)
            }
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPanelIntent = PendingIntent.getService(
            this, 1,
            Intent(this, GameOverlayService::class.java).setAction(ACTION_OPEN_PANEL),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, GameOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notif_ai)
            .setContentTitle("XAGameSpacepanel Aktif")
            .setContentText("HUD, Macro & Optimizer siap di atas game")
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Buka Panel", openPanelIntent)
            .addAction(0, "Tutup", stopIntent)
            .build()

        runCatching {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun interactiveFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun passThroughFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun attachComposeOwners(view: ComposeView) {
        view.setViewTreeLifecycleOwner(lifecycleOwner)
        view.setViewTreeSavedStateRegistryOwner(lifecycleOwner)
        view.setViewTreeViewModelStoreOwner(lifecycleOwner)
    }

    private fun dpToPx(dp: Float): Int =
        (dp * resources.displayMetrics.density).roundToInt()

    private fun observeOverlayState() {
        // 1. Performance HUD window lifecycle & background telemetry polling
        serviceScope.launch {
            combine(prefs.hudConfig, prefs.overlayPanelExpanded) { hud, panelOpen ->
                hud to panelOpen
            }.collectLatest { (hud, panelOpen) ->
                if (hud.enabled || panelOpen) {
                    telemetryMonitor.start()
                } else {
                    telemetryMonitor.stop()
                }
                if (hud.enabled) {
                    ensureHudWindow()
                    hudParams?.let { p ->
                        val targetGravity = Gravity.TOP or when (hud.position) {
                            HudPosition.LEFT -> Gravity.START
                            HudPosition.CENTER -> Gravity.CENTER_HORIZONTAL
                            HudPosition.RIGHT -> Gravity.END
                        }
                        if (p.gravity != targetGravity) {
                            p.gravity = targetGravity
                            p.x = 0
                            runCatching { windowManager.updateViewLayout(hudView, p) }
                        }
                    }
                } else {
                    removeHudWindow()
                }
            }
        }

        // 2. Edge Handle window lifecycle
        serviceScope.launch {
            combine(
                combine(prefs.overlayPanelExpanded, prefs.aiCropOverlayMode, prefs.aiTargetPickerMode) { exp, crop, pick ->
                    !exp && !crop && !pick
                },
                prefs.gameSessionActive,
                prefs.hudConfig,
                prefs.macroConfig,
                combine(prefs.crosshairConfig, prefs.aiTriggerMasterEnabled) { ch, ai -> ch.enabled || ai }
            ) { canShow, session, hud, macro, chOrAi ->
                canShow && (session || hud.enabled || macro.enabled || chOrAi)
            }.collectLatest { shouldShowEdge ->
                if (shouldShowEdge) ensureEdgeHandleWindow() else removeEdgeHandleWindow()
            }
        }

        // Keep Edge Handle accent color synced
        serviceScope.launch {
            prefs.accentPreset.collectLatest { preset ->
                edgeHandleView?.setAccentColor(accentColorFor(preset, true).toArgb())
            }
        }

        // 3. Crosshair compact pass-through window lifecycle
        serviceScope.launch {
            prefs.crosshairConfig.collectLatest { ch ->
                if (ch.enabled) {
                    ensureCrosshairWindow(ch)
                } else {
                    removeCrosshairWindow()
                }
            }
        }

        // 4. Macro Trigger, Target & Connector Line windows lifecycle
        serviceScope.launch {
            combine(
                prefs.macroConfig,
                prefs.macroPlacementMode,
                prefs.overlayPanelExpanded,
                prefs.accentPreset
            ) { macro, placement, panelOpen, accentPreset ->
                listOf(macro, placement, panelOpen, accentPreset)
            }.collectLatest { values ->
                val macro = values[0] as MacroConfig
                val placement = values[1] as Boolean
                val panelOpen = values[2] as Boolean
                val accent = accentColorFor(values[3] as com.example.model.AccentPreset, true).toArgb()
                val lockedMode = macro.isLocked && !placement
                val useTarget2 = macro.enableTarget2 || macro.pattern == MacroPattern.QUICK_SWITCH

                if (macro.enabled) {
                    ensureMacroTriggerWindow(macro, lockedMode, placement, accent)
                    if (macro.showTarget) {
                        ensureMacroTargetWindow(macro, lockedMode, placement, accent)
                        if (useTarget2) {
                            ensureMacroTarget2Window(macro, lockedMode, placement)
                        } else {
                            removeMacroTarget2Window()
                        }
                        if (!lockedMode) {
                            ensureMacroLineWindow()
                            macroLineView?.updatePoints(
                                triggerX = macro.triggerNormX,
                                triggerY = macro.triggerNormY,
                                target1X = macro.targetNormX,
                                target1Y = macro.targetNormY,
                                hasTarget2 = useTarget2,
                                target2X = macro.target2NormX,
                                target2Y = macro.target2NormY
                            )
                        } else {
                            removeMacroLineWindow()
                        }
                    } else {
                        removeMacroTargetWindow()
                        removeMacroTarget2Window()
                        removeMacroLineWindow()
                    }
                    if (!lockedMode && !placement && !panelOpen) {
                        ensureMacroLockChipWindow()
                    } else {
                        removeMacroLockChipWindow()
                    }
                } else {
                    removeMacroTriggerWindow()
                    removeMacroTargetWindow()
                    removeMacroTarget2Window()
                    removeMacroLineWindow()
                    removeMacroLockChipWindow()
                }
            }
        }

        // 4b. Live X/Y Aim Booster Pad (Kernel Slot-8, concurrent with 10 physical fingers & Macro Slot-9)
        serviceScope.launch {
            combine(
                prefs.touchConfig,
                prefs.accentPreset,
                ShizukuBridge.status
            ) { touch, accentPreset, st ->
                Triple(touch, accentColorFor(accentPreset, true).toArgb(), st.isKernelMultiTouch)
            }.collectLatest { (touch, accentColor, isKernel) ->
                if (touch.enabled && touch.liveAimPadEnabled && isKernel) {
                    ensureTouchAimPadWindow(touch, accentColor)
                } else {
                    removeTouchAimPadWindow()
                }
            }
        }

        // 5. Floating Panel window lifecycle
        serviceScope.launch {
            prefs.overlayPanelExpanded.collectLatest { expanded ->
                if (expanded) ensurePanelWindow() else removePanelWindow()
            }
        }

        // 6. Macro D-Pad placement editor lifecycle
        serviceScope.launch {
            prefs.macroPlacementMode.collectLatest { placement ->
                if (placement) ensureDpadEditorWindow() else removeDpadEditorWindow()
            }
        }

        // 7. Radial Quick Wheel lifecycle
        serviceScope.launch {
            prefs.radialConfig.collectLatest { radial ->
                if (radial.enabled) ensureRadialWindow() else removeRadialWindow()
            }
        }

        // 7b. AI Trigger interactive Crop & Target Aim Pickers
        serviceScope.launch {
            prefs.aiCropOverlayMode.collectLatest { cropMode ->
                removeAiCropOverlayWindow()
                if (cropMode) ensureAiCropOverlayWindow()
            }
        }
        serviceScope.launch {
            prefs.aiTargetPickerMode.collectLatest { pickerMode ->
                if (pickerMode) ensureAiTargetPickerWindow() else removeAiTargetPickerWindow()
            }
        }

        // 7c. AI Trigger real-time scanning & injection loop + lightweight corner status pill
        serviceScope.launch {
            combine(
                prefs.aiTriggerMasterEnabled,
                prefs.aiTriggerRules,
                AiTriggerCaptureManager.hasProjection,
                ShizukuBridge.status
            ) { _, _, _, _ -> Unit }.collectLatest {
                AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
            }
        }
        serviceScope.launch {
            combine(
                prefs.aiTriggerMasterEnabled,
                prefs.overlayPanelExpanded,
                prefs.aiCropOverlayMode,
                prefs.aiTargetPickerMode
            ) { master, panel, crop, pick ->
                master && !panel && !crop && !pick
            }.collectLatest { showBadge ->
                if (showBadge) ensureAiStatusBadgeWindow() else removeAiStatusBadgeWindow()
            }
        }
        serviceScope.launch {
            combine(
                AiTriggerEngine.runtimeState,
                prefs.overlayPanelExpanded,
                prefs.aiCropOverlayMode,
                prefs.aiTargetPickerMode
            ) { rt, panel, crop, pick ->
                Triple(rt, rt.masterEnabled && rt.showLiveHud && !panel && !crop && !pick, Unit)
            }.collectLatest { (rt, showHud, _) ->
                if (showHud) {
                    ensureAiCrosshairWindow(rt)
                } else {
                    removeAiCrosshairWindow()
                }
            }
        }
        // 8. Auto-stop foreground service cleanly when EVERY overlay feature is turned off
        serviceScope.launch {
            combine(
                prefs.gameSessionActive,
                prefs.hudConfig,
                prefs.crosshairConfig,
                prefs.macroConfig,
                combine(prefs.radialConfig, prefs.aiTriggerMasterEnabled) { rad, ai -> rad.enabled || ai },
                combine(prefs.overlayPanelExpanded, prefs.aiCropOverlayMode, prefs.aiTargetPickerMode) { p, c, t -> p || c || t },
                prefs.macroPlacementMode,
                prefs.touchConfig
            ) { values ->
                val session = values[0] as Boolean
                val hud = (values[1] as com.example.model.HudConfig).enabled
                val ch = (values[2] as CrosshairConfig).enabled
                val macro = (values[3] as com.example.model.MacroConfig).enabled
                val radialOrAi = values[4] as Boolean
                val modalOverlay = values[5] as Boolean
                val placement = values[6] as Boolean
                val touch = values[7] as TouchConfig
                val aimPad = touch.enabled && touch.liveAimPadEnabled && ShizukuBridge.isKernelMultiTouchActive()
                session || hud || ch || macro || radialOrAi || modalOverlay || placement || aimPad
            }.collectLatest { anyActive ->
                if (!anyActive) {
                    delay(200)
                    val touch = prefs.touchConfig.value
                    val aimPad = touch.enabled && touch.liveAimPadEnabled && ShizukuBridge.isKernelMultiTouchActive()
                    val stillOff = !prefs.gameSessionActive.value &&
                        !prefs.hudConfig.value.enabled &&
                        !prefs.crosshairConfig.value.enabled &&
                        !prefs.macroConfig.value.enabled &&
                        !prefs.radialConfig.value.enabled &&
                        !prefs.aiTriggerMasterEnabled.value &&
                        !prefs.overlayPanelExpanded.value &&
                        !prefs.aiCropOverlayMode.value &&
                        !prefs.aiTargetPickerMode.value &&
                        !prefs.macroPlacementMode.value &&
                        !aimPad
                    if (stillOff) stopSelf()
                }
            }
        }

        // 9. Observe Shizuku auto-provision banner
        serviceScope.launch {
            ShizukuBridge.autoProvisionBanner.collectLatest { msg ->
                if (!msg.isNullOrBlank()) {
                    showTransientStatus(msg)
                    ShizukuBridge.clearAutoProvisionBanner()
                }
            }
        }
    }

    private fun startForegroundGameExitWatcher() {
        foregroundWatcherJob?.cancel()
        foregroundWatcherJob = serviceScope.launch(Dispatchers.IO) {
            val launcherPkgs = optimizer.getLauncherPackages()
            var hasEnteredGame = false
            var trackedSessionPkg: String? = prefs.activeSessionGamePkg.value
            var outsideCount = 0
            var shizukuPollTick = 0

            while (isActive) {
                delay(2200L)

                // Periodically trigger Shizuku auto-detection if enabled & not yet bound (~6.6s cadence)
                shizukuPollTick++
                if (prefs.useShizuku.value && shizukuPollTick % 3 == 0) {
                    val st = ShizukuBridge.status.value
                    if (!st.canRunPrivileged || (st.isRunning && st.isPermissionGranted && !st.isInputServiceBound)) {
                        ShizukuBridge.refresh(this@GameOverlayService, autoTriggerIfReady = true)
                    }
                }

                if (AiTriggerCaptureManager.awaitingConsentPrompt) continue

                // Determine current foreground package via UsageStatsManager (primary) or throttled Shizuku fallback (~8.8s)
                val fgPkg = optimizer.getCurrentForegroundPackage()
                    ?: (if (shizukuPollTick % 4 == 0) ShizukuBridge.getForegroundPackageViaShizuku() else null)
                    ?: continue

                if (isTransientSystemPackage(fgPkg)) continue

                val addedGames = prefs.addedGames.value
                val activeTarget = prefs.activeSessionGamePkg.value
                if (activeTarget != null) {
                    trackedSessionPkg = activeTarget
                }

                val isKnownGame = addedGames.contains(fgPkg) ||
                    (trackedSessionPkg != null && fgPkg == trackedSessionPkg)

                val isLauncher = launcherPkgs.contains(fgPkg) || isLikelyLauncherPackage(fgPkg)

                if (fgPkg == packageName) {
                    // User is inside XAGameSpacepanel UI configuring settings; don't self-kill here
                    continue
                }

                if (isKnownGame) {
                    hasEnteredGame = true
                    trackedSessionPkg = fgPkg
                    outsideCount = 0
                } else if (addedGames.isEmpty() && !isLauncher && fgPkg != "com.android.settings") {
                    if (!hasEnteredGame) {
                        hasEnteredGame = true
                        trackedSessionPkg = fgPkg
                        outsideCount = 0
                    } else if (fgPkg == trackedSessionPkg) {
                        outsideCount = 0
                    } else {
                        outsideCount++
                    }
                } else if (hasEnteredGame) {
                    // User exited the game to Home/Launcher or another non-game app
                    outsideCount++
                }

                if (hasEnteredGame && outsideCount >= 2) {
                    withContext(Dispatchers.Main) {
                        stopTriggerMacro()
                        AiTriggerEngine.stopLoop(prefs)
                        AiTriggerProjectionService.stop(this@GameOverlayService)
                        prefs.setAiCropOverlayMode(false)
                        prefs.setAiTargetPickerMode(false)
                        prefs.setAiTriggerMasterEnabled(false)
                        prefs.setOverlayPanelExpanded(false)
                        prefs.setMacroPlacementMode(false)
                        prefs.updateMacroConfig { it.copy(isRunning = false) }
                        prefs.setGameSessionActive(false, null)
                    }
                    if (prefs.restoreAfterSession.value) {
                        optimizer.restoreAllSessionTweaks()
                    }
                    withContext(Dispatchers.Main) {
                        stopSelf()
                    }
                    break
                }
            }
        }
    }

    private fun isTransientSystemPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower == "com.android.systemui" ||
            lower == "com.google.android.permissioncontroller" ||
            lower == "com.android.permissioncontroller" ||
            lower == "com.android.packageinstaller" ||
            lower == "moe.shizuku.privileged.api" ||
            lower == "com.miui.securitycenter" ||
            lower == "com.coloros.securitypermission" ||
            lower == "com.oplus.securitypermission" ||
            lower == "com.vivo.permissionmanager" ||
            lower.contains("permission") ||
            lower.contains("projection")
    }

    private fun isLikelyLauncherPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("launcher") || lower.contains("trebuchet") || lower == "com.miui.home"
    }

    // --- 1. Edge Handle (ultra-slim, flush to physical screen edge, hold-to-move) ---
    private fun ensureEdgeHandleWindow() {
        if (edgeHandleView != null || !Settings.canDrawOverlays(this)) return
        val handleW = dpToPx(7f).coerceAtLeast(10)
        val handleH = dpToPx(36f).coerceAtLeast(36)
        val (screenW, screenH) = getScreenSize()
        val isRight = prefs.edgeHandleRight.value
        val normY = prefs.edgeHandleNormY.value

        edgeHandleParams = WindowManager.LayoutParams(
            handleW,
            handleH,
            overlayWindowType(),
            interactiveFlags() or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = if (isRight) (screenW - handleW).coerceAtLeast(0) else 0
            y = ((normY * screenH) - (handleH / 2f)).roundToInt()
                .coerceIn(0, (screenH - handleH).coerceAtLeast(0))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val initialAccent = accentColorFor(prefs.accentPreset.value, true).toArgb()
        edgeHandleView = EdgeHandleTabView(
            context = this,
            accentColor = initialAccent,
            isRightEdge = isRight,
            getScreenSize = ::getScreenSize,
            readWindowParams = { edgeHandleParams },
            onUpdateLayout = { p ->
                runCatching { windowManager.updateViewLayout(edgeHandleView, p) }
            },
            onTapOpenPanel = { prefs.setOverlayPanelExpanded(true) },
            onPositionCommitted = { rightEdge, committedNormY ->
                prefs.setEdgeHandlePosition(rightEdge, committedNormY)
            }
        )
        runCatching { windowManager.addView(edgeHandleView, edgeHandleParams) }
    }

    private fun snapEdgeHandleToCurrentScreen() {
        val view = edgeHandleView ?: return
        val p = edgeHandleParams ?: return
        val (screenW, screenH) = getScreenSize()
        val handleW = p.width
        val handleH = p.height
        val isRight = prefs.edgeHandleRight.value
        val normY = prefs.edgeHandleNormY.value
        p.x = if (isRight) (screenW - handleW).coerceAtLeast(0) else 0
        p.y = ((normY * screenH) - (handleH / 2f)).roundToInt()
            .coerceIn(0, (screenH - handleH).coerceAtLeast(0))
        view.setRightEdge(isRight)
        runCatching { windowManager.updateViewLayout(view, p) }
    }

    private fun removeEdgeHandleWindow() {
        edgeHandleView?.let { runCatching { windowManager.removeView(it) } }
        edgeHandleView = null
        edgeHandleParams = null
    }

    // --- 2. Performance HUD ---
    private fun ensureHudWindow() {
        if (hudView != null || !Settings.canDrawOverlays(this)) return
        val hud = prefs.hudConfig.value
        hudParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or when (hud.position) {
                HudPosition.LEFT -> Gravity.START
                HudPosition.CENTER -> Gravity.CENTER_HORIZONTAL
                HudPosition.RIGHT -> Gravity.END
            }
            x = 0
            y = 28
        }

        hudView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val curHud by prefs.hudConfig.collectAsState()
                val snap by telemetryMonitor.snapshot.collectAsState()
                val accentPreset by prefs.accentPreset.collectAsState()
                val accent = accentColorFor(accentPreset, true)

                val alphaVal = (curHud.opacityPercent / 100f).coerceIn(0.3f, 1f)
                val scaleVal = (curHud.scalePercent / 100f).coerceIn(0.7f, 1.4f)
                val tempStr = if (curHud.useFahrenheit) {
                    "${((snap.tempC * 9f / 5f) + 32f).roundToInt()}°F"
                } else {
                    "${snap.tempC.roundToInt()}°C"
                }
                val parts = buildList {
                    if (curHud.showFps) add(if (curHud.showLabels) "${snap.fps} FPS" else "${snap.fps}")
                    if (curHud.showCpu) add(if (curHud.showLabels) "CPU ${snap.cpuPercent}%" else "${snap.cpuPercent}%")
                    if (curHud.showRam) add(if (curHud.showLabels) "RAM ${snap.ramPercent}%" else "${snap.ramPercent}%")
                    if (curHud.showTemp) add(tempStr)
                    if (curHud.showBattery) add("${snap.batteryPercent}%")
                    if (curHud.showPing) add("${snap.pingMs}ms")
                }
                val separator = if (curHud.compactMode) " " else "  •  "

                Box(
                    modifier = Modifier
                        .wrapContentSize()
                        .scale(scaleVal)
                        .alpha(alphaVal)
                        .clip(RoundedCornerShape(if (curHud.singleRow) 50 else 14))
                        .background(ObsidianSurface.copy(alpha = 0.88f))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(if (curHud.singleRow) 50 else 14))
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                hudParams?.let { p ->
                                    val deltaX = if (curHud.position == HudPosition.RIGHT) -dragAmount.x else dragAmount.x
                                    p.x += deltaX.roundToInt()
                                    p.y += dragAmount.y.roundToInt()
                                    runCatching { windowManager.updateViewLayout(hudView, p) }
                                }
                            }
                        }
                        .clickable {
                            prefs.setOverlayPanelExpanded(!prefs.overlayPanelExpanded.value)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (curHud.singleRow || parts.size <= 2) {
                        val text = if (parts.isEmpty()) "${snap.fps} FPS" else parts.joinToString(separator)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (snap.fps >= 45) StatusGreen else accent)
                            )
                            Text(
                                text = text,
                                color = ObsidianTextPrimary,
                                fontFamily = JetBrainsMono,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            parts.chunked(3).forEach { rowItems ->
                                Text(
                                    text = rowItems.joinToString(separator),
                                    color = ObsidianTextPrimary,
                                    fontFamily = JetBrainsMono,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
        runCatching { windowManager.addView(hudView, hudParams) }
    }

    private fun removeHudWindow() {
        hudView?.let { runCatching { windowManager.removeView(it) } }
        hudView = null
        hudParams = null
    }

    // --- 3. Compact Native Crosshair View (never blocks screen touches!) ---
    private fun ensureCrosshairWindow(config: CrosshairConfig) {
        if (!Settings.canDrawOverlays(this)) return
        val boxPx = dpToPx((config.sizeDp * 2 + 24).toFloat()).coerceAtLeast(dpToPx(48f))
        if (crosshairView == null) {
            crosshairParams = WindowManager.LayoutParams(
                boxPx,
                boxPx,
                overlayWindowType(),
                passThroughFlags(),
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
                x = dpToPx(config.offsetX.toFloat())
                y = dpToPx(config.offsetY.toFloat())
            }
            crosshairView = CrosshairCanvasView(this).apply {
                alpha = 0.78f // safely under Android 12+ untrusted touch threshold
                updateConfig(config)
            }
            runCatching { windowManager.addView(crosshairView, crosshairParams) }
        } else {
            crosshairView?.updateConfig(config)
            crosshairParams?.let { p ->
                p.width = boxPx
                p.height = boxPx
                p.x = dpToPx(config.offsetX.toFloat())
                p.y = dpToPx(config.offsetY.toFloat())
                runCatching { windowManager.updateViewLayout(crosshairView, p) }
            }
        }
    }

    private fun removeCrosshairWindow() {
        crosshairView?.let { runCatching { windowManager.removeView(it) } }
        crosshairView = null
        crosshairParams = null
    }

    // --- 4. Macro Connector Line (lightweight native view, pass-through) ---
    private fun ensureMacroLineWindow() {
        if (macroLineView != null || !Settings.canDrawOverlays(this)) return
        macroLineParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        )
        macroLineView = MacroConnectorCanvasView(this).apply {
            alpha = 0.72f
        }
        runCatching { windowManager.addView(macroLineView, macroLineParams) }
    }

    private fun removeMacroLineWindow() {
        macroLineView?.let { runCatching { windowManager.removeView(it) } }
        macroLineView = null
        macroLineParams = null
    }

    // --- 5. Macro Target & Trigger Floating Handles (Lockable, Transparent & Pass-Through Target) ---
    private fun macroWindowFlags(passThrough: Boolean): Int =
        (if (passThrough) passThroughFlags() else interactiveFlags()) or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun applyCutoutMode(params: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun ensureMacroTargetWindow(
        macro: MacroConfig,
        lockedMode: Boolean,
        placement: Boolean,
        accentColor: Int
    ) {
        if (!Settings.canDrawOverlays(this)) return
        val sizePx = dpToPx(if (lockedMode) 34f else 44f).coerceAtLeast(36)
        targetHalfW = sizePx / 2
        targetHalfH = sizePx / 2
        val (screenW, screenH) = getScreenSize()
        val desiredX = (macro.targetNormX * screenW).roundToInt() - targetHalfW
        val desiredY = (macro.targetNormY * screenH).roundToInt() - targetHalfH
        val desiredFlags = macroWindowFlags(passThrough = lockedMode)

        if (macroTargetView == null) {
            macroTargetParams = WindowManager.LayoutParams(
                sizePx,
                sizePx,
                overlayWindowType(),
                desiredFlags,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                y = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                applyCutoutMode(this)
            }
            macroTargetView = MacroTargetOverlayView(
                context = this,
                badgeText = "1",
                accentColor = accentColor,
                getScreenSize = ::getScreenSize,
                readWindowParams = { macroTargetParams },
                onUpdateLayout = { p ->
                    runCatching { windowManager.updateViewLayout(macroTargetView, p) }
                },
                onMoved = { normX, normY ->
                    prefs.updateMacroConfig {
                        it.copy(targetNormX = normX, targetNormY = normY)
                    }
                },
                onSelectedForPlacement = { activePlacementTarget = 1 }
            ).apply {
                updateState(
                    locked = lockedMode,
                    placementHighlighted = placement && activePlacementTarget == 1,
                    running = macro.isRunning,
                    lockedAlpha = macro.lockedOpacity,
                    accentColor = accentColor
                )
            }
            runCatching { windowManager.addView(macroTargetView, macroTargetParams) }
        } else {
            macroTargetView?.updateState(
                locked = lockedMode,
                placementHighlighted = placement && activePlacementTarget == 1,
                running = macro.isRunning,
                lockedAlpha = macro.lockedOpacity,
                accentColor = accentColor
            )
            macroTargetParams?.let { p ->
                val clampedX = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                val clampedY = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                val needLayoutUpdate =
                    p.flags != desiredFlags || p.width != sizePx || p.height != sizePx ||
                        p.x != clampedX || p.y != clampedY
                if (needLayoutUpdate) {
                    p.flags = desiredFlags
                    p.width = sizePx
                    p.height = sizePx
                    p.x = clampedX
                    p.y = clampedY
                    runCatching { windowManager.updateViewLayout(macroTargetView, p) }
                }
            }
        }
    }

    private fun removeMacroTargetWindow() {
        macroTargetView?.let { runCatching { windowManager.removeView(it) } }
        macroTargetView = null
        macroTargetParams = null
    }

    private fun ensureMacroTarget2Window(
        macro: MacroConfig,
        lockedMode: Boolean,
        placement: Boolean
    ) {
        if (!Settings.canDrawOverlays(this)) return
        val sizePx = dpToPx(if (lockedMode) 34f else 44f).coerceAtLeast(36)
        target2HalfW = sizePx / 2
        target2HalfH = sizePx / 2
        val (screenW, screenH) = getScreenSize()
        val desiredX = (macro.target2NormX * screenW).roundToInt() - target2HalfW
        val desiredY = (macro.target2NormY * screenH).roundToInt() - target2HalfH
        val desiredFlags = macroWindowFlags(passThrough = lockedMode)
        val target2Color = android.graphics.Color.rgb(0, 229, 255) // Cyan accent for Weapon Switch (2)

        if (macroTarget2View == null) {
            macroTarget2Params = WindowManager.LayoutParams(
                sizePx,
                sizePx,
                overlayWindowType(),
                desiredFlags,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                y = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                applyCutoutMode(this)
            }
            macroTarget2View = MacroTargetOverlayView(
                context = this,
                badgeText = "2",
                accentColor = target2Color,
                getScreenSize = ::getScreenSize,
                readWindowParams = { macroTarget2Params },
                onUpdateLayout = { p ->
                    runCatching { windowManager.updateViewLayout(macroTarget2View, p) }
                },
                onMoved = { normX, normY ->
                    prefs.updateMacroConfig {
                        it.copy(target2NormX = normX, target2NormY = normY)
                    }
                },
                onSelectedForPlacement = { activePlacementTarget = 2 }
            ).apply {
                updateState(
                    locked = lockedMode,
                    placementHighlighted = placement && activePlacementTarget == 2,
                    running = macro.isRunning,
                    lockedAlpha = macro.lockedOpacity,
                    accentColor = target2Color
                )
            }
            runCatching { windowManager.addView(macroTarget2View, macroTarget2Params) }
        } else {
            macroTarget2View?.updateState(
                locked = lockedMode,
                placementHighlighted = placement && activePlacementTarget == 2,
                running = macro.isRunning,
                lockedAlpha = macro.lockedOpacity,
                accentColor = target2Color
            )
            macroTarget2Params?.let { p ->
                val clampedX = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                val clampedY = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                val needLayoutUpdate =
                    p.flags != desiredFlags || p.width != sizePx || p.height != sizePx ||
                        p.x != clampedX || p.y != clampedY
                if (needLayoutUpdate) {
                    p.flags = desiredFlags
                    p.width = sizePx
                    p.height = sizePx
                    p.x = clampedX
                    p.y = clampedY
                    runCatching { windowManager.updateViewLayout(macroTarget2View, p) }
                }
            }
        }
    }

    private fun removeMacroTarget2Window() {
        macroTarget2View?.let { runCatching { windowManager.removeView(it) } }
        macroTarget2View = null
        macroTarget2Params = null
    }

    private fun ensureMacroTriggerWindow(
        macro: MacroConfig,
        lockedMode: Boolean,
        placement: Boolean,
        accentColor: Int
    ) {
        if (!Settings.canDrawOverlays(this)) return
        val sizePx = dpToPx(50f * macro.triggerScale).coerceIn(dpToPx(36f), dpToPx(84f))
        triggerHalfW = sizePx / 2
        triggerHalfH = sizePx / 2
        val (screenW, screenH) = getScreenSize()
        val desiredX = (macro.triggerNormX * screenW).roundToInt() - triggerHalfW
        val desiredY = (macro.triggerNormY * screenH).roundToInt() - triggerHalfH

        if (macroTriggerView == null) {
            macroTriggerParams = WindowManager.LayoutParams(
                sizePx,
                sizePx,
                overlayWindowType(),
                macroWindowFlags(passThrough = false),
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                y = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                applyCutoutMode(this)
            }

            macroTriggerView = MacroTriggerOverlayView(
                context = this,
                accentColor = accentColor,
                getScreenSize = ::getScreenSize,
                readWindowParams = { macroTriggerParams },
                onUpdateLayout = { p ->
                    runCatching { windowManager.updateViewLayout(macroTriggerView, p) }
                },
                onMoved = { normX, normY ->
                    prefs.updateMacroConfig {
                        it.copy(triggerNormX = normX, triggerNormY = normY)
                    }
                },
                onSelectedForPlacement = { activePlacementTarget = 0 },
                onHoldStart = { startTriggerMacro() },
                onHoldStop = { stopTriggerMacro() },
                onTapToggle = { toggleMacroExecution() },
                onLatchedFromCancel = {
                    if (!shownNonRootLatchHint) {
                        shownNonRootLatchHint = true
                        showTransientStatus("Macro aktif otomatis (ketuk Trigger sekali lagi untuk berhenti).")
                    }
                },
                isKernelMultiTouch = { ShizukuBridge.isKernelMultiTouchActive() }
            ).apply {
                updateState(
                    locked = lockedMode,
                    holdToTrigger = macro.holdToTrigger,
                    placementHighlighted = placement && activePlacementTarget == 0,
                    running = macro.isRunning,
                    lockedAlpha = macro.lockedOpacity,
                    accentColor = accentColor
                )
            }
            runCatching { windowManager.addView(macroTriggerView, macroTriggerParams) }
        } else {
            macroTriggerView?.updateState(
                locked = lockedMode,
                holdToTrigger = macro.holdToTrigger,
                placementHighlighted = placement && activePlacementTarget == 0,
                running = macro.isRunning,
                lockedAlpha = macro.lockedOpacity,
                accentColor = accentColor
            )
            macroTriggerParams?.let { p ->
                val clampedX = desiredX.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
                val clampedY = desiredY.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
                val needLayoutUpdate = p.width != sizePx || p.height != sizePx || p.x != clampedX || p.y != clampedY
                if (needLayoutUpdate) {
                    p.width = sizePx
                    p.height = sizePx
                    p.x = clampedX
                    p.y = clampedY
                    runCatching { windowManager.updateViewLayout(macroTriggerView, p) }
                }
            }
        }
    }

    private fun removeMacroTriggerWindow() {
        stopTriggerMacro()
        macroTriggerView?.let { runCatching { windowManager.removeView(it) } }
        macroTriggerView = null
        macroTriggerParams = null
    }

    private fun ensureMacroLockChipWindow() {
        if (macroLockChipView != null || !Settings.canDrawOverlays(this)) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dpToPx(18f)
        }
        macroLockChipView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val accentPreset by prefs.accentPreset.collectAsState()
                val curMacro by prefs.macroConfig.collectAsState()
                val accent = accentColorFor(accentPreset, true)
                val target2On = curMacro.enableTarget2 || curMacro.pattern == MacroPattern.QUICK_SWITCH
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.92f))
                        .border(1.dp, accent.copy(alpha = 0.7f), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (target2On) "1:Tembak • 2:Senjata" else "Geser 1 ke tombol",
                        color = ObsidianTextSecondary,
                        fontSize = 11.sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (target2On) StatusCyan.copy(alpha = 0.22f) else ObsidianCard)
                            .border(
                                1.dp,
                                if (target2On) StatusCyan else ObsidianBorder,
                                RoundedCornerShape(50)
                            )
                            .clickable {
                                prefs.updateMacroConfig { cur ->
                                    val nextOn = !target2On
                                    cur.copy(
                                        enableTarget2 = nextOn,
                                        showTarget = if (nextOn) true else cur.showTarget,
                                        pattern = if (nextOn) MacroPattern.QUICK_SWITCH else MacroPattern.REPEAT
                                    )
                                }
                            }
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (target2On) "2: ON" else "+ Tombol 2",
                            color = if (target2On) StatusCyan else ObsidianTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(accent)
                            .clickable {
                                prefs.updateMacroConfig { it.copy(isLocked = true, isRunning = false) }
                                showTransientStatus("Macro dikunci & transparan. Tahan Trigger sambil tetap bisa geser layar!")
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Kunci",
                            color = Color(0xFF0B0C0F),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        runCatching { windowManager.addView(macroLockChipView, params) }
    }

    private fun removeMacroLockChipWindow() {
        macroLockChipView?.let { runCatching { windowManager.removeView(it) } }
        macroLockChipView = null
    }

    private fun startTriggerMacro() {
        val cur = prefs.macroConfig.value
        if (!cur.enabled) return
        val st = ShizukuBridge.refresh(this, autoTriggerIfReady = true)
        if (st.canRunPrivileged) {
            ShizukuBridge.ensureInputServiceBound()
            startShizukuMacroLoop()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastShizukuHintAtMs > 2500L) {
            lastShizukuHintAtMs = now
            if (st.isRunning && !st.isPermissionGranted) {
                ShizukuBridge.requestPermission()
                showTransientStatus("Meminta izin Shizuku... ketuk Izinkan untuk Macro 10-Jari.")
            } else {
                showTransientStatus("Aktifkan Shizuku (Wireless Debugging) untuk Macro tanpa Aksesibilitas.")
            }
        }
    }

    private fun stopTriggerMacro() {
        shizukuMacroJob?.cancel()
        shizukuMacroJob = null
        if (prefs.macroConfig.value.isRunning) {
            prefs.updateMacroConfig { it.copy(isRunning = false) }
        }
    }

    private fun toggleMacroExecution() {
        if (prefs.macroConfig.value.isRunning) {
            stopTriggerMacro()
        } else {
            startTriggerMacro()
        }
    }

    private suspend fun performMacroTap(
        x: Float,
        y: Float,
        pressMs: Long,
        mode: MacroInjectionMode,
        screenW: Int,
        screenH: Int,
        rotation: Int,
        slotOffset: Int = 0,
        allowSlowShellFallback: Boolean = false
    ): Boolean {
        val pulsed = ShizukuBridge.injectPulse(
            x = x,
            y = y,
            pressMs = pressMs,
            mode = mode,
            screenW = screenW,
            screenH = screenH,
            rotation = rotation,
            slotOffset = slotOffset
        )
        if (pulsed) return true
        if (allowSlowShellFallback) {
            return ShizukuBridge.injectTapFallback(x, y, pressMs)
        }
        return false
    }

    private fun startShizukuMacroLoop() {
        shizukuMacroJob?.cancel()
        prefs.updateMacroConfig { it.copy(isRunning = true) }
        shizukuMacroJob = serviceScope.launch(Dispatchers.IO) {
            var cachedScreenSize = getScreenSize()
            var cachedRotation = getDisplayRotation()
            var lastMetricsAtMs = SystemClock.uptimeMillis()
            var lastShellFallbackAtMs = 0L
            var consecutiveFailures = 0

            fun notifySlowFailure(): Boolean {
                consecutiveFailures++
                if (consecutiveFailures >= 3) {
                    serviceScope.launch(Dispatchers.Main) {
                        showTransientStatus("Aktifkan 'Debugging USB (Setelan Keamanan)' agar Macro bekerja lancar tanpa lag.")
                    }
                    return true
                }
                return false
            }

            while (isActive && prefs.macroConfig.value.enabled && prefs.macroConfig.value.isRunning) {
                val nowMs = SystemClock.uptimeMillis()
                if (nowMs - lastMetricsAtMs >= 550L) {
                    cachedScreenSize = getScreenSize()
                    cachedRotation = getDisplayRotation()
                    lastMetricsAtMs = nowMs
                }
                val (screenW, screenH) = cachedScreenSize
                val rotation = cachedRotation
                val cur = prefs.macroConfig.value
                val mode = cur.injectionMode
                val jitter = cur.randomJitterPx
                fun pointFor(normX: Float, normY: Float): Pair<Float, Float> {
                    val jx = if (jitter > 0) Random.nextInt(-jitter, jitter + 1).toFloat() else 0f
                    val jy = if (jitter > 0) Random.nextInt(-jitter, jitter + 1).toFloat() else 0f
                    return (normX * screenW + jx).coerceIn(10f, (screenW - 10).coerceAtLeast(10).toFloat()) to
                        (normY * screenH + jy).coerceIn(10f, (screenH - 10).coerceAtLeast(10).toFloat())
                }
                val (tx1, ty1) = pointFor(cur.targetNormX, cur.targetNormY)
                val (tx2, ty2) = pointFor(cur.target2NormX, cur.target2NormY)
                val useSecondTarget = cur.enableTarget2 || cur.pattern == MacroPattern.QUICK_SWITCH
                val tapPressMs = if (cur.intervalMs <= 60) {
                    cur.holdDurationMs.toLong().coerceIn(5L, 14L)
                } else {
                    cur.holdDurationMs.toLong().coerceIn(6L, 38L)
                }
                val shellFallbackAllowed = cur.intervalMs >= 260 && (nowMs - lastShellFallbackAtMs >= 320L)

                suspend fun dispatchTap(x: Float, y: Float, hold: Long, slot: Int): Boolean {
                    val ok = performMacroTap(x, y, hold, mode, screenW, screenH, rotation, slot, shellFallbackAllowed)
                    if (ok) {
                        consecutiveFailures = 0
                        if (shellFallbackAllowed && !ShizukuBridge.wasRecentInjection(80L)) {
                            lastShellFallbackAtMs = SystemClock.uptimeMillis()
                        }
                        return true
                    }
                    return !notifySlowFailure()
                }

                when (cur.pattern) {
                    MacroPattern.QUICK_SWITCH -> {
                        if (!dispatchTap(tx1, ty1, tapPressMs.coerceAtMost(24L), 0)) break
                        if (!isActive || !prefs.macroConfig.value.isRunning) break
                        delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                        if (!isActive || !prefs.macroConfig.value.isRunning) break
                        if (!dispatchTap(tx2, ty2, tapPressMs.coerceAtMost(24L), 1)) break
                        delay(cur.intervalMs.toLong().coerceIn(12L, 2000L))
                    }
                    MacroPattern.REPEAT -> {
                        if (!dispatchTap(tx1, ty1, tapPressMs, 0)) break
                        if (useSecondTarget && isActive && prefs.macroConfig.value.isRunning) {
                            delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                            if (isActive && prefs.macroConfig.value.isRunning) {
                                if (!dispatchTap(tx2, ty2, tapPressMs.coerceAtMost(24L), 1)) break
                            }
                        }
                        val gapMs = (cur.intervalMs.toLong() - tapPressMs).coerceAtLeast(4L)
                        delay(gapMs)
                    }
                    MacroPattern.BURST -> {
                        val burstPressMs = cur.holdDurationMs.toLong().coerceIn(5L, 14L)
                        var aborted = false
                        repeat(cur.burstCount.coerceIn(2, 8)) {
                            if (!isActive || !prefs.macroConfig.value.isRunning || aborted) return@repeat
                            if (!dispatchTap(tx1, ty1, burstPressMs, 0)) {
                                aborted = true
                                return@repeat
                            }
                            delay(8L)
                        }
                        if (aborted) break
                        if (useSecondTarget && isActive && prefs.macroConfig.value.isRunning) {
                            delay(cur.switchDelayMs.toLong().coerceIn(16L, 1200L))
                            if (isActive && prefs.macroConfig.value.isRunning) {
                                if (!dispatchTap(tx2, ty2, burstPressMs, 1)) break
                            }
                        }
                        delay(cur.intervalMs.toLong().coerceIn(14L, 2000L))
                    }
                    MacroPattern.HOLD -> {
                        val downTime = SystemClock.uptimeMillis()
                        val downOk = ShizukuBridge.injectMotion(
                            MotionEvent.ACTION_DOWN, tx1, ty1, downTime, mode, screenW, screenH, rotation, 0
                        )
                        if (downOk) {
                            consecutiveFailures = 0
                            try {
                                val chunkMs = cur.holdDurationMs.toLong().coerceIn(120L, 1200L)
                                var elapsed = 0L
                                while (isActive && prefs.macroConfig.value.isRunning && elapsed < chunkMs) {
                                    delay(30L)
                                    elapsed += 30L
                                }
                            } finally {
                                withContext(NonCancellable) {
                                    ShizukuBridge.injectMotion(
                                        MotionEvent.ACTION_UP, tx1, ty1, downTime, mode, screenW, screenH, rotation, 0
                                    )
                                }
                            }
                            delay(8L)
                        } else if (nowMs - lastShellFallbackAtMs >= 320L) {
                            lastShellFallbackAtMs = nowMs
                            val ok = ShizukuBridge.injectTapFallback(tx1, ty1, cur.holdDurationMs.toLong().coerceIn(120L, 1200L))
                            if (ok) consecutiveFailures = 0 else if (notifySlowFailure()) break
                        } else {
                            if (notifySlowFailure()) break
                            delay(40L)
                        }
                    }
                    MacroPattern.SWIPE -> {
                        val touchCfg = prefs.touchConfig.value
                        val gainY = if (touchCfg.enabled) touchCfg.gainY() else 1f
                        val swipeDx = if (touchCfg.enabled) (touchCfg.speedX / 100f) * 65f else 0f
                        val swipeDy = -180f * gainY
                        val endX = (tx1 + swipeDx).coerceIn(20f, (screenW - 20).coerceAtLeast(20).toFloat())
                        val endY = (ty1 + swipeDy).coerceIn(20f, (screenH - 20).coerceAtLeast(20).toFloat())
                        val baseDur = cur.holdDurationMs.toLong().coerceIn(60L, 400L)
                        val dur = if (touchCfg.enabled && touchCfg.responseBoost > 0) {
                            (baseDur * (1f - touchCfg.responseBoost * 0.004f)).toLong().coerceIn(35L, 400L)
                        } else {
                            baseDur
                        }
                        val ok = ShizukuBridge.injectSwipe(tx1, ty1, endX, endY, dur, mode, screenW, screenH, rotation)
                        if (ok) consecutiveFailures = 0 else if (notifySlowFailure()) break
                        delay(cur.intervalMs.toLong().coerceIn(20L, 2000L))
                    }
                }
            }
            prefs.updateMacroConfig { it.copy(isRunning = false) }
        }
    }

    // --- 6. Draggable 7-Tab Floating Game Space Panel ---
    private fun ensurePanelWindow() {
        if (panelView != null || !Settings.canDrawOverlays(this)) return
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            x = dpToPx(10f)
            y = 0
        }

        panelView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val telemetry by telemetryMonitor.snapshot.collectAsState()
                val hud by prefs.hudConfig.collectAsState()
                val touch by prefs.touchConfig.collectAsState()
                val crosshair by prefs.crosshairConfig.collectAsState()
                val macro by prefs.macroConfig.collectAsState()
                val burik by prefs.burikConfig.collectAsState()
                val fpsLock by prefs.fpsLockConfig.collectAsState()
                val radial by prefs.radialConfig.collectAsState()
                val fastAnim by prefs.fastAnimationEnabled.collectAsState()
                val shizukuStatus by ShizukuBridge.status.collectAsState()
                val aiMaster by prefs.aiTriggerMasterEnabled.collectAsState()
                val aiRules by prefs.aiTriggerRules.collectAsState()
                val aiDraft by prefs.aiDraftRule.collectAsState()
                val aiRuntime by AiTriggerEngine.runtimeState.collectAsState()
                val requestedTab by prefs.requestedPanelTab.collectAsState()
                val accentPreset by prefs.accentPreset.collectAsState()
                val themeMode by prefs.themeMode.collectAsState()
                val accent = accentColorFor(accentPreset, true)

                val (screenW, screenH) = getScreenSize()
                val density = resources.displayMetrics.density
                val maxPanelWidthDp = ((screenW / density) - 24f).coerceIn(260f, 344f)
                val maxPanelHeightDp = ((screenH / density) * 0.62f).coerceIn(270f, 356f)

                XAGameSpaceTheme(themeMode = themeMode, accentPreset = accentPreset) {
                    FloatingGamePanelContent(
                        telemetry = telemetry,
                        hudConfig = hud,
                        touchConfig = touch,
                        crosshairConfig = crosshair,
                        macroConfig = macro,
                        burikConfig = burik,
                        fpsLockConfig = fpsLock,
                        radialConfig = radial,
                        fastAnimEnabled = fastAnim,
                        shizukuStatus = shizukuStatus,
                        physicalDensityDpi = if (cachedPhysDpi > 0) cachedPhysDpi else resources.displayMetrics.densityDpi,
                        accentColor = accent,
                        statusMessage = statusBannerMessage,
                        panelWidthDp = maxPanelWidthDp,
                        panelHeightDp = maxPanelHeightDp,
                        onDragPanel = { dx, dy ->
                            panelParams?.let { p ->
                                p.x = (p.x - dx.roundToInt()).coerceIn(0, (screenW - 200).coerceAtLeast(0))
                                p.y = (p.y + dy.roundToInt()).coerceIn(-screenH / 3, screenH / 3)
                                runCatching { windowManager.updateViewLayout(panelView, p) }
                            }
                        },
                        onClose = { prefs.setOverlayPanelExpanded(false) },
                        onUpdateHud = { prefs.updateHudConfig(it) },
                        onResetHudPosition = {
                            hudParams?.let { p ->
                                p.x = 0
                                p.y = 28
                                runCatching { windowManager.updateViewLayout(hudView, p) }
                            }
                            showTransientStatus("Posisi HUD direset.")
                        },
                        onBoostNow = { triggerBoost() },
                        onSelectFpsLock = { target ->
                            prefs.updateFpsLockConfig { it.copy(target = target) }
                            serviceScope.launch {
                                val res = optimizer.applyFpsLock(prefs.addedGames.value.toList(), prefs.fpsLockConfig.value)
                                showTransientStatus(res.message)
                            }
                        },
                        onToggleFastAnim = { enabled ->
                            prefs.setFastAnimation(enabled)
                            serviceScope.launch {
                                val res = optimizer.applyFastAnimation(enabled)
                                showTransientStatus(res.message)
                            }
                        },
                        onUpdateTouch = { transform ->
                            val before = prefs.touchConfig.value
                            prefs.updateTouchConfig(transform)
                            val after = prefs.touchConfig.value
                            val toggledMasterOrDpi = (before.enabled != after.enabled) ||
                                (before.dpiBoostEnabled != after.dpiBoostEnabled) ||
                                (before.nubiaGameTweakEnabled != after.nubiaGameTweakEnabled)
                            touchApplyJob?.cancel()
                            if (toggledMasterOrDpi) {
                                touchApplyJob = serviceScope.launch {
                                    val res = optimizer.applyTouchSensitivity(after, applyDpiChange = true)
                                    showTransientStatus(res.message)
                                }
                            } else {
                                touchApplyJob = serviceScope.launch {
                                    delay(250L)
                                    optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = false)
                                }
                            }
                        },
                        onApplyTouchNow = {
                            touchApplyJob?.cancel()
                            touchApplyJob = serviceScope.launch {
                                val curTouch = prefs.touchConfig.value
                                val toApply = if (!curTouch.enabled) {
                                    prefs.updateTouchConfig { it.copy(enabled = true) }
                                    prefs.touchConfig.value
                                } else curTouch
                                val res = optimizer.applyTouchSensitivity(toApply, applyDpiChange = true)
                                showTransientStatus(res.message)
                            }
                        },
                        onResetTouch = {
                            touchApplyJob?.cancel()
                            prefs.updateTouchConfig {
                                it.copy(
                                    speedX = 0,
                                    speedY = 0,
                                    responseBoost = 0,
                                    smoothing = 0,
                                    deadzone = 0,
                                    liveAimPadEnabled = false,
                                    aimPadLocked = false
                                )
                            }
                            touchApplyJob = serviceScope.launch {
                                val res = optimizer.applyTouchSensitivity(prefs.touchConfig.value, applyDpiChange = true)
                                showTransientStatus(res.message)
                            }
                        },
                        onUpdateCrosshair = { prefs.updateCrosshairConfig(it) },
                        onResetCrosshair = {
                            prefs.updateCrosshairConfig { it.copy(offsetX = 0, offsetY = 0) }
                            showTransientStatus("Crosshair dipusatkan.")
                        },
                        onUpdateMacro = { prefs.updateMacroConfig(it) },
                        onOpenMacroPlacement = {
                            prefs.updateMacroConfig { it.copy(enabled = true, showTarget = true, isLocked = false, isRunning = false) }
                            prefs.setOverlayPanelExpanded(false)
                            prefs.setMacroPlacementMode(true)
                        },
                        onConnectShizuku = {
                            val st = ShizukuBridge.refresh(this@GameOverlayService, autoTriggerIfReady = true)
                            when {
                                st.canRunPrivileged -> {
                                    ShizukuBridge.ensureInputServiceBound()
                                    showTransientStatus("Shizuku Input Engine aktif (Support 10 Jari).")
                                }
                                st.isRunning && !st.isPermissionGranted -> {
                                    ShizukuBridge.requestPermission()
                                    showTransientStatus("Meminta izin Shizuku...")
                                }
                                st.isInstalled -> {
                                    packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let {
                                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        startActivity(it)
                                    }
                                    showTransientStatus("Jalankan Shizuku lalu kembali ke game — akan terdeteksi otomatis.")
                                }
                                else -> showTransientStatus("Pasang Shizuku untuk mengaktifkan Macro tanpa Aksesibilitas.")
                            }
                        },
                        onSelectBurikPreset = { preset ->
                            burikApplyJob?.cancel()
                            prefs.updateBurikConfig { it.copy(preset = preset) }
                            burikApplyJob = serviceScope.launch {
                                val targets = prefs.addedGames.value.toList()
                                val res = optimizer.applyBurik(targets, prefs.burikConfig.value)
                                showTransientStatus(res.message)
                            }
                        },
                        onUpdateBurikConfig = { transform ->
                            val before = prefs.burikConfig.value
                            prefs.updateBurikConfig(transform)
                            val after = prefs.burikConfig.value
                            val immediate = before.applyAllGames != after.applyAllGames ||
                                before.customNearestFiltering != after.customNearestFiltering ||
                                before.customDisableAnisotropic != after.customDisableAnisotropic
                            burikApplyJob?.cancel()
                            burikApplyJob = serviceScope.launch {
                                if (!immediate) delay(250L)
                                val targets = prefs.addedGames.value.toList()
                                val res = optimizer.applyBurik(targets, prefs.burikConfig.value)
                                if (immediate) showTransientStatus(res.message)
                            }
                        },
                        onApplyBurikNow = {
                            burikApplyJob?.cancel()
                            burikApplyJob = serviceScope.launch {
                                val targets = prefs.addedGames.value.toList()
                                val res = optimizer.applyBurik(targets, prefs.burikConfig.value)
                                showTransientStatus(res.message)
                            }
                        },
                        onApplyBurikAndRestart = {
                            burikApplyJob?.cancel()
                            burikApplyJob = serviceScope.launch {
                                val targets = prefs.addedGames.value.toList()
                                val applyRes = optimizer.applyBurik(targets, prefs.burikConfig.value)
                                if (applyRes.success) {
                                    val restartRes = optimizer.restartTargetGameForAngle()
                                    showTransientStatus(restartRes.message)
                                } else {
                                    showTransientStatus(applyRes.message)
                                }
                            }
                        },
                        onRestoreSession = {
                            serviceScope.launch {
                                val res = optimizer.restoreAllSessionTweaks()
                                prefs.updateBurikConfig { it.copy(preset = BurikPreset.OFF) }
                                prefs.updateFpsLockConfig { it.copy(target = FpsLockTarget.DEFAULT) }
                                prefs.updateTouchConfig { it.copy(enabled = false, liveAimPadEnabled = false, aimPadLocked = false) }
                                showTransientStatus(res.message)
                            }
                        },
                        onUpdateRadial = { prefs.updateRadialConfig(it) },
                        aiTriggerMasterEnabled = aiMaster,
                        aiTriggerRules = aiRules,
                        aiDraftRule = aiDraft,
                        aiRuntimeState = aiRuntime,
                        requestedTab = requestedTab,
                        screenWidthPx = screenW,
                        screenHeightPx = screenH,
                        loadAiTemplateBitmap = prefs::loadAiTemplateBitmap,
                        onConsumeRequestedTab = { prefs.requestPanelTab(null) },
                        onToggleAiMaster = { enabled ->
                            prefs.setAiTriggerMasterEnabled(enabled)
                            if (enabled) {
                                if (!AiTriggerCaptureManager.isProjectionActive()) {
                                    prefs.setOverlayPanelExpanded(false)
                                    ScreenCapturePermissionActivity.launch(
                                        context = this@GameOverlayService,
                                        enableMasterOnGrant = true
                                    ) { granted ->
                                        AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                                        prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                        prefs.setOverlayPanelExpanded(true)
                                        if (granted) {
                                            showTransientStatus("AI Trigger real-time aktif!")
                                        } else if (ShizukuBridge.status.value.canRunPrivileged) {
                                            showTransientStatus("AI Trigger berjalan via Shizuku backup capture.")
                                        } else {
                                            showTransientStatus("Izinkan Rekam Layar agar AI Trigger dapat membaca layar game.")
                                        }
                                    }
                                } else {
                                    AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                                    showTransientStatus("AI Trigger aktif memindai layar.")
                                }
                            } else {
                                AiTriggerEngine.stopLoop(prefs)
                                AiTriggerProjectionService.stop(this@GameOverlayService)
                                showTransientStatus("AI Trigger dimatikan.")
                            }
                        },
                        onRequestAiProjection = {
                            prefs.setOverlayPanelExpanded(false)
                            ScreenCapturePermissionActivity.launch(
                                context = this@GameOverlayService,
                                openCropOnGrant = false,
                                enableMasterOnGrant = prefs.aiTriggerMasterEnabled.value
                            ) { granted ->
                                AiTriggerEngine.refreshStatusSnapshot(prefs)
                                prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                prefs.setOverlayPanelExpanded(true)
                                showTransientStatus(
                                    if (granted) "Rekam layar MediaProjection siap!"
                                    else "Izin rekam layar tidak diberikan."
                                )
                            }
                        },
                        onStartCreateAiRule = {
                            val nextIndex = prefs.aiTriggerRules.value.size + 1
                            prefs.setAiDraftRule(
                                AiTriggerRule(
                                    id = "ai_${System.currentTimeMillis()}",
                                    name = "AI Trigger ${nextIndex.toString().padStart(2, '0')}"
                                )
                            )
                        },
                        onEditAiRule = { rule -> prefs.setAiDraftRule(rule) },
                        onToggleAiRule = { id, enabled ->
                            prefs.toggleAiTriggerRule(id, enabled)
                            if (enabled && !prefs.aiTriggerMasterEnabled.value) {
                                prefs.setAiTriggerMasterEnabled(true)
                            }
                            AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                        },
                        onDeleteAiRule = { id ->
                            prefs.deleteAiTriggerRule(id)
                            AiTriggerEngine.invalidateTemplateCache(id)
                            AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                            showTransientStatus("AI Trigger dihapus.")
                        },
                        onUpdateAiDraft = { transform ->
                            prefs.aiDraftRule.value?.let { cur ->
                                prefs.setAiDraftRule(transform(cur))
                            }
                        },
                        onCancelAiDraft = { prefs.setAiDraftRule(null) },
                        onSaveAiDraft = { rule ->
                            AiTriggerEngine.invalidateTemplateCache(rule.id)
                            prefs.upsertAiTriggerRule(rule)
                            prefs.setAiDraftRule(null)
                            if (rule.enabled && !prefs.aiTriggerMasterEnabled.value) {
                                prefs.setAiTriggerMasterEnabled(true)
                            }
                            AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                            if (rule.enabled && !AiTriggerCaptureManager.isProjectionActive() &&
                                !ShizukuBridge.status.value.canRunPrivileged
                            ) {
                                prefs.setOverlayPanelExpanded(false)
                                ScreenCapturePermissionActivity.launch(
                                    context = this@GameOverlayService,
                                    enableMasterOnGrant = true
                                ) { granted ->
                                    AiTriggerEngine.syncLoop(this@GameOverlayService, prefs)
                                    prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                    prefs.setOverlayPanelExpanded(true)
                                    showTransientStatus(
                                        if (granted) "AI Trigger \"${rule.name}\" aktif & memindai layar!"
                                        else "AI Trigger tersimpan. Izinkan Rekam Layar untuk mulai."
                                    )
                                }
                            } else {
                                showTransientStatus(
                                    if (rule.enabled) "AI Trigger \"${rule.name}\" tersimpan & AKTIF memindai!"
                                    else "AI Trigger \"${rule.name}\" tersimpan."
                                )
                            }
                        },
                        onOpenAiCropOverlay = { draft ->
                            prefs.setAiDraftRule(draft)
                            val canCaptureNow = AiTriggerCaptureManager.isProjectionActive() ||
                                ShizukuBridge.status.value.canRunPrivileged
                            if (!canCaptureNow) {
                                prefs.setOverlayPanelExpanded(false)
                                ScreenCapturePermissionActivity.launch(
                                    context = this@GameOverlayService,
                                    openCropOnGrant = true
                                ) { granted ->
                                    if (!granted) {
                                        prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                        prefs.setOverlayPanelExpanded(true)
                                        showTransientStatus("Izinkan Rekam Layar untuk mengambil area gambar.")
                                    }
                                }
                            } else {
                                prefs.setOverlayPanelExpanded(false)
                                prefs.setAiCropOverlayMode(true)
                            }
                        },
                        onOpenAiTargetPicker = { draft ->
                            prefs.setAiDraftRule(draft)
                            prefs.setOverlayPanelExpanded(false)
                            prefs.setAiTargetPickerMode(true)
                        },
                        onSetPanelFocusable = { focusable ->
                            panelParams?.let { p ->
                                val base = interactiveFlags()
                                val targetFlags = if (focusable) {
                                    base and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                                } else {
                                    base
                                }
                                if (p.flags != targetFlags) {
                                    p.flags = targetFlags
                                    runCatching { windowManager.updateViewLayout(panelView, p) }
                                }
                            }
                        }
                    )
                }
            }
        }
        runCatching { windowManager.addView(panelView, panelParams) }
    }

    private fun removePanelWindow() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelParams = null
    }

    // --- 7. Macro D-Pad Placement Editor ---
    private fun ensureDpadEditorWindow() {
        if (dpadEditorView != null || !Settings.canDrawOverlays(this)) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 32
        }

        dpadEditorView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val accentPreset by prefs.accentPreset.collectAsState()
                val curMacro by prefs.macroConfig.collectAsState()
                val accent = accentColorFor(accentPreset, true)
                val target2On = curMacro.enableTarget2 || curMacro.pattern == MacroPattern.QUICK_SWITCH
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(20.dp))
                        .background(ObsidianSurface.copy(alpha = 0.94f))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = when (activePlacementTarget) {
                            0 -> "Atur Posisi: Trigger"
                            2 -> "Atur Posisi: 2 (Ganti Senjata)"
                            else -> "Atur Posisi: 1 (Tembak)"
                        },
                        color = ObsidianTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NudgeButton("Trigger", activePlacementTarget == 0, accent) { activePlacementTarget = 0 }
                        NudgeButton("1 • Tembak", activePlacementTarget == 1, accent) { activePlacementTarget = 1 }
                        if (target2On) {
                            NudgeButton("2 • Senjata", activePlacementTarget == 2, StatusCyan) {
                                activePlacementTarget = 2
                            }
                        } else {
                            NudgeButton("+ 2 Senjata", false, StatusCyan) {
                                prefs.updateMacroConfig {
                                    it.copy(enableTarget2 = true, showTarget = true, pattern = MacroPattern.QUICK_SWITCH)
                                }
                                activePlacementTarget = 2
                            }
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        DpadKey("^") { nudgeActivePoint(0, -14) }
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            DpadKey("<") { nudgeActivePoint(-14, 0) }
                            DpadKey(">") { nudgeActivePoint(14, 0) }
                        }
                        DpadKey("v") { nudgeActivePoint(0, 14) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            prefs.setMacroPlacementMode(false)
                            prefs.setOverlayPanelExpanded(true)
                        }) {
                            Text("Batal", color = ObsidianTextPrimary, fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                prefs.updateMacroConfig { it.copy(isLocked = true, isRunning = false) }
                                prefs.setMacroPlacementMode(false)
                                showTransientStatus("Posisi Macro dikunci & transparan. Tahan Trigger sambil tetap bisa geser layar!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF0B0C0F))
                        ) {
                            Text("Selesai & Kunci", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        runCatching { windowManager.addView(dpadEditorView, params) }
    }

    private fun nudgeActivePoint(dx: Int, dy: Int) {
        val (w, h) = getScreenSize()
        when (activePlacementTarget) {
            1 -> macroTargetParams?.let { p ->
                p.x = (p.x + dx).coerceIn(0, w - targetHalfW * 2)
                p.y = (p.y + dy).coerceIn(0, h - targetHalfH * 2)
                runCatching { windowManager.updateViewLayout(macroTargetView, p) }
                prefs.updateMacroConfig {
                    it.copy(
                        targetNormX = ((p.x + targetHalfW).toFloat() / w).coerceIn(0.05f, 0.95f),
                        targetNormY = ((p.y + targetHalfH).toFloat() / h).coerceIn(0.05f, 0.95f)
                    )
                }
            }
            2 -> macroTarget2Params?.let { p ->
                p.x = (p.x + dx).coerceIn(0, w - target2HalfW * 2)
                p.y = (p.y + dy).coerceIn(0, h - target2HalfH * 2)
                runCatching { windowManager.updateViewLayout(macroTarget2View, p) }
                prefs.updateMacroConfig {
                    it.copy(
                        target2NormX = ((p.x + target2HalfW).toFloat() / w).coerceIn(0.05f, 0.95f),
                        target2NormY = ((p.y + target2HalfH).toFloat() / h).coerceIn(0.05f, 0.95f)
                    )
                }
            }
            else -> macroTriggerParams?.let { p ->
                p.x = (p.x + dx).coerceIn(0, w - triggerHalfW * 2)
                p.y = (p.y + dy).coerceIn(0, h - triggerHalfH * 2)
                runCatching { windowManager.updateViewLayout(macroTriggerView, p) }
                prefs.updateMacroConfig {
                    it.copy(
                        triggerNormX = ((p.x + triggerHalfW).toFloat() / w).coerceIn(0.05f, 0.95f),
                        triggerNormY = ((p.y + triggerHalfH).toFloat() / h).coerceIn(0.05f, 0.95f)
                    )
                }
            }
        }
    }

    private fun removeDpadEditorWindow() {
        dpadEditorView?.let { runCatching { windowManager.removeView(it) } }
        dpadEditorView = null
    }

    // --- 8. Radial Quick Wheel ---
    private fun ensureRadialWindow() {
        if (radialView != null || !Settings.canDrawOverlays(this)) return
        radialParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            x = 24
            y = 140
        }

        radialView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                var wheelOpen by remember { mutableStateOf(false) }
                val accentPreset by prefs.accentPreset.collectAsState()
                val accent = accentColorFor(accentPreset, true)

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.wrapContentSize()
                ) {
                    if (wheelOpen) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(ObsidianSurface.copy(alpha = 0.92f))
                                .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
                                .padding(8.dp)
                        ) {
                            RadialActionChip("Boost", accent) { triggerBoost(); wheelOpen = false }
                            RadialActionChip("HUD", accent) {
                                prefs.updateHudConfig { it.copy(enabled = !it.enabled) }
                                wheelOpen = false
                            }
                            RadialActionChip("Aim", accent) {
                                prefs.updateCrosshairConfig { it.copy(enabled = !it.enabled) }
                                wheelOpen = false
                            }
                            RadialActionChip("Macro", accent) {
                                prefs.updateMacroConfig { it.copy(enabled = !it.enabled) }
                                wheelOpen = false
                            }
                            RadialActionChip("Panel", accent) {
                                prefs.setOverlayPanelExpanded(true)
                                wheelOpen = false
                            }
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(ObsidianCard.copy(alpha = 0.92f))
                            .border(1.8.dp, accent, CircleShape)
                            .pointerInput(Unit) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    radialParams?.let { p ->
                                        p.x -= drag.x.roundToInt()
                                        p.y += drag.y.roundToInt()
                                        runCatching { windowManager.updateViewLayout(radialView, p) }
                                    }
                                }
                            }
                            .clickable { wheelOpen = !wheelOpen },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(AppIcons.RadialWheel, contentDescription = "Radial Menu", tint = accent, modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
        runCatching { windowManager.addView(radialView, radialParams) }
    }

    private fun removeRadialWindow() {
        radialView?.let { runCatching { windowManager.removeView(it) } }
        radialView = null
        radialParams = null
    }

    // --- 9. AI Trigger RedMagic-Style Crop Overlay & Target Aim Picker ---
    private fun ensureAiCropOverlayWindow() {
        if (aiCropOverlayView != null || !Settings.canDrawOverlays(this)) return
        val draft = prefs.aiDraftRule.value ?: AiTriggerRule(id = "ai_${System.currentTimeMillis()}").also {
            prefs.setAiDraftRule(it)
        }
        val (screenW, screenH) = getScreenSize()
        aiCropWidthPx = ((draft.cropRightNorm - draft.cropLeftNorm) * screenW).roundToInt().coerceAtLeast(36)
        aiCropHeightPx = ((draft.cropBottomNorm - draft.cropTopNorm) * screenH).roundToInt().coerceAtLeast(36)

        val fullParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            applyCutoutMode(this)
        }

        val cropView = AiCropBoxOverlayView(
            context = this,
            initialLeftNorm = draft.cropLeftNorm,
            initialTopNorm = draft.cropTopNorm,
            initialRightNorm = draft.cropRightNorm,
            initialBottomNorm = draft.cropBottomNorm,
            getScreenSize = ::getScreenSize,
            onRectChanged = { _, _, _, _, wPx, hPx ->
                aiCropWidthPx = wPx
                aiCropHeightPx = hPx
            }
        )
        aiCropOverlayView = cropView
        runCatching { windowManager.addView(cropView, fullParams) }

        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpToPx(18f)
            applyCutoutMode(this)
        }

        aiCropBarView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val redCrimson = Color(0xFFFF3B30)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.94f))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Batal",
                        color = ObsidianTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                prefs.setAiCropOverlayMode(false)
                                prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                prefs.setOverlayPanelExpanded(true)
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                    Text(
                        text = "Musuh ${aiCropWidthPx}x${aiCropHeightPx}",
                        color = ObsidianTextSecondary,
                        fontFamily = JetBrainsMono,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(redCrimson)
                            .clickable {
                                val rect = cropView.getNormalizedRect()
                                val dismissedAtMs = android.os.SystemClock.uptimeMillis()
                                removeAiCropOverlayWindow()
                                prefs.setAiCropOverlayMode(false)
                                serviceScope.launch {
                                    // Wait briefly so compositor flushes a clean game frame without crop scrim/brackets
                                    delay(170L)
                                    val curDraft = prefs.aiDraftRule.value ?: draft
                                    val fullBmp = withContext(Dispatchers.IO) {
                                        AiTriggerCaptureManager.captureBitmapForCrop(
                                            context = this@GameOverlayService,
                                            minTimestampMs = dismissedAtMs + 45L
                                        )
                                    }
                                    val cropped = if (fullBmp != null) {
                                        AiTriggerCaptureManager.cropNormalizedRegion(
                                            fullBmp,
                                            rect[0],
                                            rect[1],
                                            rect[2],
                                            rect[3]
                                        )
                                    } else null
                                    val savedPath = if (cropped != null) {
                                        withContext(Dispatchers.IO) {
                                            prefs.saveAiTemplateBitmap(curDraft.id, cropped)
                                        }
                                    } else null
                                    val cw = cropped?.width ?: 0
                                    val ch = cropped?.height ?: 0
                                    cropped?.recycle()
                                    fullBmp?.recycle()

                                    if (!savedPath.isNullOrBlank()) {
                                        AiTriggerEngine.invalidateTemplateCache(curDraft.id)
                                        prefs.setAiDraftRule(
                                            curDraft.copy(
                                                templatePath = savedPath,
                                                cropLeftNorm = rect[0],
                                                cropTopNorm = rect[1],
                                                cropRightNorm = rect[2],
                                                cropBottomNorm = rect[3],
                                                templateWidth = cw,
                                                templateHeight = ch
                                            )
                                        )
                                        showTransientStatus("Gambar musuh ($cw x $ch px) tersimpan! Lanjut Tambah Target Aim.")
                                    } else {
                                        showTransientStatus("Gagal crop layar. Ketuk 'Izinkan Rekam Layar' lalu coba lagi.")
                                    }
                                    prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                    prefs.setOverlayPanelExpanded(true)
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "OK",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        runCatching { windowManager.addView(aiCropBarView, barParams) }

        val hintParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dpToPx(18f)
            applyCutoutMode(this)
        }
        aiCropHintView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                Box(
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.88f))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Geser atau tarik sudut putih untuk mengkotakkan badan MUSUH, lalu ketuk OK.",
                        color = ObsidianTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
        runCatching { windowManager.addView(aiCropHintView, hintParams) }
    }

    private fun removeAiCropOverlayWindow() {
        aiCropHintView?.let { runCatching { windowManager.removeView(it) } }
        aiCropHintView = null
        aiCropBarView?.let { runCatching { windowManager.removeView(it) } }
        aiCropBarView = null
        aiCropOverlayView?.let { runCatching { windowManager.removeView(it) } }
        aiCropOverlayView = null
    }

    private fun ensureAiTargetPickerWindow() {
        if (aiTargetPickerView != null || !Settings.canDrawOverlays(this)) return
        val draft = prefs.aiDraftRule.value ?: AiTriggerRule(id = "ai_${System.currentTimeMillis()}").also {
            prefs.setAiDraftRule(it)
        }
        aiHeadOffsetXPct = draft.headOffsetXPercent.coerceIn(10, 90)
        aiHeadOffsetYPct = draft.headOffsetPercent.coerceIn(5, 55)
        aiPickerPreviewBitmap = prefs.loadAiTemplateBitmap(draft.templatePath)

        val fullParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            applyCutoutMode(this)
        }

        val pickerView = AiTargetPickerOverlayView(
            context = this,
            templateBitmap = aiPickerPreviewBitmap,
            initialHeadOffsetXPercent = aiHeadOffsetXPct,
            initialHeadOffsetYPercent = aiHeadOffsetYPct,
            initialCrosshairNormX = draft.gameCrosshairNormX,
            initialCrosshairNormY = draft.gameCrosshairNormY,
            contactRadiusPercent = draft.contactRadiusPercent,
            getScreenSize = ::getScreenSize,
            onPointsChanged = { headXPct, headYPct, _, _ ->
                aiHeadOffsetXPct = headXPct
                aiHeadOffsetYPct = headYPct
            }
        )
        aiTargetPickerView = pickerView
        runCatching { windowManager.addView(pickerView, fullParams) }

        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            interactiveFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpToPx(18f)
            applyCutoutMode(this)
        }

        aiTargetBarView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val redCrimson = Color(0xFFFF3B30)
                var testingSwipe by remember { mutableStateOf(false) }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.94f))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Batal",
                        color = ObsidianTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                prefs.setAiTargetPickerMode(false)
                                prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                prefs.setOverlayPanelExpanded(true)
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                    Text(
                        text = "Reset Tengah",
                        color = StatusCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(StatusCyan.copy(alpha = 0.14f))
                            .clickable { pickerView.resetCrosshairToCenter() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                    Text(
                        text = if (testingSwipe) "Menguji..." else "Tes Tarik",
                        color = if (testingSwipe) ObsidianTextSecondary else StatusGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(StatusGreen.copy(alpha = 0.16f))
                            .border(1.dp, StatusGreen.copy(alpha = 0.6f), RoundedCornerShape(50))
                            .clickable(enabled = !testingSwipe) {
                                testingSwipe = true
                                val curDraft = (prefs.aiDraftRule.value ?: draft).copy(
                                    headOffsetXPercent = pickerView.headOffsetXPercent,
                                    headOffsetPercent = pickerView.headOffsetYPercent,
                                    gameCrosshairNormX = pickerView.gameCrosshairNormX,
                                    gameCrosshairNormY = pickerView.gameCrosshairNormY
                                )
                                prefs.setAiDraftRule(curDraft)
                                serviceScope.launch {
                                    val origFlags = fullParams.flags
                                    fullParams.flags = origFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                    pickerView.alpha = 0.25f
                                    runCatching { windowManager.updateViewLayout(pickerView, fullParams) }
                                    delay(90L)
                                    val (_, msg) = AiTriggerEngine.testHeadTriggerSwipe(
                                        context = this@GameOverlayService,
                                        prefs = prefs,
                                        rule = curDraft
                                    )
                                    delay(90L)
                                    fullParams.flags = origFlags
                                    pickerView.alpha = 1f
                                    runCatching { windowManager.updateViewLayout(pickerView, fullParams) }
                                    testingSwipe = false
                                    showTransientStatus(msg)
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                    Text(
                        text = "Kepala ${aiHeadOffsetXPct}%,${aiHeadOffsetYPct}%",
                        color = redCrimson,
                        fontFamily = JetBrainsMono,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(redCrimson)
                            .clickable {
                                val curDraft = prefs.aiDraftRule.value ?: draft
                                prefs.setAiDraftRule(
                                    curDraft.copy(
                                        headOffsetXPercent = pickerView.headOffsetXPercent,
                                        headOffsetPercent = pickerView.headOffsetYPercent,
                                        gameCrosshairNormX = pickerView.gameCrosshairNormX,
                                        gameCrosshairNormY = pickerView.gameCrosshairNormY
                                    )
                                )
                                prefs.setAiTargetPickerMode(false)
                                prefs.requestPanelTab(PanelTab.AI_TRIGGER)
                                prefs.setOverlayPanelExpanded(true)
                                showTransientStatus("Aim Kepala (${aiHeadOffsetXPct}%, ${aiHeadOffsetYPct}%) lurus dengan crosshair tengah!")
                            }
                            .padding(horizontal = 15.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "OK",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        runCatching { windowManager.addView(aiTargetBarView, barParams) }

        val hintParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dpToPx(18f)
            applyCutoutMode(this)
        }
        aiTargetHintView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                Box(
                    modifier = Modifier
                        .wrapContentSize()
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.88f))
                        .border(1.dp, Color(0xFFFF3B30).copy(alpha = 0.55f), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Geser Aim MERAH tepat ke KEPALA musuh untuk meluruskan dengan crosshair tengah, lalu OK.",
                        color = ObsidianTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
        runCatching { windowManager.addView(aiTargetHintView, hintParams) }
    }

    private fun removeAiTargetPickerWindow() {
        aiTargetHintView?.let { runCatching { windowManager.removeView(it) } }
        aiTargetHintView = null
        aiTargetBarView?.let { runCatching { windowManager.removeView(it) } }
        aiTargetBarView = null
        aiTargetPickerView?.let { runCatching { windowManager.removeView(it) } }
        aiTargetPickerView = null
        aiPickerPreviewBitmap = null
    }

    private fun ensureAiCrosshairWindow(rt: com.example.model.AiTriggerRuntimeState) {
        if (!Settings.canDrawOverlays(this)) return
        if (aiCrosshairView == null) {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayWindowType(),
                passThroughFlags() or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                applyCutoutMode(this)
            }
            aiCrosshairView = AiTriggerCrosshairView(this, ::getScreenSize).apply {
                alpha = 0.82f
            }
            runCatching { windowManager.addView(aiCrosshairView, params) }
        }
        aiCrosshairView?.updateTrackingState(
            crossNormX = rt.activeCrosshairNormX,
            crossNormY = rt.activeCrosshairNormY,
            contactRadiusPercent = rt.activeContactRadiusPercent,
            matched = rt.isMatched,
            touchingBody = rt.crosshairTouchingBody,
            aimingHead = rt.isAimingToHead,
            leftNorm = rt.matchedLeftNorm,
            topNorm = rt.matchedTopNorm,
            rightNorm = rt.matchedRightNorm,
            bottomNorm = rt.matchedBottomNorm,
            headX = rt.headTargetNormX,
            headY = rt.headTargetNormY,
            score = rt.lastMatchScore
        )
    }

    private fun removeAiCrosshairWindow() {
        aiCrosshairView?.let { runCatching { windowManager.removeView(it) } }
        aiCrosshairView = null
    }

    private fun ensureAiStatusBadgeWindow() {
        if (aiStatusBadgeView != null || !Settings.canDrawOverlays(this)) return
        aiStatusBadgeParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(14f)
            y = dpToPx(24f)
        }

        aiStatusBadgeView = ComposeView(this).apply {
            attachComposeOwners(this)
            setContent {
                val aiRuntime by AiTriggerEngine.runtimeState.collectAsState()
                val dotColor = when {
                    aiRuntime.crosshairTouchingBody || aiRuntime.isAimingToHead -> StatusGreen
                    aiRuntime.isMatched -> Color(0xFFFFC640)
                    aiRuntime.lastError != null -> Color(0xFFFFB740)
                    aiRuntime.isCapturing -> StatusCyan
                    else -> Color(0xFFFF3B30)
                }
                val lat = if (aiRuntime.scanLatencyMs > 0) " • ${aiRuntime.scanLatencyMs}ms" else ""
                val textLabel = when {
                    aiRuntime.lastError != null -> "AI: ${aiRuntime.lastError}"
                    aiRuntime.isAimingToHead || aiRuntime.crosshairTouchingBody ->
                        "LOCK KEPALA ${aiRuntime.lastMatchScore}% (${aiRuntime.triggerCount}x)$lat"
                    aiRuntime.isMatched -> "MUSUH ${aiRuntime.lastMatchScore}%$lat"
                    else -> "AI ${aiRuntime.lastMatchScore}% • ${aiRuntime.activeRulesCount}/5$lat"
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .wrapContentSize()
                        .alpha(0.82f)
                        .clip(RoundedCornerShape(50))
                        .background(ObsidianSurface.copy(alpha = 0.88f))
                        .border(1.dp, dotColor.copy(alpha = 0.65f), RoundedCornerShape(50))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Text(
                        text = textLabel,
                        color = ObsidianTextPrimary,
                        fontFamily = JetBrainsMono,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        runCatching { windowManager.addView(aiStatusBadgeView, aiStatusBadgeParams) }
    }

    private fun removeAiStatusBadgeWindow() {
        aiStatusBadgeView?.let { runCatching { windowManager.removeView(it) } }
        aiStatusBadgeView = null
        aiStatusBadgeParams = null
    }

    private fun triggerBoost() {
        serviceScope.launch {
            telemetryMonitor.setBoosting(true)
            val result = optimizer.performBoost()
            telemetryMonitor.updateBoostStats(result.scoreAfter, result.freedMb, result.killedProcesses, false)
            showTransientStatus(result.summary)
        }
    }

    private fun showTransientStatus(msg: String) {
        statusBannerMessage = msg
        statusClearJob?.cancel()
        statusClearJob = serviceScope.launch {
            delay(3600L)
            statusBannerMessage = null
        }
    }

    private fun ensureTouchAimPadWindow(config: TouchConfig, accentColor: Int) {
        if (!Settings.canDrawOverlays(this)) return
        val padW = dpToPx(116f).coerceAtLeast(100)
        val padH = dpToPx(104f).coerceAtLeast(90)
        val (screenW, screenH) = getScreenSize()
        val desiredX = (config.aimPadNormX * screenW - padW / 2f).roundToInt()
            .coerceIn(0, (screenW - padW).coerceAtLeast(0))
        val desiredY = (config.aimPadNormY * screenH - padH / 2f).roundToInt()
            .coerceIn(0, (screenH - padH).coerceAtLeast(0))

        if (touchAimPadView == null) {
            touchAimPadParams = WindowManager.LayoutParams(
                padW,
                padH,
                overlayWindowType(),
                interactiveFlags() or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = desiredX
                y = desiredY
                applyCutoutMode(this)
            }
            touchAimPadView = TouchAimBoosterPadView(
                context = this,
                accentColor = accentColor,
                serviceScope = serviceScope,
                getScreenSize = ::getScreenSize,
                getDisplayRotation = ::getDisplayRotation,
                readWindowParams = { touchAimPadParams },
                onUpdateLayout = { p ->
                    runCatching { windowManager.updateViewLayout(touchAimPadView, p) }
                },
                onMoved = { normX, normY ->
                    prefs.updateTouchConfig { it.copy(aimPadNormX = normX, aimPadNormY = normY) }
                }
            ).apply {
                updateConfig(config, accentColor)
            }
            runCatching { windowManager.addView(touchAimPadView, touchAimPadParams) }
        } else {
            touchAimPadView?.updateConfig(config, accentColor)
            touchAimPadParams?.let { p ->
                if (p.width != padW || p.height != padH || p.x != desiredX || p.y != desiredY) {
                    p.width = padW
                    p.height = padH
                    p.x = desiredX
                    p.y = desiredY
                    runCatching { windowManager.updateViewLayout(touchAimPadView, p) }
                }
            }
        }
    }

    private fun snapTouchAimPadToCurrentScreen() {
        val view = touchAimPadView ?: return
        val p = touchAimPadParams ?: return
        val cfg = prefs.touchConfig.value
        val (w, h) = getScreenSize()
        p.x = (cfg.aimPadNormX * w - p.width / 2f).roundToInt().coerceIn(0, (w - p.width).coerceAtLeast(0))
        p.y = (cfg.aimPadNormY * h - p.height / 2f).roundToInt().coerceIn(0, (h - p.height).coerceAtLeast(0))
        runCatching { windowManager.updateViewLayout(view, p) }
    }

    private fun removeTouchAimPadWindow() {
        touchAimPadView?.cancelActiveInjection()
        touchAimPadView?.let { runCatching { windowManager.removeView(it) } }
        touchAimPadView = null
        touchAimPadParams = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        snapEdgeHandleToCurrentScreen()
        snapMacroViewsToCurrentScreen()
        snapTouchAimPadToCurrentScreen()
    }

    private fun snapMacroViewsToCurrentScreen() {
        val (w, h) = getScreenSize()
        val macro = prefs.macroConfig.value
        macroTargetParams?.let { p ->
            p.x = (macro.targetNormX * w - targetHalfW).roundToInt().coerceIn(0, (w - targetHalfW * 2).coerceAtLeast(0))
            p.y = (macro.targetNormY * h - targetHalfH).roundToInt().coerceIn(0, (h - targetHalfH * 2).coerceAtLeast(0))
            runCatching { windowManager.updateViewLayout(macroTargetView, p) }
        }
        macroTarget2Params?.let { p ->
            p.x = (macro.target2NormX * w - target2HalfW).roundToInt().coerceIn(0, (w - target2HalfW * 2).coerceAtLeast(0))
            p.y = (macro.target2NormY * h - target2HalfH).roundToInt().coerceIn(0, (h - target2HalfH * 2).coerceAtLeast(0))
            runCatching { windowManager.updateViewLayout(macroTarget2View, p) }
        }
        macroTriggerParams?.let { p ->
            p.x = (macro.triggerNormX * w - triggerHalfW).roundToInt().coerceIn(0, (w - triggerHalfW * 2).coerceAtLeast(0))
            p.y = (macro.triggerNormY * h - triggerHalfH).roundToInt().coerceIn(0, (h - triggerHalfH * 2).coerceAtLeast(0))
            runCatching { windowManager.updateViewLayout(macroTriggerView, p) }
        }
    }

    private fun getScreenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun getDisplayRotation(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { display?.rotation ?: Surface.ROTATION_0 }.getOrDefault(Surface.ROTATION_0)
        } else {
            @Suppress("DEPRECATION")
            runCatching { windowManager.defaultDisplay.rotation }.getOrDefault(Surface.ROTATION_0)
        }
    }

    override fun onDestroy() {
        isRunning = false
        touchApplyJob?.cancel()
        burikApplyJob?.cancel()
        foregroundWatcherJob?.cancel()
        telemetryMonitor.stop()
        stopTriggerMacro()
        removeTouchAimPadWindow()
        ShizukuBridge.unbindInputService()
        lifecycleOwner.onStop()
        lifecycleOwner.onDestroy()
        serviceScope.cancel()
        removeHudWindow()
        removeEdgeHandleWindow()
        removeCrosshairWindow()
        removeMacroLineWindow()
        removeMacroTriggerWindow()
        removeMacroTargetWindow()
        removeMacroTarget2Window()
        removeMacroLockChipWindow()
        removeDpadEditorWindow()
        removeRadialWindow()
        removePanelWindow()
        removeAiCropOverlayWindow()
        removeAiTargetPickerWindow()
        removeAiCrosshairWindow()
        removeAiStatusBadgeWindow()
        AiTriggerEngine.stopLoop(prefs)
        AiTriggerProjectionService.stop(this)
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PANEL = "com.example.action.OPEN_PANEL"
        const val ACTION_STOP = "com.example.action.STOP_OVERLAY"
        const val ACTION_BOOST = "com.example.action.BOOST_OVERLAY"
        private const val NOTIFICATION_ID = 7041

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context, openPanelImmediately: Boolean = false) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, GameOverlayService::class.java).apply {
                if (openPanelImmediately) action = ACTION_OPEN_PANEL
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GameOverlayService::class.java))
        }
    }
}

/**
 * Native lightweight pass-through View for Crosshair drawing.
 * Sized tightly around the reticle so it never spans full-screen or blocks touches.
 */
private class CrosshairCanvasView(context: Context) : View(context) {
    private var config = CrosshairConfig()
    private val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = android.graphics.Color.BLACK
    }

    fun updateConfig(newConfig: CrosshairConfig) {
        config = newConfig
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val sz = config.sizeDp * density
        val thick = config.thicknessDp * density
        val gap = config.gapDp * density
        val outlineStroke = thick + 2f * density
        val col = CrosshairPalette.getOrElse(config.colorIndex) { Color.Cyan }.toArgb()

        mainPaint.color = col
        mainPaint.strokeWidth = thick
        fillPaint.color = col
        outlinePaint.strokeWidth = outlineStroke

        fun drawCross(paint: Paint) {
            canvas.drawLine(cx - sz, cy, cx - gap, cy, paint)
            canvas.drawLine(cx + gap, cy, cx + sz, cy, paint)
            canvas.drawLine(cx, cy - sz, cx, cy - gap, paint)
            canvas.drawLine(cx, cy + gap, cx, cy + sz, paint)
        }

        when (config.shape) {
            CrosshairShape.DOT -> {
                if (config.outline) {
                    fillPaint.color = android.graphics.Color.BLACK
                    canvas.drawCircle(cx, cy, thick * 1.4f + 1.5f * density, fillPaint)
                    fillPaint.color = col
                }
                canvas.drawCircle(cx, cy, thick * 1.4f, fillPaint)
            }
            CrosshairShape.PLUS -> {
                if (config.outline) drawCross(outlinePaint)
                drawCross(mainPaint)
            }
            CrosshairShape.TARGET -> {
                if (config.outline) {
                    canvas.drawCircle(cx, cy, sz * 0.65f, outlinePaint)
                    drawCross(outlinePaint)
                }
                canvas.drawCircle(cx, cy, sz * 0.65f, mainPaint)
                drawCross(mainPaint)
                canvas.drawCircle(cx, cy, thick, fillPaint)
            }
            CrosshairShape.CROSS_X -> {
                val d = sz * 0.72f
                val g = gap * 0.7f
                if (config.outline) {
                    canvas.drawLine(cx - d, cy - d, cx - g, cy - g, outlinePaint)
                    canvas.drawLine(cx + g, cy + g, cx + d, cy + d, outlinePaint)
                    canvas.drawLine(cx + d, cy - d, cx + g, cy - g, outlinePaint)
                    canvas.drawLine(cx - g, cy + g, cx - d, cy + d, outlinePaint)
                }
                canvas.drawLine(cx - d, cy - d, cx - g, cy - g, mainPaint)
                canvas.drawLine(cx + g, cy + g, cx + d, cy + d, mainPaint)
                canvas.drawLine(cx + d, cy - d, cx + g, cy - g, mainPaint)
                canvas.drawLine(cx - g, cy + g, cx - d, cy + d, mainPaint)
            }
            CrosshairShape.DIAMOND -> {
                val path = android.graphics.Path().apply {
                    moveTo(cx, cy - sz)
                    lineTo(cx + sz, cy)
                    lineTo(cx, cy + sz)
                    lineTo(cx - sz, cy)
                    close()
                }
                if (config.outline) canvas.drawPath(path, outlinePaint)
                canvas.drawPath(path, mainPaint)
                canvas.drawCircle(cx, cy, thick, fillPaint)
            }
        }
    }
}

/**
 * Native lightweight pass-through View for dashed line between Macro Trigger and Target.
 */
private class MacroConnectorCanvasView(context: Context) : View(context) {
    private var tx = 0.22f
    private var ty = 0.62f
    private var t1x = 0.48f
    private var t1y = 0.56f
    private var has2 = false
    private var t2x = 0.68f
    private var t2y = 0.36f

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.argb(190, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f * context.resources.displayMetrics.density
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    private val switchLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.argb(215, 0, 229, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * context.resources.displayMetrics.density
        pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
    }

    fun updatePoints(
        triggerX: Float,
        triggerY: Float,
        target1X: Float,
        target1Y: Float,
        hasTarget2: Boolean = false,
        target2X: Float = 0.68f,
        target2Y: Float = 0.36f
    ) {
        tx = triggerX
        ty = triggerY
        t1x = target1X
        t1y = target1Y
        has2 = hasTarget2
        t2x = target2X
        t2y = target2Y
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        canvas.drawLine(tx * width, ty * height, t1x * width, t1y * height, linePaint)
        if (has2) {
            canvas.drawLine(t1x * width, t1y * height, t2x * width, t2y * height, switchLinePaint)
        }
    }
}

@Composable
private fun DpadKey(symbol: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(ObsidianCard)
            .border(1.dp, ObsidianBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(symbol, color = ObsidianTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun NudgeButton(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) accent else ObsidianCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color(0xFF0B0C0F) else ObsidianTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun RadialActionChip(label: String, accent: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = ObsidianTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Ultra-slim native edge-handle line flush against the physical left or right screen edge.
 * - Quick tap opens the floating panel.
 * - Hold (long-press 260ms) unlocks free movement across the screen and snaps flush to the nearest
 *   left/right edge on release based on the current device screen resolution.
 */
private class EdgeHandleTabView(
    context: Context,
    accentColor: Int,
    private var isRightEdge: Boolean,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val readWindowParams: () -> WindowManager.LayoutParams?,
    private val onUpdateLayout: (WindowManager.LayoutParams) -> Unit,
    private val onTapOpenPanel: () -> Unit,
    private val onPositionCommitted: (Boolean, Float) -> Unit
) : View(context) {

    private var accent = accentColor
    private var isDragging = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startParamX = 0
    private var startParamY = 0
    private var movedBeyondSlop = false

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private val holdHandler = Handler(Looper.getMainLooper())
    private val longPressRunnable = Runnable {
        isDragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val tabRect = RectF()
    private val barRect = RectF()
    private val cornerRadii = FloatArray(8)
    private val path = android.graphics.Path()

    fun setAccentColor(color: Int) {
        accent = color
        invalidate()
    }

    fun setRightEdge(rightEdge: Boolean) {
        isRightEdge = rightEdge
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 5f * density

        // Rounded only on the side facing inward; 0px gap/radius on the outer physical screen edge
        if (isRightEdge) {
            cornerRadii[0] = r; cornerRadii[1] = r
            cornerRadii[2] = 0f; cornerRadii[3] = 0f
            cornerRadii[4] = 0f; cornerRadii[5] = 0f
            cornerRadii[6] = r; cornerRadii[7] = r
        } else {
            cornerRadii[0] = 0f; cornerRadii[1] = 0f
            cornerRadii[2] = r; cornerRadii[3] = r
            cornerRadii[4] = r; cornerRadii[5] = r
            cornerRadii[6] = 0f; cornerRadii[7] = 0f
        }

        tabRect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(tabRect, cornerRadii, android.graphics.Path.Direction.CW)

        bgPaint.color = if (isDragging) {
            android.graphics.Color.argb(242, 22, 26, 36)
        } else {
            android.graphics.Color.argb(205, 14, 17, 23)
        }
        canvas.drawPath(path, bgPaint)

        borderPaint.strokeWidth = if (isDragging) 1.5f * density else 1f * density
        val red = android.graphics.Color.red(accent)
        val green = android.graphics.Color.green(accent)
        val blue = android.graphics.Color.blue(accent)
        borderPaint.color = android.graphics.Color.argb(if (isDragging) 245 else 160, red, green, blue)
        canvas.drawPath(path, borderPaint)

        val barW = if (isDragging) 3f * density else 2.2f * density
        val barH = h * 0.56f
        val barLeft = if (isRightEdge) {
            (w - barW) * 0.55f
        } else {
            (w - barW) * 0.45f
        }
        val barTop = (h - barH) / 2f
        barRect.set(barLeft, barTop, barLeft + barW, barTop + barH)
        barPaint.color = android.graphics.Color.argb(if (isDragging) 255 else 225, red, green, blue)
        canvas.drawRoundRect(barRect, barW / 2f, barW / 2f, barPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val p = readWindowParams() ?: return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                startParamX = p.x
                startParamY = p.y
                isDragging = false
                movedBeyondSlop = false
                holdHandler.removeCallbacks(longPressRunnable)
                holdHandler.postDelayed(longPressRunnable, 260L)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!isDragging) {
                    if (kotlin.math.hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                        movedBeyondSlop = true
                        holdHandler.removeCallbacks(longPressRunnable)
                    }
                    return true
                }
                val (screenW, screenH) = getScreenSize()
                val maxX = (screenW - width).coerceAtLeast(0)
                val maxY = (screenH - height).coerceAtLeast(0)
                p.x = (startParamX + dx.roundToInt()).coerceIn(0, maxX)
                p.y = (startParamY + dy.roundToInt()).coerceIn(0, maxY)
                isRightEdge = (p.x + width / 2) >= (screenW / 2)
                onUpdateLayout(p)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                holdHandler.removeCallbacks(longPressRunnable)
                if (isDragging) {
                    isDragging = false
                    snapAndCommit(p)
                    invalidate()
                } else if (!movedBeyondSlop) {
                    performClick()
                    onTapOpenPanel()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                holdHandler.removeCallbacks(longPressRunnable)
                if (isDragging) {
                    isDragging = false
                    snapAndCommit(p)
                    invalidate()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        return super.performClick()
    }

    override fun onDetachedFromWindow() {
        holdHandler.removeCallbacks(longPressRunnable)
        super.onDetachedFromWindow()
    }

    private fun snapAndCommit(p: WindowManager.LayoutParams) {
        val (screenW, screenH) = getScreenSize()
        val maxX = (screenW - width).coerceAtLeast(0)
        val maxY = (screenH - height).coerceAtLeast(0)
        val rightEdge = (p.x + width / 2) >= (screenW / 2)
        p.x = if (rightEdge) maxX else 0
        p.y = p.y.coerceIn(0, maxY)
        isRightEdge = rightEdge
        val normY = ((p.y + height / 2f) / screenH.toFloat().coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
        onUpdateLayout(p)
        onPositionCommitted(rightEdge, normY)
    }
}

/**
 * Native Macro Target reticle:
 * - Unlocked/Placement: solid ring, freely draggable with rawX/rawY.
 * - Locked: transparent & FLAG_NOT_TOUCHABLE so all taps pass straight through to the game underneath.
 */
private class MacroTargetOverlayView(
    context: Context,
    private val badgeText: String,
    accentColor: Int,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val readWindowParams: () -> WindowManager.LayoutParams?,
    private val onUpdateLayout: (WindowManager.LayoutParams) -> Unit,
    private val onMoved: (Float, Float) -> Unit,
    private val onSelectedForPlacement: () -> Unit
) : View(context) {

    private var locked = false
    private var placementHighlighted = false
    private var running = false
    private var lockedAlpha = 0.30f
    private var accent = accentColor

    private var activePointerId = MotionEvent.INVALID_POINTER_ID
    private var downRawX = 0f
    private var downRawY = 0f
    private var startParamX = 0
    private var startParamY = 0
    private var movedBeyondSlop = false
    private var lastMovePersistAtMs = 0L
    private var pendingNormX = 0f
    private var pendingNormY = 0f
    private var hasPendingMove = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun updateState(
        locked: Boolean,
        placementHighlighted: Boolean,
        running: Boolean,
        lockedAlpha: Float,
        accentColor: Int
    ) {
        this.locked = locked
        this.placementHighlighted = placementHighlighted
        this.running = running
        this.lockedAlpha = lockedAlpha
        this.accent = accentColor
        alpha = if (locked) (lockedAlpha * 0.85f).coerceIn(0.14f, 0.60f) else 1.0f
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = (minOf(width, height) / 2f) - 3f * density

        fillPaint.color = android.graphics.Color.argb(if (locked) 95 else 160, 11, 12, 15)
        canvas.drawCircle(cx, cy, r, fillPaint)

        ringPaint.strokeWidth = 2f * density
        ringPaint.color = when {
            running -> android.graphics.Color.rgb(46, 213, 115)
            placementHighlighted -> android.graphics.Color.rgb(0, 229, 255)
            else -> accent
        }
        canvas.drawCircle(cx, cy, r, ringPaint)

        if (locked) {
            fillPaint.color = if (running) android.graphics.Color.rgb(46, 213, 115) else android.graphics.Color.WHITE
            canvas.drawCircle(cx, cy, 2.5f * density, fillPaint)
            textPaint.textSize = 9.5f * density
            textPaint.color = android.graphics.Color.argb(215, 255, 255, 255)
            canvas.drawText(badgeText, cx, cy - 4.5f * density, textPaint)
        } else {
            textPaint.textSize = 13f * density
            textPaint.color = if (running) android.graphics.Color.rgb(46, 213, 115) else android.graphics.Color.WHITE
            val textY = cy - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(badgeText, cx, textY, textPaint)
        }
    }

    private fun flushPendingMove() {
        if (hasPendingMove) {
            hasPendingMove = false
            onMoved(pendingNormX, pendingNormY)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (locked) return false
        val p = readWindowParams() ?: return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                downRawX = event.rawX
                downRawY = event.rawY
                startParamX = p.x
                startParamY = p.y
                movedBeyondSlop = false
                hasPendingMove = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx < 0) return false
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!movedBeyondSlop && kotlin.math.hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    movedBeyondSlop = true
                }
                if (movedBeyondSlop) {
                    val (w, h) = getScreenSize()
                    p.x = (startParamX + dx.roundToInt()).coerceIn(0, (w - width).coerceAtLeast(0))
                    p.y = (startParamY + dy.roundToInt()).coerceIn(0, (h - height).coerceAtLeast(0))
                    onUpdateLayout(p)
                    val normX = ((p.x + width / 2f) / w.toFloat().coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
                    val normY = ((p.y + height / 2f) / h.toFloat().coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
                    pendingNormX = normX
                    pendingNormY = normY
                    hasPendingMove = true
                    val now = SystemClock.uptimeMillis()
                    if (now - lastMovePersistAtMs >= 120L) {
                        lastMovePersistAtMs = now
                        hasPendingMove = false
                        onMoved(normX, normY)
                    }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                if (pointerId == activePointerId) {
                    activePointerId = MotionEvent.INVALID_POINTER_ID
                    flushPendingMove()
                    if (!movedBeyondSlop) {
                        performClick()
                        onSelectedForPlacement()
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePointerId = MotionEvent.INVALID_POINTER_ID
                flushPendingMove()
                if (event.actionMasked == MotionEvent.ACTION_UP && !movedBeyondSlop) {
                    performClick()
                    onSelectedForPlacement()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()
}

/**
 * Native Macro Trigger button:
 * - Uses FLAG_SPLIT_TOUCH so while Finger 1 presses/holds Trigger, Finger 2+ can swipe/aim the game freely!
 * - Tracks activePointerId so secondary pointers never hijack Trigger state.
 * - Unlocked/Placement: opaque & freely draggable with rawX/rawY so user can place it.
 * - Locked: transparent & completely immovable; supports Hold-to-Fire (ACTION_DOWN starts firing,
 *   ACTION_UP / ACTION_CANCEL stops immediately) or Tap-Toggle when holdToTrigger is disabled.
 */
private class MacroTriggerOverlayView(
    context: Context,
    accentColor: Int,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val readWindowParams: () -> WindowManager.LayoutParams?,
    private val onUpdateLayout: (WindowManager.LayoutParams) -> Unit,
    private val onMoved: (Float, Float) -> Unit,
    private val onSelectedForPlacement: () -> Unit,
    private val onHoldStart: () -> Unit,
    private val onHoldStop: () -> Unit,
    private val onTapToggle: () -> Unit,
    private val onLatchedFromCancel: () -> Unit,
    private val isKernelMultiTouch: () -> Boolean
) : View(context) {

    private var locked = false
    private var holdToTrigger = true
    private var placementHighlighted = false
    private var running = false
    private var lockedAlpha = 0.30f
    private var accent = accentColor

    private var activePointerId = MotionEvent.INVALID_POINTER_ID
    private var latchedRunning = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startParamX = 0
    private var startParamY = 0
    private var movedBeyondSlop = false
    private var lastMovePersistAtMs = 0L
    private var pendingNormX = 0f
    private var pendingNormY = 0f
    private var hasPendingMove = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private fun flushPendingMove() {
        if (hasPendingMove) {
            hasPendingMove = false
            onMoved(pendingNormX, pendingNormY)
        }
    }

    fun updateState(
        locked: Boolean,
        holdToTrigger: Boolean,
        placementHighlighted: Boolean,
        running: Boolean,
        lockedAlpha: Float,
        accentColor: Int
    ) {
        this.locked = locked
        this.holdToTrigger = holdToTrigger
        this.placementHighlighted = placementHighlighted
        this.running = running
        if (!running) latchedRunning = false
        this.lockedAlpha = lockedAlpha
        this.accent = accentColor
        alpha = if (locked) {
            if (running) (lockedAlpha + 0.22f).coerceIn(0.25f, 0.72f)
            else lockedAlpha.coerceIn(0.15f, 0.68f)
        } else {
            1.0f
        }
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = (minOf(width, height) / 2f) - 3f * density

        fillPaint.color = if (running) {
            android.graphics.Color.argb(110, 46, 213, 115)
        } else {
            android.graphics.Color.argb(if (locked) 130 else 180, 14, 17, 23)
        }
        canvas.drawCircle(cx, cy, r, fillPaint)

        ringPaint.strokeWidth = 2.2f * density
        ringPaint.color = when {
            running -> android.graphics.Color.rgb(46, 213, 115)
            placementHighlighted -> android.graphics.Color.rgb(0, 229, 255)
            else -> accent
        }
        canvas.drawCircle(cx, cy, r, ringPaint)

        // Draw crisp bolt/macro reticle glyph inside
        val g = r * 0.42f
        glyphPaint.strokeWidth = 2f * density
        glyphPaint.color = if (running) android.graphics.Color.rgb(46, 213, 115) else android.graphics.Color.WHITE
        canvas.drawLine(cx - g, cy, cx + g, cy, glyphPaint)
        canvas.drawLine(cx, cy - g, cx, cy + g, glyphPaint)
        if (locked) {
            fillPaint.color = if (running) android.graphics.Color.rgb(46, 213, 115) else accent
            canvas.drawCircle(cx, cy, 2.5f * density, fillPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val p = readWindowParams() ?: return super.onTouchEvent(event)
        if (locked) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (!holdToTrigger) {
                        // Sekali Ketuk (On/Off): toggle immediately on ACTION_DOWN so lifting/cancel never interferes
                        activePointerId = MotionEvent.INVALID_POINTER_ID
                        latchedRunning = false
                        performClick()
                        onTapToggle()
                        return true
                    }
                    if (running && latchedRunning) {
                        // Already running via non-root latch -> tap again to stop cleanly
                        latchedRunning = false
                        activePointerId = MotionEvent.INVALID_POINTER_ID
                        performClick()
                        onHoldStop()
                        return true
                    }
                    activePointerId = event.getPointerId(0)
                    latchedRunning = false
                    onHoldStart()
                    return true
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    // Keep stream alive for 10-finger split-touch; FLAG_SPLIT_TOUCH routes outside fingers directly to game
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    return event.findPointerIndex(activePointerId) >= 0
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val pointerId = event.getPointerId(event.actionIndex)
                    if (pointerId == activePointerId) {
                        activePointerId = MotionEvent.INVALID_POINTER_ID
                        if (holdToTrigger && !latchedRunning) {
                            onHoldStop()
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val isTracked = activePointerId != MotionEvent.INVALID_POINTER_ID
                    activePointerId = MotionEvent.INVALID_POINTER_ID
                    if (isTracked && holdToTrigger && !latchedRunning) {
                        onHoldStop()
                    }
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (activePointerId != MotionEvent.INVALID_POINTER_ID) {
                        activePointerId = MotionEvent.INVALID_POINTER_ID
                        if (holdToTrigger) {
                            if (!isKernelMultiTouch() && running && ShizukuBridge.wasRecentInjection()) {
                                // Non-root IInputManager injection cancels active overlay stream; latch cleanly instead of dying after 1 tap
                                latchedRunning = true
                                onLatchedFromCancel()
                            } else {
                                onHoldStop()
                            }
                        }
                    }
                    return true
                }
            }
            return false
        }

        // Unlocked / Placement mode: freely draggable with tracked activePointerId
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                downRawX = event.rawX
                downRawY = event.rawY
                startParamX = p.x
                startParamY = p.y
                movedBeyondSlop = false
                hasPendingMove = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx < 0) return false
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!movedBeyondSlop && kotlin.math.hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    movedBeyondSlop = true
                }
                if (movedBeyondSlop) {
                    val (w, h) = getScreenSize()
                    p.x = (startParamX + dx.roundToInt()).coerceIn(0, (w - width).coerceAtLeast(0))
                    p.y = (startParamY + dy.roundToInt()).coerceIn(0, (h - height).coerceAtLeast(0))
                    onUpdateLayout(p)
                    val normX = ((p.x + width / 2f) / w.toFloat().coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
                    val normY = ((p.y + height / 2f) / h.toFloat().coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
                    pendingNormX = normX
                    pendingNormY = normY
                    hasPendingMove = true
                    val now = SystemClock.uptimeMillis()
                    if (now - lastMovePersistAtMs >= 120L) {
                        lastMovePersistAtMs = now
                        hasPendingMove = false
                        onMoved(normX, normY)
                    }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                if (pointerId == activePointerId) {
                    activePointerId = MotionEvent.INVALID_POINTER_ID
                    flushPendingMove()
                    if (!movedBeyondSlop) {
                        performClick()
                        onSelectedForPlacement()
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePointerId = MotionEvent.INVALID_POINTER_ID
                flushPendingMove()
                if (event.actionMasked == MotionEvent.ACTION_UP && !movedBeyondSlop) {
                    performClick()
                    onSelectedForPlacement()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()
}

/**
 * Live Asymmetric X/Y Aim Booster Pad (Kernel Slot-8, slotOffset = 1).
 * - Unlocked: draggable rounded glass pad positioned wherever the user places their aiming thumb.
 * - Locked: semi-transparent, intercepts drags inside the small pad and injects deadzone-filtered,
 *   EMA-smoothed, asymmetrically X/Y-amplified deltas through Kernel Slot-8 at an anchor coordinate
 *   guaranteed OUTSIDE the pad's bounds (preventing self-feedback loops and preserving 10-finger concurrence).
 */
private class TouchAimBoosterPadView(
    context: Context,
    accentColor: Int,
    private val serviceScope: CoroutineScope,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val getDisplayRotation: () -> Int,
    private val readWindowParams: () -> WindowManager.LayoutParams?,
    private val onUpdateLayout: (WindowManager.LayoutParams) -> Unit,
    private val onMoved: (Float, Float) -> Unit
) : View(context) {

    private var config = TouchConfig()
    private var accent = accentColor

    private var activePointerId = MotionEvent.INVALID_POINTER_ID
    private var isTouchingAim = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var startParamX = 0
    private var startParamY = 0
    private var movedBeyondSlop = false
    private var lastMovePersistAtMs = 0L
    private var pendingNormX = 0f
    private var pendingNormY = 0f
    private var hasPendingMove = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()

    // Asymmetric injection state (Kernel Slot-8)
    private var downTimeMs = 0L
    private var injectX = 0f
    private var injectY = 0f
    private var emaDx = 0f
    private var emaDy = 0f
    private var lastDispatchMs = 0L
    private var moveJob: Job? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(0, 229, 255)
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun updateConfig(newConfig: TouchConfig, accentColor: Int) {
        val wasLocked = config.aimPadLocked
        config = newConfig
        accent = accentColor
        if (wasLocked && !newConfig.aimPadLocked) {
            cancelActiveInjection()
        }
        alpha = if (newConfig.aimPadLocked) {
            if (isTouchingAim) 0.50f else 0.30f
        } else {
            0.94f
        }
        invalidate()
    }

    fun cancelActiveInjection() {
        moveJob?.cancel()
        moveJob = null
        if (isTouchingAim) {
            isTouchingAim = false
            val finalX = injectX
            val finalY = injectY
            val dt = downTimeMs
            val (w, h) = getScreenSize()
            val rot = getDisplayRotation()
            serviceScope.launch(Dispatchers.IO + NonCancellable) {
                ShizukuBridge.injectMotion(
                    MotionEvent.ACTION_UP,
                    finalX,
                    finalY,
                    dt,
                    MacroInjectionMode.SMART_POINTER,
                    w,
                    h,
                    rot,
                    1
                )
            }
        }
        activePointerId = MotionEvent.INVALID_POINTER_ID
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val pad = 2f * density
        val radius = 16f * density
        rect.set(pad, pad, width - pad, height - pad)

        bgPaint.color = if (isTouchingAim) {
            android.graphics.Color.argb(120, 0, 229, 255)
        } else if (config.aimPadLocked) {
            android.graphics.Color.argb(82, 11, 14, 20)
        } else {
            android.graphics.Color.argb(175, 14, 17, 23)
        }
        canvas.drawRoundRect(rect, radius, radius, bgPaint)

        borderPaint.strokeWidth = if (config.aimPadLocked) 1.5f * density else 2.2f * density
        borderPaint.color = when {
            isTouchingAim -> android.graphics.Color.rgb(46, 213, 115)
            config.aimPadLocked -> android.graphics.Color.argb(190, 0, 229, 255)
            else -> accent
        }
        canvas.drawRoundRect(rect, radius, radius, borderPaint)

        val cx = width / 2f
        val cy = height / 2f
        titlePaint.textSize = 11f * density
        subPaint.textSize = 10f * density
        val header = if (config.aimPadLocked) "AIM X/Y" else "GESER PAD"
        val sub = "X ${"%.2fx".format(config.gainX())} • Y ${"%.2fx".format(config.gainY())}"
        canvas.drawText(header, cx, cy - 4f * density, titlePaint)
        canvas.drawText(sub, cx, cy + 12f * density, subPaint)
    }

    private fun computeSafeAnchorOutsidePad(
        p: WindowManager.LayoutParams,
        screenW: Int,
        screenH: Int
    ): Pair<Float, Float> {
        val padCenterX = p.x + width / 2f
        val marginPx = 48f * resources.displayMetrics.density
        val candidateX = if (padCenterX >= screenW * 0.5f) {
            (p.x - marginPx - width * 0.5f).coerceIn(screenW * 0.14f, (p.x - 24f).coerceAtLeast(screenW * 0.14f))
        } else {
            (p.x + width + marginPx + width * 0.5f).coerceIn((p.x + width + 24f).coerceAtMost(screenW * 0.86f), screenW * 0.86f)
        }
        val safeY = (p.y + height / 2f).coerceIn(screenH * 0.18f, screenH * 0.82f)
        return candidateX to safeY
    }

    private fun flushPendingMove() {
        if (hasPendingMove) {
            hasPendingMove = false
            onMoved(pendingNormX, pendingNormY)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val p = readWindowParams() ?: return super.onTouchEvent(event)
        if (config.aimPadLocked) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activePointerId = event.getPointerId(0)
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    val (screenW, screenH) = getScreenSize()
                    val (ax, ay) = computeSafeAnchorOutsidePad(p, screenW, screenH)
                    injectX = ax
                    injectY = ay
                    emaDx = 0f
                    emaDy = 0f
                    downTimeMs = SystemClock.uptimeMillis()
                    lastDispatchMs = 0L
                    isTouchingAim = true
                    alpha = 0.50f
                    invalidate()
                    val rot = getDisplayRotation()
                    serviceScope.launch(Dispatchers.IO) {
                        ShizukuBridge.injectMotion(
                            MotionEvent.ACTION_DOWN,
                            ax,
                            ay,
                            downTimeMs,
                            MacroInjectionMode.SMART_POINTER,
                            screenW,
                            screenH,
                            rot,
                            1
                        )
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val idx = event.findPointerIndex(activePointerId)
                    if (idx < 0 || !isTouchingAim) return true
                    val rawDx = event.rawX - lastRawX
                    val rawDy = event.rawY - lastRawY
                    lastRawX = event.rawX
                    lastRawY = event.rawY

                    val density = resources.displayMetrics.density
                    val deadzonePx = config.deadzone * 0.30f * density
                    val dist = hypot(rawDx.toDouble(), rawDy.toDouble()).toFloat()
                    if (dist < deadzonePx) return true

                    val smoothAlpha = (1f - config.smoothing * 0.007f).coerceIn(0.28f, 1f)
                    emaDx = emaDx * (1f - smoothAlpha) + rawDx * smoothAlpha
                    emaDy = emaDy * (1f - smoothAlpha) + rawDy * smoothAlpha

                    val (screenW, screenH) = getScreenSize()
                    injectX = (injectX + emaDx * config.gainX()).coerceIn(20f, (screenW - 20).coerceAtLeast(20).toFloat())
                    injectY = (injectY + emaDy * config.gainY()).coerceIn(20f, (screenH - 20).coerceAtLeast(20).toFloat())

                    val now = SystemClock.uptimeMillis()
                    if (now - lastDispatchMs >= 8L && (moveJob == null || moveJob?.isCompleted == true)) {
                        lastDispatchMs = now
                        val tx = injectX
                        val ty = injectY
                        val dt = downTimeMs
                        val rot = getDisplayRotation()
                        moveJob = serviceScope.launch(Dispatchers.IO) {
                            ShizukuBridge.injectMotion(
                                MotionEvent.ACTION_MOVE,
                                tx,
                                ty,
                                dt,
                                MacroInjectionMode.SMART_POINTER,
                                screenW,
                                screenH,
                                rot,
                                1
                            )
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    if (event.getPointerId(event.actionIndex) == activePointerId) {
                        cancelActiveInjection()
                        alpha = 0.30f
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    cancelActiveInjection()
                    alpha = 0.30f
                    invalidate()
                    return true
                }
            }
            return true
        }

        // Unlocked: drag pad cleanly across the screen
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                downRawX = event.rawX
                downRawY = event.rawY
                startParamX = p.x
                startParamY = p.y
                movedBeyondSlop = false
                hasPendingMove = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx < 0) return false
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!movedBeyondSlop && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    movedBeyondSlop = true
                }
                if (movedBeyondSlop) {
                    val (w, h) = getScreenSize()
                    p.x = (startParamX + dx.roundToInt()).coerceIn(0, (w - width).coerceAtLeast(0))
                    p.y = (startParamY + dy.roundToInt()).coerceIn(0, (h - height).coerceAtLeast(0))
                    onUpdateLayout(p)
                    val normX = ((p.x + width / 2f) / w.toFloat().coerceAtLeast(1f)).coerceIn(0.08f, 0.92f)
                    val normY = ((p.y + height / 2f) / h.toFloat().coerceAtLeast(1f)).coerceIn(0.08f, 0.92f)
                    pendingNormX = normX
                    pendingNormY = normY
                    hasPendingMove = true
                    val now = SystemClock.uptimeMillis()
                    if (now - lastMovePersistAtMs >= 120L) {
                        lastMovePersistAtMs = now
                        hasPendingMove = false
                        onMoved(normX, normY)
                    }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePointerId = MotionEvent.INVALID_POINTER_ID
                flushPendingMove()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()
}
