package com.example.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Step 1: Full-screen Enemy Crop Selector ("Crop Musuh"):
 * - Translucent dark scrim outside the crop frame so the game enemy stays sharp inside.
 * - Crisp white border + thick white L-corner brackets matching RedMagic's cropper.
 * - Maps normalized (0..1) coordinates strictly against physical screen bounds via getLocationOnScreen()
 *   so notches, status bars, or cutouts never offset the captured enemy template.
 */
class AiCropBoxOverlayView(
    context: Context,
    initialLeftNorm: Float,
    initialTopNorm: Float,
    initialRightNorm: Float,
    initialBottomNorm: Float,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val onRectChanged: (leftNorm: Float, topNorm: Float, rightNorm: Float, bottomNorm: Float, wPx: Int, hPx: Int) -> Unit
) : View(context) {

    private var normLeft = initialLeftNorm.coerceIn(0.05f, 0.80f)
    private var normTop = initialTopNorm.coerceIn(0.05f, 0.80f)
    private var normRight = initialRightNorm.coerceIn(normLeft + 0.06f, 0.95f)
    private var normBottom = initialBottomNorm.coerceIn(normTop + 0.06f, 0.95f)

    private enum class DragHandle {
        NONE, MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
    }

    private var activeHandle = DragHandle.NONE
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private val locOnScreen = IntArray(2)
    private val density = resources.displayMetrics.density

    private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(132, 6, 8, 12)
        style = Paint.Style.FILL
    }
    private val scrimPath = Path().apply {
        fillType = Path.FillType.EVEN_ODD
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(72, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 0.9f * density
        pathEffect = DashPathEffect(floatArrayOf(6f * density, 6f * density), 0f)
    }
    private val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.SQUARE
        strokeJoin = Paint.Join.MITER
        strokeWidth = 3.8f * density
    }
    private val labelBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 14, 16, 22)
        style = Paint.Style.FILL
    }
    private val labelTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10.5f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val cropRect = RectF()
    private val labelRect = RectF()

    fun getNormalizedRect(): FloatArray = floatArrayOf(normLeft, normTop, normRight, normBottom)

    private fun screenMetrics(): Triple<Int, Int, Pair<Float, Float>> {
        val (sw, sh) = getScreenSize()
        getLocationOnScreen(locOnScreen)
        val safeW = sw.coerceAtLeast(width.coerceAtLeast(1))
        val safeH = sh.coerceAtLeast(height.coerceAtLeast(1))
        return Triple(safeW, safeH, locOnScreen[0].toFloat() to locOnScreen[1].toFloat())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        emitRect()
    }

    private fun emitRect() {
        val (sw, sh) = getScreenSize()
        val w = sw.coerceAtLeast(width.coerceAtLeast(1))
        val h = sh.coerceAtLeast(height.coerceAtLeast(1))
        val wPx = ((normRight - normLeft) * w).roundToInt().coerceAtLeast(1)
        val hPx = ((normBottom - normTop) * h).roundToInt().coerceAtLeast(1)
        onRectChanged(normLeft, normTop, normRight, normBottom, wPx, hPx)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return

        val (sw, sh, origin) = screenMetrics()
        val ox = origin.first
        val oy = origin.second

        val l = (normLeft * sw - ox).coerceIn(0f, vw)
        val t = (normTop * sh - oy).coerceIn(0f, vh)
        val r = (normRight * sw - ox).coerceIn(l + 8f, vw)
        val b = (normBottom * sh - oy).coerceIn(t + 8f, vh)
        cropRect.set(l, t, r, b)

        scrimPath.reset()
        scrimPath.addRect(0f, 0f, vw, vh, Path.Direction.CW)
        scrimPath.addRect(cropRect, Path.Direction.CCW)
        canvas.drawPath(scrimPath, scrimPaint)

        canvas.drawRect(cropRect, borderPaint)
        val thirdW = cropRect.width() / 3f
        val thirdH = cropRect.height() / 3f
        canvas.drawLine(l + thirdW, t, l + thirdW, b, gridPaint)
        canvas.drawLine(l + 2f * thirdW, t, l + 2f * thirdW, b, gridPaint)
        canvas.drawLine(l, t + thirdH, r, t + thirdH, gridPaint)
        canvas.drawLine(l, t + 2f * thirdH, r, t + 2f * thirdH, gridPaint)

        val arm = min(20f * density, min(cropRect.width(), cropRect.height()) * 0.42f)
        canvas.drawLine(l, t + arm, l, t, bracketPaint)
        canvas.drawLine(l, t, l + arm, t, bracketPaint)
        canvas.drawLine(r - arm, t, r, t, bracketPaint)
        canvas.drawLine(r, t, r, t + arm, bracketPaint)
        canvas.drawLine(l, b - arm, l, b, bracketPaint)
        canvas.drawLine(l, b, l + arm, b, bracketPaint)
        canvas.drawLine(r - arm, b, r, b, bracketPaint)
        canvas.drawLine(r, b - arm, r, b, bracketPaint)

        val dimText = "MUSUH • ${cropRect.width().roundToInt()} x ${cropRect.height().roundToInt()} px"
        val badgeW = (labelTextPaint.measureText(dimText) + 20f * density).coerceAtLeast(112f * density)
        val badgeH = 22f * density
        val cx = cropRect.centerX().coerceIn(badgeW / 2f + 8f, vw - badgeW / 2f - 8f)
        val badgeTop = if (b + badgeH + 10f * density < vh) b + 8f * density else (t - badgeH - 8f * density).coerceAtLeast(8f)
        labelRect.set(cx - badgeW / 2f, badgeTop, cx + badgeW / 2f, badgeTop + badgeH)
        canvas.drawRoundRect(labelRect, 11f * density, 11f * density, labelBgPaint)
        canvas.drawText(dimText, cx, badgeTop + badgeH * 0.68f, labelTextPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val (sw, sh, origin) = screenMetrics()
        val ox = origin.first
        val oy = origin.second
        val fsw = sw.toFloat().coerceAtLeast(1f)
        val fsh = sh.toFloat().coerceAtLeast(1f)

        val l = normLeft * fsw
        val t = normTop * fsh
        val r = normRight * fsw
        val b = normBottom * fsh
        val minBoxPx = (10f * density).coerceAtLeast(20f)
        val boxW = (r - l).coerceAtLeast(minBoxPx)
        val boxH = (b - t).coerceAtLeast(minBoxPx)
        val cornerRadius = min(28f * density, max(12f * density, min(boxW, boxH) * 0.36f))

        val sx = ox + event.x
        val sy = oy + event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = sx
                lastTouchY = sy
                val dTL = hypot((sx - l).toDouble(), (sy - t).toDouble())
                val dTR = hypot((sx - r).toDouble(), (sy - t).toDouble())
                val dBL = hypot((sx - l).toDouble(), (sy - b).toDouble())
                val dBR = hypot((sx - r).toDouble(), (sy - b).toDouble())
                val minCornerDist = min(min(dTL, dTR), min(dBL, dBR))
                val innerPadX = (boxW * 0.24f).coerceAtLeast(4f)
                val innerPadY = (boxH * 0.24f).coerceAtLeast(4f)
                val insideCenter = sx in (l + innerPadX)..(r - innerPadX) &&
                    sy in (t + innerPadY)..(b - innerPadY)

                activeHandle = when {
                    !insideCenter && minCornerDist <= cornerRadius -> when (minCornerDist) {
                        dTL -> DragHandle.TOP_LEFT
                        dTR -> DragHandle.TOP_RIGHT
                        dBL -> DragHandle.BOTTOM_LEFT
                        else -> DragHandle.BOTTOM_RIGHT
                    }
                    sx in (l - 14f)..(r + 14f) && sy in (t - 14f)..(b + 14f) -> DragHandle.MOVE
                    else -> DragHandle.NONE
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (activeHandle == DragHandle.NONE) return true
                val dx = sx - lastTouchX
                val dy = sy - lastTouchY
                lastTouchY = sy
                lastTouchX = sx

                var nl = l
                var nt = t
                var nr = r
                var nb = b

                when (activeHandle) {
                    DragHandle.MOVE -> {
                        val bw = nr - nl
                        val bh = nb - nt
                        nl = (nl + dx).coerceIn(0f, max(0f, fsw - bw))
                        nt = (nt + dy).coerceIn(0f, max(0f, fsh - bh))
                        nr = nl + bw
                        nb = nt + bh
                    }
                    DragHandle.TOP_LEFT -> {
                        nl = (nl + dx).coerceIn(0f, nr - minBoxPx)
                        nt = (nt + dy).coerceIn(0f, nb - minBoxPx)
                    }
                    DragHandle.TOP_RIGHT -> {
                        nr = (nr + dx).coerceIn(nl + minBoxPx, fsw)
                        nt = (nt + dy).coerceIn(0f, nb - minBoxPx)
                    }
                    DragHandle.BOTTOM_LEFT -> {
                        nl = (nl + dx).coerceIn(0f, nr - minBoxPx)
                        nb = (nb + dy).coerceIn(nt + minBoxPx, fsh)
                    }
                    DragHandle.BOTTOM_RIGHT -> {
                        nr = (nr + dx).coerceIn(nl + minBoxPx, fsw)
                        nb = (nb + dy).coerceIn(nt + minBoxPx, fsh)
                    }
                    DragHandle.NONE -> Unit
                }

                normLeft = (nl / fsw).coerceIn(0f, 0.96f)
                normTop = (nt / fsh).coerceIn(0f, 0.96f)
                normRight = (nr / fsw).coerceIn(normLeft + 0.02f, 1f)
                normBottom = (nb / fsh).coerceIn(normTop + 0.02f, 1f)
                emitRect()
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeHandle = DragHandle.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()
}

/**
 * Step 2: Center Head-Aim Alignment Picker ("Luruskan Aim Tambahan ke Kepala Musuh"):
 * - Displays an enlarged, crisp preview of the cropped enemy right in the middle of the screen.
 * - Lets the user drag the glowing Red `AIM KEPALA` dot directly onto the enemy's head
 *   (`headOffsetXPercent`, `headOffsetYPercent`).
 * - Draws the Cyan `CROSSHAIR TENGAH` reticle and a neon green alignment vector connecting
 *   CROSSHAIR -> AIM KEPALA so users verify how center game crosshair tracks the enemy's head.
 */
class AiTargetPickerOverlayView(
    context: Context,
    private val templateBitmap: Bitmap?,
    initialHeadOffsetXPercent: Int,
    initialHeadOffsetYPercent: Int,
    initialCrosshairNormX: Float,
    initialCrosshairNormY: Float,
    private val contactRadiusPercent: Int,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val onPointsChanged: (
        headXPercent: Int,
        headYPercent: Int,
        crossX: Float,
        crossY: Float
    ) -> Unit
) : View(context) {

    var headOffsetXPercent = initialHeadOffsetXPercent.coerceIn(10, 90)
        private set
    var headOffsetYPercent = initialHeadOffsetYPercent.coerceIn(5, 55)
        private set
    var gameCrosshairNormX = initialCrosshairNormX.coerceIn(0.15f, 0.85f)
        private set
    var gameCrosshairNormY = initialCrosshairNormY.coerceIn(0.15f, 0.85f)
        private set

    private enum class Handle {
        NONE, HEAD_AIM, GAME_CROSSHAIR
    }

    private var activeHandle = Handle.NONE
    private val locOnScreen = IntArray(2)
    private val density = resources.displayMetrics.density
    private val previewRect = RectF()
    private val srcRect = Rect()
    private val badgeRect = RectF()

    private val veilPaint = Paint().apply {
        color = Color.argb(128, 6, 8, 12)
    }
    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(228, 12, 16, 22)
        style = Paint.Style.FILL
    }
    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(56, 245, 156)
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val alignVectorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(56, 245, 156)
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
        pathEffect = DashPathEffect(floatArrayOf(6f * density, 4f * density), 0f)
    }
    private val redHairlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 255, 59, 48)
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }
    private val redHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(72, 255, 59, 48)
        style = Paint.Style.FILL
    }
    private val redOuterRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 255, 82, 72)
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
    }
    private val redCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 45, 58)
        style = Paint.Style.FILL
    }
    private val whiteInnerStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val crosshairZonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(145, 0, 229, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
        pathEffect = DashPathEffect(floatArrayOf(6f * density, 5f * density), 0f)
    }
    private val crosshairRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
    }
    private val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 12, 14, 20)
        style = Paint.Style.FILL
    }
    private val coordTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val subLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255)
        textSize = 9.5f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun resetCrosshairToCenter() {
        gameCrosshairNormX = 0.50f
        gameCrosshairNormY = 0.50f
        headOffsetXPercent = 50
        headOffsetYPercent = 18
        emitPoints()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        emitPoints()
    }

    private fun emitPoints() {
        onPointsChanged(
            headOffsetXPercent,
            headOffsetYPercent,
            gameCrosshairNormX,
            gameCrosshairNormY
        )
    }

    private fun computePreviewRect(chX: Float, chY: Float, vw: Float, vh: Float): RectF {
        val aspect = if (templateBitmap != null && templateBitmap.width > 0 && templateBitmap.height > 0) {
            (templateBitmap.width.toFloat() / templateBitmap.height.toFloat()).coerceIn(0.32f, 1.45f)
        } else {
            0.48f
        }
        val targetH = min(vh * 0.56f, 220f * density).coerceAtLeast(140f * density)
        val targetW = (targetH * aspect).coerceIn(96f * density, min(vw * 0.44f, 240f * density))
        val l = (chX - targetW / 2f).coerceIn(16f * density, max(16f * density, vw - targetW - 16f * density))
        val t = (chY - targetH / 2f).coerceIn(58f * density, max(58f * density, vh - targetH - 48f * density))
        previewRect.set(l, t, l + targetW, t + targetH)
        return previewRect
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return

        val (sw, sh) = getScreenSize()
        getLocationOnScreen(locOnScreen)
        val safeW = sw.coerceAtLeast(width.coerceAtLeast(1)).toFloat()
        val safeH = sh.coerceAtLeast(height.coerceAtLeast(1)).toFloat()
        val ox = locOnScreen[0].toFloat()
        val oy = locOnScreen[1].toFloat()

        val chX = (gameCrosshairNormX * safeW - ox).coerceIn(0f, vw)
        val chY = (gameCrosshairNormY * safeH - oy).coerceIn(0f, vh)
        val rect = computePreviewRect(chX, chY, vw, vh)

        canvas.drawRect(0f, 0f, vw, vh, veilPaint)

        // 1. Centered Cropped Enemy Ghost Card
        canvas.drawRoundRect(rect, 10f * density, 10f * density, cardBgPaint)
        if (templateBitmap != null && !templateBitmap.isRecycled) {
            srcRect.set(0, 0, templateBitmap.width, templateBitmap.height)
            canvas.drawBitmap(templateBitmap, srcRect, rect, bitmapPaint)
        }
        canvas.drawRoundRect(rect, 10f * density, 10f * density, cardBorderPaint)

        // 2. Center Game Crosshair Reticle (Cyan)
        val contactZoneR = (min(safeW, safeH) * (0.04f + contactRadiusPercent * 0.0012f)).coerceIn(18f * density, 48f * density)
        canvas.drawCircle(chX, chY, contactZoneR, crosshairZonePaint)
        val chR = 9f * density
        canvas.drawCircle(chX, chY, chR, crosshairRingPaint)
        canvas.drawLine(chX - chR * 1.4f, chY, chX + chR * 1.4f, chY, crosshairRingPaint)
        canvas.drawLine(chX, chY - chR * 1.4f, chX, chY + chR * 1.4f, crosshairRingPaint)

        // 3. Draggable Red AIM KEPALA dot inside cropped enemy + alignment line
        val headX = rect.left + rect.width() * (headOffsetXPercent / 100f)
        val headY = rect.top + rect.height() * (headOffsetYPercent / 100f)

        canvas.drawLine(chX, chY, headX, headY, alignVectorPaint)
        canvas.drawLine(0f, headY, vw, headY, redHairlinePaint)
        canvas.drawLine(headX, 0f, headX, vh, redHairlinePaint)

        canvas.drawCircle(headX, headY, 21f * density, redHaloPaint)
        canvas.drawCircle(headX, headY, 15f * density, redOuterRingPaint)
        canvas.drawCircle(headX, headY, 8f * density, redCorePaint)
        canvas.drawCircle(headX, headY, 8f * density, whiteInnerStrokePaint)

        drawPillLabel(
            canvas = canvas,
            cx = headX,
            bottomY = min(rect.top - 8f * density, headY - 22f * density),
            text = "AIM KEPALA ($headOffsetXPercent%, $headOffsetYPercent%)",
            paint = coordTextPaint,
            vw = vw
        )
        drawPillLabel(
            canvas = canvas,
            cx = rect.centerX(),
            bottomY = rect.bottom + 24f * density,
            text = "CROSSHAIR TENGAH",
            paint = subLabelPaint,
            vw = vw
        )
    }

    private fun drawPillLabel(
        canvas: Canvas,
        cx: Float,
        bottomY: Float,
        text: String,
        paint: Paint,
        vw: Float
    ) {
        val tw = paint.measureText(text)
        val bw = tw + 16f * density
        val bh = 20f * density
        val clampedCx = cx.coerceIn(bw / 2f + 6f, vw - bw / 2f - 6f)
        val topY = (bottomY - bh).coerceAtLeast(8f)
        badgeRect.set(clampedCx - bw / 2f, topY, clampedCx + bw / 2f, topY + bh)
        canvas.drawRoundRect(badgeRect, 10f * density, 10f * density, pillPaint)
        canvas.drawText(text, clampedCx, topY + bh * 0.70f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val vw = width.toFloat().coerceAtLeast(1f)
        val vh = height.toFloat().coerceAtLeast(1f)
        val (sw, sh) = getScreenSize()
        getLocationOnScreen(locOnScreen)
        val safeW = sw.coerceAtLeast(width.coerceAtLeast(1)).toFloat()
        val safeH = sh.coerceAtLeast(height.coerceAtLeast(1)).toFloat()
        val ox = locOnScreen[0].toFloat()
        val oy = locOnScreen[1].toFloat()

        val chX = (gameCrosshairNormX * safeW - ox).coerceIn(0f, vw)
        val chY = (gameCrosshairNormY * safeH - oy).coerceIn(0f, vh)
        val rect = computePreviewRect(chX, chY, vw, vh)
        val lx = event.x
        val ly = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val headX = rect.left + rect.width() * (headOffsetXPercent / 100f)
                val headY = rect.top + rect.height() * (headOffsetYPercent / 100f)
                val dHead = hypot((lx - headX).toDouble(), (ly - headY).toDouble())
                val dCross = hypot((lx - chX).toDouble(), (ly - chY).toDouble())
                val insidePreview = lx in (rect.left - 28f * density)..(rect.right + 28f * density) &&
                    ly in (rect.top - 28f * density)..(rect.bottom + 28f * density)

                activeHandle = when {
                    insidePreview || dHead <= dCross -> Handle.HEAD_AIM
                    dCross <= 44f * density -> Handle.GAME_CROSSHAIR
                    else -> Handle.HEAD_AIM
                }
                moveActiveHandle(lx, ly, rect, ox, oy, safeW, safeH)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                moveActiveHandle(lx, ly, rect, ox, oy, safeW, safeH)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeHandle = Handle.NONE
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun moveActiveHandle(
        lx: Float,
        ly: Float,
        rect: RectF,
        ox: Float,
        oy: Float,
        safeW: Float,
        safeH: Float
    ) {
        when (activeHandle) {
            Handle.HEAD_AIM -> {
                val xFrac = ((lx - rect.left) / rect.width().coerceAtLeast(1f)).coerceIn(0.10f, 0.90f)
                val yFrac = ((ly - rect.top) / rect.height().coerceAtLeast(1f)).coerceIn(0.05f, 0.55f)
                headOffsetXPercent = (xFrac * 100f).roundToInt().coerceIn(10, 90)
                headOffsetYPercent = (yFrac * 100f).roundToInt().coerceIn(5, 55)
            }
            Handle.GAME_CROSSHAIR -> {
                gameCrosshairNormX = ((lx + ox) / safeW).coerceIn(0.15f, 0.85f)
                gameCrosshairNormY = ((ly + oy) / safeH).coerceIn(0.15f, 0.85f)
            }
            Handle.NONE -> return
        }
        emitPoints()
        invalidate()
    }

    override fun performClick(): Boolean = super.performClick()
}

/**
 * Pass-through live AI Trigger HUD rendered while scanning in-game:
 * - Shows subtle crosshair contact reticle at `(crosshairNormX, crosshairNormY)`.
 * - Highlights detected enemy body box (`matchedLeftNorm..matchedBottomNorm`).
 * - Lights up neon green + crimson HEAD target dot and snap vector from center crosshair to head!
 */
class AiTriggerCrosshairView(
    context: Context,
    private val getScreenSize: () -> Pair<Int, Int>
) : View(context) {

    private var crosshairNormX = 0.50f
    private var crosshairNormY = 0.50f
    private var contactRadiusPct = 28
    private var isMatched = false
    private var crosshairTouchingBody = false
    private var isAimingToHead = false
    private var bodyLeftNorm = 0.44f
    private var bodyTopNorm = 0.36f
    private var bodyRightNorm = 0.56f
    private var bodyBottomNorm = 0.64f
    private var headNormX = 0.50f
    private var headNormY = 0.42f
    private var scorePercent = 0

    private val density = resources.displayMetrics.density
    private val locOnScreen = IntArray(2)
    private val bodyRect = RectF()

    private val idleColor = Color.rgb(0, 229, 255)
    private val detectColor = Color.rgb(255, 198, 64)
    private val headLockColor = Color.rgb(56, 245, 156)
    private val headDotColor = Color.rgb(255, 59, 48)

    private val reticlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
    }
    private val contactCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * density
        pathEffect = DashPathEffect(floatArrayOf(5f * density, 5f * density), 0f)
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val bodyBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
    }
    private val snapLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = headLockColor
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * density
        pathEffect = DashPathEffect(floatArrayOf(7f * density, 5f * density), 0f)
    }
    private val headRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * density
    }
    private val statusTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9.5f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun updateTrackingState(
        crossNormX: Float,
        crossNormY: Float,
        contactRadiusPercent: Int,
        matched: Boolean,
        touchingBody: Boolean,
        aimingHead: Boolean,
        leftNorm: Float,
        topNorm: Float,
        rightNorm: Float,
        bottomNorm: Float,
        headX: Float,
        headY: Float,
        score: Int
    ) {
        if (this.crosshairNormX == crossNormX &&
            this.crosshairNormY == crossNormY &&
            this.contactRadiusPct == contactRadiusPercent &&
            this.isMatched == matched &&
            this.crosshairTouchingBody == touchingBody &&
            this.isAimingToHead == aimingHead &&
            this.bodyLeftNorm == leftNorm &&
            this.bodyTopNorm == topNorm &&
            this.bodyRightNorm == rightNorm &&
            this.bodyBottomNorm == bottomNorm &&
            this.headNormX == headX &&
            this.headNormY == headY &&
            this.scorePercent == score
        ) {
            return
        }
        this.crosshairNormX = crossNormX
        this.crosshairNormY = crossNormY
        this.contactRadiusPct = contactRadiusPercent
        this.isMatched = matched
        this.crosshairTouchingBody = touchingBody
        this.isAimingToHead = aimingHead
        this.bodyLeftNorm = leftNorm
        this.bodyTopNorm = topNorm
        this.bodyRightNorm = rightNorm
        this.bodyBottomNorm = bottomNorm
        this.headNormX = headX
        this.headNormY = headY
        this.scorePercent = score
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return

        val (sw, sh) = getScreenSize()
        getLocationOnScreen(locOnScreen)
        val safeW = sw.coerceAtLeast(width.coerceAtLeast(1)).toFloat()
        val safeH = sh.coerceAtLeast(height.coerceAtLeast(1)).toFloat()
        val ox = locOnScreen[0].toFloat()
        val oy = locOnScreen[1].toFloat()

        val chX = (crosshairNormX * safeW - ox).coerceIn(0f, vw)
        val chY = (crosshairNormY * safeH - oy).coerceIn(0f, vh)

        val activeColor = when {
            crosshairTouchingBody || isAimingToHead -> headLockColor
            isMatched -> detectColor
            else -> idleColor
        }

        val contactR = (min(safeW, safeH) * (0.032f + contactRadiusPct * 0.0012f)).coerceIn(14f * density, 46f * density)
        contactCirclePaint.color = activeColor
        contactCirclePaint.alpha = if (crosshairTouchingBody || isAimingToHead) 225 else 115
        canvas.drawCircle(chX, chY, contactR, contactCirclePaint)

        reticlePaint.color = activeColor
        dotPaint.color = activeColor
        val tick = 14f * density
        val gap = 5f * density
        canvas.drawLine(chX - tick, chY, chX - gap, chY, reticlePaint)
        canvas.drawLine(chX + gap, chY, chX + tick, chY, reticlePaint)
        canvas.drawLine(chX, chY - tick, chX, chY - gap, reticlePaint)
        canvas.drawLine(chX, chY + gap, chX, chY + tick, reticlePaint)
        canvas.drawCircle(chX, chY, 2.2f * density, dotPaint)

        if (isMatched || isAimingToHead) {
            val l = (bodyLeftNorm * safeW - ox).coerceIn(2f, vw - 2f)
            val t = (bodyTopNorm * safeH - oy).coerceIn(2f, vh - 2f)
            val r = (bodyRightNorm * safeW - ox).coerceIn(l + 8f, vw - 2f)
            val b = (bodyBottomNorm * safeH - oy).coerceIn(t + 8f, vh - 2f)
            bodyRect.set(l, t, r, b)

            bodyBoxPaint.color = if (crosshairTouchingBody || isAimingToHead) headLockColor else detectColor
            canvas.drawRoundRect(bodyRect, 6f * density, 6f * density, bodyBoxPaint)

            val hx = (headNormX * safeW - ox).coerceIn(2f, vw - 2f)
            val hy = (headNormY * safeH - oy).coerceIn(2f, vh - 2f)
            if (crosshairTouchingBody || isAimingToHead) {
                canvas.drawLine(chX, chY, hx, hy, snapLinePaint)
                dotPaint.color = headDotColor
                canvas.drawCircle(hx, hy, 5.5f * density, dotPaint)
                canvas.drawCircle(hx, hy, 5.5f * density, headRingPaint)
            } else {
                dotPaint.color = detectColor
                canvas.drawCircle(hx, hy, 3.5f * density, dotPaint)
            }

            statusTextPaint.color = if (crosshairTouchingBody || isAimingToHead) headLockColor else detectColor
            val label = when {
                isAimingToHead || crosshairTouchingBody -> "LOCK KEPALA $scorePercent%"
                else -> "MUSUH $scorePercent%"
            }
            canvas.drawText(label, bodyRect.centerX(), (t - 6f * density).coerceAtLeast(14f), statusTextPaint)
        }
    }
}
