package com.example.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.AiTriggerCaptureManager
import com.example.core.AiTriggerEngine
import com.example.data.BoosterPreferences

/**
 * Dedicated Foreground Service with foregroundServiceType="mediaProjection" (Android 14+ compliant).
 * Only started AFTER ScreenCapturePermissionActivity obtains a valid MediaProjection consent token.
 */
class AiTriggerProjectionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                AiTriggerCaptureManager.stopProjection()
                isRunning = false
                stopSelfCleanly()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                AiTriggerCaptureManager.awaitingConsentPrompt = false

                // MUST satisfy startForeground() before returning if started via startForegroundService(),
                // AND must run with FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION before getMediaProjection().
                val fgStarted = startProjectionForegroundSafe()
                if (!fgStarted) {
                    isRunning = false
                    AiTriggerEngine.reportCaptureError("Gagal memulai layanan rekam layar (izin FGS ditolak sistem).")
                    stopSelfCleanly()
                    return START_NOT_STICKY
                }

                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    runCatching { intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) }.getOrNull()
                } else {
                    @Suppress("DEPRECATION")
                    runCatching { intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA) }.getOrNull()
                }

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    isRunning = false
                    AiTriggerEngine.reportCaptureError("Token izin rekam layar tidak valid atau kedaluwarsa.")
                    stopSelfCleanly()
                    return START_NOT_STICKY
                }

                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                if (mpm == null) {
                    isRunning = false
                    AiTriggerEngine.reportCaptureError("MediaProjectionManager tidak tersedia di perangkat ini.")
                    stopSelfCleanly()
                    return START_NOT_STICKY
                }

                val projection = runCatching { mpm.getMediaProjection(resultCode, resultData) }.getOrNull()
                if (projection == null) {
                    isRunning = false
                    AiTriggerEngine.reportCaptureError("Sesi rekam layar gagal dibuka. Ketuk Izinkan Rekam Layar lagi.")
                    stopSelfCleanly()
                    return START_NOT_STICKY
                }

                val attached = AiTriggerCaptureManager.attachProjection(this, projection)
                if (!attached) {
                    isRunning = false
                    val reason = AiTriggerCaptureManager.lastCaptureError
                        ?: "Gagal membuat VirtualDisplay rekam layar."
                    AiTriggerEngine.reportCaptureError(reason)
                    stopSelfCleanly()
                    return START_NOT_STICKY
                }

                isRunning = true
                AiTriggerEngine.clearCaptureError()
                AiTriggerEngine.syncLoop(
                    applicationContext,
                    BoosterPreferences.getInstance(applicationContext)
                )
                return START_NOT_STICKY
            }
            else -> {
                stopSelfCleanly()
                return START_NOT_STICKY
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        runCatching { AiTriggerCaptureManager.syncOrientationIfNeeded(this) }
    }

    override fun onDestroy() {
        isRunning = false
        AiTriggerCaptureManager.stopProjection()
        super.onDestroy()
    }

    private fun stopSelfCleanly() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        runCatching { stopSelf() }
    }

    private fun startProjectionForegroundSafe(): Boolean {
        return try {
            val channelId = "xa_ai_projection_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(NotificationManager::class.java)
                val channel = NotificationChannel(
                    channelId,
                    getString(R.string.ai_projection_notif_title),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.ai_projection_notif_desc)
                }
                nm?.createNotificationChannel(channel)
            }

            val openAppIntent = PendingIntent.getActivity(
                this, 10,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
            val stopIntent = PendingIntent.getService(
                this, 11,
                Intent(this, AiTriggerProjectionService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )

            val notification: Notification = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_notif_ai)
                .setContentTitle(getString(R.string.ai_projection_notif_title))
                .setContentText(getString(R.string.ai_projection_notif_desc))
                .setOngoing(true)
                .setContentIntent(openAppIntent)
                .addAction(0, "Matikan", stopIntent)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    companion object {
        const val ACTION_START = "com.example.action.AI_PROJECTION_START"
        const val ACTION_STOP = "com.example.action.AI_PROJECTION_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        private const val NOTIFICATION_ID = 7049

        @Volatile
        var isRunning: Boolean = false
            private set

        fun startWithToken(context: Context, resultCode: Int, data: Intent): Boolean {
            val svcIntent = Intent(context, AiTriggerProjectionService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            return runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(svcIntent)
                } else {
                    context.startService(svcIntent)
                }
                true
            }.onFailure {
                AiTriggerEngine.reportCaptureError("Gagal memulai layanan rekam layar: ${it.message ?: it.javaClass.simpleName}")
            }.getOrDefault(false)
        }

        fun stop(context: Context) {
            AiTriggerCaptureManager.stopProjection()
            runCatching {
                context.stopService(Intent(context, AiTriggerProjectionService::class.java))
            }
        }
    }
}
