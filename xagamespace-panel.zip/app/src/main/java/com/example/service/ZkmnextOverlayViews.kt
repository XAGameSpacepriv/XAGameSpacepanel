package com.example.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * ZKMNEXT-inspired AFK Screen Dimmer / Black Screen overlay.
 * Keeps active games alive while dimming OLED pixels to near-black and preventing
 * accidental pocket touches. Double-tap anywhere to unlock cleanly.
 */
class ScreenDimmerOverlayView(
    context: Context,
    private val onRequestUnlock: () -> Unit
) : View(context) {

    private val density = context.resources.displayMetrics.density
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val clockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 240, 244, 250)
        textSize = 44f * density
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 0, 229, 255)
        textSize = 12.5f * density
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.CENTER
    }

    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(165, 195, 204, 218)
        textSize = 11.5f * density
        textAlign = Paint.Align.CENTER
    }

    private var batteryPct = 80
    private var socTempC = 35.0f
    private var lastTapMs = 0L
    private var showSecondTapHint = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            invalidate()
            mainHandler.postDelayed(this, 1000L)
        }
    }

    init {
        setBackgroundColor(Color.argb(238, 4, 6, 9))
        mainHandler.post(clockTick)
    }

    fun updateMetrics(battery: Int, socTemp: Float) {
        if (battery != batteryPct || kotlin.math.abs(socTemp - socTempC) >= 0.4f) {
            batteryPct = battery
            socTempC = socTemp
            invalidate()
        }
    }

    fun stopTicker() {
        mainHandler.removeCallbacks(clockTick)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val now = SystemClock.uptimeMillis()
            if (now - lastTapMs <= 420L) {
                lastTapMs = 0L
                onRequestUnlock()
            } else {
                lastTapMs = now
                showSecondTapHint = true
                invalidate()
            }
            return true
        }
        return true // absorb all accidental touches while AFK dimmed
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val timeStr = timeFormat.format(Date())
        canvas.drawText(timeStr, cx, cy - 16f * density, clockPaint)
        canvas.drawText(
            "AFK MODE • BATERAI $batteryPct% • SoC ${"%.1f".format(socTempC)}°C",
            cx,
            cy + 14f * density,
            infoPaint
        )
        val hint = if (showSecondTapHint) {
            "Ketuk 1x lagi untuk membuka layar"
        } else {
            "Ketuk 2x cepat di mana saja untuk kembali ke game"
        }
        canvas.drawText(hint, cx, cy + 40f * density, hintPaint)
    }
}

/**
 * ZKMNEXT-inspired Pinned Floating Game Note card.
 * Draggable translucent note pill/card over the game. Quick tap toggles expanded/compact view.
 */
class PinnedNoteOverlayView(
    context: Context,
    private val getScreenSize: () -> Pair<Int, Int>,
    private val readParams: () -> WindowManager.LayoutParams?,
    private val onUpdateLayout: (WindowManager.LayoutParams) -> Unit,
    private val onPositionCommitted: (Float, Float) -> Unit
) : View(context) {

    private val density = context.resources.displayMetrics.density
    private val bgRect = RectF()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(212, 16, 19, 25)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.15f * density
        color = Color.argb(170, 0, 229, 255)
    }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255)
        textSize = 9.5f * density
        typeface = Typeface.MONOSPACE
        isFakeBoldText = true
    }
    private val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(235, 240, 248)
        textSize = 10.5f * density
    }

    private var noteText: String = "Catatan Game"
    private var collapsed = false

    private var downRawX = 0f
    private var downRawY = 0f
    private var startParamX = 0
    private var startParamY = 0
    private var dragged = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    fun setAccentColor(colorInt: Int) {
        borderPaint.color = Color.argb(170, Color.red(colorInt), Color.green(colorInt), Color.blue(colorInt))
        titlePaint.color = colorInt
        invalidate()
    }

    fun updateNoteText(text: String) {
        val next = text.trim().ifBlank { "Ketuk panel Alat untuk mengisi catatan..." }
        if (next != noteText) {
            noteText = next
            invalidate()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val p = readParams() ?: return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                startParamX = p.x
                startParamY = p.y
                dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!dragged && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                    dragged = true
                }
                if (dragged) {
                    val (sw, sh) = getScreenSize()
                    p.x = (startParamX + dx.roundToInt()).coerceIn(0, (sw - width).coerceAtLeast(0))
                    p.y = (startParamY + dy.roundToInt()).coerceIn(0, (sh - height).coerceAtLeast(0))
                    onUpdateLayout(p)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragged) {
                    val (sw, sh) = getScreenSize()
                    val nx = (p.x.toFloat() / sw.coerceAtLeast(1)).coerceIn(0.02f, 0.85f)
                    val ny = (p.y.toFloat() / sh.coerceAtLeast(1)).coerceIn(0.05f, 0.85f)
                    onPositionCommitted(nx, ny)
                } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                    collapsed = !collapsed
                    p.height = if (collapsed) (28f * density).roundToInt() else (94f * density).roundToInt()
                    onUpdateLayout(p)
                    invalidate()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        bgRect.set(2f, 2f, width - 2f, height - 2f)
        val r = 10f * density
        canvas.drawRoundRect(bgRect, r, r, bgPaint)
        canvas.drawRoundRect(bgRect, r, r, borderPaint)

        val padH = 9f * density
        val headerY = 16f * density
        val headerLabel = if (collapsed) "NOTES • Ketuk buka" else "NOTES • Ketuk lipat"
        canvas.drawText(headerLabel, padH, headerY, titlePaint)

        if (!collapsed) {
            val contentW = (width - padH * 2f).toInt().coerceAtLeast(40)
            val layout = StaticLayout.Builder
                .obtain(noteText, 0, noteText.length, bodyPaint, contentW)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(4)
                .build()
            canvas.save()
            canvas.translate(padH, 23f * density)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
