package com.example.service

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.data.BoosterPreferences

/**
 * Invisible translucent helper Activity to obtain MediaProjection consent cleanly
 * from either the floating in-game overlay or the Optimizer screen, then immediately start
 * AiTriggerProjectionService and optionally enter Crop mode.
 */
class ScreenCapturePermissionActivity : ComponentActivity() {

    private var openCropOnGrant = false
    private var enableMasterOnGrant = false

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
        val prefs = BoosterPreferences.getInstance(this)
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            val started = AiTriggerProjectionService.startWithToken(this, result.resultCode, data)
            if (enableMasterOnGrant && started) {
                prefs.setAiTriggerMasterEnabled(true)
            }
            if (openCropOnGrant && started) {
                prefs.setOverlayPanelExpanded(false)
                prefs.setAiCropOverlayMode(true)
            }
            onGrantResult?.invoke(started)
        } else {
            onGrantResult?.invoke(false)
        }
        onGrantResult = null
        finishNoAnim()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launchConsentPrompt(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (!promptActive) {
            launchConsentPrompt(intent)
        }
    }

    private fun launchConsentPrompt(sourceIntent: Intent?) {
        openCropOnGrant = sourceIntent?.getBooleanExtra(EXTRA_OPEN_CROP, false) ?: false
        enableMasterOnGrant = sourceIntent?.getBooleanExtra(EXTRA_ENABLE_MASTER, false) ?: false
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (mpm == null) {
            com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
            onGrantResult?.invoke(false)
            onGrantResult = null
            finishNoAnim()
            return
        }

        promptActive = true
        com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = true
        val captureIntent = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            } else {
                mpm.createScreenCaptureIntent()
            }
        }.getOrNull()

        if (captureIntent == null) {
            promptActive = false
            com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
            onGrantResult?.invoke(false)
            onGrantResult = null
            finishNoAnim()
            return
        }

        runCatching {
            captureLauncher.launch(captureIntent)
        }.onFailure {
            promptActive = false
            com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
            onGrantResult?.invoke(false)
            onGrantResult = null
            finishNoAnim()
        }
    }

    private fun finishNoAnim() {
        promptActive = false
        finish()
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
            } else {
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
    }

    override fun onDestroy() {
        promptActive = false
        com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_OPEN_CROP = "extra_open_crop"
        private const val EXTRA_ENABLE_MASTER = "extra_enable_master"

        @Volatile
        private var promptActive = false

        @Volatile
        private var onGrantResult: ((Boolean) -> Unit)? = null

        fun launch(
            context: Context,
            openCropOnGrant: Boolean = false,
            enableMasterOnGrant: Boolean = false,
            callback: ((Boolean) -> Unit)? = null
        ) {
            onGrantResult = callback
            val intent = Intent(context, ScreenCapturePermissionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                putExtra(EXTRA_OPEN_CROP, openCropOnGrant)
                putExtra(EXTRA_ENABLE_MASTER, enableMasterOnGrant)
            }
            runCatching {
                context.startActivity(intent)
            }.onFailure {
                com.example.core.AiTriggerCaptureManager.awaitingConsentPrompt = false
                onGrantResult?.invoke(false)
                onGrantResult = null
            }
        }
    }
}
