package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.MainTab
import com.example.model.SubScreen
import com.example.ui.MainViewModel
import com.example.ui.components.FloatingBottomDock
import com.example.ui.screens.AddGameScreen
import com.example.ui.screens.BurikScreen
import com.example.ui.screens.CompatibilityScreen
import com.example.ui.screens.CompileScreen
import com.example.ui.screens.DebloatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OptimizerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.XAGameSpaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            XAGameSpaceApp()
        }
    }
}

@Composable
fun XAGameSpaceApp(viewModel: MainViewModel = viewModel()) {
    val currentTab by viewModel.currentTab.collectAsState()
    val subScreen by viewModel.subScreen.collectAsState()
    val themeMode by viewModel.prefs.themeMode.collectAsState()
    val accentPreset by viewModel.prefs.accentPreset.collectAsState()
    val language by viewModel.prefs.language.collectAsState()
    val telemetry by viewModel.telemetry.snapshot.collectAsState()
    val gameSessionActive by viewModel.prefs.gameSessionActive.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val addedGames by viewModel.addedGameEntries.collectAsState()
    val allApps by viewModel.allApps.collectAsState()
    val isLoadingApps by viewModel.isLoadingApps.collectAsState()
    val debloatApps by viewModel.debloatApps.collectAsState()
    val isLoadingDebloat by viewModel.isLoadingDebloat.collectAsState()
    val compilingPackages by viewModel.compilingPackages.collectAsState()
    val hudConfig by viewModel.prefs.hudConfig.collectAsState()
    val touchConfig by viewModel.prefs.touchConfig.collectAsState()
    val macroConfig by viewModel.prefs.macroConfig.collectAsState()
    val aiTriggerMasterEnabled by viewModel.prefs.aiTriggerMasterEnabled.collectAsState()
    val aiTriggerRules by viewModel.prefs.aiTriggerRules.collectAsState()
    val burikConfig by viewModel.prefs.burikConfig.collectAsState()
    val fpsLockConfig by viewModel.prefs.fpsLockConfig.collectAsState()
    val fastAnimEnabled by viewModel.prefs.fastAnimationEnabled.collectAsState()
    val useShizuku by viewModel.prefs.useShizuku.collectAsState()
    val useRoot by viewModel.prefs.useRoot.collectAsState()
    val privilegeMode by viewModel.prefs.privilegeMode.collectAsState()
    val restoreAfterSession by viewModel.prefs.restoreAfterSession.collectAsState()
    val compatibilityReport by viewModel.compatibilityReport.collectAsState()
    val angleReport by viewModel.angleRuntimeReport.collectAsState()
    val performanceProfile by viewModel.prefs.performanceProfile.collectAsState()
    val bypassStatus by viewModel.bypassChargingStatus.collectAsState()
    val stopwatchConfig by viewModel.prefs.stopwatchConfig.collectAsState()
    val gyroAimConfig by viewModel.prefs.gyroAimConfig.collectAsState()
    val perGameProfiles by viewModel.prefs.perGameProfiles.collectAsState()
    val thermalConfig by viewModel.prefs.thermalConfig.collectAsState()
    val thermalStatus by viewModel.thermalStatus.collectAsState()
    val touchDriverStatus by viewModel.touchDriverStatus.collectAsState()
    val antiMistouchConfig by viewModel.prefs.antiMistouchConfig.collectAsState()
    val fpsSessionRecords by viewModel.prefs.fpsSessionRecords.collectAsState()
    val maxScreenResponseConfig by viewModel.prefs.maxScreenResponseConfig.collectAsState()
    val screenResponseStatus by viewModel.screenResponseStatus.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    // Request POST_NOTIFICATIONS gracefully on Android 13+ for foreground overlay service
    val context = androidx.compose.ui.platform.LocalContext.current
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Refresh compatibility & Shizuku status whenever user returns from Settings
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshCompatibility()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    XAGameSpaceTheme(themeMode = themeMode, accentPreset = accentPreset) {
        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                if (subScreen != SubScreen.NONE) {
                    when (subScreen) {
                        SubScreen.ADD_GAME -> AddGameScreen(
                            apps = allApps,
                            isLoading = isLoadingApps,
                            getAppIcon = viewModel::getAppIcon,
                            onToggleApp = viewModel::toggleAddedGame,
                            onBack = viewModel::closeSubScreen,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        SubScreen.BURIK -> BurikScreen(
                            config = burikConfig,
                            angleReport = angleReport,
                            addedGames = addedGames,
                            getAppIcon = viewModel::getAppIcon,
                            onSelectPreset = viewModel::selectBurikPreset,
                            onUpdateCustom = viewModel::updateBurikCustom,
                            onApplyAndRestart = viewModel::applyAndRestartGameForBurik,
                            onCheckBurik = viewModel::checkBurikCompatibility,
                            onBack = viewModel::closeSubScreen,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        SubScreen.COMPILE -> CompileScreen(
                            games = addedGames,
                            isLoading = isLoadingApps,
                            compilingPackages = compilingPackages,
                            getAppIcon = viewModel::getAppIcon,
                            onCompileSingle = viewModel::compileSingleGame,
                            onCompileAll = viewModel::compileAllGames,
                            onBack = viewModel::closeSubScreen,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        SubScreen.DEBLOAT -> DebloatScreen(
                            packages = debloatApps,
                            isLoading = isLoadingDebloat,
                            getAppIcon = viewModel::getAppIcon,
                            onActionPackage = viewModel::debloatApp,
                            onRefreshList = viewModel::refreshDebloat,
                            onBack = viewModel::closeSubScreen,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        SubScreen.COMPATIBILITY -> CompatibilityScreen(
                            report = compatibilityReport,
                            privilegeMode = privilegeMode,
                            onSelectPrivilegeMode = viewModel::selectPrivilegeMode,
                            onRefresh = viewModel::refreshCompatibility,
                            onGrantOverlay = viewModel::openOverlayPermissionSettings,
                            onGrantUsageAccess = viewModel::openUsageAccessSettings,
                            onGrantShizuku = viewModel::requestShizukuOrCheck,
                            onGrantRoot = viewModel::requestRootAccess,
                            onGrantWriteSettings = viewModel::openWriteSettings,
                            onGrantDnd = viewModel::openDndSettings,
                            onBack = viewModel::closeSubScreen,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        SubScreen.NONE -> Unit
                    }
                } else {
                    when (currentTab) {
                        MainTab.HOME -> HomeScreen(
                            sessionId = viewModel.prefs.deviceSessionId,
                            telemetry = telemetry,
                            gameSessionActive = gameSessionActive,
                            shizukuStatus = shizukuStatus,
                            privilegeMode = privilegeMode,
                            addedGames = addedGames,
                            getAppIcon = viewModel::getAppIcon,
                            onBoostClick = viewModel::boostNow,
                            onToggleSession = viewModel::toggleGameSession,
                            onGameClick = viewModel::launchGameWithPanel,
                            onAddGameClick = { viewModel.openSubScreen(SubScreen.ADD_GAME) },
                            onOpenDiagnostics = { viewModel.openSubScreen(SubScreen.COMPATIBILITY) },
                            performanceProfile = performanceProfile,
                            bypassStatus = bypassStatus,
                            perGameProfiles = perGameProfiles,
                            onSelectPerformanceProfile = viewModel::selectPerformanceProfile,
                            onToggleBypassCharging = viewModel::toggleBypassCharging,
                            onResetFpsStats = viewModel::resetFpsSessionStats,
                            onSaveGameProfile = viewModel::saveGameProfile,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        MainTab.OPTIMIZER -> OptimizerScreen(
                            sessionId = viewModel.prefs.deviceSessionId,
                            hudConfig = hudConfig,
                            touchConfig = touchConfig,
                            macroConfig = macroConfig,
                            burikConfig = burikConfig,
                            fpsLockConfig = fpsLockConfig,
                            fastAnimEnabled = fastAnimEnabled,
                            onToggleHud = viewModel::togglePerformanceHud,
                            onToggleSensitivity = viewModel::toggleSensitivity,
                            onToggleMacro = viewModel::toggleMacro,
                            onSelectFpsLock = viewModel::selectFpsLock,
                            onOpenBurik = { viewModel.openSubScreen(SubScreen.BURIK) },
                            onOpenCompile = { viewModel.openSubScreen(SubScreen.COMPILE) },
                            onOpenDebloat = { viewModel.openSubScreen(SubScreen.DEBLOAT) },
                            onToggleFastAnim = viewModel::toggleFastAnimation,
                            aiTriggerMasterEnabled = aiTriggerMasterEnabled,
                            aiTriggerRules = aiTriggerRules,
                            onToggleAiTrigger = viewModel::toggleAiTrigger,
                            onOpenAiTriggerPanel = viewModel::openAiTriggerPanel,
                            performanceProfile = performanceProfile,
                            bypassStatus = bypassStatus,
                            stopwatchConfig = stopwatchConfig,
                            gyroAimConfig = gyroAimConfig,
                            hasGyroSensor = viewModel.hasGyroSensor,
                            onSelectPerformanceProfile = viewModel::selectPerformanceProfile,
                            onToggleBypassCharging = viewModel::toggleBypassCharging,
                            onProbeBypassCharging = { viewModel.refreshBypassCharging(silent = false) },
                            onToggleStopwatch = viewModel::toggleStopwatch,
                            onToggleGyroAim = viewModel::toggleGyroAim,
                            onUpdateGyroAimConfig = viewModel::updateGyroAimConfig,
                            thermalConfig = thermalConfig,
                            thermalStatus = thermalStatus,
                            touchDriverStatus = touchDriverStatus,
                            antiMistouchConfig = antiMistouchConfig,
                            fpsSessionRecords = fpsSessionRecords,
                            onSelectThermalProfile = viewModel::selectThermalProfile,
                            onSetThermalMaxLimit = viewModel::setThermalMaxLimit,
                            onProbeThermal = { viewModel.refreshThermalStatus(silent = false) },
                            onOpenThermalPanel = viewModel::openThermalFloatingPanel,
                            onOpenTouchPanel = viewModel::openTouchFloatingPanel,
                            onProbeTouchDriver = { viewModel.refreshTouchDriverStatus(silent = false) },
                            onApplyTouchPreset = viewModel::applyTouchPreset,
                            onToggleAntiMistouch = viewModel::toggleAntiMistouch,
                            onSaveFpsRecord = viewModel::saveCurrentFpsRecord,
                            onClearFpsRecords = viewModel::clearFpsSessionRecords,
                            maxScreenResponseConfig = maxScreenResponseConfig,
                            screenResponseStatus = screenResponseStatus,
                            onToggleMaxScreenResponse = viewModel::toggleMaxScreenResponse,
                            onSelectScreenResponseLevel = viewModel::selectScreenResponseLevel,
                            onUpdateMaxScreenResponseConfig = viewModel::updateMaxScreenResponseConfig,
                            onApplyMaxScreenResponseNow = viewModel::applyMaxScreenResponseNow,
                            onProbeScreenResponse = { viewModel.refreshScreenResponseStatus(silent = false) },
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                        MainTab.PROFILE -> ProfileScreen(
                            sessionId = viewModel.prefs.deviceSessionId,
                            shizukuStatus = shizukuStatus,
                            privilegeMode = privilegeMode,
                            useShizuku = useShizuku,
                            useRoot = useRoot,
                            themeMode = themeMode,
                            accentPreset = accentPreset,
                            language = language,
                            restoreAfterSession = restoreAfterSession,
                            onSelectPrivilegeMode = viewModel::selectPrivilegeMode,
                            onCheckWirelessDebugging = viewModel::openWirelessDebuggingSettings,
                            onToggleUseShizuku = viewModel::toggleUseShizuku,
                            onRequestShizuku = viewModel::requestShizukuOrCheck,
                            onToggleUseRoot = viewModel::toggleUseRoot,
                            onRequestRoot = viewModel::requestRootAccess,
                            onSelectTheme = viewModel::setThemeMode,
                            onSelectAccent = viewModel::setAccentPreset,
                            onSelectLanguage = viewModel::setLanguage,
                            onOpenCompatibility = { viewModel.openSubScreen(SubScreen.COMPATIBILITY) },
                            onToggleRestoreAfterSession = { viewModel.prefs.setRestoreAfterSession(it) },
                            onRestoreNow = viewModel::restoreAllAfterSession,
                            modifier = Modifier.align(Alignment.TopCenter)
                        )
                    }

                    FloatingBottomDock(
                        currentTab = currentTab,
                        onSelectTab = viewModel::selectTab,
                        onAddGameClick = { viewModel.openSubScreen(SubScreen.ADD_GAME) },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }
        }
    }
}
