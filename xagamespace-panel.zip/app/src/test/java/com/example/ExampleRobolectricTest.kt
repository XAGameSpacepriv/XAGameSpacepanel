package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.test.core.app.ApplicationProvider
import com.example.data.BoosterPreferences
import com.example.data.UadDatabase
import com.example.model.BurikConfig
import com.example.model.BurikPreset
import com.example.model.DebloatCategory
import com.example.model.FpsLockConfig
import com.example.model.FpsLockTarget
import com.example.model.HudConfig
import com.example.model.MacroConfig
import com.example.model.MacroPattern
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches XAGameSpacepanel`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("XAGameSpacepanel", appName)
    }

    @Test
    fun `monitor hud is off by default and not always on`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)
        assertFalse(HudConfig().enabled)
        assertFalse(prefs.hudConfig.value.enabled)
    }

    @Test
    fun `uad database classifies telemetry as safe and systemui as unsafe`() {
        val dummyInfo = ApplicationInfo()
        val (telemetryCat, _) = UadDatabase.classify("com.miui.analytics", dummyInfo)
        val (systemCat, _) = UadDatabase.classify("com.android.systemui", dummyInfo)
        assertEquals(DebloatCategory.SAFE, telemetryCat)
        assertEquals(DebloatCategory.UNSAFE, systemCat)
    }

    @Test
    fun `all pro features and ANGLE texture all games are unlocked in preferences`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)
        val defaultBurik = BurikConfig()
        assertTrue(defaultBurik.applyAllGames)

        prefs.updateBurikConfig { it.copy(preset = BurikPreset.RETRO) }
        prefs.updateMacroConfig { it.copy(enabled = true, intervalMs = 16, pattern = MacroPattern.BURST) }
        assertEquals(BurikPreset.RETRO, prefs.burikConfig.value.preset)
        assertEquals(20, prefs.burikConfig.value.effectiveTextureQuality())
        assertEquals(4, prefs.burikConfig.value.effectiveMipmapLevel())
        assertTrue(prefs.macroConfig.value.enabled)
        assertEquals(16, prefs.macroConfig.value.intervalMs)
    }

    @Test
    fun `fps lock 90fps and macro hold lock transparency persist properly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)

        val defaultFps = FpsLockConfig()
        assertEquals(FpsLockTarget.DEFAULT, defaultFps.target)

        prefs.updateFpsLockConfig { it.copy(target = FpsLockTarget.FPS_90) }
        assertEquals(FpsLockTarget.FPS_90, prefs.fpsLockConfig.value.target)
        assertEquals(90, prefs.fpsLockConfig.value.target.fps)

        val defaultMacro = MacroConfig()
        assertTrue(defaultMacro.holdToTrigger)
        assertFalse(defaultMacro.isLocked)
        assertEquals(0.30f, defaultMacro.lockedOpacity, 0.01f)

        prefs.updateMacroConfig {
            it.copy(
                enabled = true,
                isLocked = true,
                holdToTrigger = true,
                lockedOpacity = 0.25f,
                pattern = MacroPattern.QUICK_SWITCH,
                injectionMode = com.example.model.MacroInjectionMode.STYLUS_HYBRID,
                enableTarget2 = true,
                target2NormX = 0.72f,
                target2NormY = 0.34f,
                switchDelayMs = 110
            )
        }
        assertTrue(prefs.macroConfig.value.isLocked)
        assertTrue(prefs.macroConfig.value.holdToTrigger)
        assertEquals(0.25f, prefs.macroConfig.value.lockedOpacity, 0.01f)
        assertEquals(MacroPattern.QUICK_SWITCH, prefs.macroConfig.value.pattern)
        assertEquals(com.example.model.MacroInjectionMode.STYLUS_HYBRID, prefs.macroConfig.value.injectionMode)
        assertTrue(prefs.macroConfig.value.enableTarget2)
        assertEquals(0.72f, prefs.macroConfig.value.target2NormX, 0.01f)
        assertEquals(0.34f, prefs.macroConfig.value.target2NormY, 0.01f)
        assertEquals(110, prefs.macroConfig.value.switchDelayMs)
    }

    @Test
    fun `shizuku user service supports v13 context constructor and kernel slot9 defaults`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val status = com.example.model.ShizukuStatus(
            isRunning = true,
            isPermissionGranted = true,
            isKernelMultiTouch = true,
            activeEngineLabel = "Kernel Slot-9 (10-Jari Hardware)"
        )
        assertTrue(status.canRunPrivileged)
        assertTrue(status.isKernelMultiTouch)

        val ctor = com.example.core.ShizukuInputUserService::class.java.getConstructor(Context::class.java)
        val instance = ctor.newInstance(context)
        assertTrue(instance.pingBinder())
    }

    @Test
    fun `touch config asymmetric X Y gains, DPI estimation, and preferences persist properly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)

        val cfg = com.example.model.TouchConfig(
            enabled = true,
            speedX = 40,
            speedY = 120,
            responseBoost = 80,
            smoothing = 25,
            deadzone = 10,
            dpiBoostEnabled = true,
            liveAimPadEnabled = true,
            aimPadNormX = 0.81f,
            aimPadNormY = 0.42f,
            aimPadLocked = true
        )

        // gainX = 1 + 0.40 + 0.20 = 1.60; gainY = 1 + 1.20 + 0.20 = 2.40
        assertEquals(1.60f, cfg.gainX(), 0.01f)
        assertEquals(2.40f, cfg.gainY(), 0.01f)
        assertTrue(cfg.gainY() > cfg.gainX())

        // Positive X/Y sensitivity reduces target density cleanly (raising smallest-width dp)
        val boostedDpi = cfg.estimatedDensity(440)
        assertTrue(boostedDpi in 240..439)

        prefs.updateTouchConfig { cfg }
        val loaded = prefs.touchConfig.value
        assertTrue(loaded.enabled)
        assertEquals(40, loaded.speedX)
        assertEquals(120, loaded.speedY)
        assertEquals(80, loaded.responseBoost)
        assertTrue(loaded.dpiBoostEnabled)
        assertTrue(loaded.liveAimPadEnabled)
        assertEquals(0.81f, loaded.aimPadNormX, 0.01f)
        assertEquals(0.42f, loaded.aimPadNormY, 0.01f)
        assertTrue(loaded.aimPadLocked)
    }

    @Test
    fun `burik angle texture config and custom parameters persist properly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)

        prefs.updateBurikConfig {
            it.copy(
                preset = BurikPreset.CUSTOM,
                customTextureQualityPercent = 35,
                customMipmapLevel = 3,
                customNearestFiltering = true,
                customDisableAnisotropic = true,
                applyAllGames = true
            )
        }
        val saved = prefs.burikConfig.value
        assertEquals(BurikPreset.CUSTOM, saved.preset)
        assertEquals(35, saved.effectiveTextureQuality())
        assertEquals(3, saved.effectiveMipmapLevel())
        assertTrue(saved.effectiveNearestFiltering())
        assertTrue(saved.effectiveDisableAnisotropic())
        assertTrue(saved.applyAllGames)

        val customFlags = saved.angleFeatureFlags()
        assertTrue(customFlags.contains("enableRenderPassLoadStoreOpNone"))
        assertTrue(customFlags.contains("disableAnisotropicFiltering"))
        assertTrue(customFlags.contains("forceNearestMipFiltering"))
        assertTrue(customFlags.contains("disableFlippingBlockingFence"))
        assertFalse(customFlags.contains("emulateAdvancedBlendEquations"))

        val offFlags = BurikConfig(preset = BurikPreset.OFF).angleFeatureFlags()
        assertTrue(offFlags.isEmpty())

        val softFlags = BurikConfig(preset = BurikPreset.SOFT).angleFeatureFlags()
        assertEquals(listOf("enableRenderPassLoadStoreOpNone", "disableAnisotropicFiltering"), softFlags)
    }

    @Test
    fun `ai trigger matcher detects enemy body, crosshair body contact, and upper head coordinate`() {
        val frameW = 96
        val frameH = 72
        val tplW = 14
        val tplH = 22
        val targetX = 41 // centered horizontally around x=48 (0.50)
        val targetY = 25 // body spans y=25..47, covering crosshair y=36 (0.50)

        val tplPixels = IntArray(tplW * tplH)
        for (y in 0 until tplH) {
            for (x in 0 until tplW) {
                val isHead = x in 4..9 && y in 1..6
                val isTorso = x in 2..11 && y in 7..19
                val r = when {
                    isHead -> 240
                    isTorso -> 200
                    else -> 24
                }
                val g = when {
                    isHead -> 95
                    isTorso -> 175
                    else -> 28
                }
                val b = if (isHead || isTorso) 48 else 32
                tplPixels[y * tplW + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val prepared = com.example.core.AiTriggerMatcher.prepareFromPixels(
            argbPixels = tplPixels,
            width = tplW,
            height = tplH,
            frameRefWidth = frameW,
            frameRefHeight = frameH
        )!!

        // Unpack from padded RGBA buffer (simulating real ImageReader rowStride)
        val pixelStride = 4
        val rowStride = frameW * pixelStride + 16
        val rawRgba = ByteArray(rowStride * frameH)
        for (y in 0 until frameH) {
            for (x in 0 until frameW) {
                val tx = x - targetX
                val ty = y - targetY
                val argb = if (tx in 0 until tplW && ty in 0 until tplH) {
                    tplPixels[ty * tplW + tx]
                } else {
                    (0xFF shl 24) or (20 shl 16) or (25 shl 8) or 30
                }
                val off = y * rowStride + x * pixelStride
                rawRgba[off] = ((argb ushr 16) and 0xFF).toByte()
                rawRgba[off + 1] = ((argb ushr 8) and 0xFF).toByte()
                rawRgba[off + 2] = (argb and 0xFF).toByte()
                rawRgba[off + 3] = 0xFF.toByte()
            }
        }
        val unpackedFrame = com.example.core.AiTriggerMatcher.rgbaBytesToArgbPixels(
            bytes = rawRgba,
            width = frameW,
            height = frameH,
            pixelStride = pixelStride,
            rowStride = rowStride
        )

        val ruleTouching = com.example.model.AiTriggerRule(
            id = "test_head_rule",
            name = "FF Enemy",
            cropLeftNorm = targetX.toFloat() / frameW,
            cropTopNorm = targetY.toFloat() / frameH,
            cropRightNorm = (targetX + tplW).toFloat() / frameW,
            cropBottomNorm = (targetY + tplH).toFloat() / frameH,
            matchPrecision = 82,
            gameCrosshairNormX = 0.50f,
            gameCrosshairNormY = 0.50f,
            headOffsetPercent = 18
        )
        val matchTouch = com.example.core.AiTriggerMatcher.match(unpackedFrame, frameW, frameH, prepared, ruleTouching)
        assertTrue("Enemy body should match (score=${matchTouch.scorePercent})", matchTouch.matched)
        assertTrue("Exact body match score >= 90 (got ${matchTouch.scorePercent})", matchTouch.scorePercent >= 90)
        assertTrue("Crosshair at center should touch enemy body", matchTouch.touchingCrosshair)
        assertTrue(
            "Head Y (${matchTouch.headNormY}) must be strictly above body center Y (${matchTouch.bestBodyNormY})",
            matchTouch.headNormY < matchTouch.bestBodyNormY
        )

        // When crosshair is far away on bottom-right, touchingCrosshair must remain false
        val ruleFarCrosshair = ruleTouching.copy(gameCrosshairNormX = 0.80f, gameCrosshairNormY = 0.80f)
        val matchFar = com.example.core.AiTriggerMatcher.match(unpackedFrame, frameW, frameH, prepared, ruleFarCrosshair)
        assertFalse("Distant crosshair must not report touchingCrosshair", matchFar.touchingCrosshair)

        // Uniform flat wall frame must NOT match
        val blankFrame = IntArray(frameW * frameH) { (0xFF shl 24) or (12 shl 16) or (14 shl 8) or 18 }
        val nonMatch = com.example.core.AiTriggerMatcher.match(blankFrame, frameW, frameH, prepared, ruleTouching)
        assertFalse("Uniform blank frame must not match (score=${nonMatch.scorePercent})", nonMatch.matched)
        assertFalse(nonMatch.touchingCrosshair)
    }

    @Test
    fun `ai trigger head step aims upward toward head and respects deadband and safe anchor`() {
        val (dx, dy) = com.example.core.AiTriggerEngine.computeHeadTriggerStepPx(
            headTargetNormX = 0.505f,
            headTargetNormY = 0.42f,
            crosshairNormX = 0.50f,
            crosshairNormY = 0.50f,
            screenW = 2400,
            screenH = 1080,
            headLiftPower = 110
        )
        assertTrue("dx ($dx) should slightly track right toward head X", dx > 0f)
        assertTrue("dy ($dy) must move upward (< 0) toward enemy head", dy < 0f)

        val (deadX, deadY) = com.example.core.AiTriggerEngine.computeHeadTriggerStepPx(
            headTargetNormX = 0.501f,
            headTargetNormY = 0.501f,
            crosshairNormX = 0.500f,
            crosshairNormY = 0.500f,
            screenW = 1080,
            screenH = 2400,
            headLiftPower = 110
        )
        assertEquals(0f, deadX, 0.001f)
        assertEquals(0f, deadY, 0.001f)

        val rightRule = com.example.model.AiTriggerRule(targetAimNormX = 0.82f, targetAimNormY = 0.68f)
        val (rx, ry) = com.example.core.AiTriggerEngine.resolveCameraDragAnchor(rightRule, 2400, 1080)
        assertEquals(0.82f * 2400f, rx, 1f)
        assertEquals(0.68f * 1080f, ry, 1f)

        val leftRule = com.example.model.AiTriggerRule(targetAimNormX = 0.18f, targetAimNormY = 0.72f)
        val (safeX, safeY) = com.example.core.AiTriggerEngine.resolveCameraDragAnchor(leftRule, 2400, 1080)
        assertEquals(0.76f * 2400f, safeX, 1f)
        assertEquals(0.54f * 1080f, safeY, 1f)
    }

    @Test
    fun `ai trigger rules persist redmagic fields and enforce 5 rule limit`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)
        prefs.aiTriggerRules.value.map { it.id }.forEach { prefs.deleteAiTriggerRule(it) }

        val rule = com.example.model.AiTriggerRule(
            id = "ai_rm_1",
            name = "Free Fire MAX_1",
            enabled = true,
            templatePath = "/tmp/enemy.png",
            cropLeftNorm = 0.42f,
            cropTopNorm = 0.34f,
            cropRightNorm = 0.58f,
            cropBottomNorm = 0.66f,
            templateWidth = 140,
            templateHeight = 220,
            matchPrecision = 86,
            minIntervalMs = 60,
            actionType = com.example.model.AiTriggerActionType.HEAD_LOCK,
            targetAimNormX = 0.84f,
            targetAimNormY = 0.71f,
            gameCrosshairNormX = 0.50f,
            gameCrosshairNormY = 0.49f,
            contactRadiusPercent = 22,
            headOffsetXPercent = 48,
            headOffsetPercent = 16,
            headLiftPower = 125,
            showLiveHud = true
        )
        prefs.upsertAiTriggerRule(rule)
        val loaded = prefs.aiTriggerRules.value.firstOrNull { it.id == "ai_rm_1" }
        assertTrue(loaded != null)
        assertEquals("Free Fire MAX_1", loaded?.name)
        assertEquals(86, loaded?.matchPrecision)
        assertEquals(60, loaded?.minIntervalMs)
        assertEquals(com.example.model.AiTriggerActionType.HEAD_LOCK, loaded?.actionType)
        assertEquals(0.84f, loaded?.targetAimNormX ?: 0f, 0.01f)
        assertEquals(0.71f, loaded?.targetAimNormY ?: 0f, 0.01f)
        assertEquals(0.50f, loaded?.gameCrosshairNormX ?: 0f, 0.01f)
        assertEquals(0.49f, loaded?.gameCrosshairNormY ?: 0f, 0.01f)
        assertEquals(22, loaded?.contactRadiusPercent)
        assertEquals(48, loaded?.headOffsetXPercent)
        assertEquals(16, loaded?.headOffsetPercent)
        assertEquals(125, loaded?.headLiftPower)

        prefs.toggleAiTriggerRule("ai_rm_1", false)
        assertFalse(prefs.aiTriggerRules.value.first { it.id == "ai_rm_1" }.enabled)

        // Verify 5-rule cap matching RedMagic Game Space (5/5)
        for (i in 2..7) {
            prefs.upsertAiTriggerRule(rule.copy(id = "ai_rm_$i", name = "Rule $i"))
        }
        assertEquals(5, prefs.aiTriggerRules.value.size)

        prefs.aiTriggerRules.value.map { it.id }.forEach { prefs.deleteAiTriggerRule(it) }
        assertTrue(prefs.aiTriggerRules.value.isEmpty())

        val (sw, sh) = com.example.core.AiTriggerCaptureManager.computeScaledCaptureSize(2400, 1080)
        assertEquals(960, sw)
        assertEquals(432, sh)
        val (swHi, shHi) = com.example.core.AiTriggerCaptureManager.computeScaledCaptureSize(2400, 1080, 1280)
        assertEquals(1280, swHi)
        assertEquals(576, shHi)
    }

    @Test
    fun `ai trigger matcher detects slender scaled enemy across completely swapped background`() {
        val frameW = 320
        val frameH = 144

        // 1. Crop a slender standing bot against a WARM WOODEN WALL background (20x46 px)
        val cropW = 20
        val cropH = 46
        val cropPixels = IntArray(cropW * cropH)
        for (y in 0 until cropH) {
            for (x in 0 until cropW) {
                val isHead = x in 7..12 && y in 3..11
                val isJacket = x in 5..14 && y in 12..28
                val isPants = (x in 6..8 || x in 11..13) && y in 29..43
                val px = when {
                    isHead -> (0xFF shl 24) or (215 shl 16) or (165 shl 8) or 125
                    isJacket -> (0xFF shl 24) or (26 shl 16) or (28 shl 8) or 34
                    isPants -> (0xFF shl 24) or (34 shl 16) or (36 shl 8) or 42
                    else -> (0xFF shl 24) or (146 shl 16) or (102 shl 8) or 62 // warm wood wall
                }
                cropPixels[y * cropW + x] = px
            }
        }
        val cropBmp = android.graphics.Bitmap.createBitmap(cropPixels, cropW, cropH, android.graphics.Bitmap.Config.ARGB_8888)
        val prepared = com.example.core.AiTriggerMatcher.prepareFromBitmap(
            bitmap = cropBmp,
            cropWidthNorm = cropW.toFloat() / frameW,
            cropHeightNorm = cropH.toFloat() / frameH,
            frameW = frameW,
            frameH = frameH
        )!!
        cropBmp.recycle()

        // 2. Render enemy scaled ~0.75x (15x34) in front of a DARK GRAY PILLAR + GRAY FLOOR background
        fun renderCombatFrame(enemyW: Int, enemyH: Int): IntArray {
            val frame = IntArray(frameW * frameH)
            for (y in 0 until frameH) {
                for (x in 0 until frameW) {
                    frame[y * frameW + x] = when {
                        y > 98 -> (0xFF shl 24) or (145 shl 16) or (146 shl 8) or 148 // gray floor
                        x in 140..176 -> (0xFF shl 24) or (62 shl 16) or (64 shl 8) or 68 // dark gray pillar
                        else -> (0xFF shl 24) or (142 shl 16) or (100 shl 8) or 60 // wooden wall
                    }
                }
            }
            val startX = 160 - enemyW / 2
            val startY = 72 - enemyH / 2
            for (ey in 0 until enemyH) {
                for (ex in 0 until enemyW) {
                    val nx = ex.toFloat() / enemyW
                    val ny = ey.toFloat() / enemyH
                    val isHead = nx in 0.35f..0.65f && ny in 0.06f..0.24f
                    val isJacket = nx in 0.25f..0.75f && ny in 0.25f..0.62f
                    val isPants = (nx in 0.28f..0.44f || nx in 0.54f..0.70f) && ny in 0.63f..0.94f
                    if (isHead || isJacket || isPants) {
                        val c = when {
                            isHead -> (0xFF shl 24) or (215 shl 16) or (165 shl 8) or 125
                            isJacket -> (0xFF shl 24) or (28 shl 16) or (30 shl 8) or 36
                            else -> (0xFF shl 24) or (36 shl 16) or (38 shl 8) or 44
                        }
                        frame[(startY + ey) * frameW + (startX + ex)] = c
                    }
                }
            }
            return frame
        }

        val rule = com.example.model.AiTriggerRule(
            id = "ff_slender_rule",
            cropLeftNorm = 0.46f,
            cropTopNorm = 0.34f,
            cropRightNorm = 0.46f + cropW.toFloat() / frameW,
            cropBottomNorm = 0.34f + cropH.toFloat() / frameH,
            matchPrecision = 82,
            gameCrosshairNormX = 0.50f,
            gameCrosshairNormY = 0.50f,
            headOffsetPercent = 18
        )

        // Scaled down (0.75x distance enemy on dark gray pillar)
        val distantFrame = renderCombatFrame(15, 35)
        val distantMatch = com.example.core.AiTriggerMatcher.match(distantFrame, frameW, frameH, prepared, rule)
        assertTrue(
            "Distant 0.75x slender enemy on swapped pillar background should match (score=${distantMatch.scorePercent})",
            distantMatch.matched
        )
        assertTrue("Crosshair should lock onto distant enemy body", distantMatch.touchingCrosshair)
        assertTrue(distantMatch.headNormY < distantMatch.bestBodyNormY)

        // Scaled up (1.30x closer enemy on dark gray pillar)
        val closeFrame = renderCombatFrame(26, 60)
        val closeMatch = com.example.core.AiTriggerMatcher.match(closeFrame, frameW, frameH, prepared, rule)
        assertTrue(
            "Closer 1.30x slender enemy on swapped pillar background should match (score=${closeMatch.scorePercent})",
            closeMatch.matched
        )
        assertTrue("Crosshair should lock onto closer enemy body", closeMatch.touchingCrosshair)

        // Empty scene (pillar + wood wall + floor with NO enemy) must NOT trigger
        val emptyScene = renderCombatFrame(0, 0)
        val emptyMatch = com.example.core.AiTriggerMatcher.match(emptyScene, frameW, frameH, prepared, rule)
        assertFalse(
            "Empty pillar/wall scene without enemy must not match (score=${emptyMatch.scorePercent})",
            emptyMatch.matched
        )
        assertFalse(emptyMatch.touchingCrosshair)
    }

    @Test
    fun `ai trigger headOffsetXPercent and headOffsetPercent pinpoint custom head alignment accurately`() {
        val frameW = 96
        val frameH = 72
        val tplW = 14
        val tplH = 22
        val targetX = 41
        val targetY = 25

        val tplPixels = IntArray(tplW * tplH)
        for (y in 0 until tplH) {
            for (x in 0 until tplW) {
                val isHead = x in 4..9 && y in 1..6
                val isTorso = x in 2..11 && y in 7..19
                val r = if (isHead) 240 else if (isTorso) 200 else 24
                val g = if (isHead) 95 else if (isTorso) 175 else 28
                val b = if (isHead || isTorso) 48 else 32
                tplPixels[y * tplW + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val prepared = com.example.core.AiTriggerMatcher.prepareFromPixels(
            argbPixels = tplPixels,
            width = tplW,
            height = tplH,
            frameRefWidth = frameW,
            frameRefHeight = frameH
        )!!
        val framePixels = IntArray(frameW * frameH) { (0xFF shl 24) or (20 shl 16) or (25 shl 8) or 30 }
        for (ty in 0 until tplH) {
            for (tx in 0 until tplW) {
                framePixels[(targetY + ty) * frameW + (targetX + tx)] = tplPixels[ty * tplW + tx]
            }
        }

        val leftLeaningRule = com.example.model.AiTriggerRule(
            id = "head_align_left",
            cropLeftNorm = targetX.toFloat() / frameW,
            cropTopNorm = targetY.toFloat() / frameH,
            cropRightNorm = (targetX + tplW).toFloat() / frameW,
            cropBottomNorm = (targetY + tplH).toFloat() / frameH,
            matchPrecision = 82,
            headOffsetXPercent = 30,
            headOffsetPercent = 14
        )
        val rightLeaningRule = leftLeaningRule.copy(
            id = "head_align_right",
            headOffsetXPercent = 72,
            headOffsetPercent = 38
        )

        val resLeft = com.example.core.AiTriggerMatcher.match(framePixels, frameW, frameH, prepared, leftLeaningRule)
        val resRight = com.example.core.AiTriggerMatcher.match(framePixels, frameW, frameH, prepared, rightLeaningRule)

        assertTrue(resLeft.matched)
        assertTrue(resRight.matched)
        assertTrue(
            "headOffsetXPercent=30 (${resLeft.headNormX}) must be left of headOffsetXPercent=72 (${resRight.headNormX})",
            resLeft.headNormX < resRight.headNormX
        )
        assertTrue(
            "headOffsetPercent=14 (${resLeft.headNormY}) must be higher than headOffsetPercent=38 (${resRight.headNormY})",
            resLeft.headNormY < resRight.headNormY
        )
        val expectedLeftX = resLeft.bestLeftNorm + (resLeft.bestRightNorm - resLeft.bestLeftNorm) * 0.30f
        val expectedRightY = resRight.bestTopNorm + (resRight.bestBottomNorm - resRight.bestTopNorm) * 0.38f
        assertEquals(expectedLeftX, resLeft.headNormX, 0.005f)
        assertEquals(expectedRightY, resRight.headNormY, 0.005f)
    }

    @Test
    fun `ai trigger matches real Free Fire enemy across frames and ignores HUD medkit`() {
        val shot1File = listOf(
            java.io.File("public/assets/aistudio/Screenshot_20261115-212201_7e8f8b50.png"),
            java.io.File("../public/assets/aistudio/Screenshot_20261115-212201_7e8f8b50.png")
        ).firstOrNull { it.exists() }
        val shot2File = listOf(
            java.io.File("public/assets/aistudio/Screenshot_20261115-214745_e9cc7eb5.png"),
            java.io.File("../public/assets/aistudio/Screenshot_20261115-214745_e9cc7eb5.png")
        ).firstOrNull { it.exists() }
        if (shot1File == null || shot2File == null) return

        val raw1 = android.graphics.BitmapFactory.decodeFile(shot1File.absolutePath)!!
        val raw2 = android.graphics.BitmapFactory.decodeFile(shot2File.absolutePath)!!
        val (capW, capH) = com.example.core.AiTriggerCaptureManager.computeScaledCaptureSize(raw1.width, raw1.height)
        val frame1 = android.graphics.Bitmap.createScaledBitmap(raw1, capW, capH, true)
        val frame2 = android.graphics.Bitmap.createScaledBitmap(raw2, capW, capH, true)
        raw1.recycle()
        raw2.recycle()

        // Realistic finger crop of standing Free Fire Enemy #1 in shot 1
        val cropLeftNorm = 0.508f
        val cropTopNorm = 0.470f
        val cropRightNorm = 0.544f
        val cropBottomNorm = 0.622f
        val cx = (cropLeftNorm * capW).toInt()
        val cy = (cropTopNorm * capH).toInt()
        val cw = ((cropRightNorm - cropLeftNorm) * capW).toInt().coerceAtLeast(8)
        val ch = ((cropBottomNorm - cropTopNorm) * capH).toInt().coerceAtLeast(12)
        val cropBmp = android.graphics.Bitmap.createBitmap(frame1, cx, cy, cw, ch)

        val prepared = com.example.core.AiTriggerMatcher.prepareFromBitmap(
            bitmap = cropBmp,
            cropWidthNorm = cropRightNorm - cropLeftNorm,
            cropHeightNorm = cropBottomNorm - cropTopNorm,
            frameW = capW,
            frameH = capH
        )!!
        cropBmp.recycle()
        frame1.recycle()

        val frame2Pixels = IntArray(capW * capH)
        frame2.getPixels(frame2Pixels, 0, capW, 0, 0, capW, capH)
        frame2.recycle()

        val rule = com.example.model.AiTriggerRule(
            id = "real_ff_shot_rule",
            name = "FF Real Bot",
            cropLeftNorm = cropLeftNorm,
            cropTopNorm = cropTopNorm,
            cropRightNorm = cropRightNorm,
            cropBottomNorm = cropBottomNorm,
            matchPrecision = 82,
            gameCrosshairNormX = 0.50f,
            gameCrosshairNormY = 0.50f,
            headOffsetPercent = 18,
            autoTriggerAllZones = true
        )

        val result = com.example.core.AiTriggerMatcher.match(frame2Pixels, capW, capH, prepared, rule)
        assertTrue(
            "Real Free Fire enemy in shot 2 must match cleanly (got score=${result.scorePercent}, pos=(${result.bestBodyNormX}, ${result.bestBodyNormY}))",
            result.matched
        )
        assertTrue(
            "Matched body X (${result.bestBodyNormX}) should lock onto Enemy #1 (~0.50..0.57), NOT HUD Medkit (>0.65)",
            result.bestBodyNormX in 0.49f..0.57f
        )
        assertTrue(
            "Matched body Y (${result.bestBodyNormY}) should lock onto Enemy #1 (~0.47..0.63), NOT top HUD",
            result.bestBodyNormY in 0.46f..0.64f
        )
        assertTrue("Head target Y (${result.headNormY}) must be above body center Y", result.headNormY < result.bestBodyNormY)
    }

    @Test
    fun `legacy ai trigger rules upgrade cleanly to HEAD_LOCK with default head alignment`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val rawPrefs = context.getSharedPreferences("xa_booster_prefs", Context.MODE_PRIVATE)
        val legacyJson = """[{"id":"legacy_1","name":"Old Rule","enabled":true,"templatePath":"/tmp/t.png","actionType":"STICKY_FIRE_AIM"}]"""
        rawPrefs.edit().putString("ai_trigger_rules_json", legacyJson).commit()

        val migrated = BoosterPreferences.getInstance(context)
        assertTrue(migrated.aiTriggerRules.value.isNotEmpty() || rawPrefs.contains("ai_trigger_rules_json"))
        rawPrefs.edit().remove("ai_trigger_rules_json").commit()
    }

    @Test
    fun `projection service invalid tokens, non-visual display metrics, and notif drawable do not crash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Monochrome notification vector icon resolves cleanly (not an adaptive mipmap XML)
        val iconDrawable = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_notif_ai)
        assertTrue("Notification vector icon ic_notif_ai must resolve cleanly", iconDrawable != null)

        // 2. DisplayManager-based queryDisplayMetrics must work on non-visual ApplicationContext at SDK 36
        val (w, h, dpi) = com.example.core.AiTriggerCaptureManager.queryDisplayMetrics(context)
        assertTrue("Screen width ($w) must be positive", w > 0)
        assertTrue("Screen height ($h) must be positive", h > 0)
        assertTrue("DPI ($dpi) must be in valid range", dpi in 120..640)

        // 3. Starting AiTriggerProjectionService with missing/invalid token must NOT throw and returns START_NOT_STICKY
        val controller = org.robolectric.Robolectric.buildService(com.example.service.AiTriggerProjectionService::class.java)
        val service = controller.create().get()
        val badIntent = android.content.Intent(context, com.example.service.AiTriggerProjectionService::class.java).apply {
            action = com.example.service.AiTriggerProjectionService.ACTION_START
        }
        val startResult = service.onStartCommand(badIntent, 0, 1)
        assertEquals(android.app.Service.START_NOT_STICKY, startResult)
        assertFalse(com.example.service.AiTriggerProjectionService.isRunning)
        assertFalse(com.example.core.AiTriggerEngine.runtimeState.value.lastError.isNullOrBlank())

        // 4. Clearing capture error restores clean runtime state
        com.example.core.AiTriggerEngine.clearCaptureError()
        assertEquals(null, com.example.core.AiTriggerEngine.runtimeState.value.lastError)
        controller.destroy()
    }

    @Test
    fun `nubia touch engine preference persists and device detector works cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = BoosterPreferences.getInstance(context)

        assertTrue(com.example.model.TouchConfig().nubiaGameTweakEnabled)
        prefs.updateTouchConfig { it.copy(enabled = true, nubiaGameTweakEnabled = false) }
        assertFalse(prefs.touchConfig.value.nubiaGameTweakEnabled)
        prefs.updateTouchConfig { it.copy(nubiaGameTweakEnabled = true) }
        assertTrue(prefs.touchConfig.value.nubiaGameTweakEnabled)

        assertTrue(com.example.core.SystemOptimizer.isNubiaOrRedMagicDevice("nubia", "nubia", "NX729J"))
        assertTrue(com.example.core.SystemOptimizer.isNubiaOrRedMagicDevice("ZTE", "REDMAGIC", "RedMagic 9 Pro"))
        assertFalse(com.example.core.SystemOptimizer.isNubiaOrRedMagicDevice("Samsung", "samsung", "SM-S928B"))

        // requestImmediateFrame must be callable safely without throwing when no session is active
        com.example.core.AiTriggerCaptureManager.requestImmediateFrame()
    }
}
